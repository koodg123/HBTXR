# Prompt Operations

## Prompt Pack Fields

- Skill: `hw-nonlinear-approximation`
- Objective: one sentence (approximate which nonlinear op, remove which FP unit).
- Context: operator spec, input range/distribution, bit-width, datapath context, MODULE_GUIDE refs.
- Constraints: scope, tools, precision budget, non-goals.
- Required output: exact artifact type (approximation-method plan / LUT sizing table / accuracy-impact note).
- Verification: evidence needed (file:line, bit-exact sim, end-task accuracy).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (range/distribution/bit-width) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when operator, input range/distribution, bit-width, or acceptance criteria are missing and the missing fact would change the method or LUT sizing. Never fabricate end-task accuracy or synthesis PPA.
