# REF Corpus Context — HW Nonlinear Approximation (softmax/GELU/LayerNorm/exp/div/sqrt)

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW, §9 S-PyTorch). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) and a 1차 요약 `<repo>.md`.

## Core References (route to these MODULE_GUIDEs)

1. **함수별 비교표 / ★레퍼런스**: `ViT-Quantization/mixed-non-linear-quantization/MODULE_GUIDE.md` — I-ViT / I-BERT / FQ-ViT의 softmax·GELU·LayerNorm을 함수별로 직접 비교(시프트 vs 다항 vs Log-Int). **시프트 근사(barrel shifter) vs 다항식(제곱기) 자원·정확도 트레이드오프** 의사결정표의 1차 출처.
2. **정수·시프트 전용 (I-ViT)**: `ViT-Quantization/I-ViT/MODULE_GUIDE.md` — ShiftGELU, Shiftmax, 정수 LayerNorm(뉴턴법 rsqrt), dyadic requant. 곱셈기·부동소수 없이 softmax/GELU/LayerNorm 구현 직접 레퍼런스.
3. **Log-Int-Softmax + PTF (FQ-ViT)**: `ViT-Quantization/FQ-ViT/MODULE_GUIDE.md` — Log-Int-Softmax(log2=shift), LayerNorm Power-of-Two Factor. 정수 전용 softmax/LayerNorm.
4. **다항 vs 시프트 (integer-only-transformer)**: `ViT-Quantization/integer-only-transformer/MODULE_GUIDE.md` — I-BERT 계열 GELU/Softmax/LayerNorm 정수 다항 근사. 시프트 대비 다항(제곱기) 비용 비교 대상.
5. **곱셈기 없는 exp**: `ViT-Accelerator/AURA-FlashAttention-AISC-Accelerator/MODULE_GUIDE.md` — ExpMul(1.4375x 근사 + 배럴시프트), 곱셈기 0, 1-pass online softmax, 트리리덕션. exp을 곱셈기 없이 만드는 직접 레퍼런스.
6. **LUT exp 보간**: `ViT-Accelerator/hls-fpga-accelerators/MODULE_GUIDE.md` — unary exp 32-pt LUT 보간, 데이터타입·버스폭 파라미터화. LUT 엔트리/비트폭/인덱싱 사이징 레퍼런스.
7. **log2=shift (AHCPTQ)**: `ViT-Quantization/AHCPTQ/MODULE_GUIDE.md` — 하드웨어 친화 PTQ, log2=시프트 인덱싱.

(전체 목록·정량 요약은 `INDEX.md` §8/§9 표 참조.)

## 방법 선택 규약 (정량 도출, 정적)
- **시프트 근사(barrel shifter)**: exp/2^x를 비트시프트+소량 보정으로 — 곱셈기 0, LUT 최소; 정확도는 근사 차수에 종속.
- **다항식(제곱기·Horner)**: 차수 d → 곱셈기 d개; 정확도↑·자원↑.
- **LUT**: 엔트리 = 입력 범위/스텝, 폭 = 출력 비트; index = MSB 추출/affine 매핑. 메모리 = entries × bit. 분포 편중 시 히스토그램 기반 fine/coarse 분할.
- **output quantizer 융합**: 비선형 출력 양자화기를 다음 matmul의 입력 양자화기와 합쳐 별도 스케일 유닛 제거.
- 정확도 영향(end-task)은 README/논문 인용 시만 기재, 없으면 "확인 필요". 합성 PPA도 리포트 동봉 시만 인용.

## Reusable Verification Questions
- 어떤 비선형 연산인가(softmax/GELU/LayerNorm/exp/reciprocal/rsqrt)?
- 입력 범위·분포와 비트폭은? (LUT 엔트리/인덱싱 결정)
- 시프트 근사 vs 다항 vs LUT 중 자원/정확도 목표는?
- output quantizer를 다음 matmul 입력 양자화기와 융합 가능한가?
- 검증 가능한 최소 단위(대표 입력 벡터/1 레이어)와 1차 지표(근사오차 vs end-task accuracy)는?

## Why This Skill Is Relevant
REF 코퍼스의 정수전용·HW 비선형 구현체(I-ViT/FQ-ViT/integer-only-transformer/AURA/hls-fpga-accelerators/AHCPTQ)가 softmax/GELU/LayerNorm/exp을 시프트·다항·LUT로 반복적으로 근사하며, file:line 근거로 방법 선택과 LUT 사이징을 뒷받침한다.
