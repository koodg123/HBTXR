# Production Playbook

## Purpose

This playbook supports `hw-nonlinear-approximation` for LUT/shift/polynomial approximation of transformer nonlinear operators (softmax/GELU/LayerNorm/exp/reciprocal/rsqrt). It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: which nonlinear op to approximate and why (remove FP exp/div/sqrt, shrink area/latency).
- Inputs: operator spec, input range/distribution, bit-width, datapath context (preceding/following matmul), MODULE_GUIDE references.
- Output format: approximation-method plan, LUT sizing table, or accuracy-impact note.
- Success metrics: approximation error vs FP, area (LUT/FF/DSP), latency, end-task accuracy.
- Constraints: tool availability, precision budget, non-goals, validation limits.

## Decision Flow

- Capture operator, input range/distribution, bit-width, datapath context.
- Choose the approximation family: LUT + affine indexing, bit-shift (barrel shifter), or polynomial (squarer/Horner).
- Read the matching REF MODULE_GUIDE(s); extract the function-by-function method with file:line.
- Size cost statically: LUT entries × bit-width (range/precision), index/MSB extraction, shift count, polynomial degree/multipliers; fuse output quantizer with next matmul input quantizer.
- Return artifacts linking the approximation method, LUT/precision sizing, and accuracy impact.

## Tradeoff Questions

- Shift approximation (barrel shifter, 곱셈기 0) vs polynomial (squarer, 차수 d → 곱셈기 d) vs LUT (memory = entries × bit) — which fits the resource/accuracy target?
- Which assumption (LUT entry count vs tail error, shift degree, accuracy at low bit) most likely invalidates the artifact?
- Can the output quantizer fuse into the next matmul's input quantizer to drop a scale unit?
- What is the smallest change validatable by bit-exact sim or end-task accuracy eval now?
- Which existing skill (`hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, `fpga-transformer-accelerator-kb`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need sim/eval), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
