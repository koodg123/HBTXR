# Prompt Template

Use `$hw-nonlinear-approximation` to handle the following task.

Objective:

Inputs (operator / input range+distribution / bit-width / datapath context / MODULE_GUIDE refs):

Constraints:

Required artifact (approximation-method plan / LUT sizing table / accuracy-impact note):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / bit-exact sim / end-task accuracy):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
