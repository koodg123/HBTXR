# Intake Prompt Bundle

Use `$hw-nonlinear-approximation` for this request.

1. Normalize the request into a measurable HW objective (which nonlinear op, target error vs FP, area/latency saved by removing exp/div/sqrt).
2. Identify source artifacts (operator spec, input range/distribution, bit-width, datapath context) and missing inputs.
3. Select required supporting skills (`hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, `fpga-transformer-accelerator-kb`) and the matching REF MODULE_GUIDE.
4. Produce the first usable artifact (approximation-method plan / LUT sizing table / accuracy-impact note).
5. Define the verification gate (file:line + bit-exact sim / end-task accuracy) and residual risks.
