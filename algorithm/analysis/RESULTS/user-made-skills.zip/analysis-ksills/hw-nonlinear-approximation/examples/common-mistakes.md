# Common Mistakes

- Producing general approximation advice without a prompt pack or a concrete artifact.
- Quoting accuracy/area numbers without file:line evidence, or citing end-task accuracy that does not exist in the repo (should be "확인 필요").
- Mixing approximation error with area/latency claims.
- Choosing a method (shift vs polynomial vs LUT) without stating the resource/accuracy tradeoff or the input range/distribution it assumes.
- Sizing a LUT without deriving entries/bit-width/indexing from the operator range and precision.
- Forgetting to fuse the output quantizer with the next matmul's input quantizer (leaving a redundant scale unit).
- Forgetting to route into the relevant REF MODULE_GUIDE before inventing a new approximation.
- Recommending an irreversible choice (too-small LUT, aggressive shift) with no validation (bit-exact sim, end-task accuracy) path.
