# Good Output Example

## Prompt Pack

Skill: `hw-nonlinear-approximation`
Objective: HW화 softmax via **Log-Int-Softmax** (remove FP exp/div), with LUT size, shift count, and accuracy validated.
Inputs: operator (softmax), attention-score range/distribution, bit-width (e.g., INT8/INT16), datapath context (after QKᵀ, before ×V).
Constraints: state target error vs FP, area/latency budget, and scope limits.
Verification: define the evidence (file:line, bit-exact sim, end-task accuracy) required for signoff.

## Artifact

Structured decisions with **MODULE_GUIDE line evidence**, e.g.:
- Method: Log-Int-Softmax — exp via log2=shift instead of FP exp/div (cite `…/FQ-ViT/MODULE_GUIDE.md`); contrast shift (barrel shifter) vs polynomial (squarer) cost (cite `…/mixed-non-linear-quantization/MODULE_GUIDE.md`).
- LUT sizing: entries = input range/step, width = output bits, index = MSB extraction / affine map; histogram fine/coarse split if distribution is skewed (cite `…/hls-fpga-accelerators/MODULE_GUIDE.md` for 32-pt exp LUT).
- Quantizer fusion: fold the softmax output quantizer into the ×V matmul input quantizer (removes a separate scale unit).
- Tradeoffs and the smallest change validatable by bit-exact sim first.

## Risks

List uncertain assumptions (e.g., LUT entry count vs tail error, shift-approx degree, accuracy at low bit) and the next experiment (bit-exact sim, end-task accuracy eval) to resolve each. End-task accuracy = "확인 필요" unless README/paper reports it.
