---
name: hw-nonlinear-approximation
description: "FPGA/ASIC 트랜스포머 비선형 연산을 LUT·비트시프트·다항으로 근사해 FP exp/div/sqrt 유닛을 제거하는 설계 기법. Log-Int-Softmax, ShiftGELU/Shiftmax, 곱셈기 없는 exp, 정수 LayerNorm(뉴턴 rsqrt), LUT 크기·정밀도·히스토그램 분할, output quantizer 융합. Use whenever removing FP exp/div/sqrt from a datapath, LUT-ifying/shift-approximating a nonlinear op, or sizing a nonlinear LUT — even without naming the operator."
---

# Hardware Nonlinear Approximation

## Overview

Use this skill to **approximate transformer nonlinear operators (softmax/GELU/LayerNorm/exp/reciprocal/rsqrt) in hardware** via LUT, bit-shift, and polynomial methods so the datapath no longer needs floating-point exp/div/sqrt units. Build transparent, decision-ready artifacts grounded in the analyzed REF corpus (function-by-function integer/shift/LUT references) rather than free-form advice.

This skill complements `hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, and `fpga-transformer-accelerator-kb`. It should produce reusable artifacts (approximation plan, LUT sizing table, accuracy-impact note) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable HW objective (which nonlinear op, target error vs FP, area/latency saved by removing exp/div/sqrt).
2. List source artifacts (operator spec, input range/distribution, bit-width, datapath context) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (approximation-method plan vs LUT sizing table vs accuracy-impact note).

## Workflow

1. Capture the operator (softmax/GELU/LayerNorm/exp/reciprocal/rsqrt), input range/distribution, bit-width, and the datapath it feeds.
2. Choose the approximation family: LUT + affine indexing, bit-shift (barrel shifter), or polynomial (squarer/Horner) — per the resource/accuracy tradeoff.
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md` and extract the function-by-function method with file:line evidence.
4. Size with measurable cost: LUT entries × bit-width, index/MSB extraction, shift count, polynomial degree/multipliers; fuse the output quantizer with the next matmul's input quantizer.
5. Return artifacts connecting the approximation method, LUT/precision sizing, and accuracy impact; flag what needs simulation or end-task eval to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (approximation-method plan / LUT sizing table / accuracy-impact note) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (bit-exact sim, end-task accuracy eval).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis nonlinear-approximation MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/approximation error is separated from area/latency claims.
- Operator, input range/distribution, and bit-width are explicit before choosing a method.
- The approximation family (LUT vs shift vs polynomial) is chosen against a stated resource/accuracy tradeoff.
- LUT sizing (entries × bit-width, indexing) is derived from the operator range/precision; the output quantizer is fused with the next matmul input quantizer where possible.
- Accuracy impact is cited from README/paper if present, else marked "확인 필요"; never invent end-task numbers.
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (operator spec, input range/distribution, bit-width, datapath context) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on end-task accuracy, bit-exact simulation, or unavailable tools.
- A recommendation would lock the user into a method (e.g., a too-small LUT or aggressive shift) without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, the method comparison conventions, and known-limitation flags. The project baseline accelerator is **HG-PIPE** (전계층 온칩, LUT 비선형); approximation choices should stay consistent with its on-chip nonlinear datapath.
