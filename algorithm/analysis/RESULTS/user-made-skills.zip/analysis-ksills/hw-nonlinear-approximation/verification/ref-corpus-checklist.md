# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s).
- [ ] Applied this skill to the relevant nonlinear operator (softmax / GELU / LayerNorm / exp / reciprocal / rsqrt).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE (method, LUT size, shift/poly degree).
- [ ] Kept the method-comparison convention (shift = barrel shifter / 곱셈기 0; polynomial = squarer; LUT = entries × bit) with the resource/accuracy tradeoff stated.
- [ ] Used `mixed-non-linear-quantization` as the function-by-function comparison reference (I-ViT / I-BERT / FQ-ViT).
- [ ] Marked end-task accuracy as "확인 필요" unless README/paper reports it; no fabricated synthesis PPA.
- [ ] Noted output-quantizer fusion with the next matmul input quantizer where applicable.
- [ ] Produced a concrete artifact + validation evidence, and stated HG-PIPE on-chip nonlinear relevance where applicable.
