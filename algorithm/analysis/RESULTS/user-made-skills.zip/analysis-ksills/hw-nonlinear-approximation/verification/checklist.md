# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: hw-nonlinear-approximation` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable HW objective (operator, target error, unit removed).
- [ ] Source artifacts (operator/range/distribution/bit-width/datapath), assumptions, and constraints are separated.
- [ ] Required supporting skills and the matching REF MODULE_GUIDE are named.
- [ ] The approximation family (LUT vs bit-shift vs polynomial) is chosen against a stated resource/accuracy tradeoff.
- [ ] LUT sizing (entries × bit-width, indexing) is derived from operator range/precision; output quantizer fused with next matmul input quantizer where possible.
- [ ] Approximation error is separated from area/latency; end-task accuracy is cited from README/paper else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (bit-exact sim / end-task accuracy) are explicit.
- [ ] Residual risks and next validation steps are listed.
