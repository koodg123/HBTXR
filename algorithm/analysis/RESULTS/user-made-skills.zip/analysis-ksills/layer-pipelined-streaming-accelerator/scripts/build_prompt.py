#!/usr/bin/env python3
"""Build a prompt pack for layer-pipelined-streaming-accelerator."""

import argparse


def main():
    parser = argparse.ArgumentParser(description="Build a reusable prompt pack.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--inputs", default="")
    parser.add_argument("--constraints", default="")
    parser.add_argument("--artifact", default="layer-partition / II-balance / FIFO+on-chip budget")
    parser.add_argument("--verification", default="file:line evidence + synthesis PPA + per-layer latency sim")
    args = parser.parse_args()

    print("Skill: layer-pipelined-streaming-accelerator")
    print(f"Objective: {args.objective}")
    print(f"Inputs: {args.inputs}")
    print(f"Constraints: {args.constraints}")
    print(f"Required artifact: {args.artifact}")
    print(f"Verification evidence: {args.verification}")


if __name__ == "__main__":
    main()
