# Production Playbook

## Purpose

This playbook supports `layer-pipelined-streaming-accelerator` for designing fully-pipelined, all-on-chip, layer-streaming DNN/Transformer accelerators. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to design (layer partition, II balance, FIFO/on-chip budget, layer-chain glue) for which model.
- Inputs: model layer graph (per-layer ops/shapes/seq/depth/heads), datatype/quantization, target board + clock, source RTL/HLS, reference refs.
- Output format: layer-partition plan, II-balance table, FIFO+on-chip budget, or layer-chain design.
- Success metrics: FPS/throughput, per-stage II, latency (avg + p95/p99), on-chip budget fit, area (LUT/FF/DSP/BRAM/URAM), energy.
- Constraints: on-chip capacity, tool availability, board fit, non-goals, validation limits.

## Decision Flow

- Capture device, model layer graph, datatype, clock, runtime contract.
- Choose partition granularity: layer-per-kernel chain (max throughput, all-on-chip) vs time-multiplexed single engine (resource reuse). Identify design entry: HLS kernels + RTL/SpinalHDL glue vs pure HLS DATAFLOW.
- Read the matching REF reference(s); extract layer-pipeline / FIFO / II-balance / on-chip-residency patterns with file:line.
- Balance statically: per-stage II + bottleneck stage (slowest layer), FIFO depth/payload (incl. deep residual/skip buffers), backpressure/handshake (ap_ctrl_chain daisy-chain), on-chip budget = Σ(weights + LUT + intermediate/residual FIFO).
- Return artifacts linking layer partition, II balance, FIFO/on-chip budget, and validation metrics.

## Tradeoff Questions

- Which mapping would be costly to reverse (all-on-chip residency vs HBM streaming, layer-per-kernel vs time-multiplexed)?
- Which stage is the bottleneck, and which assumption (achievable Fmax, FIFO depth, on-chip fit) most likely invalidates the artifact?
- Does the total on-chip budget (all weights + tensors resident) exceed the device? If so, hand off to `composable-hls-multi-slr-scaling`.
- What is the smallest change validatable by synthesis or per-layer latency sim now?
- Which existing skill (`fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`, `hgpipe-porting-advisor`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need synthesis), assumptions, risks, and the next validation step (synthesis PPA + per-layer latency sim). Keep it structured enough for another Worker to use directly.
