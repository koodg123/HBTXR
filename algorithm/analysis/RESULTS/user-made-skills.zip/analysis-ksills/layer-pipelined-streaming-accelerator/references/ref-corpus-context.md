# REF Corpus Context — Layer-Pipelined Streaming Accelerators

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW). 1차 요약은 `<repo>.md`, deep MODULE_GUIDE는 존재 시 `<repo>/MODULE_GUIDE.md`.

설계 도메인: **전계층 온칩 파이프라인** = 레이어를 각각 독립 커널로 합성(layer-per-kernel) + FIFO/핸드셰이크로 데이지체인 + 전 가중치 온칩 상주의 스트리밍 가속기. layer-단위 coarse + layer-내부 dataflow fine의 2계층 파이프라인.

## Routing (read these references)

1. **★레퍼런스 — HG-PIPE**: `Transformer-Accel/HG-PIPE.md` (1차 분석) + `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md` (이식·확장).
   - 26 레이어(PatchEmbed + ATTN×12 + MLP×12 + Head)를 각각 **독립 HLS 커널**로 합성, **SpinalHDL `BlockSequence`가 FIFO + ap_ctrl_chain 핸드셰이크로 26블록 데이지체인** (`HG-PIPE.md` §3.13, §4.1).
   - **전 레이어 가중치·중간 텐서 온칩 상주**(외부 DRAM 가중치 스트리밍 없음, §4.2), **레이어 내부 `#pragma HLS dataflow` II=1** (§3.2, §4.1).
   - 2계층: fine = 레이어 내부 dataflow(LN/matmul/quant/softmax/gelu 프로세스 FIFO 직결), coarse = 레이어 간 매크로 파이프라인(전 레이어가 동시에 다른 이미지/토큰 처리, §4.1).
2. **ESDA / SEE (이벤트 sparse layer-pipeline dataflow)**: `CNN-Accel/ESDA`, `CNN-Accel/SEE`.
   - 이벤트 sparse CNN을 레이어별 dataflow로 스트리밍. sparse token+mask로 dense 파이프라인과 다른 메모리 패턴(`HG-PIPE_PORTING_ROADMAP.md` §3.1 ESDA 매핑성 ★낮음 — sparse dataflow는 dense 파이프라인과 패러다임 상이). SEE는 ZCU102 PYNQ 지연 + INA226 18레일 전력 동시측정 하네스(로드맵 B5).
3. **dac_sdc UltraNet 계열 (전계층 DATAFLOW)**: `CNN-Accel/dac_sdc_2022_champion` 등.
   - 전 레이어를 하나의 HLS `DATAFLOW`로 직결한 layer-pipeline CNN(저비트). 단일 die 전계층 스트리밍의 CNN 사례.
4. **Edge-MoE (단일 커널 dataflow — 대조군)**: `Transformer-Accel/Edge-MoE`.
   - 레이어를 **시분할 단일 엔진**으로 재사용(layer-per-kernel과 대비되는 축). dense-MLP/top-2 MoE, expert prefetch. layer-per-kernel vs time-multiplexed 트레이드오프의 반대편 사례.

(전체 목록·정량 요약은 `INDEX.md` §8 표 참조.)

## 핵심 설계 축 (정성+정적 정량)
- **layer-per-kernel vs 시분할 단일엔진**: 전계층 독립 커널 체인(HG-PIPE/UltraNet) = 최고 throughput·저지연, 단 전 가중치 온칩 상주 필요 → 모델 크기 제약. 시분할 단일엔진(Edge-MoE) = 자원 재사용, 단 throughput↓·가중치 재로드.
- **FIFO depth·payload**: 레이어 간 FIFO 깊이/폭. residual/skip은 블록을 우회하므로 **깊은 FIFO 필요**(HG-PIPE `mlp.h` `resi_sm depth=512`, 잔차 URAM 깊이 ≈12288, `HG-PIPE.md` §3.11, §4.2). depth는 자동 탐색 가능(`constants.py` 후보 테이블).
- **스테이지 II 균형**: 전체 throughput ≈ 1 / (가장 느린 레이어 지연). **병목 스테이지**(HG-PIPE ATTN ≈57625 cycle, `HG-PIPE.md` §4.1)를 찾아 병렬도(TP/CIP/COP)로 II/지연을 맞춤. 한 스테이지만 느리면 전체 처리량이 그에 묶임.
- **온칩 메모리 예산 (전 가중치 상주 한계 = 모델 크기 제약)**: 가중치(BRAM/LUTRAM/URAM) + LUT 비선형 + 중간텐서/잔차 FIFO가 모두 온칩. 합 > 디바이스 용량이면 layer-pipeline 불가 → 모델 축소 또는 `composable-hls-multi-slr-scaling` 핸드오프.
- **백프레셔·핸드셰이크**: FIFO full/empty 백프레셔 + ap_ctrl_chain(ap_start/ready/done) 데이지체인으로 블록 간 연속 호출(HG-PIPE `Manager.scala`/`ApChain`, `HG-PIPE.md` §3.13). 각 블록이 독립 handshake로 pipelined 호출.
- **coarse+fine 2계층**: coarse(레이어 간 FIFO 체인) + fine(레이어 내부 dataflow II=1). 두 계층을 분리해 균형.

## 수치 규약 (정량 도출, 정적)
- per-stage II / 스테이지 지연 = 레이어 내부 루프 trips × II · FIFO depth = 배열/스트림 깊이(엔트리) · payload bit = 스트림 폭 · 온칩 예산 = Σ(가중치 배열 깊이×bit + LUT + 중간/잔차 FIFO 깊이×폭). 합성 PPA(LUT/DSP/BRAM/URAM/Fmax)와 실측 지연·FPS는 리포트/측정 동봉 시만 인용, 없으면 "확인 필요".

## Reusable Verification Questions
- 타깃 디바이스·클럭·런타임 계약은? 전 가중치 온칩 상주가 자원에 들어가는가?
- 파티션 입도: layer-per-kernel 체인인가 시분할 단일엔진인가?
- 병목 스테이지(가장 느린 레이어)와 그 II/지연은? 다른 스테이지와 균형이 맞는가?
- 레이어 간 FIFO depth/payload, residual/skip 우회 버퍼 깊이는?
- 백프레셔·핸드셰이크(ap_ctrl_chain/데이지체인) 결선은?
- 1차 지표는 FPS/throughput·latency·on-chip budget·area·power 중 무엇?

## Handoff
- 모델이 온칩 예산을 초과(더 큰 ViT/긴 시퀀스/LLM)하면 **`composable-hls-multi-slr-scaling`**(TAPA/RapidStream 멀티-SLR/HBM)로 핸드오프. 단일 die 전계층 상주 고집은 합성 실패 리스크.
- HG-PIPE 기준선의 효율/이식 단계는 `hgpipe-porting-advisor` 및 `HG-PIPE_PORTING_ROADMAP.md` 참조.

## Why This Skill Is Relevant
HG-PIPE(★)는 전계층 온칩 + 레이어-per-커널 FIFO 체인 + 2계층 파이프라인의 정준 사례이며, ESDA/SEE/UltraNet/Edge-MoE가 sparse·CNN·시분할 대조축을 제공한다. file:line 근거로 II 균형·FIFO 설계·온칩 예산 의사결정을 뒷받침한다. 합성 PPA·Fmax는 본 분석 환경 미실행이므로 "확인 필요".
