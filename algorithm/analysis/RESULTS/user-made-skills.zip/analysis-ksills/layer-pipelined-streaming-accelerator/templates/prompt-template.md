# Prompt Template

Use `$layer-pipelined-streaming-accelerator` to handle the following task.

Objective:

Inputs (model layer graph / datatype / board+clock / source RTL or HLS / reference refs):

Constraints (on-chip capacity, scope, target platform, non-goals):

Required artifact (layer-partition plan / II-balance table / FIFO+on-chip budget / layer-chain design):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / synthesis PPA / per-layer latency sim / bit-exact C-sim):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
