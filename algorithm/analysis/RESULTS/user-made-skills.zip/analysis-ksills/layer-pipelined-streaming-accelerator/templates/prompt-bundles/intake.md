# Intake Prompt Bundle

Use `$layer-pipelined-streaming-accelerator` for this request.

1. Normalize the request into a measurable HW objective (FPS/throughput / per-stage II / latency / on-chip budget / area / power).
2. Identify source artifacts (model layer graph, board+clock, datatype, RTL/HLS) and missing inputs.
3. Choose partition granularity (layer-per-kernel chain vs time-multiplexed single engine) and select supporting skills (`fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`, `hgpipe-porting-advisor`) and the matching REF reference.
4. Produce the first usable artifact (layer-partition plan / II-balance table / FIFO+on-chip budget).
5. Define the verification gate (file:line + synthesis PPA + per-layer latency sim), residual risks, and whether on-chip residency forces a handoff to `composable-hls-multi-slr-scaling`.
