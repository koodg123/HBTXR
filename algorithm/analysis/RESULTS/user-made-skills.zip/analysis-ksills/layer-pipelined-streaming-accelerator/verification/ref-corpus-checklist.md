# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching reference(s) (HG-PIPE ★ via `Transformer-Accel/HG-PIPE.md` + `HG-PIPE_PORTING_ROADMAP.md`; ESDA/SEE/UltraNet/Edge-MoE as needed).
- [ ] Applied this skill to the relevant axis (layer-per-kernel chain / II balance / FIFO design / on-chip budget / partition granularity).
- [ ] Preserved source-linked (file:line) evidence from the reference (e.g., HG-PIPE §3.13 SpinalHDL FIFO chain, §4.1 bottleneck ATTN ≈57625 cycle, §3.11 deep residual FIFO).
- [ ] Kept the quantitative convention (per-stage II / FIFO depth / payload bit / on-chip budget; synthesis PPA·Fmax·FPS = "확인 필요" if no report/measurement).
- [ ] Carried over known-limitation flags (all-on-chip residency = model-size ceiling, DeiT-Tiny 특수화, H=3 hardcode, 합성시점 가중치 상수화, sparse vs dense paradigm mismatch).
- [ ] Produced a concrete artifact + validation evidence, stated HG-PIPE relevance / porting link, and flagged any handoff to `composable-hls-multi-slr-scaling` when residency exceeds the device.
