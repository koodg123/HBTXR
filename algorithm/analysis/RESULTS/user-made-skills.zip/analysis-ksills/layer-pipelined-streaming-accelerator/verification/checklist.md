# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: layer-pipelined-streaming-accelerator` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable HW objective.
- [ ] Source artifacts (model layer graph / board / clock / datatype / on-chip capacity), assumptions, and constraints are separated.
- [ ] Partition granularity (layer-per-kernel vs time-multiplexed) is stated; required supporting skills and the matching REF reference are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] The bottleneck stage (slowest layer) and per-stage II are identified; FIFO depth/payload and the on-chip budget (weights+LUT+intermediate/residual) carry file:line evidence.
- [ ] Synthesis PPA / Fmax / measured FPS are cited only if a report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (synthesis / per-layer latency sim / bit-exact C-sim) are explicit.
- [ ] If all-resident weights+tensors exceed the device, the handoff to `composable-hls-multi-slr-scaling` is noted.
- [ ] Residual risks and next validation steps are listed.
