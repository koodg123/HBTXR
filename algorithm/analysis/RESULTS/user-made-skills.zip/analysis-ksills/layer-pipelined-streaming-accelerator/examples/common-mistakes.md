# Common Mistakes

- Producing general layer-pipeline advice without a prompt pack or a concrete artifact (partition / II-balance / FIFO+budget).
- Not identifying the bottleneck stage (slowest layer) — throughput ≈ 1 / (slowest-layer latency), so unbalanced stages waste the whole pipeline.
- Claiming all-on-chip residency without budgeting it: Σ(weights + LUT + intermediate/residual FIFO) must fit the device, and exceeding it should trigger a `composable-hls-multi-slr-scaling` handoff, not a forced single-die pipeline.
- Forgetting that residual/skip FIFOs bypass the whole block and need deep buffers (shallow residual FIFO stalls the pipeline).
- Quoting FPS/throughput/area without file:line evidence, or citing synthesis PPA / Fmax / measured FPS that does not exist (should be "확인 필요").
- Mixing functional correctness with per-stage II and on-chip resource claims.
- Choosing layer-per-kernel vs time-multiplexed single engine without stating the throughput/resource consequence.
- Omitting backpressure/handshake (ap_ctrl_chain daisy-chain) so blocks cannot be continuously pipelined.
- Forgetting to route into the relevant REF reference (HG-PIPE ★) before inventing a new layer-chain.
- Recommending an irreversible partition with no validation (synthesis, per-layer latency sim, bit-exact C-sim) path.
