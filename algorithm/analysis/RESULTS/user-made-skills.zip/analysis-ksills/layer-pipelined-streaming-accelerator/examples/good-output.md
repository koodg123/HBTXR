# Good Output Example

## Prompt Pack

Skill: `layer-pipelined-streaming-accelerator`
Objective: Design a 12-block ViT (DeiT-Tiny class) as a fully-pipelined, all-on-chip, layer-streaming accelerator.
Inputs: layer graph (PatchEmbed + ATTN×12 + MLP×12 + Head), 3-bit weights + per-tensor INT8~15, target board+clock, source HLS kernels (if any).
Constraints: all weights+tensors must fit on-chip; state tool, target, and scope limits.
Verification: define the evidence (file:line, synthesis PPA, per-layer latency sim) required for signoff.

## Artifact — "ViT 12 blocks as a layer-pipeline"

Structured decisions with **reference line evidence** (route via `references/ref-corpus-context.md`):

- **Layer partition (coarse)**: 26 independent kernels (PatchEmbed + ATTN×12 + MLP×12 + Head), each its own HLS kernel; chain them with FIFO + ap_ctrl_chain handshake (HG-PIPE `BlockSequence` style, `HG-PIPE.md` §3.13). Granularity choice: layer-per-kernel (max throughput, all-on-chip) over time-multiplexed single engine (Edge-MoE style) because target = high FPS / low latency.
- **Intra-layer dataflow (fine)**: each kernel is one `#pragma HLS dataflow` (LN→matmul→quant→softmax/gelu) at II=1 (`HG-PIPE.md` §3.2, §4.1). 2-level = coarse FIFO chain + fine dataflow.
- **II balance**: throughput ≈ 1 image / (slowest-layer latency). Identify the bottleneck stage — ATTN ≈ 57625 cycle is the slowest in HG-PIPE (`HG-PIPE.md` §4.1). Tune ATTN parallelism (TP/CIP/COP) up so its II/latency matches MLP; raising MLP parallelism would not help while ATTN dominates.
- **FIFO depth/payload**: inter-layer FIFO width = stream bit-width (per-layer 8~15 bit, power-of-two aligned). **Residual/skip FIFOs must be deep** because residual bypasses the whole block (HG-PIPE `mlp.h` `resi_sm depth=512`; residual URAM depth ≈12288, `HG-PIPE.md` §3.11, §4.2). Depth can be auto-searched (candidate table).
- **On-chip budget (model-size ceiling)**: budget = Σ(weight arrays×bit + LUT nonlinear + intermediate/residual FIFO). All weights resident → no external DRAM streaming (`HG-PIPE.md` §4.2). Check Σ ≤ device capacity; if a larger ViT/longer sequence overflows, hand off to `composable-hls-multi-slr-scaling`.
- **Backpressure/handshake**: FIFO full/empty backpressure + ap_ctrl_chain daisy-chain (ap_start/ready/done) for continuous pipelined block calls (`HG-PIPE.md` §3.13).
- Tradeoffs and the smallest change validatable by synthesis + per-layer latency sim first.

## Risks

List uncertain assumptions (achievable Fmax, FIFO depth sufficiency, whether all-resident weights fit, accuracy at 3-bit) and the next experiment (synthesis/PPA, per-layer latency sim, bit-exact C-sim via HG-PIPE `check_stream`) to resolve each. If residency exceeds the device, note the `composable-hls-multi-slr-scaling` handoff.
