---
name: layer-pipelined-streaming-accelerator
description: "전 레이어를 독립 커널로 합성해 FIFO/핸드셰이크로 잇는 layer-pipelined 스트리밍 가속기 설계 기법(레이어 단위 coarse + 레이어 내부 dataflow fine의 2계층 파이프라인). 전 가중치 온칩 상주, II 균형, 데이지체인, 백프레셔. HG-PIPE/ESDA/UltraNet 스타일. Use whenever designing a fully-pipelined, all-on-chip, layer-streaming DNN/transformer accelerator, balancing per-stage II, or chaining layer kernels."
---

# Layer-Pipelined Streaming Accelerator

## Overview

Use this skill to design a **fully-pipelined, all-on-chip, layer-streaming** DNN/Transformer accelerator: synthesize each layer as an independent kernel and chain them with FIFO + handshake into a **2-level pipeline** (per-layer coarse grain + intra-layer dataflow fine grain). Build transparent, decision-ready design artifacts grounded in the analyzed REF corpus (HG-PIPE/ESDA/UltraNet style) rather than free-form advice.

This skill complements `fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`, `composable-hls-multi-slr-scaling`, and `hgpipe-porting-advisor`. It should produce reusable artifacts (layer-partition plan, II-balance table, FIFO/on-chip budget) backed by concrete reference evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable HW objective (FPS/throughput, per-stage II, latency, on-chip budget, area, power).
2. List source artifacts (model layer graph, datatype/quantization, board, clock) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from reference line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (layer-partition plan vs II-balance table vs FIFO/on-chip budget).

## Workflow

1. Capture target device, model layer graph (per-layer ops/shapes/seq/depth), datatype/quantization, clock, and runtime contract.
2. Decide the partition granularity: layer-per-kernel chain vs time-multiplexed single engine, and the design entry (HLS C++ kernels + RTL/SpinalHDL glue, or pure HLS DATAFLOW).
3. Read the relevant REF reference(s) via `references/ref-corpus-context.md` and extract layer-pipeline / FIFO / II-balance / on-chip-residency patterns with file:line evidence.
4. Balance the pipeline: per-stage II, bottleneck stage, FIFO depth/payload, residual/skip buffers, backpressure/handshake, and the on-chip weight+tensor budget (= model-size ceiling).
5. Return artifacts connecting layer partition, II balance, FIFO/on-chip budget, and validation metrics; flag what needs synthesis to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (layer-partition plan / II-balance table / FIFO+on-chip budget / layer-chain design) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually synthesis/PPA + per-layer latency sim).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis layer-pipeline references (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Functional correctness is separated from per-stage throughput (II) and on-chip resource claims.
- Partition granularity (layer-per-kernel vs time-multiplexed), datatype/quantization, and per-layer shapes are explicit.
- Backend/board assumptions are named before II-balance or budget claims.
- Per-stage II and the bottleneck stage are identified; FIFO depth/payload and the on-chip weight+tensor budget (model-size ceiling) are derived from code (unroll/shape/depth) with file:line; synthesis PPA/Fmax is cited only if a report exists, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (layer graph, datatype, board/clock) or constraints are missing.
- Multiple plausible interpretations (layer-per-kernel vs single engine) would materially change the artifact.
- The result depends on synthesis PPA/Fmax, board measurements, or unavailable tools.
- The model exceeds the on-chip budget — hand off to `composable-hls-multi-slr-scaling` instead of forcing a brittle single-die pipeline.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the reference line-evidence, quantitative conventions, and known-limitation flags. The reference layer-pipeline baseline is **HG-PIPE** (`Transformer-Accel/HG-PIPE.md` + `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`); when the model outgrows on-chip residency, hand off to `composable-hls-multi-slr-scaling`.
