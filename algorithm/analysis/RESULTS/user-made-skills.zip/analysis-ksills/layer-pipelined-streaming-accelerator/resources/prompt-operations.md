# Prompt Operations

## Prompt Pack Fields

- Skill: `layer-pipelined-streaming-accelerator`
- Objective: one sentence (partition / II-balance / FIFO+budget / layer-chain design).
- Context: model layer graph, datatype, target board+clock, source RTL/HLS, reference refs.
- Constraints: on-chip capacity, scope, tools, target platform, non-goals.
- Required output: exact artifact type (layer-partition plan / II-balance table / FIFO+on-chip budget / layer-chain design).
- Verification: evidence needed (file:line, synthesis PPA, per-layer latency sim, bit-exact C-sim).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml` (pipeline-balance / on-chip-memory / layer-partition reviewers).
3. Revise when reviewers find missing constraints (board/clock/datatype/on-chip capacity) or weak evidence (no bottleneck-stage identification, unbudgeted residency).
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when device/clock, model layer graph, datatype, or on-chip capacity are missing and the missing fact would change the partition/II/budget. If all-resident weights+tensors exceed the device, hand off to `composable-hls-multi-slr-scaling`. Never fabricate synthesis PPA, Fmax, or measured FPS.
