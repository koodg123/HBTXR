# Production Playbook

## Purpose

This playbook supports `flash-attention-hardware` for designing FlashAttention/online-softmax attention datapaths (QKᵀ → softmax → ×V) on FPGA/ASIC. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to design (online-softmax update, fused-MHA datapath, buffer/tile budget, dynamic-weight replay).
- Inputs: model shape (seq N, head dim d, heads H), datatype/bit-width, target board + clock, source RTL/HLS, MODULE_GUIDE references; causal vs full, prefill vs decode.
- Output format: online-softmax update plan, fused-MHA datapath plan, buffer/tile budget table, or attention-core MODULE_GUIDE.
- Success metrics: latency (avg + p95/p99), throughput/II, area (LUT/FF/DSP/BRAM/URAM), energy, softmax accuracy (bit-exact or bounded error).
- Constraints: tool availability, board fit, non-goals, validation limits.

## Decision Flow

- Capture model shape, datatype, clock, runtime contract.
- Choose softmax pass strategy: 1-pass online (running max `m`, running sum `ℓ`, rescale partial ×V) vs 2-/3-pass baseline — justify by buffer/latency.
- Read the matching REF attention MODULE_GUIDE(s); extract the online-softmax recurrence, exp approximation, and score-buffer policy with file:line.
- Plan the fused datapath: QKᵀ (INT8 GEMM, int32 accum) → online softmax (multiplier-free exp + rescale) → ×V; ensure the score matrix is never fully materialized.
- Size tiles, line buffers, reduction-tree depth, and running-statistics registers; compute cost statically.
- Return artifacts linking the update recurrence, the exp/rescale datapath, memory/buffer budget, and validation metrics.

## Tradeoff Questions

- Which choice is costly to reverse (score-resident vs streaming, 1-pass online vs 3-pass, INT8-only vs full integer softmax)?
- Which assumption (exp approximation error, INT8 softmax-precision split, Fmax, score-block BRAM fit) most likely invalidates the artifact?
- What is the smallest change validatable by synthesis or a bit-exact softmax match now?
- Which existing skill (`fpga-transformer-accelerator-kb`, `hw-nonlinear-approximation`, `transformer-accel-microarch`, `vit-llm-quantization-kb`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need synthesis), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
