# REF Corpus Context — FlashAttention / Online-Softmax Attention Datapath

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§3.3 Attention/Softmax HW화, §8 HW, §9.4 attention HW화 의사결정). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량).

## Core Routing (open these MODULE_GUIDEs)

1. **★ Reference attention core — 1-pass online softmax**: `ViT-Accelerator/AURA-FlashAttention-AISC-Accelerator/MODULE_GUIDE.md` (INT8 + multiplier-free exp "ExpMul" + 1-pass online softmax running max/sum + 64→1 tree reduction 3-stage, 256 MAC = 4PE×64, Synopsys DC ASIC). This is the canonical online-softmax datapath to imitate.
2. **INT8 fused-MHA quantization (GEMM-only INT8, softmax precision separate)**: `ViT-Quantization/int-flashattention/MODULE_GUIDE.md`, `ViT-Quantization/qflash/MODULE_GUIDE.md`, `ViT-Quantization/INT8-Flash-Attention-FMHA-Quantization/MODULE_GUIDE.md` — all keep **QKᵀ/×V GEMM in INT8 but softmax in FP**; full integer attention needs an integer softmax (IntSoftmax) fused in.
3. **Streaming softmax single-datapath (FPGA HLS)**: `Transformer-Accel/ViT-Accelerator-on-FPGA-with-INT8-quantization/MODULE_GUIDE.md` (DeiT-Tiny INT8, streaming softmax, GELU 177-LUT, 256 MAC 16×16, weight-reload bottleneck).
4. **Contrast baseline (dynamic matmul + 3-pass softmax)**: HG-PIPE `attn.h` (dynamic-weight matmul + 3-pass softmax) — the score-resident / multi-pass design the online-softmax core is meant to replace. Porting/extension context: `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.

(전체 attention/softmax 목록은 `INDEX.md` §3.3 / §9.4 참조.)

## 핵심 설계 기법 (이 스킬이 사상하는 것)

- **online-softmax 갱신식**: running max `m`, running sum `ℓ`, partial ×V accumulator `O`. 새 score 블록마다 `m' = max(m, m_blk)`, `O ← O·exp(m − m')`, `ℓ ← ℓ·exp(m − m') + Σ exp(s − m')`. 2-pass(max-pass + exp/normalize-pass) / 3-pass softmax를 회피.
- **곱셈기 없는 exp**: exp를 시프트/LUT(또는 ExpMul형)로 근사 → rescale/normalize 경로에 FP 곱셈기 0개.
- **score 행렬 미머티리얼라이즈**: N×N score를 전부 온칩에 두지 않고 현재 블록 + 러닝 통계만 유지 → 버퍼 절감.
- **INT8 GEMM + softmax 정밀 분리**: QKᵀ·×V는 INT8(int32 누산), softmax는 별도 정밀. **완전정수 attention은 IntSoftmax 결합 필요**(int-flashattention/qflash/INT8-FMHA는 GEMM만 INT8).
- **타일/버퍼 설계**: K/V 타일 치수, line buffer bit, reduction-tree 깊이(log2 단), head별 러닝-통계 레지스터.
- **dynamic-weight replay**: 동적 가중치(QKᵀ의 K, ×V의 V) 재투입/리플레이 스케줄링.

## 수치 규약 (정량 도출, 정적)
- MAC lanes = unroll/병렬도 차원 곱 · scalar MACs = shape 곱 · loop trips = 타일 곱 · memory = 배열 깊이×bit · reduction-tree 깊이 = log2(폭). exp-unit 수 = 병렬 score lane 수. 합성 PPA(LUT/DSP/BRAM/Fmax)는 리포트 동봉 시만 인용, 없으면 "확인 필요".

## Reusable Verification Questions
- 모델 shape(seq N·head dim d·heads H)와 데이터타입/비트폭은? causal/full, prefill/decode?
- softmax pass 전략은 1-pass online인가 2-/3-pass인가, 그 버퍼/지연 결과는?
- exp 근사는 무엇이며(시프트/LUT/ExpMul) FP 곱셈기를 남기는가?
- score 행렬을 미머티리얼라이즈하는가, 러닝-통계 레지스터/타일 치수는?
- INT8 GEMM과 softmax 정밀의 분리(또는 완전정수 IntSoftmax)는?
- 검증 가능한 최소 단위(1 head/1 score 블록의 bit-exact softmax 매치)는?

## Why This Skill Is Relevant
REF 코퍼스의 attention HW화(AURA 1-pass + ExpMul, streaming-softmax HLS, INT8 fused-MHA 양자화 3종)가 online-softmax 갱신식·곱셈기-free exp·score 버퍼 회피·INT8/softmax 정밀 분리를 file:line 근거로 반복 제공한다. 합성 PPA 미동봉 시 "확인 필요".
