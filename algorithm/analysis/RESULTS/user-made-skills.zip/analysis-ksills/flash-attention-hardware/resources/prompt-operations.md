# Prompt Operations

## Prompt Pack Fields

- Skill: `flash-attention-hardware`
- Objective: one sentence (design online-softmax update / fused-MHA datapath / buffer-tile budget / dynamic-weight replay).
- Context: model shape (seq N, head dim d, heads H), datatype/bit-width, target board+clock, source RTL/HLS, MODULE_GUIDE refs; causal vs full, prefill vs decode.
- Constraints: scope, tools, target platform, non-goals.
- Required output: exact artifact type (online-softmax update plan / fused-MHA datapath / buffer-tile budget / attention-core MODULE_GUIDE).
- Verification: evidence needed (file:line, synthesis PPA, bit-exact softmax match).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml` (online-softmax-reviewer / datapath-streaming-reviewer / int-fmha-reviewer).
3. Revise when reviewers find missing constraints (shape/datatype/board/clock, pass strategy, score residency) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when model shape, datatype, pass strategy (1-pass vs 3-pass), or acceptance criteria are missing and the missing fact would change the datapath/cost. Never fabricate synthesis PPA, and never claim full integer attention when softmax is actually FP.
