# Good Output Example

## Prompt Pack

Skill: `flash-attention-hardware`
Objective: Design a 1-pass online-softmax MHA core (QKᵀ → softmax → ×V) with INT8 GEMM and a multiplier-free exp, validated against a bit-exact reference.
Inputs: model shape (seq N, head dim d, heads H), datatype/bit-width, target board+clock, source RTL/HLS (if any).
Constraints: state tool, data, target, scope; causal vs full; prefill vs decode.
Verification: define the evidence (file:line, synthesis PPA, bit-exact softmax match) required for signoff.

## Artifact

A 1-pass online-softmax MHA core with **MODULE_GUIDE line evidence**, e.g.:
- Online-softmax recurrence: keep running max `m`, running sum `ℓ`, and a rescaled partial accumulator `O`; on each new score block update `m' = max(m, m_blk)`, rescale `O ← O·exp(m − m')`, `ℓ ← ℓ·exp(m − m') + Σexp(s − m')` (cite AURA `…/MODULE_GUIDE.md`). Score matrix is never fully materialized — only the current block + running stats live on-chip.
- exp datapath: multiplier-free exp (shift/LUT or ExpMul-style) so the rescale/normalize path carries no FP multiplier (route to `hw-nonlinear-approximation`).
- INT8 GEMM split: QKᵀ and ×V in INT8 with int32 accumulation; softmax kept at higher precision unless a full integer softmax (IntSoftmax) is fused — state which.
- Buffer/tile budget: K/V tile dims, line-buffer bits, reduction-tree depth (e.g., 64→1 in log2 stages), running-statistics registers per head.
- Tradeoffs and the smallest change that synthesis or a bit-exact softmax match can validate first.

## Risks

List uncertain assumptions (exp approximation error vs end-task accuracy, INT8 softmax-precision split, achievable Fmax, score-block tile fit in BRAM) and the next experiment (synthesis/PPA, bit-exact C-sim against PyTorch softmax) to resolve each.
