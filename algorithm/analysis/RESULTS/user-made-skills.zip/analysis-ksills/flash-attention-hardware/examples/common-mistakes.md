# Common Mistakes

- Producing general attention advice without a prompt pack or a concrete online-softmax / fused-MHA artifact.
- Materializing the full N×N score matrix on-chip when a 1-pass online-softmax keeps only the current block plus running max/sum (defeats the whole point).
- Using a 2-/3-pass softmax (separate max-pass, exp-pass, normalize-pass) without stating the buffer/latency cost vs the 1-pass online update.
- Leaving an FP multiplier/divider in the exp or rescale path when a multiplier-free exp (shift/LUT/ExpMul-style) is the reference technique.
- Claiming "INT8 attention" while keeping softmax in FP — pure INT8 GEMM with FP softmax is partial; full integer attention requires fusing an integer softmax (IntSoftmax).
- Quoting throughput/area numbers without file:line evidence, or citing synthesis PPA that does not exist in the repo (should be "확인 필요").
- Mixing softmax numerical correctness (running max/sum/rescale stability) with performance and resource claims.
- Forgetting to route into the relevant REF attention MODULE_GUIDE before inventing a new datapath.
- Recommending a score-resident or dynamic-weight-replay design with no validation (synthesis, bit-exact softmax match) path.
