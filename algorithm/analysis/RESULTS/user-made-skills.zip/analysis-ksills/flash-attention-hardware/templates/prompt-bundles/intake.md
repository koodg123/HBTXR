# Intake Prompt Bundle

Use `$flash-attention-hardware` for this request.

1. Normalize the request into a measurable attention-datapath objective (latency/throughput/area/power/softmax accuracy of the MHA core).
2. Identify source artifacts (model shape seq/dim/heads, datatype/bit-width, board+clock, RTL/HLS) and missing inputs; note causal/full and prefill/decode.
3. Select required supporting skills (`fpga-transformer-accelerator-kb`, `hw-nonlinear-approximation`, `transformer-accel-microarch`, `vit-llm-quantization-kb`) and the matching REF attention MODULE_GUIDE (AURA / INT8-Flash / streaming-softmax).
4. Decide the softmax pass strategy (1-pass online vs 2-/3-pass) and produce the first usable artifact (online-softmax update plan / fused-MHA datapath / buffer-tile budget).
5. Define the verification gate (file:line + synthesis PPA + bit-exact softmax match) and residual risks.
