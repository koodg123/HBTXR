# Prompt Template

Use `$flash-attention-hardware` to handle the following task.

Objective:

Inputs (model shape: seq N / head dim d / heads H · datatype/bit-width · board+clock · source RTL or HLS · MODULE_GUIDE refs · causal/full · prefill/decode):

Constraints:

Required artifact (online-softmax update plan / fused-MHA datapath / buffer-tile budget / attention-core MODULE_GUIDE):

Softmax pass strategy (1-pass online vs 2-/3-pass) and exp approximation (shift/LUT/ExpMul):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / synthesis PPA / bit-exact softmax match):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
