---
name: flash-attention-hardware
description: "FlashAttention/online-softmax 어텐션을 FPGA/ASIC 데이터패스로 설계하는 기법. 1-pass running max/sum(2-pass softmax 회피), 곱셈기 없는 exp, INT8 fused MHA(QKᵀ→softmax→×V) 스트리밍, score 행렬 미머티리얼라이즈·타일/버퍼 설계, dynamic-weight replay. EN: a design-technique skill for FlashAttention/online-softmax attention datapaths on FPGA/ASIC — 1-pass running max/sum (avoid 2-pass softmax), multiplier-free exp, INT8 fused MHA (QKᵀ→softmax→×V) streaming, score-matrix never materialized, tile/buffer design, dynamic-weight replay. Routes into REF/Analysis attention MODULE_GUIDEs (AURA / INT8-Flash / streaming-softmax). Use whenever designing an attention/MHA hardware datapath, an online-softmax core, or an INT8 fused attention accelerator — even without naming FlashAttention."
---

# FlashAttention Hardware (Online-Softmax Attention Datapath Design)

## Overview

Use this skill to **design FlashAttention/online-softmax attention datapaths in hardware (FPGA/ASIC)**. It turns the attention math (QKᵀ → softmax → ×V) into a streaming, score-never-materialized datapath: 1-pass running max/sum, multiplier-free exp, INT8 fused MHA, and tile/buffer sizing — grounded in the analyzed REF corpus (attention MODULE_GUIDEs), not free-form advice.

This skill complements `fpga-transformer-accelerator-kb`, `hw-nonlinear-approximation`, `transformer-accel-microarch`, and `vit-llm-quantization-kb`. It should produce reusable artifacts (online-softmax update plan, fused-MHA datapath plan, buffer/tile budget) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable attention-datapath objective (latency/throughput/area/accuracy of the MHA core).
2. List source artifacts (model: seq/dim/heads, datatype/bit-width, board+clock, source RTL/HLS) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (online-softmax update plan vs fused-MHA datapath vs buffer/tile budget).

## Workflow

1. Capture model shape (seq N, head dim d, heads H), datatype/bit-width, clock, and the runtime contract (prefill vs decode, causal vs full).
2. Decide the softmax pass strategy: 1-pass online (running max m, running sum ℓ, rescale of partial ×V) vs the 2-/3-pass baseline; justify by buffer/latency cost.
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md`; extract the online-softmax update recurrence, exp approximation, and score-buffer policy with file:line evidence.
4. Plan the fused datapath: QKᵀ (INT8 GEMM) → online softmax (exp + rescale) → ×V, with score matrix never fully materialized; size tiles, line buffers, and the running-statistics registers.
5. Return artifacts connecting the update recurrence, the exp/rescale datapath, the tile/buffer budget, and the validation metrics; flag what needs synthesis (PPA) or bit-exact C-sim to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (online-softmax update plan / fused-MHA datapath / buffer-tile budget) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually synthesis/PPA, bit-exact softmax match).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis attention MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Functional correctness of softmax (running max/sum/rescale, numerical stability) is separated from performance and resource claims.
- Datatype/bit-width and the INT8-GEMM-vs-softmax-precision split are explicit (full integer needs an integer softmax; pure INT8 GEMM with FP softmax is partial).
- Pass strategy (1-pass online vs 2-/3-pass) is named with its buffer/latency consequence.
- Cost numbers (MAC lanes, exp-unit count, reduction-tree depth, score-buffer bits) are derived from code (unroll/shape) with file:line; synthesis PPA is cited only if a report exists, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (model shape, datatype, board/clock) or constraints are missing.
- Multiple plausible interpretations would materially change the datapath (causal vs full, prefill vs decode, score residency).
- The result depends on synthesis PPA, board measurements, or unavailable tools.
- A recommendation would lock the user into a score-resident or 3-pass design without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. The reference attention core is **AURA-FlashAttention** (1-pass online softmax + multiplier-free ExpMul + tree reduction); the project baseline contrast is HG-PIPE `attn.h` (dynamic matmul + 3-pass softmax).
