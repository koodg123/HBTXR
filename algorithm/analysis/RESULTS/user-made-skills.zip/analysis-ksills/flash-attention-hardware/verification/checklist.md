# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: flash-attention-hardware` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable attention-datapath objective.
- [ ] Source artifacts (model shape/datatype/board/clock, causal-full, prefill-decode), assumptions, and constraints are separated.
- [ ] Required supporting skills and the matching REF attention MODULE_GUIDE (AURA / INT8-Flash / streaming-softmax) are named.
- [ ] The softmax pass strategy (1-pass online vs 2-/3-pass) is stated with its buffer/latency consequence.
- [ ] The online-softmax recurrence (running max/sum, partial ×V rescale) and exp approximation (multiplier-free) are explicit and numerically justified.
- [ ] The score matrix is confirmed non-materialized (current block + running stats only), with tile/line-buffer/reduction-tree sizing.
- [ ] The INT8 GEMM / softmax-precision split is explicit (full integer attention flagged as requiring a fused IntSoftmax).
- [ ] Cost numbers (MAC lanes/exp-unit count/reduction-tree depth/score-buffer bits) carry file:line evidence; synthesis PPA is cited only if a report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (synthesis / bit-exact softmax match) are explicit.
- [ ] Residual risks and next validation steps are listed.
