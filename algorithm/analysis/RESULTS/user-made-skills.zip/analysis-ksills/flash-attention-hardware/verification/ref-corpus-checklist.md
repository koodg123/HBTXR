# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s) (AURA-FlashAttention / int-flashattention / qflash / INT8-FMHA / ViT-Accelerator-on-FPGA-INT8 streaming softmax).
- [ ] Applied this skill to the relevant attention pattern (1-pass online softmax / INT8 fused-MHA / streaming softmax), with HG-PIPE `attn.h` (3-pass) as the contrast baseline.
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE (online-softmax recurrence, ExpMul/exp approximation, tree-reduction depth, score-buffer policy).
- [ ] Kept the quantitative convention (MAC lanes/scalar MACs/loop trips/memory/reduction-tree depth/exp-unit count; synthesis PPA = "확인 필요" if no report).
- [ ] Carried over known-limitation flags (e.g., int-flashattention/qflash/INT8-FMHA keep softmax in FP → not full integer; AURA is ASIC Synopsys DC; weight-reload bottleneck in the streaming-softmax HLS core).
- [ ] Produced a concrete artifact + validation evidence, and stated full-integer-attention path (fused IntSoftmax) and HG-PIPE contrast where applicable.
