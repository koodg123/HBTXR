# Prompt Template

Use `$hw-nonlinear-dsp-packing-kb` to handle the following task.

Objective:

Inputs (operator / 입력 범위·분포 / 비트폭·스케일 / 타깃 DSP / board+clock / source RTL or HLS / MODULE_GUIDE refs):

Constraints:

Required artifact (nonlinear-op HW plan / DSP-packing plan / requant·fuse plan / 비교표):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / synthesis PPA / bit-exact C-sim):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
