# Intake Prompt Bundle

Use `$hw-nonlinear-dsp-packing-kb` for this request.

1. Normalize the request into a measurable HW objective (LUT 엔트리/비트폭 · MAC/DSP 배수 · 근사 오차 · latency).
2. Identify source artifacts (operator, 입력 범위/분포, 비트폭/스케일, 타깃 DSP, board+clock, RTL/HLS) and missing inputs.
3. Select required supporting skills (`hw-friendly-nonlinear-approx`, `transformer-accel-microarch`, `algo2fpga`) and the matching REF MODULE_GUIDE.
4. Produce the first usable artifact (nonlinear-op HW plan / DSP-packing plan / requant·fuse plan).
5. Define the verification gate (file:line + synthesis PPA / bit-exact C-sim) and residual risks.
