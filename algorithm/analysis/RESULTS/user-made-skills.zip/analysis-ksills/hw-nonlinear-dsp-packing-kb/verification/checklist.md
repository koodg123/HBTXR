# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: hw-nonlinear-dsp-packing-kb` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable HW objective.
- [ ] Source artifacts (operator / 입력 범위·분포 / 비트폭·스케일 / 타깃 DSP), assumptions, and constraints are separated.
- [ ] Required supporting skills and the matching REF MODULE_GUIDE are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] 근사 방식(시프트 vs 다항 vs LUT vs 곱셈기-free)과 그 자원·정확도 결과가 짝지어져 있다.
- [ ] Cost numbers (LUT 엔트리/비트폭 · MAC/DSP 배수 · carry 보정 비트 · dyadic requant 시프트량) carry file:line evidence; synthesis PPA is cited only if a report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (synthesis / bit-exact C-sim) are explicit.
- [ ] Residual risks and next validation steps are listed.
