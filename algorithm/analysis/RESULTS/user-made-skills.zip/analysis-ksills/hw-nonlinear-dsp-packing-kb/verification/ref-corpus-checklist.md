# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s).
- [ ] Applied this skill to the relevant cluster (비선형 함수별 비교 / FlashAttention exp·softmax / DSP packing).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE.
- [ ] Kept the quantitative convention (LUT 엔트리·비트폭 / MAC/DSP 배수 / carry 보정 / dyadic requant; synthesis PPA = "확인 필요" if no report).
- [ ] Carried over known-limitation flags (e.g., 시프트 근사 범위 제한, packing guard 비트 부족 위험, 명칭-실체 불일치, HLS source absent).
- [ ] Produced a concrete artifact + validation evidence, and stated 시프트 vs 다항 트레이드오프 / fuse quantizer 적용 가능성 where applicable.
