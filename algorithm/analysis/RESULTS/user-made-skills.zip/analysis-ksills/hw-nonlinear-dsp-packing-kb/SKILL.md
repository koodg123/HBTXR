---
name: hw-nonlinear-dsp-packing-kb
description: "FPGA/ASIC 트랜스포머 비선형 연산(softmax/GELU/LayerNorm/exp/reciprocal/rsqrt)의 LUT·시프트·다항 근사 + DSP packing(1 DSP에 저비트 다중 MAC) 레시피. 곱셈기-free exp, Log-Int-Softmax, ShiftGELU, dyadic requant, DSPopt 비트배치+carry 보정, fuse quantizer. REF/Analysis 교차사례 라우팅. Use whenever the user needs to remove FP exp/div/sqrt from a datapath, LUT-ify/shift-approximate a nonlinear op, size a LUT, or pack multiple low-bit MACs per DSP — even without naming an operator."
---

# HW Nonlinear & DSP Packing Knowledge Base

## Overview

Use this skill for **트랜스포머 비선형 연산의 HW화(LUT/시프트/다항 근사)** 와 **DSP packing(1 DSP에 저비트 다중 MAC)** 의 교차주제 레시피 작업. softmax·GELU·LayerNorm·exp·reciprocal·rsqrt에서 부동소수 exp/div/sqrt를 제거하고, 저비트 곱셈을 DSP에 다중 적재하는 결정-준비(decision-ready) 산출물을 REF 코퍼스(MODULE_GUIDE) 근거로 만든다. 자유서술 조언이 아니라 재사용 산출물을 만든다.

This skill complements `hw-friendly-nonlinear-approx`, `transformer-accel-microarch`, and `algo2fpga`. It should produce reusable artifacts (nonlinear-op HW plan, DSP-packing plan, requant/fuse plan) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable HW objective (LUT 엔트리/비트폭·MAC/DSP 배수·정확도·latency).
2. List source artifacts (연산자 spec, 입력 분포/범위, 비트폭, 보드/DSP 종류) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (비선형-op HW plan vs DSP-packing plan vs requant/fuse plan).

## Workflow

1. Capture operator(s) (softmax/GELU/LayerNorm/exp/reciprocal/rsqrt), 입력 동적범위, 비트폭/스케일, 타깃 DSP(예: DSP48E2), clock, runtime contract.
2. Identify the approximation boundary: 시프트 근사(barrel shifter), 다항식(제곱기), LUT(엔트리/인덱싱), 또는 곱셈기-free exp.
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md` and extract 비선형/packing 패턴 with file:line evidence.
4. Plan or compare with measurable cost: LUT 엔트리·비트폭, 시프트 vs 제곱기 자원, MAC/DSP 배수, carry 보정 비트, dyadic requant 시프트량.
5. Return artifacts connecting datapath behavior, numeric accuracy, and validation metrics; flag what needs synthesis to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (비선형-op HW plan / DSP-packing plan / requant·fuse plan) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (보통 합성 PPA / bit-exact C-sim).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness (근사 오차·end-task 정확도) is separated from performance and resource claims.
- Operator 입력 동적범위, 비트폭/스케일, dyadic requant 가정이 명시되어 있다.
- 근사 방식(시프트 vs 다항 vs LUT)과 그 자원·정확도 결과가 짝지어져 있다.
- Cost numbers (LUT 엔트리·비트폭, MAC/DSP 배수, carry 보정 비트)는 코드(LUT 크기/언롤/비트배치)에서 file:line으로 도출; 합성 PPA는 리포트 존재 시만 인용, 없으면 "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (연산자 spec, 입력 범위, 비트폭, 타깃 DSP) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on synthesis PPA, board measurements, or unavailable tools.
- A recommendation would lock the user into a brittle 근사/packing without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. Cross-analysis routing is in `REF/Analysis/INDEX.md` §9.4 (FPGA 비선형/곱셈 HW화 의사결정). The project baseline accelerator is **HG-PIPE** (전계층 온칩, 3-bit, LUT 비선형).
