#!/usr/bin/env python3
"""Build a prompt pack for hw-nonlinear-dsp-packing-kb."""

import argparse


def main():
    parser = argparse.ArgumentParser(description="Build a reusable prompt pack.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--inputs", default="")
    parser.add_argument("--constraints", default="")
    parser.add_argument("--artifact", default="nonlinear-op HW plan / DSP-packing plan / requant-fuse plan")
    parser.add_argument("--verification", default="file:line evidence + synthesis PPA / bit-exact C-sim")
    args = parser.parse_args()

    print("Skill: hw-nonlinear-dsp-packing-kb")
    print(f"Objective: {args.objective}")
    print(f"Inputs: {args.inputs}")
    print(f"Constraints: {args.constraints}")
    print(f"Required artifact: {args.artifact}")
    print(f"Verification evidence: {args.verification}")


if __name__ == "__main__":
    main()
