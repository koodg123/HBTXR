# Prompt Operations

## Prompt Pack Fields

- Skill: `hw-nonlinear-dsp-packing-kb`
- Objective: one sentence (비선형-op HW화 / DSP-packing / requant·fuse).
- Context: operator, 입력 범위/분포, 비트폭/스케일, 타깃 DSP, 보드+clock, source RTL/HLS, MODULE_GUIDE refs.
- Constraints: scope, tools, DSP/LUT 예산, non-goals.
- Required output: exact artifact type (nonlinear-op HW plan / DSP-packing plan / requant·fuse plan / 비교표).
- Verification: evidence needed (file:line, synthesis PPA, bit-exact C-sim).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (입력 범위/비트폭/타깃 DSP) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when operator/입력 범위, 비트폭/스케일, 타깃 DSP, or acceptance criteria are missing and the missing fact would change the근사 방식/packing 비트배치/cost. Never fabricate synthesis PPA.
