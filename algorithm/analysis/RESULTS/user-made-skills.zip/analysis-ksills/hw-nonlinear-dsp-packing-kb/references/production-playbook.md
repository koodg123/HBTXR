# Production Playbook

## Purpose

This playbook supports `hw-nonlinear-dsp-packing-kb` for 트랜스포머 비선형 연산 HW화(LUT/시프트/다항) + DSP packing(저비트 다중 MAC/DSP) work. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: 어떤 비선형 연산을 HW화/근사할지, 또는 어떤 저비트 곱셈을 DSP에 어떻게 packing할지.
- Inputs: operator(softmax/GELU/LayerNorm/exp/reciprocal/rsqrt), 입력 동적범위/분포, 비트폭/스케일, 타깃 DSP(예: DSP48E2), 보드+clock, source RTL/HLS, MODULE_GUIDE references.
- Output format: nonlinear-op HW plan, DSP-packing plan, requant/fuse plan, 또는 비교표.
- Success metrics: LUT 엔트리/비트폭, 시프트 vs 제곱기 자원, MAC/DSP 배수, carry 보정 비트, 근사 오차·end-task 정확도, latency/II.
- Constraints: tool availability, DSP/LUT 예산, non-goals, validation limits.

## Decision Flow

- Capture operator(s), 입력 범위/분포, 비트폭/스케일, 타깃 DSP, clock, runtime contract.
- 근사 경계 결정: 시프트 근사(barrel shifter) vs 다항식(제곱기) vs LUT(엔트리/인덱싱) vs 곱셈기-free exp(ExpMul).
- Read the matching REF MODULE_GUIDE(s); extract 비선형/packing 패턴 with file:line.
- Compute cost statically: LUT 엔트리 = 입력비트→인덱스 매핑 크기, MAC/DSP 배수 = 비트배치/세그먼트 수, carry 보정 비트 = guard band, dyadic requant 시프트량.
- Return artifacts linking datapath behavior, numeric accuracy, and validation metrics.

## Tradeoff Questions

- 시프트 근사(barrel shifter) vs 다항식(제곱기): 어느 쪽이 자원·정확도 면에서 이 입력 범위에 맞는가?
- DSP packing 비트배치·carry 보정: guard 비트가 부족해 인접 곱이 오염되지 않는가?
- output quantizer를 다음 matmul의 input quantizer와 fuse하면 어떤 단계를 제거할 수 있는가(dyadic requant)?
- 합성/bit-exact C-sim으로 지금 검증 가능한 최소 변경은 무엇인가?
- Which existing skill (`hw-friendly-nonlinear-approx`, `transformer-accel-microarch`, `algo2fpga`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need synthesis), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
