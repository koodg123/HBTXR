# REF Corpus Context — HW Nonlinear Approx & DSP Packing

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` §9.4 (FPGA 비선형/곱셈 HW화 의사결정). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) and a 1차 요약 `<repo>.md`. 카테고리 폴더 위치는 INDEX 참고.

## Core Clusters (route to these MODULE_GUIDEs)

1. **비선형 함수별 비교 (핵심 의사결정표)**: `mixed-non-linear-quantization/MODULE_GUIDE.md` (I-ViT/I-BERT/FQ-ViT 함수별 직접 비교표 → **시프트 근사 vs 다항식 자원·정확도 트레이드오프**), `I-ViT/MODULE_GUIDE.md` (ShiftGELU·Shiftmax·정수 LayerNorm, barrel shifter), `FQ-ViT/MODULE_GUIDE.md` (Log-Int-Softmax + PTF), `integer-only-transformer/MODULE_GUIDE.md` (I-BERT 다항 vs 시프트).
2. **FlashAttention exp/softmax**: `AURA-FlashAttention-AISC-Accelerator/MODULE_GUIDE.md` (곱셈기 없는 ExpMul, 1-pass online softmax), `hls-fpga-accelerators/MODULE_GUIDE.md` (LUT exp, 파라미터화 softmax).
3. **DSP packing (저비트 다중 MAC/DSP)**: `Uint-Packing-master/MODULE_GUIDE.md` (DSPopt3 4-세그먼트 + carry 보정), `TATAA/MODULE_GUIDE.md` (INT8↔bf16 transformable PE), `Diff-DiT/MODULE_GUIDE.md` (DSP 2/6-pack, OS systolic), `AGNA-FCCM2023/MODULE_GUIDE.md` (DSP48E2 cascade INT8 2-MAC), `AHCPTQ/MODULE_GUIDE.md` (log2 shift + grouped scale), `SJTU_microe/MODULE_GUIDE.md` (4MUL/DSP).

(전체 목록·정량 요약은 `INDEX.md` §8(HW) / §9(S-PyTorch) 표 참조. 각 repo 경로는 해당 repo의 `MODULE_GUIDE.md` 헤더 참조.)

## 핵심 정리 (재사용 레시피)
- **시프트 근사(barrel shifter) vs 다항식(제곱기) 트레이드오프**: 시프트는 자원 저렴·범위 제한, 다항은 정확도↑·제곱기 비용. 입력 동적범위와 목표 오차로 선택.
- **곱셈기-free exp / Log-Int-Softmax**: exp를 시프트+덧셈/log 도메인으로 치환(ExpMul, FQ-ViT Log-Int-Softmax) → softmax에서 FP exp 제거.
- **DSP packing 비트배치·carry 보정**: 1 DSP에 저비트 다중 MAC을 배치하되 guard/carry 비트로 인접 곱 오염 방지(Uint-Packing DSPopt3 4-세그먼트, AGNA 2-MAC cascade).
- **fuse output quantizer with next matmul input quantizer**: dyadic requant(시프트+정수곱)로 두 양자화 단계를 1단계로 융합 → 나눗셈/FP 제거.

## 수치 규약 (정량 도출, 정적)
- LUT 엔트리 = 입력비트→인덱스 매핑 크기 · MAC/DSP 배수 = 비트배치/세그먼트 수 · carry 보정 = guard band 비트 · dyadic requant = 시프트량+정수 multiplier. 합성 PPA(LUT/DSP/BRAM/Fmax)는 리포트 동봉 시만 인용, 없으면 "확인 필요".

## Reusable Verification Questions
- 어떤 연산자(softmax/GELU/LayerNorm/exp/reciprocal/rsqrt)이고 입력 동적범위/분포는?
- 비트폭/스케일과 dyadic requant 가정은?
- 근사 방식은 시프트(barrel shifter)인가 다항(제곱기)인가 LUT인가 곱셈기-free인가?
- DSP packing이면 비트배치·세그먼트 수·carry 보정 비트는?
- 1차 지표는 LUT 엔트리/비트폭·MAC/DSP 배수·근사 오차·latency 중 무엇?

## Why This Skill Is Relevant
REF 코퍼스가 softmax/GELU/LayerNorm/exp 정수화·시프트·LUT 직접 구현체(I-ViT·FQ-ViT·integer-only-transformer)와 곱셈기-free attention(AURA), 저비트 DSP packing(Uint-Packing·TATAA·Diff-DiT·AGNA)을 반복적으로 다루며, file:line 근거로 비선형/packing 의사결정을 뒷받침한다.
