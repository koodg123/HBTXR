# Common Mistakes

- Producing general nonlinear/packing advice without a prompt pack or a concrete artifact.
- Quoting LUT 엔트리/MAC-per-DSP 배수 without file:line evidence, or citing synthesis PPA that does not exist in the repo (should be "확인 필요").
- Mixing 근사 오차·정확도 (functional) with resource/latency (performance) claims.
- Picking 시프트 근사 vs 다항식 without stating the 입력 동적범위 / 자원·정확도 결과 of the choice.
- Packing multiple MACs into one DSP without sizing the carry/guard 보정 비트 (인접 곱 오염).
- Forgetting to fuse the output quantizer with the next matmul's input quantizer (dyadic requant) when it removes a divide/FP step.
- Forgetting to route into the relevant REF MODULE_GUIDE (§9.4 비교표) before inventing a new근사/packing scheme.
- Recommending an irreversible근사/packing with no validation (synthesis, bit-exact C-sim) path.
