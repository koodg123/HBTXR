# Good Output Example

## Prompt Pack

Skill: `hw-nonlinear-dsp-packing-kb`
Objective: Produce a decision-ready nonlinear-op HW / DSP-packing / requant·fuse artifact.
Inputs: operator(softmax/GELU/LayerNorm/exp/reciprocal/rsqrt), 입력 동적범위·분포, 비트폭/스케일, 타깃 DSP, 보드+clock, source RTL/HLS (if any).
Constraints: state tool, DSP/LUT 예산, target, and scope limits.
Verification: define the evidence (file:line, synthesis PPA, bit-exact C-sim) required for signoff.

## Artifact

Structured decisions with **MODULE_GUIDE line evidence**, e.g.:
- Nonlinear-op: ShiftGELU/Shiftmax(barrel shifter) vs I-BERT 다항(제곱기) 선택 + LUT 엔트리·비트폭 (cite `mixed-non-linear-quantization/MODULE_GUIDE.md` 비교표).
- exp/softmax: 곱셈기-free ExpMul(1-pass online softmax, cite `AURA-…/MODULE_GUIDE.md`) 또는 Log-Int-Softmax+PTF (cite `FQ-ViT/MODULE_GUIDE.md`).
- DSP packing: 1 DSP 저비트 다중 MAC 비트배치 + carry 보정 비트, MAC/DSP 배수 (cite `Uint-Packing-master`·`AGNA-FCCM2023`·`Diff-DiT/MODULE_GUIDE.md`).
- Requant/fuse: dyadic requant로 output quantizer를 다음 matmul input quantizer와 fuse (시프트량+정수 multiplier).
- Tradeoffs (시프트 vs 다항) and the smallest change validatable by synthesis/bit-exact C-sim first.

## Risks

List uncertain assumptions (e.g., packing guard 비트 부족, 시프트 근사 범위 밖 정확도 손실, 달성 Fmax) and the next experiment (synthesis/PPA, bit-exact C-sim) to resolve each.
