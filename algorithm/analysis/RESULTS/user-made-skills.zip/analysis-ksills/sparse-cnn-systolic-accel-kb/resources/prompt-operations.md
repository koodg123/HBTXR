# Prompt Operations

## Prompt Pack Fields

- Skill: `sparse-cnn-systolic-accel-kb`
- Objective: one sentence (design/compare/port/analyze).
- Context: model/sparsity spec, datatype, target board+clock, source RTL/HLS, MODULE_GUIDE refs.
- Constraints: scope, tools, target platform, non-goals.
- Required output: exact artifact type (sparse-dataflow plan / systolic GEMM mapping / DSP-packing plan / codebase MODULE_GUIDE).
- Verification: evidence needed (file:line, synthesis PPA, bit-exact C-sim).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (board/clock/datatype/sparsity format) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when device/clock, model/sparsity spec, datatype, or acceptance criteria are missing and the missing fact would change the datapath/cost. Never fabricate synthesis PPA.
