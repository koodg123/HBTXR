# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s) under Others/ or CNN-Accel/.
- [ ] Applied this skill to the relevant cluster (희소 SpMV/SpMM / 동적 프루닝 sparse dataflow / systolic·타일 GEMM / DSP packing CNN).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE.
- [ ] Kept the quantitative convention (MAC lanes/scalar MACs/nnz·유효MAC/loop trips/memory; synthesis PPA = "확인 필요" if no report).
- [ ] Carried over known-limitation flags (e.g., row-imbalance handling, DSP packing carry bits, target-part mismatches, Kria-YOLOv4-Tiny anti-pattern).
- [ ] Produced a concrete artifact + validation evidence, and stated event-sparse (ESDA/SEE) relevance / porting link where applicable.
