# Common Mistakes

- Producing general accelerator advice without a prompt pack or a concrete artifact.
- Quoting throughput/area numbers without file:line evidence, or citing synthesis PPA that does not exist in the repo (should be "확인 필요").
- Mixing functional correctness with performance and resource claims.
- Counting dense MACs for a sparse design without stating nnz/sparsity and the resulting 유효MAC (effective MAC) and row-imbalance handling.
- Naming a DSP-packing factor (4w4a, 1 DSP = N MAC) without stating the bit-layout and carry/guard-bit consequence.
- Naming a systolic dataflow (output-stationary, weight-stationary) without stating the memory/buffer and tile consequence.
- Forgetting to route into the relevant REF MODULE_GUIDE (Others/ sparse·systolic, CNN-Accel/ packing) before inventing a new datapath.
- Recommending an irreversible mapping with no validation (synthesis, bit-exact C-sim) path; ignoring known anti-patterns (e.g., Kria-YOLOv4-Tiny single-conv `>>8` offload).
