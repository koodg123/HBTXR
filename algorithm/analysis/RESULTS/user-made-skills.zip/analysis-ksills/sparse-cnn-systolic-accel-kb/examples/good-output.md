# Good Output Example

## Prompt Pack

Skill: `sparse-cnn-systolic-accel-kb`
Objective: Produce a decision-ready sparse-dataflow/systolic GEMM/DSP-packing artifact for an FPGA sparse·systolic·CNN accelerator.
Inputs: model/sparsity spec (dims/nnz/depth), datatype/quantization, target board+clock, source RTL/HLS (if any).
Constraints: state tool, data, target, and scope limits.
Verification: define the evidence (file:line, synthesis PPA) required for signoff.

## Artifact

Structured decisions with **MODULE_GUIDE line evidence**, e.g.:
- Sparse dataflow: HBM SpMV 128-way + 2-stage shuffle + URAM forwarding PE + CPSR, or input-adaptive coordinate-stream pruning (cite `Others/HiSparse/MODULE_GUIDE.md`, `Others/DPACS/MODULE_GUIDE.md`); cost = nnz·유효MAC, II.
- Systolic GEMM: output-stationary tile (Versal AIE 8×50 / 32×32 DSP), MAC lanes = rows·cols (cite `Others/acap-gemm-sa/MODULE_GUIDE.md`, `Others/TMMA/MODULE_GUIDE.md`).
- DSP packing: 4w4a UltraNet (DSP2/DSPopt3, 1 DSP = multiple low-bit MAC), im2col vs direct conv (route to `CNN-Accel/Uint-Packing-master/MODULE_GUIDE.md`).
- Tradeoffs and the smallest change that can be validated by synthesis first.

## Risks

List uncertain assumptions (e.g., row-imbalance absorption depth, DSP packing carry bits, achievable Fmax) and the next experiment (synthesis/PPA, bit-exact C-sim) to resolve each.
