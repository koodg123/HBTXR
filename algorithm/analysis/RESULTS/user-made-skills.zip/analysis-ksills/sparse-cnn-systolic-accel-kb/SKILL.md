---
name: sparse-cnn-systolic-accel-kb
description: "FPGA 희소연산·systolic GEMM·CNN 가속 지식베이스. HBM SpMV(shuffle network, CPSR, URAM forwarding), 입력적응 동적 프루닝 sparse dataflow, systolic GEMM(Versal AIE/DSP, output-stationary), DSP packing(UltraNet/DAC-SDC, 4w4a), im2col, 이벤트 sparse CNN. REF/Analysis Others·CNN-Accel MODULE_GUIDE 라우팅. Use whenever the user designs/analyzes a sparse(SpMV/SpMM), systolic GEMM, or CNN FPGA accelerator, or needs DSP-packing/dataflow patterns — even without naming a repo."
---

# Sparse / Systolic GEMM / CNN FPGA Accelerator Knowledge Base

## Overview

Use this skill for **FPGA 희소(SpMV/SpMM)·systolic GEMM·CNN 가속기** design, comparison, porting, and codebase analysis. Build transparent, decision-ready artifacts grounded in the analyzed REF corpus (HW MODULE_GUIDEs) rather than free-form advice.

This skill complements `algo2fpga`, `sparse-event-compute`, and `transformer-accel-microarch`. It should produce reusable artifacts (sparse-dataflow plan, systolic GEMM mapping, DSP-packing plan) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable HW objective (throughput/latency/area/power/accuracy).
2. List source artifacts (RTL/HLS, model/sparsity spec, board, clock) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (sparse-dataflow plan vs systolic GEMM mapping vs DSP-packing plan).

## Workflow

1. Capture target device, model/workload (dims, sparsity/nnz, depth), datatype/quantization, clock, and runtime contract.
2. Identify the design entry and boundary: HLS C++, hand-written RTL/SpinalHDL, or mixed IP-integrator (per `hw-implementation-flow-doc` style).
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md` and extract sparse/systolic/packing patterns with file:line evidence.
4. Plan or compare with measurable cost: MAC lanes/scalar MACs (or nnz·유효MAC), loop trips/II, on-chip memory (bit), DSP/LUT/BRAM/URAM, clock.
5. Return artifacts connecting datapath behavior, memory/dataflow, and validation metrics; flag what needs synthesis to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (sparse-dataflow / systolic GEMM / DSP-packing plan or accelerator-codebase analysis) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually synthesis/PPA).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis HW MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness is separated from performance and resource claims.
- Datatype, quantization, sparsity format, and shape/operator constraints are explicit.
- Backend/board assumptions are named before scheduling or cost claims.
- Cost numbers (MAC lanes/scalar MACs/nnz·유효MAC/loop trips/memory) are derived from code (unroll/shape/sparsity) with file:line; synthesis PPA is cited only if a report exists, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (RTL/HLS, model/sparsity spec, board/clock) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on synthesis PPA, board measurements, or unavailable tools.
- A recommendation would lock the user into a brittle dataflow without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. Routing lives in `REF/Analysis/INDEX.md` §8 (Others·CNN-Accel); the most directly related event-sparse path is **ESDA/SEE**.
