# Production Playbook

## Purpose

This playbook supports `sparse-cnn-systolic-accel-kb` for FPGA/HLS/RTL 희소(SpMV/SpMM)·systolic GEMM·CNN accelerator work. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to design, compare, port, or analyze (sparse dataflow, systolic GEMM, DSP packing, codebase).
- Inputs: model/sparsity spec (dims/nnz/sparsity/depth), datatype/quantization, target board + clock, source RTL/HLS, MODULE_GUIDE references.
- Output format: sparse-dataflow plan, systolic GEMM mapping, DSP-packing plan, or accelerator-codebase MODULE_GUIDE.
- Success metrics: throughput/II, latency (avg + p95/p99), area (LUT/FF/DSP/BRAM/URAM), energy, accuracy.
- Constraints: tool availability, board fit, non-goals, validation limits.

## Decision Flow

- Capture device, model/workload, sparsity/nnz, datatype, clock, runtime contract.
- Identify design entry/boundary: HLS C++ vs hand-written RTL/SpinalHDL vs mixed IP-integrator.
- Read the matching REF MODULE_GUIDE(s); extract sparse/systolic/packing/dataflow patterns with file:line.
- Compute cost statically: MAC lanes (unroll dims), scalar MACs (shape) or nnz·유효MAC (sparsity), loop trips/II (tiling), memory (array×bit).
- Return artifacts linking datapath behavior, memory/dataflow, and validation metrics.

## Tradeoff Questions

- Which mapping would be costly to reverse (on-chip-resident vs HBM streaming, dense GEMM vs SpMV/SpMM, output-stationary vs weight-stationary)?
- Which assumption (row imbalance, DSP packing carry bits, Fmax, accuracy at low bit) most likely invalidates the artifact?
- What is the smallest change validatable by synthesis or bit-exact C-sim now?
- Which existing skill (`algo2fpga`, `sparse-event-compute`, `transformer-accel-microarch`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need synthesis), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
