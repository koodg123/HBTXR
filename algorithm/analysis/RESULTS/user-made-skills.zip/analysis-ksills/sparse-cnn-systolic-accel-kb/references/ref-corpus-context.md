# REF Corpus Context — Sparse / Systolic GEMM / CNN FPGA Accelerators

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW 심층 MODULE_GUIDE; category folders **Others/** and **CNN-Accel/**). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) and a 1차 요약 `<repo>.md`.

## Core Clusters (route to these MODULE_GUIDEs)

1. **희소 SpMV/SpMM (HBM)**: `Others/HiSparse/MODULE_GUIDE.md` (FPGA'22 Cornell, ap_ufixed 128-way, 2단 셔플 + URAM forwarding PE + CPSR), `Others/HiSpMV/MODULE_GUIDE.md` (TAPA/HBM FP32 SpMV, 불균형행 Pre-Accumulator·RDN, automation_tool DSE+codegen), `Others/HiSpMM/MODULE_GUIDE.md` (HiSpMV→N0=8 SIMD Sparse-Dense MatMul, balanced/imbalanced 자동선택).
2. **동적 프루닝 sparse dataflow**: `Others/DPACS/MODULE_GUIDE.md` (ASPLOS'23 입력적응 spatial+channel 동적 프루닝, coordinate-stream sparse dataflow), `Others/REMOT-FPGA-22/MODULE_GUIDE.md` (FPGA'22 이벤트구동 AMAP Attention Unit), `CNN-Accel/ESDA/MODULE_GUIDE.md` (이벤트 sparse MobileNetV2 토큰+마스크 dataflow, 유효MAC×sparsity), `CNN-Accel/SEE/MODULE_GUIDE.md` (ESDA wrapper, ZCU102 PYNQ 지연+INA226 전력 실측 하네스).
3. **systolic / 타일 GEMM**: `Others/acap-gemm-sa/MODULE_GUIDE.md` (Versal VCK5000 8×50 AIE FP32 OS systolic + AMPL/Gurobi DSE), `Others/TMMA/MODULE_GUIDE.md` (KV260 INT8 32×32 OS MAC, DSP 1024, 합성 PPA 실측), `CNN-Accel/SJTU_microe-main/MODULE_GUIDE.md` (4MUL/DSP 2D PE array, im2col형 — ViT GEMM 매핑성 우수), `CNN-Accel/XJTU-Tripler-master/MODULE_GUIDE.md` (HPU MPU 8×8=64 MAC).
4. **DSP packing CNN (UltraNet/DAC-SDC)**: `CNN-Accel/Uint-Packing-master/MODULE_GUIDE.md` (4w4a DSP2/DSPopt3 비트배치), `CNN-Accel/AnyPackingNet-main/MODULE_GUIDE.md` (=DeepBurning-MixQ, packing factor표·NAS), `CNN-Accel/dac_sdc_2020_designs-master/MODULE_GUIDE.md`·`dac_sdc_2021_designs-main`·`dac_sdc_2022_champion-master`·`dac_sdc_2022_designs-main`·`dac_sdc_2023_champion-main`, `CNN-Accel/SkrSkr-master/MODULE_GUIDE.md` (SkyNet W6A8 PW 512 MAC/cyc, im2col), `CNN-Accel/SkyNet-ZCU104-master/MODULE_GUIDE.md` (conv1x1 dot-tree), `CNN-Accel/yolo-fpga-accelerator-main/MODULE_GUIDE.md`, `CNN-Accel/yolov2_xilinx_fpga-flex/MODULE_GUIDE.md`, `CNN-Accel/Kria-YOLOv4-Tiny-FPGA-Accelerator/MODULE_GUIDE.md` (★안티패턴: 단일 conv·8 MAC·`>>8` 고정시프트·입력 32× 재독), `CNN-Accel/FlexCNN/MODULE_GUIDE.md` (auto_compile codegen, SA 16×14×8=1792 MAC).

(전체 목록·정량 요약은 `INDEX.md` §8 표 참조.)

## 수치 규약 (정량 도출, 정적)
- MAC lanes = unroll/병렬도 차원 곱 · scalar MACs = shape 곱 (희소는 nnz·유효MAC) · loop trips = 타일 곱 · memory = 배열 깊이×bit. 합성 PPA(LUT/DSP/BRAM/Fmax)는 리포트 동봉 시만 인용, 없으면 "확인 필요".

## Reusable Verification Questions
- 타깃 디바이스·클럭·런타임 계약은?
- 모델/워크로드 shape(dim·depth)·희소성(nnz/sparsity)·데이터타입/비트폭은?
- 설계 진입점은 HLS인가 hand-written RTL/SpinalHDL인가(혼합)?
- 검증 가능한 최소 단위(대표 GEMM 타일/1 SpMV 채널/1 레이어)는?
- 1차 지표는 throughput/latency/area/energy/accuracy 중 무엇?

## Why This Skill Is Relevant
REF 코퍼스의 Others·CNN-Accel HW 가속기가 HBM SpMV(shuffle/CPSR/URAM forwarding), 동적 프루닝 sparse dataflow, systolic/타일 GEMM, DSP packing(4w4a)을 반복적으로 다루며, file:line 근거로 설계 의사결정을 뒷받침한다. 본 프로젝트 XR 시선추적 FPGA 이식의 가장 직접적 출발점은 이벤트 sparse 경로(ESDA/SEE).
