#!/usr/bin/env python3
"""Build a prompt pack for sparse-cnn-systolic-accel-kb."""

import argparse


def main():
    parser = argparse.ArgumentParser(description="Build a reusable prompt pack.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--inputs", default="")
    parser.add_argument("--constraints", default="")
    parser.add_argument("--artifact", default="sparse-dataflow/systolic GEMM/DSP-packing plan")
    parser.add_argument("--verification", default="file:line evidence + synthesis PPA")
    args = parser.parse_args()

    print("Skill: sparse-cnn-systolic-accel-kb")
    print(f"Objective: {args.objective}")
    print(f"Inputs: {args.inputs}")
    print(f"Constraints: {args.constraints}")
    print(f"Required artifact: {args.artifact}")
    print(f"Verification evidence: {args.verification}")


if __name__ == "__main__":
    main()
