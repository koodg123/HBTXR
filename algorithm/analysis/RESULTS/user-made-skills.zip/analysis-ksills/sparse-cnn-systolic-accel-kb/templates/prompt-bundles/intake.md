# Intake Prompt Bundle

Use `$sparse-cnn-systolic-accel-kb` for this request.

1. Normalize the request into a measurable HW objective (throughput/latency/area/power/accuracy).
2. Identify source artifacts (model/sparsity spec, board+clock, RTL/HLS) and missing inputs.
3. Select required supporting skills (`algo2fpga`, `sparse-event-compute`, `transformer-accel-microarch`) and the matching REF MODULE_GUIDE (Others/ sparse·systolic, CNN-Accel/ packing).
4. Produce the first usable artifact (sparse-dataflow / systolic GEMM / DSP-packing plan).
5. Define the verification gate (file:line + synthesis PPA) and residual risks.
