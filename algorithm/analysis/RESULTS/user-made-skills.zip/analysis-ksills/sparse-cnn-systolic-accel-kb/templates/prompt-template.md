# Prompt Template

Use `$sparse-cnn-systolic-accel-kb` to handle the following task.

Objective:

Inputs (model/sparsity spec / datatype / board+clock / source RTL or HLS / MODULE_GUIDE refs):

Constraints:

Required artifact (sparse-dataflow plan / systolic GEMM mapping / DSP-packing plan / codebase MODULE_GUIDE):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / synthesis PPA / bit-exact C-sim):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
