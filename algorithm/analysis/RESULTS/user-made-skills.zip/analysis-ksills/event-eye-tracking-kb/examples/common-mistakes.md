# Common Mistakes

- Producing general eye-tracking advice without a prompt pack or a concrete artifact.
- Quoting accuracy (p-error/p10/IoU) without README/paper evidence, or inventing numbers that do not exist in the repo (should be "확인 필요").
- Mixing functional/accuracy correctness with latency and resource claims.
- Naming an event representation (voxel, point, graph) without stating the temporal-model / accumulation consequence.
- Reporting offline windowed accuracy while claiming online/causal streaming (or vice versa) without saying which.
- Forgetting to route into the relevant REF MODULE_GUIDE / paper before inventing a new model.
- Treating a dataset-only repo (eyegraph, event_based_gaze_tracking) as an algorithm implementation.
- Recommending an irreversible representation/temporal model with no validation (train-eval, on-device measurement) path.
