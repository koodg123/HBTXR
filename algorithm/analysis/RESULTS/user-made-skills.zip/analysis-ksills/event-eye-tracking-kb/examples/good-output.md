# Good Output Example

## Prompt Pack

Skill: `event-eye-tracking-kb`
Objective: Produce a decision-ready representation/model/port artifact for an event-based or near-eye eye tracker.
Inputs: task (gaze coord / pupil center / ellipse / seg), dataset, event representation, model spec, target device.
Constraints: state tool, data, on-device target, and scope limits.
Verification: define the evidence (file:line / paper citation, train-eval run) required for signoff.

## Artifact

Structured decisions with **MODULE_GUIDE / paper evidence**, e.g.:
- Event representation: time-bin event frame vs voxel vs point vs graph; bins×H×W and polarity (cite `…/MODULE_GUIDE.md`; route to `event-representation-builder`).
- Temporal model: cb-convlstm/3ET (delta sparsity) vs SSM·Mamba (EventMamba/TDTracker) vs causal Conv3d streaming (TENNs-Eye/FACET) vs SNN (retina); params/FLOPs with file:line (route to `spatiotemporal-recurrent-ssm-builder`).
- Output head / metric: coord regression vs heatmap vs ellipse vs seg; p-error/p10/IoU definition and dataset split (route to `eyetracking-dataset-benchmark-harness`, `pupil-output-head-and-loss`).
- Tradeoffs and the smallest change that can be validated by a short train/eval run first; on-device / FPGA path via ESDA where relevant.

## Risks

List uncertain assumptions (e.g., p-error definition, subject-independent split, achievable on-device latency) and the next experiment (train-eval run, on-device measurement) to resolve each.
