# Prompt Operations

## Prompt Pack Fields

- Skill: `event-eye-tracking-kb`
- Objective: one sentence (design/compare/port/analyze).
- Context: task, dataset, event representation, model spec, target device, MODULE_GUIDE / paper refs.
- Constraints: scope, tools, on-device target, non-goals.
- Required output: exact artifact type (representation plan / model comparison table / port plan / codebase MODULE_GUIDE).
- Verification: evidence needed (file:line, paper citation, train/eval run, on-device measurement).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (dataset/metric/representation/device) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when task/dataset, metric definition, representation, or acceptance criteria are missing and the missing fact would change the model/cost. Never fabricate accuracy (p-error 등) or on-device latency numbers.
