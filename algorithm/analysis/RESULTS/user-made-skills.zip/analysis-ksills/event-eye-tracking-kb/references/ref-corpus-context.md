# REF Corpus Context — Event / Near-Eye Eye Tracking

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§2.6 XR codebases, §2.7 Papers, §9.2 S2 모델). 코드는 `XR-Eye-Tracking/Codebase/<repo>/MODULE_GUIDE.md` (6요소 + 정량), 논문은 `Papers/<name>.md`.

## Core Clusters (route to these MODULE_GUIDEs / Papers)

1. **시간모델(저지연 후보)**: `XR-Eye-Tracking/Codebase/cb-convlstm-eyetracking/MODULE_GUIDE.md` (3ET, 0.417M, delta/시간 sparsity), `EventMamba` (포인트 SSM), `gg_ssms` (그래프+MST SSM), `ais2024` (TENNs-Eye 인과 Conv3d 스트리밍 등 3종), `ais2025` (TDTracker Mamba 캐스케이드). 논문: `Papers/3ET.md`, `Papers/MambaPupil.md`, `Papers/TDTracker.md`, `Papers/Pei-Lightweight-CVPRW24.md`.
2. **하이브리드·검출·추적**: `EX-Gaze` (프레임검출+이벤트추적 선형어텐션 MobileViTv2, Jetson TensorRT), `Swift-Eye` (SiamRPN++/Swin anti-blink FSM), `FACET` (TennSt 인과 Conv3d 좌표 + EPNet 타원/GWD), `EV-Eye` (U-Net 앵커 + 이벤트 ICP, 최대 38.4kHz), `E-Track` (U-Net 세그 + RoI 추적 96%↓). 논문: `Papers/EX-Gaze.md`, `Papers/Swift-Eye-Paper.md`, `Papers/FACET.md`, `Papers/EV-Eye.md`, `Papers/E-Track.md`, `Papers/DualPath-EyeTrack.md`.
3. **세그/타원**: `EllSeg` (동공/홍채/공막 분할 + 타원회귀), `RITnet` (DenseNet식 실시간 세그, 0.25M). 논문: `Papers/RITnet-Paper.md`.
4. **SNN/뉴로모픽**: `retina` (IAF SNN 4모드 ANN/SNN/이진/양자화, SynSense Speck, mW급). 논문: `Papers/Retina.md`.
5. **데이터셋·후처리·기타**: `event_based_gaze_tracking` (Angelopoulos >10kHz 공식 repo; 실제론 데이터셋 배포+시각화, 9B BHHI 이벤트 포맷이 자산), `EyeLoRiN` (무재학습 추론시점 후처리 median+ROI 옵티컬플로우, CVPR'25 2위), `eyegraph` (데이터셋 repo·알고리즘 부재). 논문: `Papers/EyeGraph.md`, `Papers/GazeRefine-MicroExpr.md`, `Papers/SynUnlabeled-PupilTrack.md`, `Papers/AdaptiveSSM-EyeFeature.md`, `Papers/NearEye-10000Hz.md`, `Papers/FAPNet.md`, `Papers/Zhang-Submanifold-CVPRW24.md`, `Papers/BRAT-CVPRW25.md`.
6. **FPGA 이식**: `ESDA` (이벤트 sparse MobileNetV2 HAWQ INT8 ZCU102 layer-pipeline; CNN-Accel ESDA 가이드 및 측정 SEE와 연계) — 이벤트 모델 FPGA 이식 최직접 경로.

(전체 목록·정량 요약은 `INDEX.md` §2.6/§2.7/§9.2 참조.)

## 수치 규약 (정량 도출, 정적)
- 이벤트 표현 dims = bins×H×W(또는 point N×C / graph V·E) · params/FLOPs = shape 곱 · activation = 버퍼 깊이×bit · 지연 = 윈도우 vs 스트리밍. 정확도(p-error/p10/p5/IoU/euclid px)는 README/논문 인용 시만, 없으면 "확인 필요".

## Reusable Verification Questions
- 타깃 태스크는? (gaze 좌표 / pupil center / 타원 / 세그)
- 데이터셋·분할(subject-independent 여부)과 p-error 정의는?
- 이벤트 표현은 voxel/time-bin/frame/point/graph 중 무엇이고 파라미터(bins·window·polarity)는?
- 시간모델은 인과/스트리밍(online) 인가 오프라인 윈도우인가?
- 1차 지표는 accuracy(p-error 등) / latency / params·FLOPs / on-device power 중 무엇?

## Why This Skill Is Relevant
REF 코퍼스의 XR 시선추적 코드 17 + 논문 22편이 이벤트 표현·시공간 모델·출력헤드/메트릭·on-device 이식을 반복적으로 다루며, file:line·논문 근거로 모델 설계 의사결정을 뒷받침한다.
