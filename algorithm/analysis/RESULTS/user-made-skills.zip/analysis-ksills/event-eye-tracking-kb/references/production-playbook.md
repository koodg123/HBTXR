# Production Playbook

## Purpose

This playbook supports `event-eye-tracking-kb` for event-camera / near-eye gaze·pupil tracking work. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to design, compare, port (reuse), or analyze (representation, temporal model, output head, codebase).
- Inputs: task (gaze coord / pupil center / ellipse / segmentation), dataset, event representation, model spec, target device, MODULE_GUIDE / paper references.
- Output format: representation plan, model comparison table, port plan, or model-codebase MODULE_GUIDE.
- Success metrics: accuracy (p-error / p10 / p5 / IoU / euclid px), latency (avg + p95), params/FLOPs/activation, on-device power.
- Constraints: tool availability, dataset access, on-device target, non-goals, validation limits.

## Decision Flow

- Capture task, dataset, event representation, temporal model, latency/runtime contract.
- Identify model family: ConvLSTM/3ET vs SSM·Mamba vs Transformer vs causal Conv3d streaming vs SNN vs seg+ellipse.
- Read the matching REF MODULE_GUIDE(s)/paper(s); extract representation/temporal/output patterns with file:line or paper citation.
- Compute cost statically: representation dims (bins×H×W), params/FLOPs (shape), activation (buffer), latency window vs streaming.
- Return artifacts linking representation, temporal model, output head/metric, and on-device feasibility.

## Tradeoff Questions

- Which choice would be costly to reverse (representation = voxel vs point vs graph, offline windowed vs online causal)?
- Which assumption (p-error definition, subject-independent split, achievable on-device latency) most likely invalidates the artifact?
- What is the smallest change validatable by a short train/eval run now?
- Which existing skill (`event-representation-builder`, `spatiotemporal-recurrent-ssm-builder`, `eyetracking-dataset-benchmark-harness`, `pupil-output-head-and-loss`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line / paper citation + which numbers need measurement), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
