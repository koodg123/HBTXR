# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s) / `Papers/<name>.md`.
- [ ] Applied this skill to the relevant cluster (temporal model / hybrid-detect-track / seg-ellipse / SNN / dataset-postproc / FPGA port).
- [ ] Preserved source-linked (file:line) or paper-cited evidence from the MODULE_GUIDE / paper.
- [ ] Kept the quantitative convention (representation dims / params·FLOPs / activation / latency; accuracy = "확인 필요" if no README/paper number).
- [ ] Carried over known-limitation flags (e.g., eyegraph/event_based_gaze_tracking = 데이터셋 repo, NearEye-10000Hz 원문 미판독, SSM FPS/그래프 연산 HW 비친화).
- [ ] Produced a concrete artifact + validation evidence, and stated on-device / FPGA porting link (ESDA) where applicable.
