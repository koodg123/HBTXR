# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: event-eye-tracking-kb` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable objective (accuracy/p-error, latency, params/FLOPs, power).
- [ ] Source artifacts (task/dataset/representation/model/device), assumptions, and constraints are separated.
- [ ] Required supporting skills and the matching REF MODULE_GUIDE / paper are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] Cost numbers carry file:line evidence; accuracy (p-error 등) is cited from README/paper, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (train-eval run / on-device measurement) are explicit.
- [ ] Residual risks and next validation steps are listed.
