---
name: event-eye-tracking-kb
description: "이벤트 카메라/근안 시선·동공 추적 지식베이스. 이벤트 표현(voxel/time-bin/frame/point/graph), 시공간 모델(ConvLSTM/3ET, SSM·Mamba, Transformer, 인과 Conv3d, SNN), 출력(좌표회귀/heatmap/타원/세그), 메트릭(p-error/p10/IoU), on-device 저지연·FPGA 이식. REF/Analysis XR 코드 17 + 논문 22 라우팅. Use whenever the user works on event-based or near-eye gaze/pupil tracking — model design, event representation, dataset/metric, or on-device/FPGA deployment — even without naming a repo."
---

# Event / Near-Eye Eye Tracking Knowledge Base

## Overview

Use this skill for **event-camera / near-eye gaze·pupil tracking** model design, comparison, porting (reuse), and codebase analysis. Build transparent, decision-ready artifacts grounded in the analyzed REF corpus (XR-Eye-Tracking MODULE_GUIDEs + Papers) rather than free-form advice.

This skill complements `event-representation-builder`, `spatiotemporal-recurrent-ssm-builder`, `eyetracking-dataset-benchmark-harness`, and `pupil-output-head-and-loss`. It should produce reusable artifacts (model/representation plan, model comparison, port plan) backed by concrete MODULE_GUIDE / paper evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable objective (accuracy/p-error, latency, params/FLOPs, on-device power).
2. List source artifacts (event stream/representation, dataset, model spec, target device) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE / paper evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (representation plan vs model comparison vs port plan).

## Workflow

1. Capture target task (gaze coord / pupil center / ellipse / segmentation), dataset, event representation, temporal model, and latency/runtime contract.
2. Identify the model family and boundary: ConvLSTM/3ET, SSM·Mamba, Transformer, causal Conv3d streaming, SNN/neuromorphic, or seg+ellipse.
3. Read the relevant REF MODULE_GUIDE(s)/paper(s) via `references/ref-corpus-context.md` and extract representation/temporal/output patterns with file:line or paper evidence.
4. Plan or compare with measurable cost: event representation params, FLOPs/params/activation, latency, metric (p-error/p10/IoU).
5. Return artifacts connecting representation, temporal model, output head/metric, and on-device feasibility; flag what needs measurement to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (representation/model/port plan or model-codebase analysis) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually train/eval or on-device measurement).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis XR MODULE_GUIDEs and Papers (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Functional/accuracy correctness is separated from latency and resource claims.
- Event representation, temporal model, and output/metric definitions are explicit.
- Dataset/metric assumptions (p-error definition, subject-independent split) are named before accuracy claims.
- Cost numbers (params/FLOPs/activation/representation dims) are derived from code (shape/config) with file:line; accuracy (p-error 등) is cited from README/paper, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (event stream/representation, dataset, model spec, target device) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on training/eval runs, on-device measurements, or unavailable tools.
- A recommendation would lock the user into a brittle representation/temporal model without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE / paper evidence, quantitative conventions, and known-limitation flags. For FPGA porting of event models the most direct route is **ESDA** (event sparse FPGA) with its measured SEE companion.
