# Intake Prompt Bundle

Use `$event-eye-tracking-kb` for this request.

1. Normalize the request into a measurable objective (accuracy/p-error, latency, params/FLOPs, on-device power).
2. Identify source artifacts (task, dataset, event representation, model spec, target device) and missing inputs.
3. Select required supporting skills (`event-representation-builder`, `spatiotemporal-recurrent-ssm-builder`, `eyetracking-dataset-benchmark-harness`, `pupil-output-head-and-loss`) and the matching REF MODULE_GUIDE / paper.
4. Produce the first usable artifact (representation/model/port plan).
5. Define the verification gate (file:line / paper citation + train-eval or on-device measurement) and residual risks.
