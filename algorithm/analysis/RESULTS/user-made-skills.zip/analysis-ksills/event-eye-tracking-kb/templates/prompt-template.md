# Prompt Template

Use `$event-eye-tracking-kb` to handle the following task.

Objective:

Inputs (task / dataset / event representation / model spec / target device / MODULE_GUIDE or paper refs):

Constraints:

Required artifact (representation plan / model comparison / port plan / codebase MODULE_GUIDE):

Known facts (with file:line or paper citation):

Assumptions:

Verification evidence (file:line / paper citation / train-eval run / on-device measurement):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
