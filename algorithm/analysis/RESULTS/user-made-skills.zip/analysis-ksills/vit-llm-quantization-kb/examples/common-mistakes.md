# Common Mistakes

- Producing general quantization advice without a prompt pack or a concrete artifact.
- Quoting accuracy/latency numbers without README/report citation, or inventing eval results that do not exist in the repo (should be "확인 필요").
- Mixing bit-exact functional correctness with accuracy and HW-cost claims.
- Naming a scheme (per-tensor, integer-only) without stating the observer/calibration and nonlinear consequence.
- Forgetting to route into the relevant REF MODULE_GUIDE before inventing a new quant recipe.
- Confusing name vs reality: AMD_QTViT ("QT"=Quadratic Taylor, 양자화 아님), Mix-Quant (실제 LLM 분리서빙), UQ-ViT (=Uniform Quant), AdaTSQ/CLAMP-ViT (핵심 코드 미공개).
- Recommending an irreversible bit-width/scheme with no validation (calibration sweep, accuracy eval) path.
