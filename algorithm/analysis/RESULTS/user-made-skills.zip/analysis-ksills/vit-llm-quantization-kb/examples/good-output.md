# Good Output Example

## Prompt Pack

Skill: `vit-llm-quantization-kb`
Objective: Produce a decision-ready quant scheme / observer-bit-width / port artifact for a ViT·LLM·VLM·Diffusion·SAM model.
Inputs: model spec (dims/seq/depth/heads), bit budget, PTQ vs QAT, calibration set, target backend.
Constraints: state tool, data, target, and scope limits.
Verification: define the evidence (file:line, calibration/accuracy eval) required for signoff.

## Artifact

Structured decisions with **MODULE_GUIDE line evidence**, e.g.:
- Quant scheme: per-channel weight + per-tensor activation, INT8/INT4 (cite `…/MODULE_GUIDE.md`); nonlinear = integer-only ShiftGELU/Shiftmax or Log-Int-Softmax.
- Observer/calibration: MinMax vs MSE vs percentile vs Hessian/FIM; PTQ reparam (RepQ-ViT) or QAT (LSQ).
- Multiplier-free / DSP-friendly: shift&add (ShiftAddViT), PoT/log shift (P2-ViT/AdaLog), 1-bit XNOR (Bi-ViT) — route HW lowering to `fpga-transformer-accelerator-kb`.
- Tradeoffs and the smallest change that can be validated by calibration/eval first.

## Risks

List uncertain assumptions (e.g., accuracy at low bit, outlier sensitivity, observer choice) and the next experiment (calibration sweep, accuracy eval, bit-exact SW↔HW check) to resolve each.
