# Prompt Operations

## Prompt Pack Fields

- Skill: `vit-llm-quantization-kb`
- Objective: one sentence (design/compare/port/analyze).
- Context: model spec, bit budget, PTQ vs QAT, calibration set, target backend, MODULE_GUIDE refs.
- Constraints: scope, tools, target platform, non-goals.
- Required output: exact artifact type (quant scheme plan / observer-bit-width table / port plan / codebase MODULE_GUIDE).
- Verification: evidence needed (file:line, calibration/accuracy eval, bit-exact SW↔HW check).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (bit budget/calibration/granularity) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when model spec, bit budget, calibration set, or acceptance criteria are missing and the missing fact would change the quant scheme/cost. Never fabricate accuracy/latency numbers.
