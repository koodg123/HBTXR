# Production Playbook

## Purpose

This playbook supports `vit-llm-quantization-kb` for ViT·LLM·VLM·Diffusion·SAM 양자화 work. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to design, compare, port, or analyze (quant scheme, observer/bit-width, nonlinear lowering, codebase).
- Inputs: model spec (dims/seq/depth/heads), bit budget, PTQ vs QAT, calibration set, target backend, MODULE_GUIDE references.
- Output format: quant scheme plan, observer/bit-width comparison table, port plan, or quantization-codebase MODULE_GUIDE.
- Success metrics: accuracy drop (top-1/task metric), bit-width, activation memory, FLOPs/params, multiplier-free ratio, latency.
- Constraints: tool availability, calibration data fit, non-goals, validation limits.

## Decision Flow

- Capture model/workload, bit budget, PTQ vs QAT, calibration set, runtime/deployment contract.
- Identify the quant boundary: per-tensor vs per-channel, weight vs activation, integer-only vs mixed, nonlinear scheme (softmax/GELU/LayerNorm).
- Read the matching REF MODULE_GUIDE(s); extract PTQ/QAT/observer/nonlinear/reparam patterns with file:line.
- Compute cost statically: bit-width, FLOPs/params (shape), activation memory (array×bit), multiplier-free substitutions.
- Return artifacts linking quant scheme, accuracy/memory, and validation metrics.

## Tradeoff Questions

- Which choice would be costly to reverse (integer-only nonlinear, 2-bit/INT4, per-tensor vs per-channel)?
- Which assumption (observer choice, outlier sensitivity, accuracy at low bit) most likely invalidates the artifact?
- What is the smallest change validatable by a calibration sweep or accuracy eval now?
- Which existing skill (`hw-friendly-nonlinear-approx`, `quantization-error-analysis`, `on-device-ai`, `fpga-transformer-accelerator-kb`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need calibration/eval), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
