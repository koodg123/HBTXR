# REF Corpus Context — ViT/LLM/VLM/Diffusion/SAM Quantization

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§9 S-PyTorch: ViT-Quantization 48편). Each repo has a deep `MODULE_GUIDE.md` (6요소 + PyTorch 정량) and a 1차 요약 `<repo>.md`. Repo path: `REF/Analysis/ViT-Quantization/<repo>/MODULE_GUIDE.md`.

## Core Clusters (route to these MODULE_GUIDEs)

1. **정수전용·비선형 HW화**: `I-ViT` (정수전용 ShiftGELU/Shiftmax), `FQ-ViT` (PTF+Log-Int-Softmax), `integer-only-transformer` (I-ViT+I-BERT 다항 번들), `q-hyvit` (Q-HyViT hybrid recon), `mixed-non-linear-quantization` (I-ViT/I-BERT/FQ 비선형 함수별 직접 비교 → 시프트 근사 vs 다항식 자원·정확도 트레이드오프).
2. **PTQ 정밀화**: `PTQ4ViT` (twin uniform), `RepQ-ViT` (scale reparam 대수증명), `NoisyQuant` (bias 흡수→MAC 불변), `AdaLog` (적응 로그밑→시프트+LUT), `APHQ-ViT` (APH+MLP recon), `FIMA-Q` (FIM-DPLR), `CLAMP-ViT` (평가전용·핵심코드 주의), `psaq-vit` (data-free 합성 보정), `postcalibration4quantization` (ONNX 영샷 재보정).
3. **저비트·곱셈치환**: `ShiftAddViT` (shift&add ~49×↓), `P2-ViT` (PoT 시프트), `Bi-ViT` (1-bit XNOR), `OFQ` (oscillation 억제), `Q-ViT-DeiT` (LSQ+head-wise bit).
4. **outlier·등가변환**: `outlier-free-transformers` (clipped softmax+gated attn), `transformer-quantization` (Qualcomm PEG 인프라), `UQ-ViT` (=Uniform Quant, 명칭 주의), `AdaTSQ` (DiT temporal-sensitivity, **코드 미공개**).
5. **FlashAttention 정수**: `int-flashattention`, `INT8-Flash-Attention-FMHA-Quantization`, `qflash` (모두 GEMM만 INT8·softmax FP32 → I-ViT IntSoftmax 결합 시 완전 정수 attention 권고).
6. **확장 도메인**: VLM/VLA `MBQ` (AWQ 확장 모달리티 균형)·`qvlm` (Q-VLM cross-layer dependency)·`QuantVLA` (GR00T DuQuant W4A8); Diffusion `Q-DiT` (group+evolutionary)·`Q-VDiT` (LoRA codebook+temporal)·`ViDiT-Q` (smooth+dynamic W4A8); SAM `ptq4sam` (BIG+AGQ)·`SAQ-SAM` (PCC/PAR 의미정렬); Detector `Q-DETR` (LSQ+W*A8, DRD 코드 부재); 기타 `PQV-Mobile` (dynamic quant+프루닝)·`FPQVAR` (VAR FP4/FP6 비균일 grid+Hadamard)·`mimiq` (data-free W4A4+head 증류).
7. **백본/특수(주의)**: `Castling-ViT` (linear-angular ~6.1×↓), `RepViT` (reparam 단일 conv), `Next-ViT` (NCB/NTB), `EdgeVisionTransformer` (프루닝+외부런타임 PTQ), `AMD_QTViT` (**"QT"=Quadratic Taylor, 양자화 아님** — EfficientViT FP), `M3ViT` (MoE active/total), `Mix-Quant` (**실제 LLM 분리서빙·명칭 오분류**).

(전체 목록·정량 요약은 `INDEX.md` §9 (S-PyTorch) 표 참조.)

## 수치 규약 (정량 도출, 정적)
- PyTorch는 FLOPs / params / activation memory / 비트폭·observer로 치환. bit-width = quantizer 설정, params/activation memory = shape×bit, observer = MinMax/MSE/percentile/Hessian/FIM. 정확도(top-1/task metric)·지연 실측은 README/report 동봉 시만 인용, 없으면 "확인 필요".

## Reusable Verification Questions
- 타깃 모델/워크로드 shape(seq·dim·depth·heads)와 비트폭(INT8/INT4/2-bit·mixed)은?
- PTQ인가 QAT인가, 보정 데이터셋은 무엇인가?
- 양자화 입도는 per-tensor인가 per-channel인가, weight/activation 분리는?
- observer/calibration은 무엇(MinMax/MSE/percentile/Hessian/FIM)이며 reparam·LSQ 경로는?
- 비선형(softmax/GELU/LayerNorm) 정수화 또는 곱셈기-free 치환이 필요한가?
- 1차 지표는 accuracy drop / bit-width / activation memory / HW cost 중 무엇?

## Why This Skill Is Relevant
REF 코퍼스의 ViT-Quantization 48편이 PTQ/QAT·observer·정수전용 비선형·곱셈기 제거·outlier 대응·확장 도메인(VLM/Diffusion/SAM)을 반복적으로 다루며, file:line 근거로 양자화 의사결정을 뒷받침한다. FPGA 이식 시 `fpga-transformer-accelerator-kb`와 HG-PIPE 데이터패스를 baseline으로 바인딩한다.
