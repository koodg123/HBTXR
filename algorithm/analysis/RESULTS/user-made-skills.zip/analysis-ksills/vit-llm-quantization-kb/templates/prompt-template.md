# Prompt Template

Use `$vit-llm-quantization-kb` to handle the following task.

Objective:

Inputs (model spec / bit budget / PTQ or QAT / calibration set / target backend / MODULE_GUIDE refs):

Constraints:

Required artifact (quant scheme plan / observer-bit-width comparison / port plan / codebase MODULE_GUIDE):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / calibration-accuracy eval / bit-exact SW↔HW check):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
