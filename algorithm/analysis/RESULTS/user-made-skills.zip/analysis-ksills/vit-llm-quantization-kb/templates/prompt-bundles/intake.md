# Intake Prompt Bundle

Use `$vit-llm-quantization-kb` for this request.

1. Normalize the request into a measurable quantization objective (accuracy drop/bit-width/activation memory/HW cost).
2. Identify source artifacts (model spec, bit budget, calibration set, target backend) and missing inputs.
3. Select required supporting skills (`hw-friendly-nonlinear-approx`, `quantization-error-analysis`, `on-device-ai`, `fpga-transformer-accelerator-kb`) and the matching REF MODULE_GUIDE.
4. Produce the first usable artifact (quant scheme / observer-bit-width / port plan).
5. Define the verification gate (file:line + calibration/accuracy eval) and residual risks.
