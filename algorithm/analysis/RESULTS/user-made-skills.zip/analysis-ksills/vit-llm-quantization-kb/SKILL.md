---
name: vit-llm-quantization-kb
description: "ViT/LLM/VLM/Diffusion/SAM 양자화 지식베이스. PTQ/QAT, INT8/INT4/2-bit, integer-only(ShiftGELU/Shiftmax/Log-Int-Softmax), per-tensor/channel, observer(MinMax/MSE/percentile/Hessian/FIM), reparameterization, smooth/dynamic quant, DSP-friendly·곱셈기-free. REF/Analysis ViT-Quantization 48편 MODULE_GUIDE 라우팅. Use whenever the user quantizes or analyzes a ViT/LLM/VLM/diffusion/SAM model, chooses bit-width/observer/nonlinear scheme, or ports a quantization technique to FPGA — even if no repo is named."
---

# ViT/LLM Quantization Knowledge Base

## Overview

Use this skill for **ViT/LLM/VLM/Diffusion/SAM 양자화** design, comparison, porting, and codebase analysis. Build transparent, decision-ready artifacts grounded in the analyzed REF corpus (ViT-Quantization MODULE_GUIDEs) rather than free-form advice.

This skill complements `hw-friendly-nonlinear-approx`, `quantization-error-analysis`, and `on-device-ai`. It should produce reusable artifacts (quant scheme plan, observer/bit-width comparison, port plan) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable quantization objective (accuracy drop/bit-width/activation memory/HW cost).
2. List source artifacts (model spec, calibration data, target backend, bit budget) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (quant scheme plan vs observer/bit-width comparison vs port plan).

## Workflow

1. Capture model/workload (dims, seq, depth, heads), datatype/bit budget, PTQ vs QAT, calibration set, and runtime/deployment contract.
2. Identify the quantization boundary: per-tensor vs per-channel, weight vs activation, nonlinear scheme (softmax/GELU/LayerNorm), integer-only vs mixed.
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md` and extract PTQ/QAT/observer/nonlinear/reparam patterns with file:line evidence.
4. Plan or compare with measurable cost: bit-width, observer (MinMax/MSE/percentile/Hessian/FIM), FLOPs/params/activation memory, multiplier-free substitutions, DSP-friendliness.
5. Return artifacts connecting quant scheme, accuracy/memory, and validation metrics; flag what needs calibration/eval to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (quant scheme / observer-bit-width comparison / port plan or quantization-codebase analysis) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually calibration/accuracy eval).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis ViT-Quantization MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness (bit-exact SW match) is separated from accuracy and HW-cost claims.
- Datatype, bit-width, observer, and per-tensor/channel granularity constraints are explicit.
- PTQ vs QAT and calibration-set assumptions are named before accuracy claims.
- Cost numbers (FLOPs/params/activation memory/bit-width) are derived from code/shape with file:line; accuracy/latency measurements are cited only if the README/report has them, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (model spec, calibration data, bit budget, target backend) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on calibration/accuracy eval, target hardware, or unavailable tools.
- A recommendation would lock the user into a brittle quant scheme without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. The corpus covers **ViT-Quantization 48편** (`REF/Analysis/INDEX.md` §9, S-PyTorch); FPGA porting of a quantization technique should bind `fpga-transformer-accelerator-kb` and HG-PIPE as the baseline datapath.
