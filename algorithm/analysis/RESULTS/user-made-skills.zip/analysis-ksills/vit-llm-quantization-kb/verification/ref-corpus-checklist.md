# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s).
- [ ] Applied this skill to the relevant quantization cluster (integer-only nonlinear / PTQ 정밀화 / 저비트·곱셈치환 / outlier·등가변환 / FlashAttention 정수 / 확장 도메인 / 백본·특수).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE.
- [ ] Kept the quantitative convention (FLOPs/params/activation memory/bit-width·observer; accuracy/latency = "확인 필요" if no README/report).
- [ ] Carried over known-limitation flags (e.g., AMD_QTViT=Quadratic Taylor 양자화 아님, Mix-Quant=실제 LLM 분리서빙, UQ-ViT=Uniform, AdaTSQ/CLAMP-ViT 코드 미공개).
- [ ] Produced a concrete artifact + validation evidence, and stated FPGA/HG-PIPE porting relevance where applicable.
