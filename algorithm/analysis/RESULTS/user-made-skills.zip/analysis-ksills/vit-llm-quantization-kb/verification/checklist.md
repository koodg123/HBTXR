# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: vit-llm-quantization-kb` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable quantization objective.
- [ ] Source artifacts (model/bit budget/PTQ-QAT/calibration/granularity), assumptions, and constraints are separated.
- [ ] Required supporting skills and the matching REF MODULE_GUIDE are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] Cost numbers (FLOPs/params/activation memory/bit-width) carry file:line evidence; accuracy/latency is cited only if a README/report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (calibration/accuracy eval / bit-exact SW↔HW check) are explicit.
- [ ] Residual risks and next validation steps are listed.
