# Prompt Template

Use `$hgpipe-porting-advisor` to handle the following task.

Objective (Track A efficiency / Track B XR pivot):

Inputs (HG-PIPE module / model spec / target board+clock / datatype / donor MODULE_GUIDE refs):

Constraints:

Required artifact (Track A efficiency plan / Track B XR pivot plan / port checklist):

Known facts (with roadmap or MODULE_GUIDE file:line):

Assumptions:

Verification evidence (MODULE_GUIDE file:line / bit-exact C-sim / synthesis PPA / on-device SEE):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
