# Intake Prompt Bundle

Use `$hgpipe-porting-advisor` for this request.

1. Normalize the request into a measurable porting objective (Track A throughput/area/power, or Track B latency/gaze-accuracy).
2. Identify the HG-PIPE baseline constraint addressed (on-chip→DeiT-Tiny, classification-only, DSP headroom, 3-pass softmax, VCK190-fixed) and missing inputs.
3. Select required supporting skills (`fpga-transformer-accelerator-kb`, `hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, `event-eye-tracking-kb`) and the donor MODULE_GUIDE via the porting roadmap.
4. Produce the first usable artifact (Track A efficiency plan / Track B XR pivot plan / port checklist).
5. Define the verification gate (MODULE_GUIDE file:line + bit-exact C-sim + synthesis PPA + on-device SEE) and residual risks.
