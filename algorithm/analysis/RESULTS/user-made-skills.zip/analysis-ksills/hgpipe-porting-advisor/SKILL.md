---
name: hgpipe-porting-advisor
description: "HG-PIPE(VCK190·DeiT-Tiny·3-bit·전계층 온칩 하이브리드-그레인 파이프라인 ViT FPGA 가속기) 이식·확장 자문. Track A 효율 극대화(DSP packing, integer 비선형, 1-pass attention, 비트폭) + Track B XR 이벤트 시선추적 전환(이벤트 front-end·회귀 head·스트리밍·에지 보드·측정). REF/Analysis 로드맵·MODULE_GUIDE 라우팅. Use whenever the user wants to improve, scale, or repurpose HG-PIPE or a hybrid-grained-pipeline ViT FPGA accelerator, or port a technique into it."
---

# HG-PIPE Porting Advisor

## Overview

Use this skill to advise on **porting and extending HG-PIPE**, the full-on-chip hybrid-grained-pipeline ViT FPGA accelerator (VCK190·DeiT-Tiny·3-bit weights·LUT nonlinear·SpinalHDL layer chain). Produce decision-ready porting artifacts grounded in the analyzed REF roadmap and MODULE_GUIDE evidence rather than free-form advice.

This skill complements `fpga-transformer-accelerator-kb`, `hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, and `event-eye-tracking-kb`. It should produce reusable artifacts (Track A efficiency plan, Track B XR pivot plan, port checklist) backed by concrete roadmap and MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable porting objective (Track A throughput/area/power, or Track B latency/gaze-accuracy).
2. List source artifacts (HG-PIPE module, model spec, target board+clock) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from roadmap / MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (Track A efficiency plan vs Track B XR pivot plan vs port checklist).

## Workflow

1. Diagnose the HG-PIPE baseline constraint being addressed (on-chip-only → DeiT-Tiny fixed, classification-only, DSP efficiency headroom, 3-pass softmax, VCK190-fixed).
2. Decide the track: Track A (same model, efficiency) keeps the pipeline skeleton and edits layer-kernel internals; Track B (XR pivot) reuses the step0/step1 codegen + BlockSequence chain and swaps/adds kernels.
3. Read the relevant REF source(s) via `references/ref-corpus-context.md` — the porting roadmap first, then the donor MODULE_GUIDE(s) — and extract the integration point (`matmul.h`, `softmax.h`, `patch_embed.h`, `head.h`, …) with evidence.
4. Plan with measurable cost: MAC density (DSP packing), pass count, LUT size, bit-width, latency/throughput, board fit.
5. Return artifacts connecting the donor technique, the HG-PIPE integration point, and validation; flag what needs synthesis/on-device to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (Track A efficiency plan / Track B XR pivot plan / port checklist) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually synthesis PPA / on-device measurement).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into the porting roadmap and donor MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness is separated from performance and resource claims.
- Track (A efficiency vs B XR pivot) and the HG-PIPE constraint being addressed are explicit.
- Target board/clock and datatype/bit-width assumptions are named before scheduling or cost claims.
- Cost numbers (MAC density, pass count, LUT/buffer size) are derived from the donor MODULE_GUIDE and the HG-PIPE integration point with file:line; synthesis PPA is cited only if a report exists, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (HG-PIPE module, model spec, target board/clock) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on synthesis PPA, on-device measurements, or unavailable tools.
- A recommendation would lock the user into a brittle dataflow (e.g., sparse paradigm vs HG-PIPE dense pipeline) without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the roadmap/MODULE_GUIDE line-evidence, quantitative conventions, and known-constraint flags. The project baseline accelerator is **HG-PIPE**; porting/extension is governed by `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.
