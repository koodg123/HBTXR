# Common Mistakes

- Producing general porting advice without a prompt pack or a concrete artifact.
- Not naming which HG-PIPE constraint (on-chip / classification-only / DSP / 3-pass / VCK190) the port addresses.
- Quoting throughput/area/power gains without MODULE_GUIDE file:line evidence, or citing synthesis PPA that does not exist (should be "확인 필요"; all PPA needs post-port synthesis).
- Mixing functional correctness (bit-exact C-sim) with performance and resource claims.
- Naming a donor technique (DSP packing, 1-pass softmax, event front-end) without stating the HG-PIPE integration point (`matmul.h` / `softmax.h` / `patch_embed.h` / `head.h`).
- Forgetting to consult the porting roadmap (Track A/B, candidate table, Phase, model-selection ranking) before inventing a port.
- For Track B, forcing a sparse event model (ESDA) onto the HG-PIPE dense pipeline instead of starting with a dense-event + ViT model (roadmap §3.1, risk register).
- Recommending an irreversible change (3→2 bit, VCK190→edge) with no 3-stage validation (bit-exact C-sim → step1 PPA → on-device SEE).
