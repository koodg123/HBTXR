# Good Output Example

## Prompt Pack

Skill: `hgpipe-porting-advisor`
Objective: Apply DSP packing (Track A) to HG-PIPE `matmul.h`, then a minimal XR head swap (Track B) for an event eye-tracking PoC.
Inputs: HG-PIPE baseline (VCK190, DeiT-Tiny, 3-bit weights), donor MODULE_GUIDEs, target (start VCK190 → later edge), datatype 3-bit weights.
Constraints: keep the BlockSequence pipeline skeleton; bit-exact regression must pass; no fabricated PPA.
Verification: define the evidence (MODULE_GUIDE file:line, bit-exact C-sim, synthesis PPA, on-device SEE) required for signoff.

## Artifact

Structured porting decisions with **roadmap + MODULE_GUIDE evidence**, e.g.:

- **Track A — A1 DSP packing** (constraint #3 DSP headroom): integrate at `matmul.h` `matmul_step2_mac` (`bind_op impl=dsp`). Pack multiple 3-bit weight MACs per DSP using `CNN-Accel/Uint-Packing-master` segment layout; carry the carry/guard correction `(p>>1)+(p&1)` verbatim (cite `Uint-Packing-master/MODULE_GUIDE.md`). Expected: higher MAC density → same DSP for more throughput, or fewer DSP. Pipeline skeleton unchanged.
- **Track B — B2 head swap** (constraint #2 classification-only): replace `head.h` 1000-class classifier with a small (x,y) coordinate-regression FC; replace `patch_embed.h` with an event-token/frame embedding (B1). Keep ATTN/MLP kernels as-is — pick a ViT eye-tracking model (best pipeline reuse; cite roadmap §3.1, `XR/EX-Gaze/MODULE_GUIDE.md`).
- **Phase placement**: A1 → Phase P1; head/front-end PoC → Phase P3 (after Track A frees resources).
- Tradeoff and the smallest change validatable first: A1 alone, bit-exact `check_stream` regression on one GEMM tile before re-synthesis.

## Risks

List uncertain assumptions (DSP packing carry/guard correctness; 3-bit accuracy on coordinate regression vs classification; on-chip fit when porting to edge) and the next experiment (bit-exact C-sim → step1 synthesis PPA → on-device SEE latency+power) to resolve each. All PPA numbers are "확인 필요" until step1 is re-run.
