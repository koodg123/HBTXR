# REF Corpus Context — HG-PIPE Porting & Extension

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW, §9 S-PyTorch). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) and a 1차 요약 `<repo>.md`.

## Baseline (read first)

- **Baseline diagnosis**: `Transformer-Accel/HG-PIPE/MODULE_GUIDE.md` (전계층 온칩, 3-bit 가중치, LUT 비선형, SpinalHDL `BlockSequence` 체인, output-stationary `matmul.h`, 3-pass `softmax.h`). 5가지 제약 = 이식 동기:
  1. **온칩 상주 전제 → DeiT-Tiny급만 수용** (더 큰 ViT/긴 시퀀스 불가).
  2. **이미지 분류 전용** (이벤트 입력·시선추적 헤드 없음).
  3. **DSP 효율 여지** (output-stationary MAC가 3-bit를 DSP당 1곱으로만 쓰면 비효율 — 패킹 미적용 추정, 합성 리포트로 확인 필요).
  4. **attention 3-pass softmax** (버퍼·패스 수 부담, 긴 시퀀스에서 악화).
  5. **VCK190 고정** (에지/저전력 타깃 시 자원 재맞춤 필요).

## Roadmap (the route)

- **Porting roadmap (핵심)**: `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md` — Track A/B, Phase 0~5, 이식 후보 표(A1~A5, B1~B6), 모델 선택 순위, 리스크 레지스터, Quick wins. 항상 여기서 후보·통합 지점·Phase를 먼저 확인.

## Donor MODULE_GUIDEs (route to these)

- **Track A → 효율 극대화**
  - DSP packing(A1): `CNN-Accel/Uint-Packing-master/MODULE_GUIDE.md`(4-세그먼트, 보정식 `(p>>1)+(p&1)`), `ViT-Accelerator/TATAA/MODULE_GUIDE.md`(INT8↔bf16 변형 PE) → `matmul.h` MAC(`bind_op impl=dsp`).
  - integer 비선형(A2): `ViT-Quantization/FQ-ViT/MODULE_GUIDE.md`(Log-Int-Softmax), `ViT-Quantization/I-ViT/MODULE_GUIDE.md`(ShiftGELU/Shiftmax) → `softmax.h`/`gelu.h`/`layernorm.h` LUT.
  - 1-pass softmax(A3): `ViT-Accelerator/AURA-FlashAttention-AISC-Accelerator/MODULE_GUIDE.md`(곱셈기-free exp + 1-pass + 트리리덕션) → `softmax.h`(3-pass) + `attn.h` dynamic matmul.
  - 비트폭(A4): `ViT-Quantization/AdaLog/MODULE_GUIDE.md`(로그밑→시프트+LUT), `ViT-Quantization/P2-ViT/MODULE_GUIDE.md`(PoT 시프트) → `quant.h` + `step0` 통계.
- **Track B → XR 이벤트 시선추적**
  - 이벤트 sparse/front-end(B1): `CNN-Accel/ESDA/MODULE_GUIDE.md`(이벤트 sparse, token+mask), `XR/event_based_gaze_tracking/MODULE_GUIDE.md`(9B BHHI 포맷) → `patch_embed.h` 대체.
  - 시간 모델(B3): `XR/cb-convlstm-eyetracking/MODULE_GUIDE.md`(3ET delta sparsity), `XR/ais2024/MODULE_GUIDE.md`(TENNs-Eye 인과 Conv3d) → `attn.h`/`mlp.h` 또는 신규 temporal 커널.
  - 모델 선택 참고: `XR/EX-Gaze/MODULE_GUIDE.md`(MobileViTv2 선형 attention, 파이프라인 매핑성 최상).
  - 회귀 head(B2): `XR/FACET/MODULE_GUIDE.md`(타원+GWD), `XR/E-Track/MODULE_GUIDE.md`(세그+타원피팅) → `head.h`(classifier) 대체로 (x,y) 좌표 회귀.
  - on-device 측정(B5): `CNN-Accel/SEE/MODULE_GUIDE.md`(ZCU102 PYNQ 지연 + INA226 18레일 전력 동시측정) → board flow(step3/step4).

(전체 목록·정량 요약은 `INDEX.md` §8/§9 표, 모델 선택 순위는 로드맵 §3.1 참조.)

## 수치 규약 (정량 도출, 정적)
- MAC density = 한 DSP에 들어가는 동시 곱 수(패킹 세그먼트) · pass count = softmax 패스 수(3→1) · LUT size = 비선형 테이블 엔트리 · bit-width = 가중치/활성 비트. 합성 PPA(LUT/DSP/BRAM/Fmax)는 리포트 동봉 시만 인용, 없으면 "확인 필요". 본 분석 환경 합성 미실행 → 모든 PPA 수치는 이식 후 합성 검증 필요.

## 검증 (3단)
- **비트정합 C-sim**: HG-PIPE 내장 `check_stream`(C-sim) + SW 골든(PyTorch) ↔ HLS/RTL 비트 비교. 각 이식 커널마다.
- **step1 합성 PPA**: `step1` 재합성 → LUT/FF/DSP/BRAM/URAM·달성 주파수, baseline 대비 회귀(`fpga-resource-power-reporting` 양식). 없으면 "확인 필요".
- **on-device**: `SEE` 하네스로 ZCU102 실측 지연+전력(INA226 18레일).

## Reusable Verification Questions
- 어떤 HG-PIPE 제약(온칩/분류전용/DSP/3-pass/VCK190)을 푸는가?
- Track A(효율)인가 Track B(XR 전환)인가, 통합 지점(`matmul.h`/`softmax.h`/`patch_embed.h`/`head.h`)은?
- 도너 기법의 출처 MODULE_GUIDE와 핵심 수치(MAC density/pass/LUT/bit)는?
- 검증 가능한 최소 단위(대표 GEMM 타일/1 head/1 레이어 비트정합)는?
- 1차 지표는 Track A throughput/area/power, Track B latency/gaze-accuracy 중 무엇?

## Why This Skill Is Relevant
HG-PIPE는 본 프로젝트의 기준선 가속기이며, REF 코퍼스 112편(HW 47 + S-PyTorch 65) MODULE_GUIDE가 Track A 효율 기법과 Track B XR 시선추적 기법의 도너 풀을 이룬다. 이 스킬은 로드맵을 라우터로 삼아 도너 기법을 HG-PIPE 통합 지점에 file:line 근거로 연결한다.
