# Production Playbook

## Purpose

This playbook supports `hgpipe-porting-advisor` for porting and extending HG-PIPE (full-on-chip hybrid-grained-pipeline ViT FPGA accelerator). It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to improve, scale, or repurpose (Track A efficiency on the same DeiT-Tiny model, or Track B XR event eye-tracking pivot).
- Inputs: HG-PIPE module/integration point, model spec (dims/seq/depth/heads), datatype/bit-width, target board + clock, donor MODULE_GUIDE references.
- Output format: Track A efficiency plan, Track B XR pivot plan, or port checklist.
- Success metrics: Track A = throughput/area/power; Track B = latency (avg + p95/p99), gaze p-error/p10, board fit.
- Constraints: tool availability, board fit (VCK190 vs edge ZCU102/Ultra96), non-goals, validation limits.

## Decision Flow

- Diagnose which HG-PIPE constraint the request targets: on-chip-only (DeiT-Tiny fixed), classification-only, DSP efficiency headroom, 3-pass softmax, VCK190-fixed.
- Choose the track. Track A keeps the BlockSequence pipeline skeleton and edits layer-kernel internals; Track B reuses the step0/step1 codegen + chain and swaps `patch_embed.h`/`head.h` (and optionally adds temporal kernels).
- Read the porting roadmap (`HG-PIPE_PORTING_ROADMAP.md`) for the candidate table, then the donor MODULE_GUIDE(s); extract the integration point with file:line.
- Compute cost statically: MAC density (DSP packing), pass count (softmax), LUT size (nonlinear), bit-width, buffer depth.
- Return artifacts linking donor technique → HG-PIPE integration point → validation metrics.

## Tradeoff Questions

- Which change would be costly to reverse (sparse event dataflow vs HG-PIPE dense pipeline; 3→2 bit weight; VCK190→edge re-fit)?
- Which assumption (DSP packing carry/guard, low-bit accuracy, on-chip fit on edge) most likely invalidates the artifact?
- What is the smallest change validatable by bit-exact C-sim (`check_stream`) or step1 synthesis now?
- Which existing skill (`fpga-transformer-accelerator-kb`, `hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, `event-eye-tracking-kb`) should be bound first?
- For Track B: which eye-tracking model maps best to the feedforward pipeline (ViT eye-tracking ≫ TENNs-Eye causal-streaming > 3ET delta-sparsity > ESDA sparse)?

## Output Standard

Output contains the artifact, evidence (roadmap/MODULE_GUIDE file:line + which numbers need synthesis/on-device), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
