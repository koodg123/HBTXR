# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md`, opened `HG-PIPE_PORTING_ROADMAP.md`, and the matching donor `MODULE_GUIDE.md`(s).
- [ ] Identified the HG-PIPE baseline constraint and the track (A efficiency / B XR pivot) from the roadmap.
- [ ] Mapped the donor technique to its HG-PIPE integration point (`matmul.h` / `softmax.h` / `attn.h` / `quant.h` / `patch_embed.h` / `head.h`).
- [ ] Preserved source-linked (file:line) evidence from the roadmap and donor MODULE_GUIDE.
- [ ] Kept the quantitative convention (MAC density / pass count / LUT size / bit-width; synthesis PPA = "확인 필요" if no report; all PPA needs post-port synthesis).
- [ ] Carried over known-constraint flags (on-chip-only, H=3 hardcoded heads, synthesis-time constant weights, dense-vs-sparse paradigm mismatch).
- [ ] Produced a concrete artifact + 3-stage validation (bit-exact C-sim + step1 PPA + on-device SEE), and stated the Phase (P0~P5) it belongs to.
