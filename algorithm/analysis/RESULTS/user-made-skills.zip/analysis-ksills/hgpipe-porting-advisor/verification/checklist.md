# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: hgpipe-porting-advisor` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable porting objective.
- [ ] The HG-PIPE baseline constraint addressed (on-chip / classification-only / DSP / 3-pass / VCK190) is named.
- [ ] The track (A efficiency vs B XR pivot) and the HG-PIPE integration point are explicit.
- [ ] Required supporting skills and the donor MODULE_GUIDE (via the porting roadmap) are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] Cost numbers (MAC density / pass count / LUT size / bit-width) carry roadmap or MODULE_GUIDE file:line evidence; synthesis PPA is cited only if a report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (bit-exact C-sim / step1 synthesis / on-device SEE) are explicit.
- [ ] Residual risks and next validation steps are listed.
