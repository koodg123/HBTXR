# Prompt Operations

## Prompt Pack Fields

- Skill: `hgpipe-porting-advisor`
- Objective: one sentence (Track A efficiency / Track B XR pivot).
- Context: HG-PIPE constraint addressed, model spec, datatype/bit-width, target board+clock, integration point, donor MODULE_GUIDE refs.
- Constraints: scope, tools, target platform (VCK190 vs edge), non-goals.
- Required output: exact artifact type (Track A efficiency plan / Track B XR pivot plan / port checklist).
- Verification: evidence needed (MODULE_GUIDE file:line, bit-exact C-sim, synthesis PPA, on-device SEE).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml` (efficiency-port-reviewer / xr-pivot-reviewer / verification-ppa-reviewer).
3. Revise when reviewers find missing constraints (board/clock/datatype/track) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when the HG-PIPE constraint, track, model spec, datatype, target board, or acceptance criteria are missing and the missing fact would change the integration point or cost. Never fabricate synthesis PPA or on-device numbers.
