# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: ref-accel-corpus-router` and a clear, trigger-rich description (KO+EN, "use first" routing intent).
- [ ] The output starts from a prompt pack and a single classified question type.
- [ ] Named cues (repo/paper/technique/board/category) and intent assumptions are separated.
- [ ] The single best specialized `*-kb` skill is named, with a fallback for mixed intent.
- [ ] The MODULE_GUIDE path(s) and category are resolved from `INDEX.md` (§8 HW / §9 S-PyTorch), not invented.
- [ ] Counts carry INDEX evidence (HW 47 + S-PyTorch 65 = 112); unverifiable claims marked "확인 필요".
- [ ] The routing decision is directly usable by another Worker (target skill + path + next step).
- [ ] Ambiguity, missing material, and name-vs-reality traps are listed as residual risks.
