# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and consulted `INDEX.md` (§8 HW / §9 S-PyTorch) for the route.
- [ ] Classified the request into one question type and the matching corpus category.
- [ ] Resolved the MODULE_GUIDE path(s) from INDEX (no invented path); marked source-absent/planned-only as "확인 필요".
- [ ] Named the single best `*-kb` skill (+ fallback) and any planning/roadmap doc (`_DEEP_ANALYSIS_PLAN*`, `_SKILL_CREATION_PLAN`, `HG-PIPE_PORTING_ROADMAP`, `_VERIFICATION`).
- [ ] Preserved the quantitative convention (HW 47 + S-PyTorch 65 = 112; category sizes from INDEX).
- [ ] Carried over known traps (name-vs-reality mismatch, source-absent repos) and stated HG-PIPE relevance / porting link where applicable.
