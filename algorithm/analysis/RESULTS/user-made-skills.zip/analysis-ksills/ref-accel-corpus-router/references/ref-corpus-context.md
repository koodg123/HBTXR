# REF Corpus Context — Index / Router for the REF/Analysis Corpus

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW, §9 S-PyTorch). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) and a 1차 요약 `<repo>.md`.
Role: this skill is the **인덱스/라우터** — classify the question, then hand off to one specialized `*-kb` skill + the matching MODULE_GUIDE. Do not solve the domain task here.

## 1. Routing Table — 6 전문 스킬 ↔ 주제·카테고리

| 전문 스킬 | 다루는 주제 | REF 카테고리(폴더) | 질문 신호(예) |
|---|---|---|---|
| `fpga-transformer-accelerator-kb` | FPGA/HLS/RTL ViT·Transformer·LLM 가속기 datapath/dataflow/mapping, systolic GEMM, attention/FlashAttention datapath, 멀티-SLR/HBM 스케일업 | ViT-Accelerator, Transformer-Accel | "FlashAttention datapath", "systolic GEMM 매핑", "weight-stationary vs streaming", "TAPA/RapidStream 멀티-SLR" |
| `vit-llm-quantization-kb` | ViT/LLM/VLM/Diffusion/SAM 양자화(PTQ/QAT), INT8/INT4/2-bit, integer-only 비선형, observer/reparam, smooth/dynamic | ViT-Quantization | "ViT INT8 PTQ", "ShiftGELU/Log-Int-Softmax", "observer 선택", "SpinQuant/Hadamard outlier" |
| `hw-nonlinear-dsp-packing-kb` | softmax/GELU/LayerNorm/exp/recip/rsqrt의 LUT·시프트·다항 근사, DSP packing(1 DSP 다중 저비트 MAC), carry 보정, fuse quantizer | 교차(ViT-Accel/Transformer-Accel/CNN-Accel/Others) | "DSP packing 비트배치", "곱셈기-free exp", "LUT 크기 산정", "dyadic requant" |
| `event-eye-tracking-kb` | 이벤트/근안 시선·동공 추적: 이벤트 표현, 시공간 모델(ConvLSTM/SSM/Transformer/Conv3d/SNN), 출력/메트릭, on-device 저지연 | XR-Eye-Tracking/Codebase, Papers | "이벤트 시선추적 저지연 모델", "voxel/time-bin 표현", "p10/IoU 메트릭", "3ET/TENNs-Eye/Mamba" |
| `sparse-cnn-systolic-accel-kb` | 희소(SpMV/SpMM), systolic GEMM(Versal AIE/DSP, OS), CNN 가속, DSP packing(UltraNet/DAC-SDC, 4w4a), im2col, 이벤트 sparse CNN | CNN-Accel, Others | "HBM SpMV shuffle network", "UltraNet 4w4a packing", "Versal AIE GEMM", "동적 프루닝 dataflow" |
| `hgpipe-porting-advisor` | 본 프로젝트 baseline HG-PIPE 설계 이해·개선·이식, 전계층 온칩 파이프라인 3-bit/LUT 비선형/SpinalHDL 체인 | Transformer-Accel/HG-PIPE + 로드맵 | "HG-PIPE 개선", "HG-PIPE 이식/확장", "전계층 파이프라인 baseline" |

> 혼합 의도(예: "양자화된 attention 가속기")는 1차=datapath(`fpga-transformer-accelerator-kb`), 2차=양자화(`vit-llm-quantization-kb`)로 듀얼 라우팅하고 fallback을 명시.

## 2. REF/Analysis 디렉토리 지도

- `INDEX.md` — 마스터 카탈로그/교차분석. **§8 HW MODULE_GUIDE**(가속기 47), **§9 S-PyTorch MODULE_GUIDE**(양자화+XR 65). 라우팅의 1차 원천.
- 카테고리 폴더: `ViT-Accelerator/`(21), `ViT-Quantization/`(48), `Transformer-Accel/`(32, 고유24+cross-ref8), `CNN-Accel/`(18), `Others/`(11), `XR-Eye-Tracking/Codebase/`(17), `Papers/`(22). 각 repo에 `MODULE_GUIDE.md` + `<repo>.md`.
- 계획문서: `_DEEP_ANALYSIS_PLAN.md`(HW), `_DEEP_ANALYSIS_PLAN_SPYTORCH.md`(알고리즘), `_SKILL_CREATION_PLAN`(스킬화 계획).
- 로드맵: `HG-PIPE_PORTING_ROADMAP.md`(baseline 이식·확장).
- 검증: `_VERIFICATION.md`(커버리지·품질 검증 리포트).

## 3. 질문 유형 → 어느 스킬/문서 (라우팅 규칙)

- "DSP packing 비트배치 / 1 DSP 다중 MAC" → `hw-nonlinear-dsp-packing-kb` (`CNN-Accel/Uint-Packing-master`, `CNN-Accel/AnyPackingNet-main`, `Transformer-Accel/Diff-DiT`).
- "softmax/GELU/LayerNorm 정수·LUT·시프트화" → `hw-nonlinear-dsp-packing-kb` (HW화) 또는 `vit-llm-quantization-kb` (알고리즘 I-ViT/FQ-ViT). 구현이면 전자, 알고리즘 선택이면 후자.
- "이벤트 시선추적 저지연 모델" → `event-eye-tracking-kb` (`XR-Eye-Tracking/Codebase/ais2024` TENNs-Eye, `…/cb-convlstm-eyetracking` 3ET).
- "ViT/LLM 양자화 비트폭/observer/방법" → `vit-llm-quantization-kb` (`ViT-Quantization/<repo>`).
- "FlashAttention / systolic GEMM / dataflow 비교" → `fpga-transformer-accelerator-kb` (`ViT-Accelerator/AURA-FlashAttention-AISC-Accelerator`, `ViT-Accelerator/ViT-FPGA-TPU`).
- "HBM SpMV / SpMM / UltraNet·DAC-SDC packing / Versal AIE GEMM" → `sparse-cnn-systolic-accel-kb` (`Others/HiSparse`, `CNN-Accel/dac_sdc_2022_champion-master`, `Others/acap-gemm-sa`).
- "HG-PIPE 개선 / 이식 / 확장" → `hgpipe-porting-advisor` (`Transformer-Accel/HG-PIPE/MODULE_GUIDE.md`, `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`).
- "어디에 X 분석이 있나 / 무엇을 분석했나 / 어떤 repo·논문이 관련 있나" → 본 라우터에서 `INDEX.md` §8/§9로 경로 해소 후 해당 스킬로 핸드오프.

## 4. 총계 (INDEX 근거)

- **심층 MODULE_GUIDE 총계: 112편 = HW 가속기 47 + S-PyTorch 65** (§8 HW 47 = Phase1 19 + Phase2 12 + Phase3 16; §9 S-PyTorch 65 = S1 16 + S2 17 + S3 18 + S4 14). + 마스터 `INDEX.md`.
- 카테고리 분석 파일 약 169(요약 포함). 라우팅 경로는 항상 `INDEX.md`에서 확인; 부재 시 "확인 필요".

## 5. Reusable Routing Questions

- 질문 유형은? (design / quantize / nonlinear-DSP / eye-tracking / sparse-CNN / HG-PIPE port / "where is X")
- 명시 단서(repo/paper/technique/board/category)는 무엇이며 INDEX에 존재하는가?
- 단일 스킬인가, 혼합 의도(듀얼 라우팅 + fallback)인가?
- 대상 MODULE_GUIDE 경로가 실재하는가, 아니면 소스 부재/계획만인가?
- 명칭-실체 불일치 함정(Tiny-GPT-on-Vortex, AnyPackingNet, UQ-ViT, eyegraph)에 해당하는가?

## 6. Why This Skill Is Relevant

REF/Analysis 코퍼스는 가속기·양자화·비선형/DSP packing·이벤트 시선추적·희소/CNN·HG-PIPE 이식의 112 MODULE_GUIDE를 카테고리별로 보유한다. 사용자가 "어디 있나/무엇을 봤나/무엇이 관련 있나"를 물을 때, 본 라우터가 INDEX 근거로 정확한 전문 스킬과 MODULE_GUIDE로 먼저 안내한다.
