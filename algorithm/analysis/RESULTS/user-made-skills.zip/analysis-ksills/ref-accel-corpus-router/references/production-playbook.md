# Production Playbook

## Purpose

This playbook supports `ref-accel-corpus-router` as the index/router into the analyzed REF corpus. It is written for agents that need a repeatable routing workflow, not a one-off answer. The router classifies a request and hands off to a specialized `*-kb` skill + MODULE_GUIDE path; it does not solve the domain task.

## Intake Contract

- Objective: which REF-corpus question to route (design / quantize / nonlinear-DSP / eye-tracking / sparse-CNN / HG-PIPE port / "where is X").
- Inputs: named cues (repo/paper/technique/board/category), whether the user already knows the target, the target deliverable.
- Output format: routing decision (target `*-kb` skill + MODULE_GUIDE path(s) + planning/roadmap doc), with a fallback for mixed intent.
- Success metrics: correct skill, correct MODULE_GUIDE path/category, INDEX-backed evidence, ambiguity surfaced.
- Constraints: single-best vs dual route, non-goals (no domain solving here), no invented paths.

## Decision Flow

- Capture question type and named cues; note any already-known target.
- Match against the routing table in `references/ref-corpus-context.md` (6 skills ↔ topics/categories).
- Resolve the exact MODULE_GUIDE path(s) and category from `INDEX.md` (§8 HW, §9 S-PyTorch).
- Add the planning/roadmap doc when relevant (`_DEEP_ANALYSIS_PLAN*`, `_SKILL_CREATION_PLAN`, `HG-PIPE_PORTING_ROADMAP`, `_VERIFICATION`).
- Return the handoff target + evidence; flag uncovered cues or missing material.

## Tradeoff Questions

- Which single skill best fits, and is a secondary/fallback needed (e.g., quantized attention accelerator → datapath + quantization)?
- Which cue is a name-vs-reality trap (Tiny-GPT-on-Vortex, AnyPackingNet=DeepBurning-MixQ, UQ-ViT=Uniform Quant)?
- Is the needed MODULE_GUIDE actually present, or is it source-absent / planned only ("확인 필요")?
- Does the request belong to HG-PIPE design/porting (→ `hgpipe-porting-advisor` + roadmap) rather than a generic datapath?

## Output Standard

Output contains the routing decision, evidence (INDEX §8/§9 line + path), the fallback skill, the ambiguity/missing-material risks, and the next step inside the target skill. Keep it structured enough for another Worker to follow the handoff directly.
