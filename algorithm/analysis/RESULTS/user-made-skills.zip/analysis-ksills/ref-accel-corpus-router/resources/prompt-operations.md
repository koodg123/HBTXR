# Prompt Operations

## Prompt Pack Fields

- Skill: `ref-accel-corpus-router`
- Objective: one sentence (route a REF-corpus question to a skill + MODULE_GUIDE).
- Context: question type, named cues (repo/paper/technique/board/category), whether the target is already known.
- Constraints: scope, single-best vs dual route, non-goals (do not solve the domain task here).
- Required output: exact routing decision (target `*-kb` skill + MODULE_GUIDE path(s) + planning/roadmap doc).
- Verification: evidence needed (INDEX §8/§9 line, category match, path exists).
- Risks: ambiguous intent, missing material, name-vs-reality mismatches.

## Review Loop

1. Draft the prompt pack before routing.
2. Route it through the roles in `sub-agents/manifest.toml` (routing-accuracy / coverage / freshness).
3. Revise when reviewers find a mis-classification, an uncovered cue, or a stale path.
4. Produce the routing decision only after the question type is stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when the named cue is absent from `INDEX.md`, when two skills are equally plausible, or when the needed MODULE_GUIDE/roadmap does not exist. Never invent a MODULE_GUIDE path; mark unverifiable routes "확인 필요".
