---
name: ref-accel-corpus-router
description: "REF/Analysis 가속기·양자화·시선추적 분석 코퍼스(112 MODULE_GUIDE + INDEX)의 인덱스/라우터. FPGA Transformer 가속, ViT/LLM 양자화, 비선형/DSP packing, 이벤트 시선추적, 희소/CNN systolic, HG-PIPE 이식 관련 질문에서 적절한 전문 스킬과 MODULE_GUIDE 경로로 안내. Use first whenever the user asks where REF analysis material is, what was analyzed, or which technique/repo/paper is relevant — then hand off to the specialized *-kb skill."
---

# REF Accel Corpus Router

## Overview

Use this skill **first** as the index/router into the analyzed REF corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis` (112 MODULE_GUIDE + INDEX). It does not produce HW/algorithm artifacts itself — it classifies the request and hands off to the right specialized `*-kb` skill and the matching `MODULE_GUIDE.md` path.

This skill complements `fpga-transformer-accelerator-kb`, `vit-llm-quantization-kb`, `hw-nonlinear-dsp-packing-kb`, `event-eye-tracking-kb`, `sparse-cnn-systolic-accel-kb`, and `hgpipe-porting-advisor`. It should produce a routing decision (target skill + MODULE_GUIDE evidence path) rather than free-form advice.

## Prompt-First Rule

Before routing, write a compact prompt pack naming the objective, the question type, candidate skills, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable routing artifact helps.

## Start Every Task With

1. Restate the user goal as a routable question type (design / quantize / nonlinear-DSP / eye-tracking / sparse-CNN / HG-PIPE port / "where is X").
2. List the named cues (repo, paper, technique, board, category) and the target deliverable.
3. Identify the single best specialized skill and the matching MODULE_GUIDE category.
4. Separate known facts (from INDEX line evidence) from assumptions about intent.
5. Decide the handoff target first; do not answer the domain question in this skill.

## Workflow

1. Capture the question type, named cues (repo/paper/technique/board/category), and whether the user already knows the target.
2. Classify against the routing table in `references/ref-corpus-context.md` (6 specialized skills ↔ topics/categories).
3. Read `REF/Analysis/INDEX.md` (§8 HW, §9 S-PyTorch) to resolve the exact MODULE_GUIDE path(s) and the matching category.
4. Hand off: name the target `*-kb` skill, the MODULE_GUIDE path(s), and the planning doc/roadmap if relevant (`_DEEP_ANALYSIS_PLAN*`, `_SKILL_CREATION_PLAN`, `HG-PIPE_PORTING_ROADMAP`, `_VERIFICATION`).
5. Return the routing decision with INDEX-backed evidence; flag ambiguity or missing material instead of inventing a guide.

## Deliverables

- Prompt pack with question type, candidate skills, and missing cues.
- Routing decision (target skill + MODULE_GUIDE path(s) + planning/roadmap doc) with explicit rationale.
- Verification checklist with the evidence required to confirm the route is correct.
- Risk list with ambiguous-intent cases and recommended clarifying question or fallback skill.

## Supporting Files

- `references/production-playbook.md` for the repeatable routing workflow and decision points.
- `references/ref-corpus-context.md` for the full routing table (6 skills ↔ topics) and the REF/Analysis directory map (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable routing prompts.
- `scripts/build_prompt.py` for generating a local routing prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus routing assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- The request is classified into exactly one primary question type before routing.
- The chosen specialized skill is named, and a secondary/fallback skill is named when intent is mixed.
- The MODULE_GUIDE path(s) and category are resolved from `INDEX.md`, not invented.
- Counts and category sizes are quoted from INDEX (HW 47 + S-PyTorch 65 = 112 MODULE_GUIDE); unverifiable claims are marked "확인 필요".
- Start with a prompt artifact so routing assumptions are visible before the handoff.
- Escalate ambiguous intent instead of guessing a skill.
- Deliver a concrete handoff target and the next step inside that skill.

## Escalate When

- The named cue (repo/paper/technique) is not in `INDEX.md` and no category clearly matches.
- Multiple specialized skills are equally plausible and the choice would materially change the answer.
- The request needs a MODULE_GUIDE or roadmap that does not exist in the corpus yet.
- A confident route would send the user to a skill that cannot satisfy the actual question.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before routing. Use `verification/ref-corpus-checklist.md` to preserve the INDEX line-evidence, category counts, and known-limitation flags. The project baseline accelerator is **HG-PIPE**; porting/extension routes to `hgpipe-porting-advisor` and `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.
