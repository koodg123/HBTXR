#!/usr/bin/env python3
"""Build a routing prompt pack for ref-accel-corpus-router."""

import argparse


def main():
    parser = argparse.ArgumentParser(description="Build a reusable routing prompt pack.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--question-type", default="")
    parser.add_argument("--cues", default="")
    parser.add_argument("--artifact", default="routing decision (target *-kb skill + MODULE_GUIDE path)")
    parser.add_argument("--verification", default="INDEX §8/§9 line evidence + path exists")
    args = parser.parse_args()

    print("Skill: ref-accel-corpus-router")
    print(f"Objective: {args.objective}")
    print(f"Question type: {args.question_type}")
    print(f"Cues (repo/paper/technique/board/category): {args.cues}")
    print(f"Required artifact: {args.artifact}")
    print(f"Verification evidence: {args.verification}")


if __name__ == "__main__":
    main()
