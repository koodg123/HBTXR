# Intake Prompt Bundle

Use `$ref-accel-corpus-router` for this request.

1. Normalize the request into a routable question type (design / quantize / nonlinear-DSP / eye-tracking / sparse-CNN / HG-PIPE port / "where is X").
2. Identify named cues (repo, paper, technique, board, category) and any already-known target.
3. Select the single best specialized skill (`fpga-transformer-accelerator-kb`, `vit-llm-quantization-kb`, `hw-nonlinear-dsp-packing-kb`, `event-eye-tracking-kb`, `sparse-cnn-systolic-accel-kb`, `hgpipe-porting-advisor`) and the matching REF MODULE_GUIDE category.
4. Produce the routing decision (target skill + MODULE_GUIDE path(s) + planning/roadmap doc).
5. Define the verification gate (INDEX §8/§9 line + path exists) and residual risks (ambiguous intent / missing material).
