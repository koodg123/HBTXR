# Prompt Template

Use `$ref-accel-corpus-router` to handle the following routing task.

Objective:

Question type (design / quantize / nonlinear-DSP / eye-tracking / sparse-CNN / HG-PIPE port / "where is X"):

Cues (repo / paper / technique / board / category / already-known target):

Constraints (single-best vs dual route; do not solve the domain task here):

Required artifact (target *-kb skill + MODULE_GUIDE path(s) + planning/roadmap doc):

Known facts (with INDEX §8/§9 line):

Assumptions about intent:

Verification evidence (INDEX line / category match / path exists):

Risks and open questions (ambiguous intent / missing material):

Return the routing decision, evidence, fallback skill, risks, and the next step inside the target skill.
