# Common Mistakes

- Answering the domain question here instead of routing to the specialized `*-kb` skill.
- Naming a MODULE_GUIDE path without confirming it in `INDEX.md` (§8 HW / §9 S-PyTorch), or inventing a guide that does not exist (should be "확인 필요").
- Routing to a skill without quoting the matching category/evidence path.
- Picking one skill when intent clearly spans two (e.g., quantization + datapath) without naming the secondary/fallback.
- Misrouting on a name-vs-reality mismatch (e.g., Tiny-GPT-on-Vortex is a 2-layer MLP, AnyPackingNet is DeepBurning-MixQ).
- Forgetting to route HG-PIPE design/porting questions to `hgpipe-porting-advisor` + `HG-PIPE_PORTING_ROADMAP.md`.
- Stating counts from memory; corpus totals (HW 47 + S-PyTorch 65 = 112) must come from INDEX.
