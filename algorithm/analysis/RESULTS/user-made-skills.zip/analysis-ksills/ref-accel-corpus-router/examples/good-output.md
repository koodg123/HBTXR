# Good Output Example

## Prompt Pack

Skill: `ref-accel-corpus-router`
Objective: Route a REF-corpus question to the correct specialized skill + MODULE_GUIDE path.
Question type: design / quantize / nonlinear-DSP / eye-tracking / sparse-CNN / HG-PIPE port / "where is X".
Cues: named repo/paper/technique/board/category, target deliverable.
Verification: confirm the MODULE_GUIDE path exists in `INDEX.md` (§8 HW / §9 S-PyTorch).

## Routing Decision

Classify, then hand off with **INDEX line evidence**, e.g.:
- "DSP packing 비트배치" → `hw-nonlinear-dsp-packing-kb`; evidence `CNN-Accel/Uint-Packing-master/MODULE_GUIDE.md`, `CNN-Accel/AnyPackingNet-main/MODULE_GUIDE.md`, `Transformer-Accel/Diff-DiT/MODULE_GUIDE.md`.
- "이벤트 시선추적 저지연 모델" → `event-eye-tracking-kb`; evidence `XR-Eye-Tracking/Codebase/ais2024/MODULE_GUIDE.md` (TENNs-Eye), `…/cb-convlstm-eyetracking/…` (3ET).
- "ViT INT8 integer-only softmax" → `vit-llm-quantization-kb`; evidence `ViT-Quantization/I-ViT/MODULE_GUIDE.md`, `…/FQ-ViT/…`.
- "FlashAttention datapath / systolic GEMM" → `fpga-transformer-accelerator-kb`; evidence `ViT-Accelerator/AURA-FlashAttention-AISC-Accelerator/MODULE_GUIDE.md`.
- "HBM SpMV / UltraNet packing" → `sparse-cnn-systolic-accel-kb`; evidence `Others/HiSparse/MODULE_GUIDE.md`, `CNN-Accel/dac_sdc_2022_champion-master/MODULE_GUIDE.md`.
- "HG-PIPE 개선 / 이식" → `hgpipe-porting-advisor`; evidence `Transformer-Accel/HG-PIPE/MODULE_GUIDE.md`, `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.

Name a fallback skill when intent is mixed, and the next step inside the target skill.

## Risks

List ambiguous-intent cases (e.g., "양자화된 attention 가속기" spans quantization + datapath) and the clarifying question or dual-route that resolves each. Flag any cue not found in `INDEX.md` as "확인 필요".
