# REF Corpus Context — Integer-Only / Fixed-Point Quantization Flow

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW, §9 S-PyTorch). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) and a 1차 요약 `<repo>.md`.

## Core Routing (read these before planning)

1. **Dyadic / integer-only 변환 (대표·★)**: `ViT-Quantization/I-ViT/MODULE_GUIDE.md` — dyadic `M=b/2^c` via `batch_frexp`/`fixedpoint_mul`, integer-only QAT, IntGELU/IntSoftmax/IntLayerNorm. 대표 케이스 DeiT-S(FP32 79.85→INT8 80.12, +0.27, `README.md:53`). per-channel(weight)·per-tensor(activation), W8/A8 + bias32, residual/softmax는 A16.
2. **정수 비선형 + PTQ 정수경로**: `ViT-Quantization/FQ-ViT/MODULE_GUIDE.md` (PTF + Log-Int-Softmax, fully integer), `ViT-Quantization/integer-only-transformer/MODULE_GUIDE.md` (integer-only transformer 경로).
3. **PoT / log2=shift / grouped scale**: `ViT-Quantization/AHCPTQ/MODULE_GUIDE.md` (log2=shift requant, grouped scale) — 곱셈기 제거형 requant.
4. **SW 골든 ↔ HLS bit-exact 검증**: `Transformer-Accel/trans-fat/MODULE_GUIDE.md` — PyTorch 골든 ↔ HLS C++ bit-exact, `stage_gt` 단계별 검증 (I-BERT INT8 경로).
5. **HW/SW 비트정합 + isqrt 매직넘버**: `ViT-Accelerator/TATAA.md` — HW/SW 비트정합, isqrt 매직넘버 `0x5f37…` SW↔HW 일치.
6. **C-sim 비트정합 (프로젝트 baseline)**: `Transformer-Accel/HG-PIPE.md` — `check_stream` 기반 C-sim 비트정합. 이식·확장은 `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.

(전체 목록·정량 요약은 `INDEX.md` §8/§9 표 참조.)

## 핵심 플로우 (변환→requant→비트폭→export→검증)

1. **변환 경로 선택**: QAT(I-ViT, 정확도 회복) vs PTQ(FQ-ViT/AHCPTQ, 빠른 전환). calibration set·granularity·signed 결정.
2. **scale/zp 결정**: dyadic(M=b/2^c, I-ViT) 또는 PoT/log2=shift(AHCPTQ). per-tensor/channel·zero-point·A16/bias32 wide path.
3. **비트폭(누산 포함)**: W/A bit + accumulator width(N·dh 합 대비). DSP-친화 폭은 `dsp-packing-low-bit-mac` 연계.
4. **정수 비선형 연계**: IntGELU/IntSoftmax/IntLayerNorm, log2=shift, isqrt 매직넘버 — `hw-nonlinear-approximation` 연계.
5. **export**: 패킹된 가중치 + dyadic multiplier/shift 테이블 HW 포맷.
6. **비트정합 검증**: SW 골든 vs HLS/RTL 단계별(trans-fat `stage_gt`, HG-PIPE `check_stream`, TATAA HW/SW match). **bit-exact C-sim 필수.**

## 수치 규약 (정량 도출, 정적)
- 비트폭/scale/zp는 코드 직접(파일:라인). dyadic은 `M=b/2^c`(b,c 정수), PoT는 shift량. accumulator width = 입력 비트 + log2(누산 길이) 상한.
- **float→fixed 정확도 손실은 인용**(README/논문). 리포트 없으면 "확인 필요". 절대 날조 금지.
- 비트정합은 **bit-exact C-sim 결과**로만 주장. 미실행 시 "확인 필요".

## Reusable Verification Questions
- 변환 경로는 QAT인가 PTQ인가? calibration set·granularity(per-tensor/channel)·signed/unsigned는?
- requant는 dyadic(M=b/2^c)인가 PoT/shift인가? zero-point·A16/bias32 wide path는?
- W/A 비트폭과 accumulator width는? DSP-친화 폭에 맞는가?
- 정수 비선형(GELU/Softmax/LayerNorm·isqrt) 연계 방식은?
- export 포맷과 SW 골든↔HLS/RTL bit-exact 검증의 최소 단위(1 GEMM/1 head/1 block)는?

## Why This Skill Is Relevant
REF 코퍼스의 양자화 repo(I-ViT/FQ-ViT/AHCPTQ 등)와 HW 비트정합 검증기(trans-fat/TATAA/HG-PIPE)가 float→integer-only 변환, dyadic/PoT requant, 비트폭 선택, SW↔HW bit-exact를 file:line 근거로 반복적으로 다룬다.
