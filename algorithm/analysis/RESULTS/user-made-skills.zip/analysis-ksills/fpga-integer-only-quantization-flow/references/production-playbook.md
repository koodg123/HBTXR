# Production Playbook

## Purpose

This playbook supports `fpga-integer-only-quantization-flow` for converting a PyTorch float model into an FPGA integer-only / fixed-point inference flow. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to convert/decide/verify (conversion path, requant scales, bit-widths, bit-exact match).
- Inputs: float checkpoint, model spec (dims/seq/depth/heads), calibration data, target board + clock, HLS/RTL boundary, MODULE_GUIDE references.
- Output format: conversion plan, requant-scale & bit-width table, or bit-exact verification plan.
- Success metrics: accuracy delta (float→fixed), bit-width / accumulator width, DSP fit, bit-exact SW↔HW match.
- Constraints: tool availability, calibration limits, non-goals, validation limits.

## Decision Flow

- Capture conversion path: QAT vs PTQ, calibration set, granularity (per-tensor / per-channel), signed/unsigned.
- Decide scale/zero-point representation: dyadic (M=b/2^c) vs Power-of-Two (PoT/shift); where A16/bias32 wide paths are required.
- Choose DSP-친화 비트폭 including accumulator width; link integer nonlinears (IntGELU/IntSoftmax/IntLayerNorm, log2=shift, isqrt magic number).
- Plan weight/scale export to the HW format (packed weights, dyadic multiplier/shift tables).
- Return the bit-exact (SW 골든 vs HLS/RTL) verification plan; C-sim bit-exact is mandatory.

## Tradeoff Questions

- Which choice would be costly to reverse (QAT retrain vs PTQ, dyadic vs PoT, per-tensor vs per-channel)?
- Which assumption (accumulator overflow, PoT rounding, activation outliers at per-tensor) most likely invalidates the artifact?
- What is the smallest unit validatable by bit-exact C-sim now (one GEMM, one head, one block requant)?
- Which existing skill (`vit-llm-quantization-kb`, `hw-nonlinear-approximation`, `dsp-packing-low-bit-mac`, `quantization-error-analysis`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need accuracy re-eval or C-sim), assumptions, risks, and the next validation step. float→fixed accuracy loss is cited or "확인 필요". Keep it structured enough for another Worker to use directly.
