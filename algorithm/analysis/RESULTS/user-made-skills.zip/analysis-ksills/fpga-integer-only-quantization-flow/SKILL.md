---
name: fpga-integer-only-quantization-flow
description: "PyTorch float 모델을 FPGA integer-only/fixed-point 추론으로 변환하는 양자화 플로우 기법. dyadic(M=b/2^c)·Power-of-Two requant, per-tensor/channel scale·zero-point, DSP-친화 비트폭 선택, 정수 비선형 연계, 가중치 export, 그리고 SW 골든↔HLS/RTL 비트정합(bit-exact) 검증. Use whenever converting a float model to integer-only FPGA inference, choosing requant scales/bit-widths, or verifying SW↔HW numerical match — even without naming a tool."
---

# FPGA Integer-Only Quantization Flow

## Overview

Use this skill for the **float→fixed/integer-only conversion flow** that takes a PyTorch float model to an FPGA integer-only / fixed-point inference datapath. Build a transparent, decision-ready flow grounded in the analyzed REF corpus (quantization MODULE_GUIDEs + HW bit-exact verifiers) rather than free-form advice.

This skill complements `vit-llm-quantization-kb`, `hw-nonlinear-approximation`, `dsp-packing-low-bit-mac`, and `quantization-error-analysis`. It should produce reusable artifacts (conversion plan, requant scale/bit-width table, bit-exact verification plan) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable conversion objective (accuracy delta, bit-width, accumulator width, bit-exact match).
2. List source artifacts (float checkpoint, model spec, calibration data, target HLS/RTL boundary) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (conversion plan vs requant/bit-width table vs bit-exact verification plan).

## Workflow

1. Capture the conversion path: **QAT vs PTQ**, calibration set, granularity (per-tensor / per-channel), and signed/unsigned domain.
2. Decide scale/zero-point representation: **dyadic (M=b/2^c) or Power-of-Two (PoT)** requant, shift-based rescale, and where A16/bias32 wide paths are needed.
3. Choose **DSP-친화 비트폭** including the accumulator width, and the integer nonlinear linkage (IntGELU/IntSoftmax/IntLayerNorm, log2=shift, isqrt magic numbers).
4. Plan the weight/scale **export** to the HW format (packed weights, dyadic multiplier/shift tables).
5. Return the **bit-exact (SW 골든 vs HLS/RTL) verification plan**; C-sim bit-exact match is mandatory, with float→fixed accuracy loss cited or marked "확인 필요".

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (conversion plan / requant-scale & bit-width table / bit-exact verification plan) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (calibration sweep, bit-exact C-sim, accuracy re-eval).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis quantization MODULE_GUIDEs and bit-exact verifiers (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness (bit-exact match) is separated from accuracy and resource claims.
- Conversion path (QAT vs PTQ), granularity, and signed/unsigned domain are explicit before scale claims.
- Requant representation (dyadic M=b/2^c vs PoT shift) and accumulator/bit-widths are named before HW cost claims.
- float→fixed accuracy loss is cited from the source (README/paper); if absent, mark "확인 필요". Never fabricate.
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Bit-exact C-sim (SW 골든 vs HLS/RTL) is the mandatory verification gate.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (float checkpoint, model spec, calibration data, HLS/RTL boundary) or constraints are missing.
- Multiple plausible interpretations (QAT vs PTQ, dyadic vs PoT, per-tensor vs per-channel) would materially change the artifact.
- The result depends on accuracy re-eval, board measurements, or unavailable tools.
- A recommendation would lock the user into a brittle scale/bit-width choice without a bit-exact validation path.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. The project baseline accelerator is **HG-PIPE** (`Transformer-Accel/HG-PIPE.md`, `check_stream` C-sim bit-exact); porting/extension is captured in `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.
