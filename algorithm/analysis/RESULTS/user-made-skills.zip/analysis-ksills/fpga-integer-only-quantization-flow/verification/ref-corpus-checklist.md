# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s) (I-ViT / FQ-ViT / integer-only-transformer / AHCPTQ / trans-fat; HG-PIPE via `Transformer-Accel/HG-PIPE.md`; TATAA via `ViT-Accelerator/TATAA.md`).
- [ ] Applied this skill to the relevant flow stage (변환 경로 / requant scale / 비트폭 / export / 비트정합 검증).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE (e.g., I-ViT `batch_frexp`/`fixedpoint_mul`, DeiT-S accuracy `README.md:53`).
- [ ] Kept the quantitative convention (dyadic M=b/2^c, PoT shift, accumulator width; float→fixed accuracy loss cited or "확인 필요").
- [ ] Carried over known-limitation flags (e.g., per-tensor activation outliers, accumulator overflow at long N, PoT rounding vs dyadic mismatch).
- [ ] Produced a concrete artifact + bit-exact C-sim validation evidence, and stated HG-PIPE relevance / porting link (`HG-PIPE_PORTING_ROADMAP.md`) where applicable.
