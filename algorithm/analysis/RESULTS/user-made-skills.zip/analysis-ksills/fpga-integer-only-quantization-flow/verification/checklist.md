# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: fpga-integer-only-quantization-flow` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable conversion objective.
- [ ] Source artifacts (float checkpoint / model spec / calibration / board / HLS-RTL boundary), assumptions, and constraints are separated.
- [ ] Conversion path (QAT vs PTQ), granularity (per-tensor/channel), and signed/unsigned domain are explicit.
- [ ] Requant representation (dyadic M=b/2^c vs PoT/shift), zero-point, and A16/bias32 wide paths are named.
- [ ] Bit-widths including accumulator width are stated and mapped to DSP-friendly widths.
- [ ] Required supporting skills and the matching REF quantization MODULE_GUIDE are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] float→fixed accuracy loss carries file:line evidence; if no report exists, marked "확인 필요" (never fabricated).
- [ ] Bit-exact (SW 골든 vs HLS/RTL) C-sim is the verification gate; unverified match marked "확인 필요".
- [ ] Residual risks and next validation steps are listed.
