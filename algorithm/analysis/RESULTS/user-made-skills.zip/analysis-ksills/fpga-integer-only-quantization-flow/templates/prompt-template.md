# Prompt Template

Use `$fpga-integer-only-quantization-flow` to handle the following task.

Objective:

Inputs (float checkpoint / model spec / calibration data / target board+clock / HLS or RTL boundary / MODULE_GUIDE refs):

Constraints (conversion path QAT/PTQ, granularity per-tensor/channel, scope):

Required artifact (conversion plan / requant-scale & bit-width table / bit-exact verification plan):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / accuracy re-eval / bit-exact C-sim):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
