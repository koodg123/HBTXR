# Intake Prompt Bundle

Use `$fpga-integer-only-quantization-flow` for this request.

1. Normalize the request into a measurable conversion objective (accuracy delta / bit-width / accumulator width / bit-exact match).
2. Identify source artifacts (float checkpoint, model spec, calibration data, target board+clock, HLS/RTL boundary) and missing inputs.
3. Select required supporting skills (`vit-llm-quantization-kb`, `hw-nonlinear-approximation`, `dsp-packing-low-bit-mac`, `quantization-error-analysis`) and the matching REF quantization MODULE_GUIDE.
4. Produce the first usable artifact (conversion plan / requant-scale & bit-width table / bit-exact verification plan).
5. Define the verification gate (file:line + accuracy re-eval + bit-exact C-sim) and residual risks.
