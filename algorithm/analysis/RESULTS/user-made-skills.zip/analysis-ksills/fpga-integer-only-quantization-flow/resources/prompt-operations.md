# Prompt Operations

## Prompt Pack Fields

- Skill: `fpga-integer-only-quantization-flow`
- Objective: one sentence (convert / decide requant / choose bit-width / verify bit-exact).
- Context: float checkpoint, model spec, calibration data, target board+clock, HLS/RTL boundary, MODULE_GUIDE refs.
- Constraints: conversion path (QAT/PTQ), granularity, scope, tools, non-goals.
- Required output: exact artifact type (conversion plan / requant-scale & bit-width table / bit-exact verification plan).
- Verification: evidence needed (file:line, accuracy re-eval, bit-exact C-sim).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (conversion path / granularity / accumulator width) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when conversion path, calibration data, granularity, bit-widths, or acceptance criteria are missing and the missing fact would change the requant/bit-width/verification. Never fabricate accuracy numbers or a bit-exact match that was not run.
