# Good Output Example

## Prompt Pack

Skill: `fpga-integer-only-quantization-flow`
Objective: Convert DeiT-S float to an integer-only FPGA inference flow with a bit-exact SW↔HLS verification gate.
Inputs: float checkpoint (DeiT-S), calibration set, target board+clock, HLS/RTL boundary, MODULE_GUIDE refs.
Constraints: state conversion path (QAT/PTQ), granularity, tool, target, and scope limits.
Verification: define the evidence (file:line, accuracy re-eval, bit-exact C-sim) required for signoff.

## Artifact — "DeiT를 integer-only로 변환" flow

Structured decisions with **MODULE_GUIDE line evidence**, e.g.:
- **Conversion path**: QAT integer-only per I-ViT (DeiT-S FP32 79.85 → INT8 80.12, +0.27; cite `ViT-Quantization/I-ViT/MODULE_GUIDE.md`). PTQ alternative for fast turnaround (route to FQ-ViT / AHCPTQ).
- **Requant**: dyadic M=b/2^c via `batch_frexp`/`fixedpoint_mul` (cite I-ViT); choose PoT/log2=shift where it removes a multiplier (route to AHCPTQ). State per-channel(weight) + per-tensor(activation) granularity, and A16/bias32 wide paths for residual/softmax.
- **Bit-widths**: W8/A8 datapath, accumulator width sized for N·dh sum; map to DSP-friendly widths (route to `dsp-packing-low-bit-mac`).
- **Integer nonlinears**: IntGELU/IntSoftmax/IntLayerNorm linkage; isqrt magic-number match (route to TATAA `0x5f37…`) and `hw-nonlinear-approximation`.
- **Export**: packed weights + dyadic multiplier/shift tables in the HW format.
- **Bit-exact verify**: SW golden vs HLS/RTL stage-by-stage (trans-fat `stage_gt`, HG-PIPE `check_stream`, TATAA HW/SW match). C-sim bit-exact is the gate; accuracy loss cited or "확인 필요".

## Risks

List uncertain assumptions (e.g., accumulator overflow at long N, PoT rounding vs dyadic mismatch, per-tensor activation outliers) and the next experiment (calibration sweep, bit-exact C-sim, accuracy re-eval) to resolve each.
