# Common Mistakes

- Producing general quantization advice without a prompt pack or a concrete conversion/requant/verification artifact.
- Quoting an accuracy number (float→fixed loss) without file:line evidence, or inventing one that does not exist in the repo (should be "확인 필요").
- Mixing bit-exact functional correctness with accuracy and resource claims.
- Naming a requant scheme (dyadic M=b/2^c, PoT/shift) without stating its rounding/bit-width consequence or the accumulator width.
- Choosing a bit-width without naming the granularity (per-tensor vs per-channel) and signed/unsigned domain, or ignoring A16/bias32 wide paths.
- Forgetting to route into the relevant REF quantization MODULE_GUIDE (I-ViT/FQ-ViT/AHCPTQ) before inventing a new conversion path.
- Recommending an export format with no bit-exact (SW 골든 vs HLS/RTL C-sim) validation path.
