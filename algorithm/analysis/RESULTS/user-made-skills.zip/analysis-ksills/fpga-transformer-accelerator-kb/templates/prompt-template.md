# Prompt Template

Use `$fpga-transformer-accelerator-kb` to handle the following task.

Objective:

Inputs (model spec / datatype / board+clock / source RTL or HLS / MODULE_GUIDE refs):

Constraints:

Required artifact (datapath plan / dataflow comparison / port plan / codebase MODULE_GUIDE):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / synthesis PPA / bit-exact C-sim):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
