# Intake Prompt Bundle

Use `$fpga-transformer-accelerator-kb` for this request.

1. Normalize the request into a measurable HW objective (throughput/latency/area/power/accuracy).
2. Identify source artifacts (model spec, board+clock, RTL/HLS) and missing inputs.
3. Select required supporting skills (`transformer-accel-microarch`, `hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`) and the matching REF MODULE_GUIDE.
4. Produce the first usable artifact (datapath/dataflow/port plan).
5. Define the verification gate (file:line + synthesis PPA) and residual risks.
