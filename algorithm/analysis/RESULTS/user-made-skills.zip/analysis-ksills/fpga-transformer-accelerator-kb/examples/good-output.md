# Good Output Example

## Prompt Pack

Skill: `fpga-transformer-accelerator-kb`
Objective: Produce a decision-ready datapath/dataflow/port artifact for an FPGA Transformer accelerator.
Inputs: model spec (dims/seq/depth), datatype/quantization, target board+clock, source RTL/HLS (if any).
Constraints: state tool, data, target, and scope limits.
Verification: define the evidence (file:line, synthesis PPA) required for signoff.

## Artifact

Structured decisions with **MODULE_GUIDE line evidence**, e.g.:
- Datapath: output-stationary MAC, MAC lanes = TP·COP·CIP (cite `…/MODULE_GUIDE.md`), scalar MACs = T·CO·CI.
- Dataflow/memory: weight-stationary vs streaming; on-chip buffer bit-size; HBM/SLR partition.
- Quantization/nonlinear: bit-width, LUT/shift softmax·GELU·LayerNorm (route to `hw-nonlinear-dsp-packing-kb`).
- Tradeoffs and the smallest change that can be validated by synthesis first.

## Risks

List uncertain assumptions (e.g., DSP packing carry bits, achievable Fmax) and the next experiment (synthesis/PPA, bit-exact C-sim) to resolve each.
