# Common Mistakes

- Producing general accelerator advice without a prompt pack or a concrete artifact.
- Quoting throughput/area numbers without file:line evidence, or citing synthesis PPA that does not exist in the repo (should be "확인 필요").
- Mixing functional correctness with performance and resource claims.
- Naming a dataflow (weight-stationary, streaming) without stating the memory/buffer consequence.
- Forgetting to route into the relevant REF MODULE_GUIDE before inventing a new datapath.
- Recommending an irreversible mapping with no validation (synthesis, bit-exact C-sim) path.
