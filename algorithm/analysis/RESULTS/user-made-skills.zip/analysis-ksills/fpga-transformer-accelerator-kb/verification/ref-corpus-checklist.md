# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s).
- [ ] Applied this skill to the relevant accelerator cluster (datapath / dataflow / attention / scale-up / GEMM core).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE.
- [ ] Kept the quantitative convention (MAC lanes/scalar MACs/loop trips/memory; synthesis PPA = "확인 필요" if no report).
- [ ] Carried over known-limitation flags (e.g., HLS source absent, A_size 불일치, name-vs-reality mismatches).
- [ ] Produced a concrete artifact + validation evidence, and stated HG-PIPE relevance / porting link where applicable.
