# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: fpga-transformer-accelerator-kb` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable HW objective.
- [ ] Source artifacts (model/board/clock/datatype), assumptions, and constraints are separated.
- [ ] Required supporting skills and the matching REF MODULE_GUIDE are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] Cost numbers carry file:line evidence; synthesis PPA is cited only if a report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (synthesis / bit-exact C-sim) are explicit.
- [ ] Residual risks and next validation steps are listed.
