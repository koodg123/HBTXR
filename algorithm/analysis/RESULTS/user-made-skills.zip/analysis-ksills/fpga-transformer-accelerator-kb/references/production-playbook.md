# Production Playbook

## Purpose

This playbook supports `fpga-transformer-accelerator-kb` for FPGA/HLS/RTL Transformer·ViT·LLM accelerator work. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to design, compare, port, or analyze (datapath, dataflow, mapping, codebase).
- Inputs: model spec (dims/seq/depth/heads), datatype/quantization, target board + clock, source RTL/HLS, MODULE_GUIDE references.
- Output format: datapath plan, dataflow comparison table, port plan, or accelerator-codebase MODULE_GUIDE.
- Success metrics: throughput/II, latency (avg + p95/p99), area (LUT/FF/DSP/BRAM/URAM), energy, accuracy.
- Constraints: tool availability, board fit, non-goals, validation limits.

## Decision Flow

- Capture device, model/workload, datatype, clock, runtime contract.
- Identify design entry/boundary: HLS C++ vs hand-written RTL/SpinalHDL vs mixed IP-integrator.
- Read the matching REF MODULE_GUIDE(s); extract datapath/dataflow/quant patterns with file:line.
- Compute cost statically: MAC lanes (unroll dims), scalar MACs (shape), loop trips/II (tiling), memory (array×bit).
- Return artifacts linking datapath behavior, memory/dataflow, and validation metrics.

## Tradeoff Questions

- Which mapping would be costly to reverse (on-chip-resident vs HBM streaming, weight-stationary vs streaming)?
- Which assumption (DSP packing, Fmax, accuracy at low bit) most likely invalidates the artifact?
- What is the smallest change validatable by synthesis or bit-exact C-sim now?
- Which existing skill (`transformer-accel-microarch`, `hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need synthesis), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
