# REF Corpus Context — FPGA Transformer/ViT/LLM Accelerators

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW, §9 S-PyTorch). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) and a 1차 요약 `<repo>.md`.

## Core Clusters (route to these MODULE_GUIDEs)

1. **하이브리드-그레인 파이프라인 / 프로젝트 baseline**: `Transformer-Accel/HG-PIPE/MODULE_GUIDE.md` (전계층 온칩, 3-bit, LUT 비선형, SpinalHDL 체인). 이식·확장은 `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.
2. **변형 연산기 / DSP 데이터패스**: `ViT-Accelerator/TATAA` (INT8↔bf16 transformable PE), `Transformer-Accel/Diff-DiT` (DSP 2/6-pack, OS systolic), `ViT-Accelerator/efficient-transformer-accelerator` (32×16 systolic + 공유 양자화기).
3. **FlashAttention / attention datapath**: `ViT-Accelerator/AURA-FlashAttention-AISC-Accelerator` (곱셈기 없는 exp, 1-pass online softmax, 트리리덕션), `ViT-Accelerator/ViT-Accelerator-on-FPGA-with-INT8-quantization` (streaming softmax).
4. **MoE / 멀티태스크**: `Transformer-Accel/Edge-MoE` (dense-MLP/top-2 MoE, expert prefetch).
5. **스케일업(멀티-SLR/HBM)**: `Transformer-Accel/FlexLLM`·`FPGA_Friendly_SpinQuant` (TAPA+RapidStream, W4A4/SpinQuant), `ViT-Accelerator/LLM_FPGA`·`LUT-LLM`·`TeraFly` (HBM/codegen; HLS 소스 부재→리포트 역추정).
6. **systolic GEMM 코어**: `ViT-Accelerator/ViT-FPGA-TPU` (16×16 FP16 OS), `Transformer-Accel/MobileVit-AI-Hardware-Accelerator` (재구성형 16×16 WS), `ViT-Accelerator/Transformer-Accelerator-Based-on-FPGA` (A_size 불일치 주의).
7. **HLS 연산자/템플릿**: `ViT-Accelerator/hls-fpga-accelerators` (파라미터화 GEMM/softmax/RMSNorm, LUT exp), `Transformer-Accel/Transformer_dataflow` (행융합 attention), `Transformer-Accel/trans-fat` (I-BERT INT8, 다중카드 4-stage).
8. **LLM/디코더·곱셈기-free**: `ViT-Accelerator/llama-fpga` (SpinalHDL FP16+AWQ), `HLS-Acceleration-of-LLaMA2`, `ternaryLLM` (삼진), `lut-gemm` (sub-4bit LUT GEMV), `Tiny-GPT-on-Vortex`(실제 toy MLP).

(전체 목록·정량 요약은 `INDEX.md` §8 표 참조.)

## 수치 규약 (정량 도출, 정적)
- MAC lanes = unroll/병렬도 차원 곱 · scalar MACs = shape 곱 · loop trips = 타일 곱 · memory = 배열 깊이×bit. 합성 PPA(LUT/DSP/BRAM/Fmax)는 리포트 동봉 시만 인용, 없으면 "확인 필요".

## Reusable Verification Questions
- 타깃 디바이스·클럭·런타임 계약은?
- 모델/워크로드 shape(seq·dim·depth)와 데이터타입/비트폭은?
- 설계 진입점은 HLS인가 hand-written RTL/SpinalHDL인가(혼합)?
- 검증 가능한 최소 단위(대표 GEMM 타일/1 head/1 레이어)는?
- 1차 지표는 throughput/latency/area/energy/accuracy 중 무엇?

## Why This Skill Is Relevant
REF 코퍼스의 HW 가속기 47편이 systolic/dataflow/DSP packing/attention datapath/양자 데이터패스를 반복적으로 다루며, file:line 근거로 설계 의사결정을 뒷받침한다.
