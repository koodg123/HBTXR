---
name: fpga-transformer-accelerator-kb
description: "FPGA/HLS/RTL ViT·Transformer·LLM 가속기 설계·분석·이식 지식베이스. systolic/output-stationary MAC array, dataflow 파이프라인, DSP packing, attention datapath(QKᵀ·online softmax·×V), weight-stationary vs streaming, 온칩/HBM 메모리계층, TAPA/RapidStream 멀티-SLR, 3-bit/INT8 양자 데이터패스. REF/Analysis의 HW MODULE_GUIDE(HG-PIPE/TATAA/AURA/FlexLLM/Edge-MoE/Diff-DiT 등)로 라우팅. Use whenever the user designs, compares, ports, or analyzes an FPGA/HLS/RTL transformer/ViT/LLM accelerator datapath, dataflow, or mapping — even if no specific repo is named."
---

# FPGA Transformer Accelerator Knowledge Base

## Overview

Use this skill for **FPGA/HLS/RTL Transformer·ViT·LLM accelerator** design, comparison, porting, and codebase analysis. Build transparent, decision-ready artifacts grounded in the analyzed REF corpus (HW MODULE_GUIDEs) rather than free-form advice.

This skill complements `transformer-accel-microarch`, `hw-friendly-nonlinear-approx`, and `algo2fpga`. It should produce reusable artifacts (datapath plan, dataflow comparison, port plan) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable HW objective (throughput/latency/area/power/accuracy).
2. List source artifacts (RTL/HLS, model spec, board, clock) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (datapath plan vs dataflow comparison vs port plan).

## Workflow

1. Capture target device, model/workload (dims, seq, depth), datatype/quantization, clock, and runtime contract.
2. Identify the design entry and boundary: HLS C++, hand-written RTL/SpinalHDL, or mixed IP-integrator (per `hw-implementation-flow-doc` style).
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md` and extract datapath/dataflow/quantization patterns with file:line evidence.
4. Plan or compare with measurable cost: MAC lanes, scalar MACs, loop trips/II, on-chip memory (bit), DSP/LUT/BRAM/URAM, clock.
5. Return artifacts connecting datapath behavior, memory/dataflow, and validation metrics; flag what needs synthesis to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (datapath/dataflow/port plan or accelerator-codebase analysis) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually synthesis/PPA).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis HW MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness is separated from performance and resource claims.
- Datatype, quantization, and shape/operator constraints are explicit.
- Backend/board assumptions are named before scheduling or cost claims.
- Cost numbers (MAC lanes/scalar MACs/loop trips/memory) are derived from code (unroll/shape) with file:line; synthesis PPA is cited only if a report exists, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (RTL/HLS, model spec, board/clock) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on synthesis PPA, board measurements, or unavailable tools.
- A recommendation would lock the user into a brittle dataflow without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. The project baseline accelerator is **HG-PIPE**; porting/extension is captured in `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.
