# Good Output Example

## Task: INT4 2×2 packed MAC (bit-layout + correction + verification)

## Prompt Pack

Skill: `dsp-packing-low-bit-mac`
Objective: Pack 4 INT4×INT4 products (2 pixels × 2 weights) into one DSP48E2 multiply, with carry correction and a bit-exact validation plan.
Inputs: W_BIT=4 (signed), IN_BIT=4, target DSP48E2, SIMD accumulation depth ≤ 16, source HLS (ap_int).
Constraints: bit-exact match to unpacked reference; no fabricated synthesis PPA.
Verification: file:line evidence + bit-exact packed-vs-unpacked match + synthesis PPA.

## Artifact

Structured decisions with **MODULE_GUIDE line evidence** (route to `CNN-Accel/Uint-Packing-master/MODULE_GUIDE.md`):

- **Field width**: `PROD_BIT = W_BIT + IN_BIT + GUARD = 4 + 4 + 2 = 10` bit. Guard = 2 bits absorbs the carry of a SIMD-16 accumulation before adjacent segments collide (Uint-Packing `PROD_BIT=IN_BIT+W_BIT+2`).
- **Bit-layout (2 weights → 1 packed weight)**: `wpack = w1·2^PROD_BIT + w0`; one multiply `m = a·wpack = (a·w1)·2^PROD_BIT + (a·w0)` places two partial products in non-overlapping 10-bit fields.
- **Segment extraction**: `out0 = m[PROD_BIT-1:0]` (Σ a·w0), `out1 = m[2·PROD_BIT-1:PROD_BIT] + m[PROD_BIT-1]` — the `+ m[PROD_BIT-1]` term is the borrow/carry correction from the signed low half to the high half (DSPopt3 pattern `(p>>1)+(p&1)` / `+acc[PROD_BIT-1]`).
- **2 pixels (the second "2")**: pack two pixels at PROD_BIT spacing on the input side (`ipack = A·2^PROD_BIT + B`) so the same multiply yields the 4-segment DSPopt3 result; valid accumulation concentrates on the two inner segments.
- **Density**: MAC/DSP = pack factor (here 2 weights × 2 pixels useful → cite the guide's "픽셀 2배 안정 packing 이득") × spatial lanes (PE×SIMD). Per-DSP DSP/LUT/Fmax = "확인 필요" until synthesis.
- **Sign domain**: signed INT4 here; if the quantizer is unsigned, switch to UINT-packing + subdata subtraction (route to `dac_sdc_2023_champion-main/MODULE_GUIDE.md`).

## Verification

- Bit-exact: enumerate all INT4×INT4 pairs and assert packed segments == unpacked reference, including the borrow-correction edge cases (negative low half).
- Guard headroom: confirm no segment overflow at SIMD=16 worst case.

## Risks

List uncertain assumptions (achievable Fmax with the extra slice/shift logic, guard headroom if SIMD grows, signed cross-talk) and the next experiment (bit-exact C-sim first, then synthesis/PPA) to resolve each.
