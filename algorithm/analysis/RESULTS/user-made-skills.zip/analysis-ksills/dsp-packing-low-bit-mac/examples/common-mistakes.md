# Common Mistakes

- Claiming a pack factor without sizing the guard bits — adjacent segments collide once SIMD accumulation carries past PROD_BIT.
- Omitting the carry/borrow correction between segments (the `+acc[PROD_BIT-1]` / `(p>>1)+(p&1)` term), so the high segment is off by the low half's sign.
- Packing signed values as if unsigned (sign-extension cross-talk) instead of using UINT-packing + subdata subtraction.
- Quoting MAC/DSP density or area numbers without file:line evidence, or citing synthesis PPA (DSP/LUT/Fmax) that does not exist in the repo (should be "확인 필요").
- Mixing functional correctness (bit-exact packed vs unpacked) with performance and resource claims.
- Choosing overlapping segments (more products/DSP) without stating the carry-correction cost, or non-overlapping without noting the lower density.
- Forgetting to route into the relevant REF MODULE_GUIDE (Uint-Packing first) before inventing a new bit-layout.
- Recommending a packing with no bit-exact validation path (exhaustive low-bit pair enumeration, then synthesis).
