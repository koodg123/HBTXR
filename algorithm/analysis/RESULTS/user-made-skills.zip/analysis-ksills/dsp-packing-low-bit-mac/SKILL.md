---
name: dsp-packing-low-bit-mac
description: "FPGA DSP에 저비트 정수 MAC을 다중 패킹하는 설계 기법. INT2/3/4/8 곱 2~6개를 1 DSP에(DSP2, DSPopt3 4-세그먼트, UINT-packing), 비트배치·시프트 분리·carry/guard 보정·세그먼트 추출·cascade 누산. FPGA DSP low-bit MAC multi-packing design technique: pack 2~6 INT2/3/4/8 products per DSP48E2/DSP58 via bit-layout, shift separation, carry/guard correction, segment extraction, cascade accumulation. Routes into REF/Analysis HW MODULE_GUIDEs (Uint-Packing/TATAA/Diff-DiT/AGNA/SJTU_microe/DAC-SDC). Use whenever packing multiple low-bit MACs per DSP, choosing a pack factor, or designing a DSP-efficient quantized MAC array — even without naming a method."
---

# DSP Packing for Low-Bit MAC

## Overview

Use this skill to **pack multiple low-bit integer MACs into one FPGA DSP** (DSP48E2/DSP58) as a reusable design technique. Build transparent, decision-ready artifacts grounded in the analyzed REF corpus (HW MODULE_GUIDEs) rather than free-form advice.

This skill complements `hw-nonlinear-dsp-packing-kb`, `fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`, and `algo2fpga`. It should produce reusable artifacts (packing scheme, bit-layout map, pack-factor decision) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable HW objective (MAC/DSP density, throughput, area, accuracy at low bit).
2. List source artifacts (bit-widths W_BIT/IN_BIT, target DSP, kernel shape, source RTL/HLS) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (bit-layout map vs pack-factor decision vs packed-MAC datapath).

## Workflow

1. Capture bit-widths (W_BIT, IN_BIT), target DSP (DSP48E2/DSP58), kernel/array shape, signed vs unsigned, and the accumulation contract.
2. Compute the per-product field width `PROD_BIT = W_BIT + IN_BIT + GUARD` and decide pack factor (how many products share one DSP) and overlapping vs non-overlapping segment layout.
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md` and extract the bit-layout, shift, carry/guard, and segment-extraction patterns with file:line evidence.
4. Design the packing: input/weight bit placement (shift), single multiply, segment extraction (slice), carry/borrow correction (e.g. `(p>>1)+(p&1)`), guard-bit budget for SIMD accumulation, signed subdata subtraction, cascade for the high half.
5. Return artifacts connecting the bit-layout to MAC/DSP density and a validation plan; flag what needs synthesis/bit-exact C-sim to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (packing scheme / bit-layout map / pack-factor decision / packed-MAC datapath) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually synthesis/PPA + bit-exact match).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis HW MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness (bit-exact packed vs unpacked) is separated from performance and resource claims.
- Bit-widths, signed/unsigned, and guard-bit budget are explicit before claiming a pack factor.
- The bit-layout (shift offsets, segment boundaries, overlap) is named before scheduling or cost claims.
- MAC/DSP density (pack factor × spatial lanes) is derived from code (shift/slice/unroll) with file:line; synthesis PPA is cited only if a report exists, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required bit-widths, target DSP, signed/unsigned, or accumulation contract are missing.
- Multiple plausible bit-layouts would materially change the carry-correction or pack factor.
- The result depends on synthesis PPA, achievable Fmax, or bit-exact tooling not available.
- A recommendation would lock the user into a brittle packing without bit-exact validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, the bit-width/guard convention, and known-limitation flags. The reference exemplar is **Uint-Packing** (`CNN-Accel/Uint-Packing-master/MODULE_GUIDE.md`); the project baseline accelerator is **HG-PIPE** (porting via `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`).
