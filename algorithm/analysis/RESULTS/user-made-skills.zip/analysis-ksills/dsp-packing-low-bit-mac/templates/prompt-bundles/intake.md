# Intake Prompt Bundle

Use `$dsp-packing-low-bit-mac` for this request.

1. Normalize the request into a measurable HW objective (MAC/DSP density, throughput, area, accuracy at low bit).
2. Identify source artifacts (bit-widths, sign domain, target DSP, shape, SIMD depth, RTL/HLS) and missing inputs.
3. Select required supporting skills (`hw-nonlinear-dsp-packing-kb`, `fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`) and the matching REF MODULE_GUIDE (Uint-Packing first).
4. Produce the first usable artifact (bit-layout map / pack-factor decision / packed-MAC datapath).
5. Define the verification gate (file:line + bit-exact packed-vs-unpacked match + synthesis PPA) and residual risks.
