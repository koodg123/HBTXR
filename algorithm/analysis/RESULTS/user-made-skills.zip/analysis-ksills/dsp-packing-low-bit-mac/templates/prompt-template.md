# Prompt Template

Use `$dsp-packing-low-bit-mac` to handle the following task.

Objective:

Inputs (bit-widths W_BIT/IN_BIT / signed-unsigned / target DSP / kernel-array shape / accumulation depth SIMD / source RTL or HLS / MODULE_GUIDE refs):

Constraints:

Required artifact (bit-layout map / pack-factor decision / packed-MAC datapath / packed array):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / bit-exact packed-vs-unpacked match / synthesis PPA):

Risks and open questions (carry correction, guard sizing, sign domain):

Return the artifact, evidence, assumptions, risks, and next validation step.
