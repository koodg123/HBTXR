# Production Playbook

## Purpose

This playbook supports `dsp-packing-low-bit-mac` for packing multiple low-bit integer MACs into one FPGA DSP (DSP48E2/DSP58). It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to design or decide (bit-layout, pack factor, packed-MAC datapath, packed array).
- Inputs: bit-widths (W_BIT, IN_BIT), signed vs unsigned, target DSP (DSP48E2/DSP58), kernel/array shape, accumulation depth (SIMD), source RTL/HLS, MODULE_GUIDE references.
- Output format: packing scheme, bit-layout map, pack-factor decision, or packed-MAC datapath.
- Success metrics: MAC/DSP density (pack factor × spatial lanes), throughput, area (DSP/LUT), accuracy at low bit, bit-exact correctness.
- Constraints: tool availability, DSP port widths, guard-bit headroom, non-goals, validation limits.

## Decision Flow

- Capture bit-widths, signed/unsigned, target DSP, shape, accumulation contract.
- Compute `PROD_BIT = W_BIT + IN_BIT + GUARD`; size the per-product field and the guard bits for SIMD accumulation.
- Choose pack factor and layout: non-overlapping segments (DSP2, INT8 2-pack) vs overlap with correction (DSPopt3 4-segment, INT3 6-pack).
- Read the matching REF MODULE_GUIDE(s); extract bit-layout, shift, segment-extraction, carry/guard patterns with file:line.
- Design correction: carry/borrow propagation (e.g. `(p>>1)+(p&1)` or `+ acc[PROD_BIT-1]`), signed subdata subtraction (UINT-packing), cascade for the high half.
- Return artifacts linking the bit-layout to MAC/DSP density and a bit-exact validation plan.

## Tradeoff Questions

- Non-overlapping (simple, fewer products/DSP) vs overlapping (more products/DSP, needs carry correction)?
- How many guard bits before adjacent segments collide under the worst-case SIMD accumulation depth?
- Signed packing (sign-extension cross-talk) vs unsigned + subdata subtraction — which matches the quantizer?
- What is the smallest change validatable by bit-exact C-sim or synthesis now?
- Which existing skill (`hw-nonlinear-dsp-packing-kb`, `fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need synthesis), the guard-bit/carry reasoning, assumptions, risks, and the next validation step (bit-exact match first, then synthesis). Keep it structured enough for another Worker to use directly.
