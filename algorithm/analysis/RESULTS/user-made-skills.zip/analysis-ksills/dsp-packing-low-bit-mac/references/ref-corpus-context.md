# REF Corpus Context — DSP Packing for Low-Bit MAC

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW; "DSP packing" cross-ref). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량); AGNA is a flat summary `.md`.

## Core References (route to these MODULE_GUIDEs)

1. **Uint-Packing** ★레퍼런스 — `CNN-Accel/Uint-Packing-master/MODULE_GUIDE.md`. DSP2(2가중치→2 MAC) + DSPopt3(2픽셀×3가중치→1곱셈 4세그먼트). 비트배치·시프트 분리·세그먼트 추출의 전 메커니즘, `(p>>1)+(p&1)`형 carry 보정, `PROD_BIT=IN_BIT+W_BIT+2` 가드, 4w4a, Ultra96-v2.
2. **TATAA** — `ViT-Accelerator/TATAA/MODULE_GUIDE.md`. INT8 SIMD 2-pack을 DSP48E2 A·D 포트에 배치(transformable PE), ViT 선형/비선형 혼합 워크로드.
3. **Diff-DiT** — `Transformer-Accel/Diff-DiT/MODULE_GUIDE.md`. INT8 2-pack / INT3 6-pack(49152 MAC/cyc), 16×16 OS systolic×32, 13-mode 차분 경로.
4. **AGNA-FCCM2023** — `Others/AGNA-FCCM2023.md`. DSP48E2 cascade INT8 2-MAC, MIGP DSE로 파라미터·인스트럭션 자동 codegen.
5. **SJTU_microe** — `CNN-Accel/SJTU_microe-main/MODULE_GUIDE.md`. 4MUL/DSP 패킹(명시 2D PE array + im2col형), conv2 128 INT4-MAC/cyc(검산 일치).
6. **DAC-SDC 우승작** — `CNN-Accel/dac_sdc_2022_champion-master/MODULE_GUIDE.md` (INT-packing, DSPopt3 4세그먼트, conv1 256 픽셀-MAC/cyc) · `CNN-Accel/dac_sdc_2023_champion-main/MODULE_GUIDE.md` (UINT-packing, unsigned + subdata 차감 보정, 2022 대비 12행 차이표).

(전체 목록·정량 요약은 `INDEX.md` §8 표 + "DSP packing" cross-ref 참조.)

## 핵심 정리 (재사용 설계 규약)

- **비트폭 산식**: `PROD_BIT = W_BIT + IN_BIT + GUARD`. 가드 비트가 SIMD 누산(최대 SIMD개 덧셈)의 캐리/오버플로를 흡수해 인접 세그먼트 충돌을 방지(예: Uint-Packing `PROD_BIT=IN_BIT+W_BIT+2`).
- **시프트 배치 / 부분곱 분리**: 가중치(또는 픽셀)를 `<<PROD_BIT` 간격 슬롯에 배치 → 한 곱셈이 비중첩 구간에 다중 부분곱 산출 → 슬라이스로 세그먼트 추출.
- **세그먼트 겹침 vs 비겹침**: 비겹침(DSP2, INT8 2-pack)은 보정 단순; 겹침(DSPopt3 4세그먼트, INT3 6-pack)은 MAC/DSP 배수↑이지만 borrow/carry 보정 필수(`+acc[PROD_BIT-1]` 또는 `(p>>1)+(p&1)`).
- **signed vs unsigned**: signed는 부호확장 cross-talk; unsigned packing + **subdata 차감**(UINT-packing, dac_sdc_2023)으로 정합. 양자화기(부호 도메인)와 일치시킬 것.
- **cascade 누산**: DSP48E2 cascade(PCIN/PCOUT)로 상위 세그먼트/부분합 누산(AGNA INT8 2-MAC).

## 수치 규약 (정량 도출, 정적)
- MAC/DSP 배수 = pack factor(세그먼트 활용 수) · 가드 비트 = `PROD_BIT − (W_BIT+IN_BIT)` · 전체 처리량 = pack factor × spatial lanes(PE×SIMD). 합성 PPA(DSP/LUT/Fmax)는 리포트 동봉 시만 인용, 없으면 "확인 필요".

## Reusable Verification Questions
- 가중치/입력 비트폭(W_BIT, IN_BIT)과 부호(signed/unsigned)는?
- 타깃 DSP(DSP48E2/DSP58)와 포트(A/B/D, pre-adder, cascade) 사용은?
- 누산 깊이(SIMD)와 가드 비트 예산은 충분한가(인접 세그먼트 충돌 없음)?
- 패킹 배치는 겹침인가 비겹침인가, carry/borrow 보정은 어디서?
- 검증 가능한 최소 단위(1 packed MAC의 bit-exact 패킹 vs 비패킹 일치)는?

## Why This Skill Is Relevant
REF 코퍼스의 DSP packing 일가(Uint-Packing/AGNA/AnyPackingNet/Diff-DiT/TATAA/DAC-SDC 우승작)가 1 DSP에 다중 저비트 MAC을 반복적으로 압축하며, file:line 근거로 비트배치·보정·세그먼트 설계를 뒷받침한다. 본 프로젝트 DSP 효율 1순위 차용 기법.
