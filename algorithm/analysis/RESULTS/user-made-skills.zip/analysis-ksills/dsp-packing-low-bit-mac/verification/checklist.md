# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: dsp-packing-low-bit-mac` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable HW objective.
- [ ] Bit-widths (W_BIT, IN_BIT), sign domain, target DSP, and SIMD accumulation depth are separated from assumptions and constraints.
- [ ] Required supporting skills and the matching REF MODULE_GUIDE are named.
- [ ] The bit-layout is explicit: PROD_BIT = W_BIT + IN_BIT + GUARD, shift offsets, segment boundaries, overlap vs non-overlap.
- [ ] Guard bits are shown to prevent adjacent-segment collision at the worst-case SIMD depth.
- [ ] Carry/borrow correction and (for UINT-packing) subdata subtraction are specified.
- [ ] MAC/DSP density (pack factor × spatial lanes) carries file:line evidence; synthesis PPA is cited only if a report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (bit-exact packed-vs-unpacked match, synthesis) are explicit.
- [ ] Residual risks and next validation steps are listed.
