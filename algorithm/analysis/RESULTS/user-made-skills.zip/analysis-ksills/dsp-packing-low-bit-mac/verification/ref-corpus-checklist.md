# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s) (Uint-Packing is the reference exemplar).
- [ ] Applied this skill to the relevant packing variant (DSP2 / DSPopt3 4-segment / INT8 2-pack / INT3 6-pack / UINT-packing / cascade 2-MAC).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE (bit-layout, shift, segment extraction, carry correction).
- [ ] Kept the quantitative convention (PROD_BIT = W_BIT + IN_BIT + GUARD; MAC/DSP = pack factor × spatial lanes; synthesis PPA = "확인 필요" if no report).
- [ ] Carried over known-limitation flags (signed cross-talk, subdata subtraction for unsigned, overlap needing carry correction, guard headroom vs SIMD depth).
- [ ] Produced a concrete artifact + bit-exact validation plan, and stated HG-PIPE relevance / porting link where applicable.
