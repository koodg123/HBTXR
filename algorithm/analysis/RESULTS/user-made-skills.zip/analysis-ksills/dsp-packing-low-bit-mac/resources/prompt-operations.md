# Prompt Operations

## Prompt Pack Fields

- Skill: `dsp-packing-low-bit-mac`
- Objective: one sentence (design bit-layout / choose pack factor / build packed-MAC datapath / pack an array).
- Context: bit-widths (W_BIT, IN_BIT), signed/unsigned, target DSP, kernel/array shape, accumulation depth (SIMD), source RTL/HLS, MODULE_GUIDE refs.
- Constraints: scope, tools, DSP port budget, guard-bit headroom, non-goals.
- Required output: exact artifact type (bit-layout map / pack-factor decision / packed-MAC datapath / packed array).
- Verification: evidence needed (file:line, bit-exact packed-vs-unpacked match, synthesis PPA).
- Risks: assumptions and missing data (carry correction, guard sizing, sign domain).

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (bit-width/sign/DSP/guard) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when bit-widths, sign domain, target DSP, guard-bit budget, or acceptance criteria are missing and the missing fact would change the bit-layout, carry correction, or pack factor. Never fabricate synthesis PPA or claim a pack factor without the guard-bit reasoning.
