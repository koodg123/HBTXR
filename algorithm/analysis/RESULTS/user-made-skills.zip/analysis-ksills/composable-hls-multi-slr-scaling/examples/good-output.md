# Good Output Example

## Prompt Pack

Skill: `composable-hls-multi-slr-scaling`
Objective: Partition a single-die-exceeding accelerator into a 3-SLR composable-HLS design (task boundaries, AXI-stream chain, HBM allocation, floorplan plan).
Inputs: model/workload (dims/seq/depth, weight size), board die+SLR map + HBM channels, datatype, source TAPA/HLS (if any).
Constraints: state tool, data, target, and scope limits.
Verification: define the evidence (file:line, RapidStream floorplan, P&R timing) required for signoff.

## Artifact

단일 die를 초과하는 가속기를 **3-SLR로 분할**하는 결정표, **MODULE_GUIDE line evidence**로 뒷받침:
- Task 경계: composable HLS task로 layer/stage 분할(예: prefill 2D / decode 1D 분리 — cite `…/FlexLLM/MODULE_GUIDE.md`); 각 task를 한 SLR에 상주시켜 crossing 최소화.
- AXI-stream 체인: SLR간 경계는 폭/깊이 명시한 AXI-stream FIFO로만 연결(SLR-crossing 수 = task 경계 수); 2-SLR 스트림 링/3-stage 분할 패턴 참조.
- HBM 채널 배분: task당 HBM 채널/뱅크 할당(가중치 스트리밍으로 온칩 상주 탈피); DSE 자동화로 채널-PE 배분 결정(route to HiSparse/HiSpMV automation_tool).
- Floorplan: RapidStream로 die/SLR region 배치; SLR-crossing FIFO를 die 경계에 정렬.
- Tradeoff와 RapidStream 플로어플랜으로 먼저 검증 가능한 최소 변경.

## Risks

List uncertain assumptions (예: SLR-crossing 후 achieved Fmax, HBM 유효 대역폭, region별 자원 fit) and the next experiment (RapidStream floorplan + P&R/timing, HBM bandwidth 측정) to resolve each. 합성 PPA·달성 Fmax는 리포트 부재 시 "확인 필요".
