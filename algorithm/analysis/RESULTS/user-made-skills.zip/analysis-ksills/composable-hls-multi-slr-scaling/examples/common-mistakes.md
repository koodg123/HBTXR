# Common Mistakes

- Producing general scale-up advice without a prompt pack or a concrete task-partition / floorplan / HBM-allocation artifact.
- Quoting achieved Fmax or HBM bandwidth without file:line/topology evidence, or citing post-floorplan PPA that does not exist in the repo (should be "확인 필요").
- Mixing functional task decomposition with floorplan and bandwidth claims.
- Partitioning across SLRs without stating the AXI-stream FIFO depth/width and the SLR-crossing count consequence.
- Forgetting to route into the relevant REF scale-up MODULE_GUIDE before inventing a new partition.
- Assuming weights stay on-chip when the design outgrows one die — failing to plan HBM streaming / channel allocation.
- Recommending an irreversible SLR partition or HBM mapping with no validation (RapidStream floorplan, P&R timing) path.
