# Intake Prompt Bundle

Use `$composable-hls-multi-slr-scaling` for this request.

1. Normalize the request into a measurable scale-up objective (throughput/latency/SLR-fit/HBM-bandwidth/Fmax).
2. Identify source artifacts (model/workload + weight size, board die+SLR+HBM map, TAPA/HLS) and missing inputs.
3. Select required supporting skills (`fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`, `high-level-synthesis-expert`, `algo2fpga`) and the matching REF scale-up MODULE_GUIDE.
4. Produce the first usable artifact (task-partition / floorplan-SLR / HBM-allocation plan).
5. Define the verification gate (file:line + RapidStream floorplan / P&R timing) and residual risks.
