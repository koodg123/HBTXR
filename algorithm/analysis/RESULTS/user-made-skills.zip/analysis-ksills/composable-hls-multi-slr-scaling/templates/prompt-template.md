# Prompt Template

Use `$composable-hls-multi-slr-scaling` to handle the following task.

Objective:

Inputs (model/workload + weight size / datatype / board die+SLR+HBM map / source TAPA or HLS / MODULE_GUIDE refs):

Constraints:

Required artifact (task-partition plan / floorplan-SLR plan / HBM-allocation table / scale-up codebase MODULE_GUIDE):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / RapidStream floorplan / P&R timing / HBM bandwidth):

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
