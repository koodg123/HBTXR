# Production Playbook

## Purpose

This playbook supports `composable-hls-multi-slr-scaling` for FPGA accelerator scale-up across multiple SLRs/dies/HBM using composable HLS (TAPA) + RapidStream. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what to partition, scale, or analyze (task split, SLR/die floorplan, HBM allocation, scale-up codebase).
- Inputs: model/workload (dims/seq/depth/weight size), board die+SLR map + HBM channels/bandwidth, datatype, source TAPA/HLS, MODULE_GUIDE references.
- Output format: task-partition plan, floorplan/SLR plan, HBM channel-allocation table, or scale-up codebase MODULE_GUIDE.
- Success metrics: throughput/II, latency (avg + p95/p99), SLR/die resource fit, HBM bandwidth utilization, achieved Fmax, SLR-crossing count.
- Constraints: tool availability (TAPA/RapidStream), board fit, non-goals, validation limits.

## Decision Flow

- Capture device die/SLR map + HBM channels, model/workload + weight size, datatype, clock, runtime contract.
- Identify design entry/boundary: TAPA composable task graph vs RapidStream floorplan vs mixed hand-RTL crossing.
- Read the matching REF MODULE_GUIDE(s); extract task-partition / AXI-stream chain / SLR-crossing / HBM-channel patterns with file:line.
- Compute cost statically: task split granularity, AXI-stream FIFO depth/width, on-chip vs HBM-streamed weight bytes, HBM channels/banks per task, SLR-crossing count.
- Return artifacts linking task graph, floorplan, HBM/memory dataflow, and validation metrics.

## Tradeoff Questions

- Which partition would be costly to reverse (task-to-SLR binding, on-chip-resident vs HBM-streamed weights, channel-to-PE allocation)?
- Which assumption (post-crossing Fmax, HBM effective bandwidth, region resource fit) most likely invalidates the artifact?
- What is the smallest change validatable by RapidStream floorplan or P&R timing now?
- Which existing skill (`fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`, `high-level-synthesis-expert`, `algo2fpga`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need floorplan/P&R), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
