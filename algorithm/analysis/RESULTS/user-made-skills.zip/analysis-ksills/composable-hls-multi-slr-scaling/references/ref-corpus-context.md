# REF Corpus Context — Composable HLS Multi-SLR/HBM Scale-Up

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§8 HW, §3.2 "Composable HLS + floorplan" 패턴). 각 repo는 심층 `MODULE_GUIDE.md`(6요소 + 정량) 또는 1차 요약 `<repo>.md`. (라우팅 경로는 실재 파일 기준으로 검증됨; MODULE_GUIDE 부재 항목은 1차 `.md`로 라우팅 + "확인 필요".)

## Core Clusters (route to these MODULE_GUIDEs)

1. **TAPA + RapidStream 멀티-SLR (1순위)** ★: `ViT-Accelerator/FlexLLM/MODULE_GUIDE.md` (SpinQuant LLaMA-3.2-1B, composable HLS(TAPA)+RapidStream, **prefill 2D / decode 1D**, 멀티-SLR; i4 2×2=4MAC/DSP, prefill FFN 2048 MAC/cyc, GQA 32/8). 동일 계열 사본: `Transformer-Accel/FlexLLM/MODULE_GUIDE.md`.
2. **TAPA end-to-end (U280)**: `Transformer-Accel/FPGA_Friendly_SpinQuant/MODULE_GUIDE.md` (SpinQuant Hadamard R4+W4A4, TAPA HLS, prefill+decode+on-FPGA Top-K end-to-end; i4 2×2 4MAC/DSP, FHT R4 곱셈0·13stage, Top-K=5).
3. **HBM 채널 배분 + DSE 자동화**: `Others/HiSparse/MODULE_GUIDE.md` (FPGA'22 HBM SpMV, 128-way(16ch×8), 2단 셔플 + URAM forwarding PE + CPSR), `Others/HiSpMV/MODULE_GUIDE.md` (TAPA/HBM SpMV, 128 PE, Pre-Accumulator·RDN 불균형행 흡수, **automation_tool DSE+crossbar+codegen**, DSE 채널배분식). HiSpMM(`Others/HiSpMM/MODULE_GUIDE.md`)은 N0=8 SIMD 확장.
4. **3-SLR region 분할 / HBM (HLS 소스 부재 → 1차 .md + "확인 필요")**: `ViT-Accelerator/LLM_FPGA.md` (HeteroCL/Allo W8A8 Transformer, int8 2-pack GEMM, **3-SLR**, U280 HBM; HLS 소스 부재→리포트 역추정). 동일: `Transformer-Accel/LLM_FPGA.md`.
5. **TAPA fuse / 2-SLR 스트림 링 (HLS 소스 일부 부재 → 1차 .md + "확인 필요")**: `ViT-Accelerator/LUT-LLM.md` (Qwen3 1.7B, TAPA+RapidStream, 활성 VQ→2D-LUT, V80/VPK180; HLS 소스 부재→빌드/리포트 역공학), `ViT-Accelerator/TeraFly.md` (LoopLynx 확장, HeteroCL/Allo OPT-1.3B **2-SLR 스트림 링**, codegen.py toml→HLS, weight_packer INT8; RTL/HLS 부재→토폴로지 역추론). 동일 사본: `Transformer-Accel/LUT-LLM.md`, `Transformer-Accel/TeraFly.md`.

> 참고: 위 라우팅 경로는 Glob으로 실재 확인함. FlexLLM·FPGA_Friendly_SpinQuant·HiSparse·HiSpMV는 MODULE_GUIDE.md 실재; LLM_FPGA·LUT-LLM·TeraFly는 MODULE_GUIDE 부재로 1차 `.md` 라우팅 → 라인단위 task/floorplan 근거는 "확인 필요"(리포트·디렉토리 규약 역추정만). (전체 목록은 `INDEX.md` §8 표 참조.)

## 핵심 설계 기법 (이 스킬의 차용 대상)
- **Composable task 분할**: 레이어/스테이지를 독립 task로(prefill/decode 분리, 다중 카드 N-stage 분할), 각 task를 한 SLR/region에 상주시켜 crossing 최소화.
- **RapidStream floorplan**: die/SLR region 배치 자동화, SLR-crossing FIFO를 die 경계에 정렬.
- **SLR-crossing FIFO (AXI-stream)**: 경계는 폭/깊이 명시 AXI-stream FIFO로만; crossing 수 = task 경계 수.
- **HBM 채널/뱅크 배분**: task당 HBM 채널/뱅크 할당, crossbar/셔플로 PE에 분배(HiSparse 128-way·HiSpMV automation_tool DSE).
- **가중치 스트리밍 (온칩 상주 탈피)**: 단일 die 온칩 용량 초과 시 가중치를 HBM에서 스트리밍(W4A4/INT8 패킹).
- **DSE 자동화**: 채널-PE 배분·partition을 automation_tool/codegen으로 탐색(HiSpMV/TeraFly/LLM_FPGA).

## 수치 규약 (정량 도출, 정적)
- task split granularity·AXI-stream FIFO depth/width·SLR-crossing count·HBM 채널/뱅크 per task·on-chip vs HBM-streamed 가중치 byte는 코드/토폴로지에서 정적 도출. **합성 PPA·달성 Fmax·HBM 유효대역폭은 리포트 동봉 시만 인용, 없으면 "확인 필요"**.

## Reusable Verification Questions
- 타깃 디바이스의 die/SLR 수·HBM 채널/대역폭·런타임 계약은?
- 모델/워크로드 shape(seq·dim·depth)와 가중치 총 byte(온칩 상주 가능 여부)는?
- 설계 진입점은 TAPA composable task 그래프인가 RapidStream floorplan인가(혼합)?
- SLR 경계는 어디(task 경계 수 = SLR-crossing 수)이고 AXI-stream FIFO 폭/깊이는?
- 1차 지표는 throughput/latency/SLR-fit/HBM-bandwidth/Fmax 중 무엇?

## Why This Skill Is Relevant
REF 코퍼스의 스케일업 가속기(FlexLLM/FPGA_Friendly_SpinQuant/LLM_FPGA/LUT-LLM/TeraFly + HBM SpMV HiSparse/HiSpMV/HiSpMM)가 TAPA composable HLS·RapidStream floorplan·SLR-crossing FIFO·HBM 채널 배분·가중치 스트리밍·DSE 자동화를 반복적으로 다루며, file:line/토폴로지 근거로 스케일업 의사결정을 뒷받침한다.
