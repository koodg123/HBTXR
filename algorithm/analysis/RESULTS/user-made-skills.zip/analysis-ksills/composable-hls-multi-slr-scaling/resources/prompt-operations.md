# Prompt Operations

## Prompt Pack Fields

- Skill: `composable-hls-multi-slr-scaling`
- Objective: one sentence (partition / scale-up / floorplan / analyze).
- Context: model/workload + weight size, datatype, board die+SLR+HBM map, source TAPA/HLS, MODULE_GUIDE refs.
- Constraints: scope, tools (TAPA/RapidStream), target platform, non-goals.
- Required output: exact artifact type (task-partition plan / floorplan-SLR plan / HBM-allocation table / scale-up codebase MODULE_GUIDE).
- Verification: evidence needed (file:line, RapidStream floorplan, P&R timing, HBM bandwidth).
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (die/SLR map, HBM channels, weight size, datatype) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when device die/SLR/HBM map, model/weight size, datatype, or acceptance criteria are missing and the missing fact would change the partition/floorplan/HBM allocation. Never fabricate post-floorplan PPA, achieved Fmax, or HBM bandwidth.
