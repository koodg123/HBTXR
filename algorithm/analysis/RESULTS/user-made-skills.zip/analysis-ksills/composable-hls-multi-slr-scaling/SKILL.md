---
name: composable-hls-multi-slr-scaling
description: "FPGA 가속기를 다중 SLR/다중 die/HBM로 스케일업하는 composable HLS 설계 기법(TAPA + RapidStream). task 분할·AXI-stream 체이닝·SLR-crossing 최소화·floorplan·HBM 채널 배분·온칩 상주 한계 탈피. REF/Analysis의 스케일업 MODULE_GUIDE(FlexLLM/FPGA_Friendly_SpinQuant/HiSparse/HiSpMV 등)로 라우팅. Use whenever an accelerator outgrows one die/region, when partitioning a design across SLRs, or when planning HBM bandwidth and floorplan for a large transformer/LLM/sparse accelerator."
---

# Composable HLS Multi-SLR Scaling

## Overview

Use this skill for **다중 SLR/다중 die/HBM 스케일업** 가속기 설계 — composable HLS(TAPA) + RapidStream floorplan 기반. 단일 die/region을 초과하는 가속기를 task 분할·AXI-stream 체이닝·SLR-crossing 최소화·HBM 채널 배분으로 스케일업하는 결정-가능 산출물을, 분석된 REF 코퍼스(스케일업 MODULE_GUIDE)에 근거해 생성한다.

This skill complements `fpga-transformer-accelerator-kb`, `sparse-cnn-systolic-accel-kb`, `high-level-synthesis-expert`, and `algo2fpga`. It should produce reusable artifacts (task-partition plan, floorplan/SLR plan, HBM channel-allocation plan) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable scale-up objective (throughput/latency/SLR fit/HBM bandwidth/Fmax).
2. List source artifacts (model/workload, board die+SLR map, HBM channels, source TAPA/HLS) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which artifact comes first (task-partition plan vs floorplan/SLR plan vs HBM allocation plan).

## Workflow

1. Capture target device (die/SLR count, HBM channels/bandwidth), model/workload (dims, seq, depth, weight size), datatype, clock, and runtime contract.
2. Identify the design entry and boundary: TAPA composable HLS task graph, RapidStream floorplan/partition, or mixed hand-RTL crossing.
3. Read the relevant REF MODULE_GUIDE(s) via `references/ref-corpus-context.md` and extract task-partition/AXI-stream/SLR-crossing/HBM patterns with file:line evidence.
4. Plan or compare with measurable cost: task split granularity, AXI-stream FIFO depth/width across SLR, on-chip vs HBM-streamed weights, HBM channels/banks per task, SLR-crossing count.
5. Return artifacts connecting task graph, floorplan, HBM/memory dataflow, and validation metrics; flag what needs synthesis/place-and-route to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (task-partition / floorplan-SLR / HBM-allocation plan or scale-up codebase analysis) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually RapidStream floorplan + P&R/timing).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis scale-up MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Functional task decomposition is separated from floorplan and HBM-bandwidth claims.
- Datatype, weight-size, and SLR/die-fit constraints are explicit.
- Board/die/SLR/HBM-channel assumptions are named before partition or bandwidth claims.
- Cost numbers (task split, AXI-stream depth/width, SLR-crossing count, HBM channels/banks) are derived from code/topology with file:line; achieved Fmax and post-floorplan PPA are cited only if a report exists, else "확인 필요".
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (TAPA/HLS, model/weight size, board die+SLR+HBM map) or constraints are missing.
- Multiple plausible interpretations would materially change the partition or floorplan.
- The result depends on RapidStream floorplan, P&R timing, board bandwidth measurements, or unavailable tools.
- A recommendation would lock the user into a brittle SLR partition or HBM mapping without validation evidence.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. The project baseline accelerator is **HG-PIPE**; porting/extension is captured in `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.
