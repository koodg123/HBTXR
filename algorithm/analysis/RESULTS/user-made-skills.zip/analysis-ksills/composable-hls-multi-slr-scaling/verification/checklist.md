# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: composable-hls-multi-slr-scaling` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable scale-up objective.
- [ ] Source artifacts (model/weight size, board die+SLR+HBM map, datatype), assumptions, and constraints are separated.
- [ ] Required supporting skills and the matching REF scale-up MODULE_GUIDE are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] Cost numbers (task split, AXI-stream depth/width, SLR-crossing count, HBM channels/banks) carry file:line/topology evidence; achieved Fmax / post-floorplan PPA / HBM bandwidth cited only if a report exists, else marked "확인 필요".
- [ ] Verification evidence and acceptance criteria (RapidStream floorplan / P&R timing / HBM bandwidth) are explicit.
- [ ] Residual risks and next validation steps are listed.
