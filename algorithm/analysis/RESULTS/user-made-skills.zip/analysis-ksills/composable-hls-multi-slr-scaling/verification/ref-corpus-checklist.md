# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md`(s) — or the 1차 `.md` with "확인 필요" when the MODULE_GUIDE is absent (LLM_FPGA / LUT-LLM / TeraFly).
- [ ] Applied this skill to the relevant scale-up cluster (TAPA+RapidStream multi-SLR / TAPA end-to-end / HBM channel allocation+DSE / 3-SLR region / 2-SLR stream ring).
- [ ] Preserved source-linked (file:line) or topology-derived evidence from the MODULE_GUIDE / 1차 .md.
- [ ] Kept the quantitative convention (task split / AXI-stream depth+width / SLR-crossing count / HBM channels+banks / weight-streamed bytes; achieved Fmax / post-floorplan PPA / HBM bandwidth = "확인 필요" if no report).
- [ ] Carried over known-limitation flags (e.g., HLS source absent → topology/report reverse-engineered, "라인단위 확인 필요").
- [ ] Produced a concrete artifact + validation evidence, and stated HG-PIPE relevance / porting link where applicable.
