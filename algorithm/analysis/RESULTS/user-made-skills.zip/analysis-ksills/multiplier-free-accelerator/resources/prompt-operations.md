# Prompt Operations

## Prompt Pack Fields

- Skill: `multiplier-free-accelerator`
- Objective: one sentence (which multiply to remove, with which substitution).
- Context: model spec, datatype/bit-width, weight/scale source, target board+clock, source RTL/HLS, MODULE_GUIDE refs.
- Constraints: scope, tools, target platform, non-goals.
- Required output: exact artifact type (substitution plan / accumulator bit-budget / resource·accuracy tradeoff).
- Verification: evidence needed (file:line, synthesis PPA, bit-exact C-sim, accuracy run).
- Risks: assumptions and missing data (accumulator overflow, accuracy at low bit, LUT fit).

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise when reviewers find missing constraints (bit-width/accumulator/scale source) or weak evidence.
4. Produce the artifact only after success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when device/clock, model spec, bit-width, accumulator policy, or acceptance criteria are missing and the missing fact would change the substitution/cost. Never fabricate synthesis PPA or accuracy numbers.
