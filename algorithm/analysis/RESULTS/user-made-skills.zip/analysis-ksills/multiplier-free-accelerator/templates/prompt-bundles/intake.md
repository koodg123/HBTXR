# Intake Prompt Bundle

Use `$multiplier-free-accelerator` for this request.

1. Normalize the request into a measurable HW objective (DSP↓/throughput/latency/area/power/accuracy) and name which multiply to remove.
2. Identify source artifacts (model spec, bit-width, weight/scale source, board+clock, RTL/HLS) and missing inputs.
3. Select required supporting skills (`hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, `dsp-packing-low-bit-mac`) and the matching REF MODULE_GUIDE.
4. Produce the first usable artifact (substitution plan / accumulator bit-budget / resource·accuracy tradeoff).
5. Define the verification gate (file:line + synthesis PPA + accuracy run) and residual risks.
