# Prompt Template

Use `$multiplier-free-accelerator` to handle the following task.

Objective (which multiply to remove, with which substitution):

Inputs (model spec / datatype+bit-width / weight or scale source / board+clock / source RTL or HLS / MODULE_GUIDE refs):

Constraints:

Required artifact (substitution plan / accumulator bit-budget / resource·accuracy tradeoff):

Known facts (with file:line):

Assumptions:

Verification evidence (file:line / synthesis PPA / bit-exact C-sim / accuracy run):

Risks and open questions (accumulator overflow / accuracy at low bit / LUT fit):

Return the artifact, evidence, assumptions, risks, and next validation step.
