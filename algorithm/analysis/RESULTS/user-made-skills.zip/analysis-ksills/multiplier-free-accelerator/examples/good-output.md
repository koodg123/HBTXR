# Good Output Example

## Prompt Pack

Skill: `multiplier-free-accelerator`
Objective: Replace a Linear layer's multipliers with a shift-add datapath (곱셈 0), with verified accumulator width and accuracy.
Inputs: model spec (dims/seq/depth), weight/scale source, datatype/bit-width, target board+clock.
Constraints: state tool, data, target, and scope limits.
Verification: define the evidence (file:line, synthesis PPA, accuracy run) required for signoff.

## Artifact

Linear층을 shift-add로 치환 — structured decisions with **MODULE_GUIDE line evidence**, e.g.:
- Substitution: weight = sign·2^shift (reparameterize), so MAC → barrel-shift + add; 곱셈 0 (cite ShiftAddViT `…/MODULE_GUIDE.md`).
- Accumulator: input bit + max-shift range → accumulator bit-width; state overflow margin (확인 필요 if not derivable).
- Resource: shifters/adders per lane vs the DSP-MAC it replaces; DSP saved (count or "확인 필요" until synthesis).
- Accuracy: cite the source's reported degradation vs FP/INT8 baseline; if absent, mark "확인 필요" and require an eval run.
- Tradeoff and the smallest change validatable by synthesis + bit-exact/accuracy check first.

## Risks

List uncertain assumptions (e.g., accumulator overflow at long seq, accuracy at sub-4bit, LUT table fit in BRAM) and the next experiment (synthesis/PPA, bit-exact C-sim, accuracy eval) to resolve each.
