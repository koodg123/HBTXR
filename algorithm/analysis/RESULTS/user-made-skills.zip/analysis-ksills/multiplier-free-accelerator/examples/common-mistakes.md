# Common Mistakes

- Producing general "remove the multiplier" advice without a prompt pack or a concrete artifact.
- Claiming "곱셈 0" without naming the replacement (shift+add / LUT / ternary / PoT) and its cost.
- Omitting the accumulator bit-width / overflow margin after replacing the MAC.
- Quoting DSP savings or area without file:line evidence, or citing synthesis PPA that does not exist in the repo (should be "확인 필요").
- Stating an accuracy number that the source does not report (should be "확인 필요" + eval run).
- Mixing functional correctness with performance and resource claims.
- Forgetting to route into the relevant REF MODULE_GUIDE before inventing a substitution.
- Recommending an irreversible arithmetic substitution with no validation (synthesis, bit-exact C-sim, accuracy) path.
