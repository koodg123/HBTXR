# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: multiplier-free-accelerator` and a clear, trigger-rich description.
- [ ] The output starts from a prompt pack and a measurable HW objective.
- [ ] Source artifacts (model/bit-width/scale source/board/clock), assumptions, and constraints are separated.
- [ ] The removed multiply (MAC / scale / nonlinear) and its replacement (shift+add / LUT / ternary / PoT) are explicit.
- [ ] Accumulator bit-width and overflow margin are stated.
- [ ] Required supporting skills and the matching REF MODULE_GUIDE are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] Cost numbers (shifters/adders, LUT entries×bit, gather width, DSP saved) carry file:line evidence; synthesis PPA cited only if a report exists, else "확인 필요".
- [ ] Accuracy claims are cited from the source, else marked "확인 필요" + eval run.
- [ ] Verification evidence and acceptance criteria (synthesis / bit-exact C-sim / accuracy) are explicit.
- [ ] Residual risks and next validation steps are listed.
