# REF Corpus Checklist

- [ ] Read `references/ref-corpus-context.md` and opened the matching `MODULE_GUIDE.md` / 요약(s).
- [ ] Applied this skill to the relevant substitution (shift&add / LUT 조회 / 삼진 가감산 / PoT·log 시프트).
- [ ] Preserved source-linked (file:line) evidence from the MODULE_GUIDE; for source-absent repos (lut-gemm, LUT-LLM) used 요약·리포트 and marked line-level "확인 필요".
- [ ] Kept the quantitative convention (shifters/adders, LUT entries×bit, gather width, accumulator bit-width; DSP saved / synthesis PPA = "확인 필요" if no report).
- [ ] Cited accuracy from the source, else marked "확인 필요" (no invented numbers).
- [ ] Carried over known-limitation flags (HLS source absent for lut-gemm/LUT-LLM, ternaryLLM partial checkout / SSR source absent).
- [ ] Produced a concrete artifact + validation evidence, and stated HG-PIPE relevance / porting link where applicable.
