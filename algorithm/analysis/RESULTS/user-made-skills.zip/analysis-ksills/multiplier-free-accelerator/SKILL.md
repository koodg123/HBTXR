---
name: multiplier-free-accelerator
description: "곱셈기를 제거한 가속기 데이터패스 설계 기법. 가중치를 shift&add로 reparameterize, 활성 부분합 LUT 조회(LUT-GEMM), 삼진({-1,0,+1}) 가감산 누산, Power-of-Two/log 스케일→시프트. DSP-lite·저전력 MAC 대체. Use whenever replacing multipliers with shift/LUT/ternary in a quantized accelerator, or evaluating multiplier-free arithmetic tradeoffs — even without naming a method."
---

# Multiplier-Free Accelerator Design

## Overview

Use this skill for **곱셈기를 제거한 가속기 데이터패스** 설계: 곱셈을 시프트+덧셈, LUT 조회, 또는 가감산으로 치환하여 DSP/전력을 줄인다. Build transparent, decision-ready artifacts grounded in the analyzed REF corpus (multiplier-free MODULE_GUIDEs/요약) rather than free-form advice.

This skill complements `hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, and `dsp-packing-low-bit-mac`. It should produce reusable artifacts (substitution plan, accumulator bit-budget, resource/accuracy tradeoff) backed by concrete MODULE_GUIDE evidence.

## Prompt-First Rule

Before solving, write a compact prompt pack naming the objective, inputs, constraints, success metrics, and known unknowns. Use `templates/prompt-template.md` or `scripts/build_prompt.py` when a reusable prompt artifact helps.

## Start Every Task With

1. Restate the user goal as a measurable HW objective (DSP↓/throughput/latency/area/power/accuracy).
2. List source artifacts (weights/scales, model spec, datatype/bit-width, board, clock) and target deliverables.
3. Identify required skills, reviewer roles, and verification evidence.
4. Separate known facts (from MODULE_GUIDE line evidence), assumptions, and hypotheses.
5. Decide which arithmetic substitution comes first (shift-add vs LUT lookup vs ternary add/sub vs PoT/log shift).

## Workflow

1. Capture target device, model/workload (dims, seq, depth), datatype/quantization, clock, and runtime contract.
2. Identify which multiply to remove: weight×activation MAC, scale multiply, or nonlinear-domain multiply.
3. Read the relevant REF MODULE_GUIDE(s)/요약 via `references/ref-corpus-context.md` and extract substitution patterns (shift&add / LUT / ternary / PoT) with file:line evidence.
4. Plan with measurable cost: shifters/adders per lane, LUT table size (entries×bit), gather/index width, accumulator bit-width, DSP saved.
5. Return artifacts connecting the arithmetic substitution, accumulation precision, and accuracy/resource validation; flag what needs synthesis to confirm.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact (multiplier-free substitution plan / accumulator bit-budget / resource·accuracy tradeoff) with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments (usually synthesis/PPA + accuracy eval).

## Supporting Files

- `references/production-playbook.md` for the repeatable workflow and decision points.
- `references/ref-corpus-context.md` for routing into REF/Analysis multiplier-free MODULE_GUIDEs (the knowledge source).
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` and `templates/prompt-bundles/intake.md` for reusable prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `verification/ref-corpus-checklist.md` to preserve REF-corpus assumptions and evidence.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical/functional correctness is separated from performance and resource claims.
- The exact multiply being removed (MAC / scale / nonlinear) and its replacement (shift+add / LUT / ternary / PoT) are explicit.
- Accumulator bit-width and overflow margin are stated, not assumed.
- Cost numbers (shifters/adders, LUT entries×bit, gather width, DSP saved) are derived from code (unroll/shape/table) with file:line; synthesis PPA is cited only if a report exists, else "확인 필요".
- Accuracy claims are cited from the source or marked "확인 필요"; never invented.
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts (weights/scales, model spec, bit-width, board/clock) or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result depends on synthesis PPA, board measurements, or accuracy runs that are unavailable.
- A recommendation would lock the user into an irreversible arithmetic substitution without accuracy/synthesis validation.

## REF Corpus Context

For tasks grounded in the analyzed corpus at `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`, read `references/ref-corpus-context.md` before planning. Use `verification/ref-corpus-checklist.md` to preserve the MODULE_GUIDE line-evidence, quantitative conventions, and known-limitation flags. The project baseline accelerator is **HG-PIPE**; porting/extension is captured in `REF/Analysis/HG-PIPE_PORTING_ROADMAP.md`.
