# REF Corpus Context — Multiplier-Free Accelerator Datapaths

Source analysis root: `\\wsl.localhost\ubuntu-24.04\home\user\project\PRJXR-HBTXR\REF\Analysis`
Master catalog/cross-analysis: `REF/Analysis/INDEX.md` (§3.1 곱셈기 제거, §9.4 곱셈 HW화 의사결정). Each repo has a deep `MODULE_GUIDE.md` (6요소 + 정량) or a 1차 요약 `<repo>.md`.

## Core Substitutions (route to these MODULE_GUIDEs / 요약)

1. **shift&add (weight = sign·2^shift)** ★: `ViT-Quantization/ShiftAddViT/MODULE_GUIDE.md` — 곱셈을 shift&add로 reparameterize한 곱셈기-경감 ViT(~49× MAC 에너지↓ 주장). 곱셈→barrel-shift+가산.
2. **LUT 부분합 조회 (sub-4bit GEMV, 디퀀트 없이)**: `ViT-Accelerator/lut-gemm.md` (요약; HLS 소스 부재) — BCQ/RTN 가중치를 디퀀트 없이 부분합 LUT 조회로 곱하는 W4A16 GEMV. MODULE_GUIDE 부재 → 요약·리포트 근거, 라인단위 "확인 필요".
3. **활성 VQ → 2D-LUT 조회 → 정수덧셈 (런타임 곱셈 0)**: `ViT-Accelerator/LUT-LLM.md` (요약; HLS 소스 부재) — 선형층 곱셈을 활성 VQ→2D-LUT 조회→정수덧셈으로 치환. MODULE_GUIDE 부재 → 빌드/리포트 역공학, 라인단위 "확인 필요".
4. **삼진({-1,0,+1}) 가감산 누산 (TCSC gather)**: `ViT-Accelerator/ternaryLLM/MODULE_GUIDE.md` — 삼진 가중치 LLM을 CPU(TCSC+AVX)/GPU(SpMM)/FPGA(SpinalHDL)에 사상. 곱셈→인덱싱+가감산(0 스킵). SSR 소스 일부 부재(부분 체크아웃).
5. **Power-of-Two 스케일 → 시프트**: `ViT-Quantization/P2-ViT/MODULE_GUIDE.md` — PoT PTQ + 전용 가속기 지향. 스케일 곱셈→시프트.
6. **로그밑(adaptive log) → 시프트 + 소형 LUT**: `ViT-Quantization/AdaLog/MODULE_GUIDE.md` — 적응 로그밑 양자화. 로그영역 정렬→시프트+소형 LUT.

(전체 목록·정량 요약은 `INDEX.md` §3.1·§9.4 참조.)

## 핵심 의사결정
- 곱셈 → {시프트+덧셈 / LUT 조회 / 가감산} 중 무엇으로 치환할지(데이터 vs 가중치 분포·비트폭 의존).
- 정확도 vs DSP/LUT/BRAM 자원 트레이드오프(shift-add=adder↑·DSP↓, LUT=BRAM↑·index 로직, ternary=adder+gather·0 스킵).
- **누산 비트폭**: 입력 비트 + 최대 시프트/조회 범위 → 누산기 폭·오버플로 마진(명시 필수).

## 수치 규약 (정량 도출, 정적)
- shifters/adders per lane = unroll/병렬도 차원 곱 · LUT entries×bit = 테이블 깊이×폭 · gather/index width = 비트폭 · 누산기 폭 = 입력+시프트범위. DSP saved·합성 PPA(LUT/DSP/BRAM/Fmax)는 리포트 동봉 시만 인용, 없으면 "확인 필요". **정확도는 출처 인용, 없으면 "확인 필요".**

## Reusable Verification Questions
- 제거 대상 곱셈은? (weight×activation MAC / 스케일 / 비선형영역)
- 치환 방식은? (shift&add / LUT 조회 / 삼진 가감산 / PoT·log 시프트)
- 모델/워크로드 shape(seq·dim·depth)와 데이터타입/비트폭은?
- 누산 비트폭·오버플로 마진은 무엇으로 도출했나?
- 1차 지표는 DSP↓/throughput/latency/area/energy/accuracy 중 무엇? 정확도 출처는?

## Why This Skill Is Relevant
REF 코퍼스가 곱셈기 제거 기법(ShiftAddViT·lut-gemm·LUT-LLM·ternaryLLM·P2-ViT·AdaLog)을 반복적으로 다루며, file:line 근거(소스 부재 시 요약·리포트)로 DSP-lite·저전력 데이터패스 의사결정을 뒷받침한다.
