# Production Playbook

## Purpose

This playbook supports `multiplier-free-accelerator` for replacing multipliers with shift-add / LUT / ternary / PoT datapaths in quantized accelerators. It is written for agents that need a repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: which multiply to remove (weight×activation MAC, scale multiply, nonlinear-domain multiply) and the target metric (DSP↓/throughput/latency/area/power/accuracy).
- Inputs: model spec (dims/seq/depth/heads), datatype/bit-width, weight/scale source, target board + clock, source RTL/HLS, MODULE_GUIDE references.
- Output format: substitution plan, accumulator bit-budget, or resource·accuracy tradeoff table.
- Success metrics: DSP saved, throughput/II, latency (avg + p95/p99), area (LUT/FF/DSP/BRAM), energy, accuracy delta.
- Constraints: tool availability, board fit, non-goals, validation limits.

## Decision Flow

- Capture device, model/workload, datatype/bit-width, clock, runtime contract.
- Pick the substitution: shift&add (weight=sign·2^shift), LUT lookup (precomputed partial sums / VQ→2D-LUT), ternary add/sub ({-1,0,+1} gather), PoT/log scale→shift.
- Read the matching REF MODULE_GUIDE(s)/요약; extract the substitution pattern with file:line.
- Compute cost statically: shifters/adders per lane, LUT entries×bit, gather/index width, accumulator bit-width, DSP saved.
- Return artifacts linking the arithmetic substitution, accumulation precision, and accuracy/resource validation.

## Tradeoff Questions

- Which substitution would be costly to reverse (datapath rebuilt around shift vs LUT vs add/sub)?
- Which assumption (accumulator overflow, accuracy at sub-4bit, LUT BRAM fit, index/gather width) most likely invalidates the artifact?
- What is the smallest change validatable by synthesis or bit-exact C-sim + accuracy check now?
- Which existing skill (`hw-nonlinear-dsp-packing-kb`, `vit-llm-quantization-kb`, `dsp-packing-low-bit-mac`) should be bound first?

## Output Standard

Output contains the artifact, evidence (file:line + which numbers need synthesis/accuracy run), assumptions, risks, and the next validation step. Keep it structured enough for another Worker to use directly.
