# Common Mistakes

- Treating `ablation-study-designer` as a broad brainstorming role instead of a Worker-sized leaf skill.
- Inventing target hardware, workload, metrics, or measurements without marking assumptions.
- Producing prose without a concrete artifact that another Worker or evaluator can use.
- Ignoring the parent skill `paper-idea-generator` and duplicating higher-level planning.
