# Good Output

A strong output for `ablation-study-designer` includes a concise objective, source mapping, explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: Ablation matrix; Control variables; Expected evidence.
