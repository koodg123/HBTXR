# IDEA-Gen Context

Phase: P1
Domain: Research Workflow
Parent skill: `paper-idea-generator`

## Why This Skill Exists

Hardware and compiler research needs ablations to show what each component contributes.

## Worker Capability

Design ablation studies that isolate algorithmic, compiler, hardware, and optimization contributions.

## Expected Outputs

- Ablation matrix
- Control variables
- Expected evidence

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the cluster and roadmap notes for `Research Workflow`.
