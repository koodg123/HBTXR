# Verification Checklist

- [ ] Skill phase `P1` and domain `Research Workflow` are stated.
- [ ] Parent skill `paper-idea-generator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] Ablation matrix is present and traceable.
- [ ] Control variables is present and traceable.
- [ ] Expected evidence is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] Residual risks and missing inputs are listed.
