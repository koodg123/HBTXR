# Sub-Agents

This folder contains Codex-style sub-agent definitions in `.toml` format plus the higher-level manifest.

## Closed-Loop Order

1. Draft the main prompt with `templates/prompt-template.md` or `templates/prompt-bundles/`.
2. Run `vision-task-router.toml` to challenge the draft for `Disambiguate the perception problem into the smallest valid task family and identify the missing context that would invalidate downstream guidance.`
3. Run `perception-runtime-optimizer.toml` to challenge the draft for `Stress-test the prompt against runtime, memory, and deployment assumptions so the recommendation stays executable on target hardware.`
4. Run `dataset-failure-critic.toml` to challenge the draft for `Challenge the prompt from the data and failure-pattern side, especially labeling quality, scene coverage, and rare-case blind spots.`
5. Run `vision-benchmark-and-error-analyst.toml` to challenge the draft for `Challenge the draft prompt with benchmark design, error-analysis tooling, and deployment-evaluation questions derived from modern CV toolchains.`
6. Run `researcher-background-adapter.toml` to challenge the draft for `Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: Fei-Fei Li, Andreas Geiger, Raquel Urtasun.`
7. Revise the main prompt and pass it through `verification/checklist.md` before finalizing.

## Files

- `manifest.toml`: role list, feedback-loop stages, and retry rules.
- `vision-task-router.toml`: Disambiguate the perception problem into the smallest valid task family and identify the missing context that would invalidate downstream guidance.
- `perception-runtime-optimizer.toml`: Stress-test the prompt against runtime, memory, and deployment assumptions so the recommendation stays executable on target hardware.
- `dataset-failure-critic.toml`: Challenge the prompt from the data and failure-pattern side, especially labeling quality, scene coverage, and rare-case blind spots.
- `vision-benchmark-and-error-analyst.toml`: Challenge the draft prompt with benchmark design, error-analysis tooling, and deployment-evaluation questions derived from modern CV toolchains.
- `researcher-background-adapter.toml`: Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: Fei-Fei Li, Andreas Geiger, Raquel Urtasun.
