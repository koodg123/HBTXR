from __future__ import annotations

import argparse


TITLE = 'Computer Vision Expert'
TASK_AXES = ['Detection and Segmentation', 'Tracking and Video Perception', 'SLAM and 3D Perception', 'Foundation-Model Workflows']
INPUT_FOCUS = ['sensor modality, synchronization, and calibration assumptions', 'annotation format, scene distribution, and representative hard cases', 'latency, FPS, memory, and deployment target constraints', 'accuracy metrics that matter operationally, not just on paper']
SUBAGENTS = [{'name': 'vision-task-router', 'inspired_by': ['knowledge-synthesizer', 'multi-agent-coordinator'], 'mission': 'Disambiguate the perception problem into the smallest valid task family and identify the missing context that would invalidate downstream guidance.', 'handoff': ['user goal', 'sensor stack', 'baseline failure examples'], 'returns': ['task family and route', 'missing evidence list', 'risk-ranked ambiguities'], 'revision_trigger': 'Revise the main prompt when the request actually spans multiple perception tasks or mixes offline and deployment failures.'}, {'name': 'perception-runtime-optimizer', 'inspired_by': ['performance-engineer', 'workflow-orchestrator'], 'mission': 'Stress-test the prompt against runtime, memory, and deployment assumptions so the recommendation stays executable on target hardware.', 'handoff': ['candidate pipeline', 'latency and memory targets', 'deployment stack'], 'returns': ['runtime bottleneck hypotheses', 'on-target validation asks', 'smallest viable optimization path'], 'revision_trigger': 'Revise when the initial prompt asks for behavior the target device or runtime cannot sustain.'}, {'name': 'dataset-failure-critic', 'inspired_by': ['research-paper-finder', 'knowledge-synthesizer'], 'mission': 'Challenge the prompt from the data and failure-pattern side, especially labeling quality, scene coverage, and rare-case blind spots.', 'handoff': ['task route', 'dataset summary', 'hard-example list'], 'returns': ['dataset risk summary', 'ablation priorities', 'failure-slice review plan'], 'revision_trigger': 'Revise when the prompt jumps to model changes before ruling out annotation noise, scene bias, or evaluation leakage.'}]


def bullets(items):
    return "\n".join(f"- {item}" for item in items if item)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Build a prompt pack for {TITLE}.")
    parser.add_argument("--goal", required=True, help="Engineering goal or user ask.")
    parser.add_argument("--route", default=TASK_AXES[0], help="Chosen task route.")
    parser.add_argument("--target", default="", help="Deployment target, runtime, or environment.")
    parser.add_argument("--constraints", nargs="*", default=[], help="Constraint strings.")
    parser.add_argument("--failures", nargs="*", default=[], help="Failure observations.")
    parser.add_argument("--metrics", nargs="*", default=[], help="Metrics or acceptance checks.")
    parser.add_argument("--context", nargs="*", default=[], help="Extra context notes.")
    return parser.parse_args()


def build_main_prompt(args: argparse.Namespace) -> str:
    constraint_lines = args.constraints or ["<fill in constraints>"]
    failure_lines = args.failures or ["<fill in failure evidence>"]
    metric_lines = args.metrics or ["<fill in success metrics>"]
    context_lines = args.context or ["<fill in missing context>"]
    return f"""You are the {TITLE}.
Prioritize prompt generation before solutioning.

Goal:
{args.goal}

Chosen route:
{args.route}

Target environment:
{args.target or '<unspecified>'}

Constraint block:
{bullets(constraint_lines)}

Failure evidence:
{bullets(failure_lines)}

Metrics and acceptance:
{bullets(metric_lines)}

Context notes:
{bullets(context_lines)}

Return:
- revised prompt pack
- ranked solution options
- validation plan
- residual risks"""


def build_subagent_prompts(args: argparse.Namespace) -> list[str]:
    prompts: list[str] = []
    for subagent in SUBAGENTS:
        prompts.append(
            f"""### {subagent['name']}
Mission: {subagent['mission']}
Handoff fields: {', '.join(subagent['handoff'])}
Expected return: {', '.join(subagent['returns'])}
Revision trigger: {subagent['revision_trigger']}

Prompt:
Challenge the draft prompt for {TITLE}.
Goal: {args.goal}
Route: {args.route}
Target: {args.target or '<unspecified>'}
Constraints:
{bullets(args.constraints or ['<fill in constraints>'])}
Failures:
{bullets(args.failures or ['<fill in failure evidence>'])}
Metrics:
{bullets(args.metrics or ["<fill in success metrics>"])}"""
        )
    return prompts


def main() -> None:
    args = parse_args()
    print(f"# {TITLE} Prompt Pack\n")
    print("## Candidate Routes\n")
    print(bullets(TASK_AXES))
    print("\n## Input Focus\n")
    print(bullets(INPUT_FOCUS))
    print("\n## Main Expert Prompt\n")
    print("```text")
    print(build_main_prompt(args).rstrip())
    print("```")
    print("\n## Sub-Agent Prompts\n")
    for prompt in build_subagent_prompts(args):
        print(prompt)
    print("\n## Closed-Loop Revision Gate\n")
    print("- Revise the prompt if routing, feasibility, or verification assumptions are contradicted.")
    print("- Prefer evidence-backed constraints over optimistic wording.")
    print("- Finalize only after the revised prompt still satisfies the original goal.")


if __name__ == "__main__":
    main()
