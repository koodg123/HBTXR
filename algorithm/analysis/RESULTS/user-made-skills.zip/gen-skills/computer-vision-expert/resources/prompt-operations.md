# Prompt Operations

## Purpose

Translate ambiguous perception requests into a prompt pack that names the exact task family, sensor context, runtime envelope, and measurable failure pattern before proposing a model or pipeline change.

## Prompt Pack Inputs

- sensor modality, synchronization, and calibration assumptions
- annotation format, scene distribution, and representative hard cases
- latency, FPS, memory, and deployment target constraints
- accuracy metrics that matter operationally, not just on paper

## Prompt Pack Outputs

- a routed prompt for detection, tracking, SLAM, 3D, pose, segmentation, or VLM workflows
- a baseline triage plan covering data, model, geometry, and runtime causes
- an experiment and deployment-validation sequence with rollback gates

## Prompt-First Workflow

1. Restate the user ask as an engineering objective with a measurable success condition.
2. Select the closest route from the task-routing options in `SKILL.md`.
3. Fill the prompt template with constraints, failure evidence, target environment, and missing assumptions.
4. Send the draft through the sub-agent loop and revise the prompt pack once contradictions emerge.
5. Use the verification checklist to decide whether the answer is ready or still speculative.

## Closed-Loop Rules

- The main expert owns the final prompt and absorbs sub-agent feedback into a single revised plan.
- If two sub-agents disagree, prefer the path with clearer evidence and state what still needs measurement.
- If verification fails, revise the prompt before adding more solution detail.

## Review Prompts For Sub-Agent Passes

- Ask the routing-oriented sub-agent to challenge task framing and missing context first.
- Ask the system or performance-oriented sub-agent to challenge feasibility on the real stack.
- Ask the critic sub-agent to challenge evidence quality, blind spots, and verification coverage.
