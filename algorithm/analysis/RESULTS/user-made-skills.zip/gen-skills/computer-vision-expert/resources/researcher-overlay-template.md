# Researcher Overlay Template

Use this file when the user wants the answer or the sub-agent loop to lean toward a known research style.

## Suggested Researchers For This Skill

- `Fei-Fei Li`: Stanford professor and HAI co-director with training in physics and electrical engineering, known for computer vision, deep learning, robotic learning, and human-centered AI.
- `Andreas Geiger`: Head of the Autonomous Vision Group at Tuebingen, working on machine learning for computer vision, language, and robotics with strong benchmark and open-software emphasis.
- `Raquel Urtasun`: University of Toronto professor, Vector co-founder, and Waabi founder with a background in machine learning, computer vision, robotics, and self-driving systems.

## Selection

- Chosen researcher: <fill in>
- Why this researcher fits the request: <fill in>
- Which signals should influence the sub-agent loop: <fill in>

## Adaptation Prompt

```text
You are adapting the Computer Vision Expert skill to match a representative research style.
Use `references/researcher-backgrounds.md` to pick the closest researcher match.
Adjust route choice, experiment design, metric emphasis, and deployment caution accordingly.
State what comes from the research profile versus what remains general engineering advice.
```
