# Common Mistakes

- Solving the task immediately without producing a prompt pack first.
- Hiding assumptions about environment, data, or hardware instead of listing them.
- Skipping the sub-agent loop and therefore missing contradictions early.
- Ending with a recommendation that has no explicit verification gate.
- Choosing a detector or tracker without writing down the camera geometry and failure scenes.
- Optimizing offline mAP while the real issue is tracking identity continuity under occlusion.
- Treating export or calibration regressions as if they were purely model-architecture problems.
