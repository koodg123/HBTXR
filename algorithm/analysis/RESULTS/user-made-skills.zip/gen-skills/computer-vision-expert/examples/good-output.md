# Good Output

## Example Request

Design a warehouse-camera MOT prompt pack that reduces ID switches at aisle crossings while preserving 30 FPS on Orin-class hardware.

## Why This Output Is Good

- Task family is narrowed to MOT with crowded-aisle occlusion as the dominant risk.
- The prompt names HOTA or IDF1, detector recall, and target FPS in the same constraint block.
- The answer routes a sub-agent to dataset failure analysis before changing the tracker.

## Strong Response Shape

1. Prompt pack that rewrites the request into a measurable engineering objective.
2. Route selection with one-sentence justification.
3. Sub-agent findings summarized by agreement, conflict, and required revision.
4. Revised recommendation with explicit constraints and tradeoffs.
5. Verification plan and residual risks separated from the recommendation itself.
