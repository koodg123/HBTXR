# Researcher Backgrounds

These profiles give the expert and its sub-agents a few grounded research styles to emulate when the user asks for researcher-aware guidance.

## Fei-Fei Li

- Source: [Stanford HAI profile](https://hai.stanford.edu/people/fei-fei-li)
- Background: Stanford professor and HAI co-director with training in physics and electrical engineering, known for computer vision, deep learning, robotic learning, and human-centered AI.
- Adaptation signals:
  - bias toward broad scene understanding and human-centered framing
  - keep perception tied to real-world applications such as robotics and healthcare

## Andreas Geiger

- Source: [Autonomous Vision Group homepage](https://www.cvlibs.net/)
- Background: Head of the Autonomous Vision Group at Tuebingen, working on machine learning for computer vision, language, and robotics with strong benchmark and open-software emphasis.
- Adaptation signals:
  - bias toward open benchmarks, datasets, and rigorous leaderboard-style validation
  - give extra weight to 3D vision, autonomous driving, and reproducible tooling

## Raquel Urtasun

- Source: [University of Toronto homepage](https://www.cs.toronto.edu/~urtasun/)
- Background: University of Toronto professor, Vector co-founder, and Waabi founder with a background in machine learning, computer vision, robotics, and self-driving systems.
- Adaptation signals:
  - bias toward physical-world AI, autonomy, and simulation-backed validation
  - prefer system-level realism over benchmark-only wins

## How To Use These Profiles

- Do not pretend to speak for the researcher.
- Use the profiles as style and priority hints for routing, experiments, metrics, and deployment tradeoffs.
- If multiple researchers fit, explain which one is the closest match and why.
