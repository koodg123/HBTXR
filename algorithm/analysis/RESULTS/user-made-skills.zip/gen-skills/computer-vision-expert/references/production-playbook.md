# Production Playbook

## When To Read This File

Read this file when the request is no longer just 'which model should I use?' and instead needs intake discipline, routing, failure analysis, metrics, or deployment-aware decision making.

## Prompt-First Translation

- Primary goal: Translate ambiguous perception requests into a prompt pack that names the exact task family, sensor context, runtime envelope, and measurable failure pattern before proposing a model or pipeline change.
- Always convert the user request into a scoped prompt pack before ranking solutions.
- Capture which sub-agent should challenge the draft first and why.

## Intake Checklist

- Task definition: detection, MOT, SOT, SLAM, 3D detection, pose, segmentation, grounding, or VLM reasoning.
- Sensor stack: RGB, stereo, depth, LiDAR, IMU, radar, multi-camera, or video only.
- Operational target: offline batch analysis, near-real-time, hard real-time, cloud inference, edge inference, or mobile.
- Data facts: dataset size, annotation quality, class distribution, scene diversity, and known domain shifts.
- Metrics and costs: mAP, IoU, IDF1/HOTA, ATE/RPE, PCK, latency, FPS, memory, and acceptable failure types.

## Domain-Specific Prompt Inputs

- sensor modality, synchronization, and calibration assumptions
- annotation format, scene distribution, and representative hard cases
- latency, FPS, memory, and deployment target constraints
- accuracy metrics that matter operationally, not just on paper

## Routing And Failure Patterns

### False negatives / missed objects

- Preferred investigation path: Check annotation completeness, object scale distribution, augmentations, anchor/query design, threshold settings, and deployment quantization side effects.

### ID switches / tracking instability

- Preferred investigation path: Inspect detector recall, association heuristics, re-ID embedding quality, frame rate, motion model assumptions, and occlusion handling.

### SLAM drift / unstable pose

- Preferred investigation path: Check calibration, timestamp sync, loop-closure assumptions, degeneracy in scene geometry, and IMU-camera alignment.

### Poor segmentation boundaries

- Preferred investigation path: Check label granularity, crop resolution, prompt strategy, decoder resolution, and post-processing assumptions.

### 3D perception regressions

- Preferred investigation path: Check sensor extrinsics, point density, voxelization range, BEV grid choices, and fusion timing.

## Closed-Loop Review Gates

- Gate 1: Does the draft prompt name the real task route and success metric?
- Gate 2: Did at least one sub-agent challenge feasibility or runtime reality?
- Gate 3: Did at least one sub-agent challenge evidence quality or verification coverage?
- Gate 4: Was the final prompt revised to absorb conflicts instead of merely listing them?

## Common Failure Patterns

- Treating every issue as a model problem when annotation noise, calibration, or export/runtime differences are the real bottleneck.
- Optimizing for benchmark metrics that do not reflect operational misses such as small objects, edge cases, or drift accumulation.
- Mixing offline validation data with deployment-only data shifts without separating causes.
- Exporting a model path that changes preprocessing, NMS, or coordinate conventions and then comparing it unfairly to the training stack.
- Choosing a detector or tracker without writing down the camera geometry and failure scenes.
- Optimizing offline mAP while the real issue is tracking identity continuity under occlusion.
- Treating export or calibration regressions as if they were purely model-architecture problems.

## Validation Checklist

- Evaluate on a slice that reflects the real deployment distribution, not only the clean validation set.
- Measure both accuracy metrics and system metrics such as latency, memory, throughput, and thermal behavior on the actual target.
- Require qualitative review of hard examples: occlusion, truncation, rare classes, low light, motion blur, and calibration stress cases.
- Before rollout, compare baseline and candidate outputs on the same scenes and record where the candidate wins and loses.
- The prompt distinguishes data issues, model issues, and runtime issues instead of blending them.
- At least one sub-agent challenge focuses on deployment parity and another on dataset failure patterns.
- Final advice states how baseline and candidate outputs will be compared on the same scenes.

## Local Reference Anchors

- claude-skills/docs/skills/engineering-team/senior-computer-vision.md: strong example of a workflow-heavy production vision skill.
- antigravity-awesome-skills/skills/computer-vision-expert/SKILL.md: specialist-role framing and anti-pattern sections.
- antigravity-awesome-skills/skills/hugging-face-vision-trainer/references/reliability_principles.md: reliability-focused training and evaluation cues.
- awesome-codex-skills/image-enhancer/SKILL.md: concise task framing for image-quality related requests.
