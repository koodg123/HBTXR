# IDEA-Gen Context

Source analysis: `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`

## Core Clusters

1. AgentOS runtime and Skill Pool: model stack, prompt, skill, harness, memory, tool/context managers, orchestration, planning, evaluation, guardrails, and Master - Expert Council - Leader - Team - Worker hierarchy.
2. PIM-NPU compiler and hardware co-design: layer-to-tile execution, multi-core assignment, dataflow scheduling, loop optimization, memory planning, stream routing, micro-ISA generation, roofline and cost-model feedback.
3. LLM on NPU: prefill, decode, KV-cache, attention kernels, BF16 or quantized precision, Llama 3.2-3B style workload breakdown, on-chip buffers, simulator and runtime planning.
4. Vision/video accelerator factory: YOLO, DETR, DINO, DEYO, ViT, ViM, Mamba, SOT, MOT, UAV, video SR, frame interpolation, EdgeSAM, EdgeTAM, VFM co-design, HLS factory flows.
5. Hardware-aware model optimization: profiler feedback, NAS, quantization, pruning, sparsity, compiler-driven compression, NPU-aware accuracy-latency-resource tradeoffs.
6. Edge predictive maintenance: sensor data collection, DNO health score, PoF, RUL, risk estimation, drift adaptation, model lightweighting, Jetson-class deployment.

## Priority Roadmap

1. Formalize Task1 PIM-NPU Compiler first because it has the clearest baseline and improvement direction.
2. Build LLM-on-NPU workload and memory model next.
3. Narrow the vision/video accelerator factory to one model family and one hardware template.
4. Fill the empty hardware-aware model optimization task with target hardware, model family, optimization knobs, metrics, and loop.
5. Recover or re-export mojibake Korean notes before finalizing edge predictive maintenance requirements.

## Reusable Verification Questions

- What is the target hardware or runtime contract?
- What is the model family and workload shape?
- What is the smallest IR, model, simulator, or accelerator artifact that can be validated?
- Which metric is primary: accuracy, latency, throughput, area, energy, memory, or engineering effort?
- What evidence links the idea to a publishable contribution or implementable design?

## Why This Skill Is Relevant

IDEA-Gen vision tasks include OD, SOT, MOT, UAV, YOLO, DETR, DINO, DEYO, EdgeSAM, EdgeTAM, SR, and FI.
