# Prompt Template

Use `$algorithm-pseudocode-rebuilder` to handle the following task.

Objective:

Inputs:

Constraints:

Required artifact:

Known facts:

Assumptions:

Verification evidence:

Risks and open questions:

Return the artifact, evidence, assumptions, risks, and next validation step.
