---
name: algorithm-pseudocode-rebuilder
description: "Rebuild precise pseudocode from prose, equations, code fragments, diagrams, or partial paper descriptions. Use when Codex needs executable-level control flow, inputs, outputs, state updates, invariants, and edge cases without committing to a programming language."
---

# Algorithm Pseudocode Rebuilder

## Overview

Use this skill for algorithm pseudocode reconstruction. Produce unambiguous pseudocode with inputs, outputs, invariants, and failure cases.

This skill complements paper-algorithm-reconstruction, programming-language-expert and should produce reusable artifacts rather than only
free-form advice.

## Prompt-First Rule

Before solving the task, write a compact prompt pack that names the objective, inputs, constraints,
success metrics, and known unknowns. Use `templates/prompt-template.md` or
`scripts/build_prompt.py` when a reusable prompt artifact would help.

## Start Every Task With

1. Restate the user goal as a measurable engineering or research objective.
2. List the source artifacts, constraints, and target deliverables.
3. Identify required skills, roles, and verification evidence.
4. Separate known facts, assumptions, and hypotheses.
5. Decide which output artifact should be produced first.

## Workflow

1. Confirm the paper identity, method scope, and source artifacts before analysis.
2. Extract claims, equations, assumptions, algorithm steps, and evaluation evidence separately.
3. Rebuild the method into notation, pseudocode, dataflow, and implementation contracts.
4. Mark uncertain reconstruction choices as hypotheses and propose tests to resolve them.
5. Return critique, ideas, or reconstruction artifacts with source-linked evidence.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact for algorithm pseudocode reconstruction with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments.

## Supporting Files

- `references/production-playbook.md` for detailed workflow guidance and decision points.
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` for reusable prompt pack structure.
- `templates/prompt-bundles/intake.md` for intake and handoff prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Claims are separated from evidence and assumptions.
- Equations, symbols, and tensor shapes are normalized before implementation advice.
- The reconstruction is testable against examples, ablations, or paper metrics.
- Speculative improvements are labeled and ranked by feasibility.
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result would depend on external measurements, target hardware, private data, or unavailable tools.
- A recommendation would lock the user into a brittle workflow without validation evidence.
