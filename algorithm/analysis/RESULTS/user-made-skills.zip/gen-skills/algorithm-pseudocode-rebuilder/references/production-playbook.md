# Production Playbook

## Purpose

This playbook supports `algorithm-pseudocode-rebuilder` for algorithm pseudocode reconstruction. It is written for agents that need a
repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what the user wants changed, analyzed, designed, or generated.
- Inputs: papers, code, diagrams, specs, constraints, datasets, reports, or logs.
- Output format: document, task card, DAG, pseudocode, hardware plan, compiler plan, model, or test plan.
- Success metrics: correctness, traceability, latency, throughput, area, energy, novelty, or acceptance tests.
- Constraints: time, tool availability, target platform, non-goals, compatibility, and validation limits.

## Decision Flow

- Confirm the paper identity, method scope, and source artifacts before analysis.
- Extract claims, equations, assumptions, algorithm steps, and evaluation evidence separately.
- Rebuild the method into notation, pseudocode, dataflow, and implementation contracts.
- Mark uncertain reconstruction choices as hypotheses and propose tests to resolve them.
- Return critique, ideas, or reconstruction artifacts with source-linked evidence.

## Tradeoff Questions

- What decision would be costly to reverse later?
- Which assumption has the highest chance of invalidating the artifact?
- What is the smallest artifact that can be validated now?
- Which existing skill should be bound to this task before execution?

## Output Standard

The output should contain the artifact, evidence, assumptions, risks, and next validation step. Keep
the artifact structured enough for another Worker to use directly.
