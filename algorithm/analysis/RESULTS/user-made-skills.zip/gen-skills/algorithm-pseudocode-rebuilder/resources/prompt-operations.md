# Prompt Operations

## Prompt Pack Fields

- Skill: `algorithm-pseudocode-rebuilder`
- Objective: one sentence.
- Context: source artifacts and current state.
- Constraints: scope, tools, target platform, and non-goals.
- Required output: exact artifact type and format.
- Verification: evidence needed before signoff.
- Risks: assumptions and missing data.

## Review Loop

1. Draft the prompt pack before technical work.
2. Route it through the roles in `sub-agents/manifest.toml`.
3. Revise the prompt when reviewers find missing constraints or weak evidence.
4. Produce the artifact only after the success criteria are stable.
5. Run `verification/checklist.md` before claiming completion.

## Escalation

Escalate instead of guessing when source artifacts, constraints, target platform, or acceptance
criteria are missing and the missing fact would change the output.
