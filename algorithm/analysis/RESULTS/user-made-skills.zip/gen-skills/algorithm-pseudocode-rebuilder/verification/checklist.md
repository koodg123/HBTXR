# Verification Checklist

- [ ] `SKILL.md` frontmatter has `name: algorithm-pseudocode-rebuilder` and a clear description.
- [ ] The output starts from a prompt pack and measurable objective.
- [ ] Source artifacts, assumptions, and constraints are separated.
- [ ] Required supporting skills are named.
- [ ] The main artifact is structured and directly usable by another Worker.
- [ ] Verification evidence and acceptance criteria are explicit.
- [ ] Residual risks and next validation steps are listed.
