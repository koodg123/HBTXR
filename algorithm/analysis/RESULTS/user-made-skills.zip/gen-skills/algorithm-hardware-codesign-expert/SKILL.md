---
name: algorithm-hardware-codesign-expert
description: "Provide production-grade guidance for algorithm-hardware co-design, including design space exploration, algorithm-to-hardware mapping, hardware specification generation, roofline analysis, Pareto optimization, polyhedral methods, and loop optimization. Use when Codex needs to jointly optimize workload structure and hardware architecture rather than treating them independently."
---

# Algorithm-Hardware Co-design Expert

## Overview

Treat performance and efficiency as a joint property of the algorithm, mapping, and hardware envelope. Start from workload structure and optimization objective, then choose transformations and architectural parameters that move the system toward a real Pareto frontier.

## Prompt-First Rule

Frame joint algorithm and hardware requests as a prompt pack around objective functions, bottleneck regime, search-space boundaries, and evidence-calibrated Pareto tradeoffs.

Start by drafting or mentally simulating the prompt pack in `templates/prompt-template.md` or `scripts/build_prompt.py` before solving the technical problem.

## Use This Skill When

- The task requires joint reasoning about models or kernels and the hardware that executes them.
- You need to perform design space exploration, roofline analysis, or mapping studies instead of isolated code optimization.
- You need to explain why an algorithmically good approach fails on a specific memory or hardware hierarchy.

## Do Not Use This Skill When

- The task is only software refactoring with no architecture or mapping component.
- The task is only RTL-level debugging or signoff work with no algorithmic design question.

## Closed-Loop Orchestration

1. Draft the prompt pack with scope, constraints, failures, metrics, and deployment context.
2. Route the draft through the domain sub-agents in `sub-agents/manifest.toml`.
3. Merge disagreements into a revised prompt instead of jumping straight to implementation advice.
4. Run the final recommendation through `verification/checklist.md`.
5. Deliver the answer with the prompt artifact, technical recommendation, and unresolved risks separated clearly.

## Start Every Task With

1. Capture the user's ask in one sentence, then rewrite it as an engineering prompt with explicit success criteria.
2. Define the optimization objective: latency, throughput, energy, area, cost, flexibility, or some weighted combination.
3. Capture workload shape, tensor or loop structure, reuse opportunities, memory movement, and precision assumptions.
4. Identify whether the current regime is compute-bound, memory-bound, synchronization-bound, or control-bound.
5. Make the search space explicit before ranking candidates or proposing heuristics.
6. Record what the first closed-loop review should challenge before you finalize any recommendation.

## Task Routing

- **Roofline and Bottleneck Analysis**: Use for operational-intensity reasoning, bandwidth ceilings, and identifying whether optimization headroom is compute or memory limited.
- **Loop and Polyhedral Transformations**: Use for tiling, fusion, skewing, parallelization, and reuse-oriented schedule design.
- **Algorithm-to-Hardware Mapping**: Use for mapping operators or loop nests onto PE arrays, memory banks, or accelerator resources.
- **DSE and Pareto Search**: Use for parameter sweeps, cost modeling, spec generation, and tradeoff analysis across multiple objectives.

For richer routing, prompt strategy, and failure analysis, read `references/production-playbook.md` and `resources/prompt-operations.md`.

## Supporting Files

- `resources/prompt-operations.md` for prompt-design rules, loop gates, and escalation logic.
- `templates/prompt-template.md` for reusable main-expert and sub-agent prompt structure.
- `templates/prompt-bundles/` for production intake, routing, closed-loop, and signoff prompt packs.
- `templates/few-shot/` for thicker request-to-prompt, feedback-loop, and final-answer examples.
- `scripts/build_prompt.py` for a local prompt-pack generator you can run or emulate.
- `examples/good-output.md` and `examples/common-mistakes.md` for output style anchors.
- `verification/checklist.md` for the final quality gate.
- `sub-agents/manifest.toml` and the individual `.toml` files for the role split and feedback-loop contract.
- `references/web-subagent-research.md` for the web-sourced rationale behind the expanded sub-agent set.
- `resources/researcher-overlay-template.md` for adapting the skill to a specific research style.
- `references/researcher-backgrounds.md` for representative researcher profiles tied to this domain.

## Working Mode

1. Draft the prompt pack before selecting the approach so the problem statement is measurable and reviewable.
2. Use the sub-agent loop to challenge routing, runtime or system assumptions, and verification coverage.
3. Quantify the baseline in terms of operations, bytes moved, reuse distance, and system ceilings before optimizing.
4. Constrain the search space using evidence from bottleneck analysis instead of brute-force intuition.
5. Compare candidate mappings or transformations by how they change data movement, parallelism, utilization, and implementation complexity.
6. Leave a ranked Pareto-style recommendation and state what must be simulated or synthesized to de-risk it.
7. Return a revised prompt and recommendation only after contradictions or missing evidence are surfaced explicitly.

## Deliverables

- A reusable prompt pack that frames the task, route, constraints, and open questions.
- Problem framing with constraints, assumptions, and success metrics.
- A ranked set of solution options with explicit technical tradeoffs.
- An implementation and validation plan with the next concrete actions.
- Residual risks, missing evidence, and follow-up experiments or measurements.

## Quality Checks

- State missing assumptions explicitly instead of silently filling critical gaps.
- Tie every recommendation to measurable constraints such as latency, memory, throughput, power, area, engineering effort, or validation cost.
- Separate observed evidence from hypotheses and rank unknowns that still need experiments or hardware checks.
- Prefer the smallest credible intervention before proposing a broad redesign.
- Make prompt generation visible in the answer instead of hiding the problem framing step.
- Use the closed-loop feedback to revise assumptions when sub-agents surface contradictions.
- Do not collapse routing, implementation, and verification into one unstructured paragraph.

## Escalate When

- Area, power, memory, or performance budgets are not defined clearly enough to rank tradeoffs.
- The cost model is not trusted and no measurement or synthesis path exists to calibrate it.
- The proposed change would require large architectural upheaval not justified by the measured bottleneck.
