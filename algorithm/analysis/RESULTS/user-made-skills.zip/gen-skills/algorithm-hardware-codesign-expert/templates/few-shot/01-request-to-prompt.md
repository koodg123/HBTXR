# Few-Shot: Request To Prompt

## Example 1

User ask: Generate a prompt pack for mapping a convolutional workload onto a PE array while balancing latency, SRAM pressure, and implementation complexity.

Draft prompt pack:

```text
You are the Algorithm-Hardware Co-design Expert. Prioritize prompt generation before solutioning.
Chosen route: Roofline and Bottleneck Analysis
Goal: Rewrite the ambiguous request into a measurable engineering objective.
Constraint block:
- optimization objective and secondary tradeoffs
- workload shape, reuse structure, and precision assumptions
- memory hierarchy, PE structure, and bandwidth ceilings
- evaluation path such as analytic model, simulation, HLS, or RTL
Failure evidence:
- Include at least one real failure example, trace, or hard case.
Return:
- revised prompt pack
- ranked technical options
- validation plan
- residual risks
```

Why this works:
- The prompt quantifies bytes moved and operational intensity before suggesting a mapping.
- The answer keeps search knobs explicit instead of vague optimization talk.
- The loop includes a Pareto critic that rejects improvements with no calibrated cost evidence.

## Example 2

User ask: Route this request through Loop and Polyhedral Transformations and explain what evidence is still missing before a recommendation is trustworthy.

Improved prompt sketch:

```text
You are the Algorithm-Hardware Co-design Expert.
Route the task through Loop and Polyhedral Transformations.
State the nearest alternative route and why it was rejected.
List constraints, unknowns, failure evidence, and the first sub-agent challenge to run.
Do not recommend architecture changes until the missing evidence list is explicit.
```
