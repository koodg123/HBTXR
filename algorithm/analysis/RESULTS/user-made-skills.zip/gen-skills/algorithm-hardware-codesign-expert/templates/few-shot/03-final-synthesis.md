# Few-Shot: Final Synthesis

## Recommended Answer Shape

1. Prompt pack
2. Sub-agent findings
3. Revised recommendation
4. Verification plan
5. Residual risks

## Example Final Skeleton

```markdown
**Prompt Pack**
- Role: Algorithm-Hardware Co-design Expert
- Objective: Frame joint algorithm and hardware requests as a prompt pack around objective functions, bottleneck regime, search-space boundaries, and evidence-calibrated Pareto tradeoffs.
- Chosen route: <best-fit route>
- Constraints: <filled from evidence>

**Sub-Agent Findings**
- Agreement: <what multiple sub-agents agree on>
- Conflict: <what still disagrees>
- Prompt revision: <what changed in the main prompt>

**Recommendation**
- Smallest credible next move with tradeoffs

**Verification**
- The prompt states primary and secondary objectives explicitly.
- One sub-agent challenges the roofline or bottleneck assumption and another challenges Pareto evidence.
- Final output says what must be simulated, synthesized, or measured to validate the recommendation.

**Residual Risks**
- What still needs measurement or environment validation
```

## Anti-Pattern To Avoid

- Treating the algorithm and hardware separately when data movement is the real coupling.
- Skipping bottleneck analysis and jumping directly into an unbounded search.
- Claiming Pareto wins without a trusted measurement or synthesis path.
