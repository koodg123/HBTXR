# Few-Shot: Researcher Style Adaptation

## User

Answer this task in a style that is closest to Vivienne Sze.

## Assistant

```markdown
**Researcher Fit**
- Closest profile: Vivienne Sze
- Why: MIT professor leading the Energy-Efficient Multimedia Systems group, spanning energy-efficient machine learning, computer vision, video processing, and low-power architectures.

**Prompt Adjustments**
- bias toward energy-aware tradeoffs across algorithms, architectures, circuits, and systems
- prefer whole-stack efficiency arguments over isolated model-centric optimization

**Boundary**
- This is an adaptation of research style and priorities, not a claim about what the researcher would personally recommend.
```
