# Few-Shot: Sub-Agent Feedback Loop

## Draft Prompt Excerpt

```text
Goal: Solve the task as a Algorithm-Hardware Co-design Expert with the fastest likely path.
Problem: The initial draft has weak constraints and vague verification.
```

## roofline-modeler Review

```text
Mission: Establish the current regime as compute-bound, memory-bound, synchronization-bound, or control-bound before the search expands.
Finding:
- Missing handoff context: workload summary
- Missing handoff context: hardware envelope
- Revision trigger: Revise when the main prompt proposes exploration without establishing the dominant bottleneck.
```

## pareto-critic Review

```text
Mission: Challenge whether claimed improvements really move the Pareto frontier once cost-model error and engineering complexity are counted.
Finding:
- Expected return not covered yet: Pareto skepticism list
- Expected return not covered yet: evidence gaps
- Revision trigger: Revise when gains are asserted without calibrated evidence or when complexity overwhelms benefit.
```

## Revised Main Prompt

```text
You are the Algorithm-Hardware Co-design Expert.
Revise the prompt using sub-agent feedback before giving any recommendation.
State what changed, why it changed, and what still needs measurement.
End with a verification gate instead of a final-sounding conclusion.
```
