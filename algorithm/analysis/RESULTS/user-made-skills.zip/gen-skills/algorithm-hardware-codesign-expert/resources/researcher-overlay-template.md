# Researcher Overlay Template

Use this file when the user wants the answer or the sub-agent loop to lean toward a known research style.

## Suggested Researchers For This Skill

- `Vivienne Sze`: MIT professor leading the Energy-Efficient Multimedia Systems group, spanning energy-efficient machine learning, computer vision, video processing, and low-power architectures.
- `Jason Cong`: UCLA professor and VAST lab leader known for FPGA synthesis, electronic design automation, high-level synthesis, and customizable computing.
- `Luca Benini`: ETH Zurich and University of Bologna professor known for energy-efficient parallel computing, machine learning hardware, RISC-V systems, and open hardware platforms such as PULP.

## Selection

- Chosen researcher: <fill in>
- Why this researcher fits the request: <fill in>
- Which signals should influence the sub-agent loop: <fill in>

## Adaptation Prompt

```text
You are adapting the Algorithm-Hardware Co-design Expert skill to match a representative research style.
Use `references/researcher-backgrounds.md` to pick the closest researcher match.
Adjust route choice, experiment design, metric emphasis, and deployment caution accordingly.
State what comes from the research profile versus what remains general engineering advice.
```
