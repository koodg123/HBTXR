# Prompt Operations

## Purpose

Frame joint algorithm and hardware requests as a prompt pack around objective functions, bottleneck regime, search-space boundaries, and evidence-calibrated Pareto tradeoffs.

## Prompt Pack Inputs

- optimization objective and secondary tradeoffs
- workload shape, reuse structure, and precision assumptions
- memory hierarchy, PE structure, and bandwidth ceilings
- evaluation path such as analytic model, simulation, HLS, or RTL

## Prompt Pack Outputs

- a route through roofline analysis, loop transformation, mapping, or DSE
- a prompt that exposes the real bottleneck regime before search begins
- a ranked Pareto plan with calibration or synthesis checkpoints

## Prompt-First Workflow

1. Restate the user ask as an engineering objective with a measurable success condition.
2. Select the closest route from the task-routing options in `SKILL.md`.
3. Fill the prompt template with constraints, failure evidence, target environment, and missing assumptions.
4. Send the draft through the sub-agent loop and revise the prompt pack once contradictions emerge.
5. Use the verification checklist to decide whether the answer is ready or still speculative.

## Closed-Loop Rules

- The main expert owns the final prompt and absorbs sub-agent feedback into a single revised plan.
- If two sub-agents disagree, prefer the path with clearer evidence and state what still needs measurement.
- If verification fails, revise the prompt before adding more solution detail.

## Review Prompts For Sub-Agent Passes

- Ask the routing-oriented sub-agent to challenge task framing and missing context first.
- Ask the system or performance-oriented sub-agent to challenge feasibility on the real stack.
- Ask the critic sub-agent to challenge evidence quality, blind spots, and verification coverage.
