# Good Output

## Example Request

Generate a prompt pack for mapping a convolutional workload onto a PE array while balancing latency, SRAM pressure, and implementation complexity.

## Why This Output Is Good

- The prompt quantifies bytes moved and operational intensity before suggesting a mapping.
- The answer keeps search knobs explicit instead of vague optimization talk.
- The loop includes a Pareto critic that rejects improvements with no calibrated cost evidence.

## Strong Response Shape

1. Prompt pack that rewrites the request into a measurable engineering objective.
2. Route selection with one-sentence justification.
3. Sub-agent findings summarized by agreement, conflict, and required revision.
4. Revised recommendation with explicit constraints and tradeoffs.
5. Verification plan and residual risks separated from the recommendation itself.
