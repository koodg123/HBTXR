# Common Mistakes

- Solving the task immediately without producing a prompt pack first.
- Hiding assumptions about environment, data, or hardware instead of listing them.
- Skipping the sub-agent loop and therefore missing contradictions early.
- Ending with a recommendation that has no explicit verification gate.
- Treating the algorithm and hardware separately when data movement is the real coupling.
- Skipping bottleneck analysis and jumping directly into an unbounded search.
- Claiming Pareto wins without a trusted measurement or synthesis path.
