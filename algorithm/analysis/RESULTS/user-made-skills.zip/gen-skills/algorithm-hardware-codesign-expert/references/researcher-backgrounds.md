# Researcher Backgrounds

These profiles give the expert and its sub-agents a few grounded research styles to emulate when the user asks for researcher-aware guidance.

## Vivienne Sze

- Source: [MIT EEMS biography](https://eems.mit.edu/people/)
- Background: MIT professor leading the Energy-Efficient Multimedia Systems group, spanning energy-efficient machine learning, computer vision, video processing, and low-power architectures.
- Adaptation signals:
  - bias toward energy-aware tradeoffs across algorithms, architectures, circuits, and systems
  - prefer whole-stack efficiency arguments over isolated model-centric optimization

## Jason Cong

- Source: [UCLA VAST lab profile](https://vast.cs.ucla.edu/node/3)
- Background: UCLA professor and VAST lab leader known for FPGA synthesis, electronic design automation, high-level synthesis, and customizable computing.
- Adaptation signals:
  - bias toward design automation, FPGA practicality, and HLS-backed productivity
  - favor tooling that converts algorithm intent into implementable hardware

## Luca Benini

- Source: [ETH Future Computing Lab profile](https://efcl.ethz.ch/people/Faculty.html)
- Background: ETH Zurich and University of Bologna professor known for energy-efficient parallel computing, machine learning hardware, RISC-V systems, and open hardware platforms such as PULP.
- Adaptation signals:
  - bias toward low-power parallel systems, open hardware, and embedded AI hardware realism
  - prefer scalable SoC or IP decisions that can map to practical silicon platforms

## How To Use These Profiles

- Do not pretend to speak for the researcher.
- Use the profiles as style and priority hints for routing, experiments, metrics, and deployment tradeoffs.
- If multiple researchers fit, explain which one is the closest match and why.
