# Production Playbook

## When To Read This File

Read this file when the right answer depends on jointly shaping the algorithm, schedule, and hardware architecture instead of optimizing each in isolation.

## Prompt-First Translation

- Primary goal: Frame joint algorithm and hardware requests as a prompt pack around objective functions, bottleneck regime, search-space boundaries, and evidence-calibrated Pareto tradeoffs.
- Always convert the user request into a scoped prompt pack before ranking solutions.
- Capture which sub-agent should challenge the draft first and why.

## Intake Checklist

- Workload description: operator mix, tensor or loop dimensions, sparsity, precision, and reuse opportunities.
- Target hardware envelope: PE count, memory hierarchy, bandwidth, bank structure, power/area limits, and programmability expectations.
- Primary objective and secondary objective for Pareto ranking.
- Available evaluation path: analytical model, simulation, HLS, RTL, or silicon measurement.
- Acceptable engineering complexity and time-to-decision.

## Domain-Specific Prompt Inputs

- optimization objective and secondary tradeoffs
- workload shape, reuse structure, and precision assumptions
- memory hierarchy, PE structure, and bandwidth ceilings
- evaluation path such as analytic model, simulation, HLS, or RTL

## Routing And Failure Patterns

### Memory-bound workload

- Preferred investigation path: Increase reuse, improve tiling and layout, reduce off-chip traffic, and verify operational intensity versus achievable bandwidth.

### Compute-bound workload

- Preferred investigation path: Increase utilization, vector width, PE occupancy, and reduce pipeline bubbles or control overhead.

### Search space is too large

- Preferred investigation path: Use bottleneck-driven pruning, objective weighting, and staged exploration before brute-force sweeps.

### Mapping is fragile

- Preferred investigation path: Check whether the chosen dataflow depends on unrealistic bank conflicts, synchronization assumptions, or shape invariants.

### Cost model disagrees with measurements

- Preferred investigation path: Calibrate the model with a smaller measured design set and isolate which assumptions are wrong.

## Closed-Loop Review Gates

- Gate 1: Does the draft prompt name the real task route and success metric?
- Gate 2: Did at least one sub-agent challenge feasibility or runtime reality?
- Gate 3: Did at least one sub-agent challenge evidence quality or verification coverage?
- Gate 4: Was the final prompt revised to absorb conflicts instead of merely listing them?

## Common Failure Patterns

- Treating theoretical compute savings as useful even when memory traffic dominates the true runtime or energy cost.
- Running DSE without first constraining the objectives, which creates noise instead of insight.
- Optimizing one operator while the pipeline bottleneck lives elsewhere.
- Assuming the best analytical schedule survives HLS/RTL realities such as banking, routing, or control overhead.
- Treating the algorithm and hardware separately when data movement is the real coupling.
- Skipping bottleneck analysis and jumping directly into an unbounded search.
- Claiming Pareto wins without a trusted measurement or synthesis path.

## Validation Checklist

- Always pair analytical reasoning with at least one measured or simulated sanity check.
- Record why each candidate is dominated or retained so the Pareto argument is auditable.
- Check sensitivity to real input shapes and data distributions rather than one heroic benchmark shape.
- Before recommending hardware changes, estimate software and verification cost as well as raw performance gain.
- The prompt states primary and secondary objectives explicitly.
- One sub-agent challenges the roofline or bottleneck assumption and another challenges Pareto evidence.
- Final output says what must be simulated, synthesized, or measured to validate the recommendation.

## Local Reference Anchors

- awesome-codex-subagents/categories/07-specialized-domains/embedded-systems.toml: constraint-first engineering behavior.
- antigravity-awesome-skills/skills/arm-cortex-expert/SKILL.md: low-level performance and memory-safety mindset.
- claude-skills/docs/skills/engineering-team/senior-architect.md: architecture and tradeoff framing for large technical decisions.
