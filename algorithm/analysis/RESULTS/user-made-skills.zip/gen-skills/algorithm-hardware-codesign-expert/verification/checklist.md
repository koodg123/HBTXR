# Verification Checklist

## Prompt Pack

- The user request was rewritten into a measurable engineering objective.
- The chosen route is explicit and the nearest rejected route is mentally considered.
- Constraints, failure evidence, and success metrics are stated clearly.

## Closed-Loop Review

- A routing-oriented sub-agent challenged the framing.
- A system or feasibility-oriented sub-agent challenged execution realism.
- A critic sub-agent challenged evidence quality and verification coverage.
- The main prompt was revised after feedback instead of just appending comments.

## Domain Checks

- The prompt states primary and secondary objectives explicitly.
- One sub-agent challenges the roofline or bottleneck assumption and another challenges Pareto evidence.
- Final output says what must be simulated, synthesized, or measured to validate the recommendation.

## Final Answer

- The response separates prompt pack, recommendation, validation, and residual risk.
- Unknowns that still require measurement or external validation are explicit.
- The final recommendation is the smallest credible next step, not the broadest redesign.
