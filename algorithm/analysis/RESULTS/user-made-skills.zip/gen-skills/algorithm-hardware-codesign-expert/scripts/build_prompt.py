from __future__ import annotations

import argparse


TITLE = 'Algorithm-Hardware Co-design Expert'
TASK_AXES = ['Roofline and Bottleneck Analysis', 'Loop and Polyhedral Transformations', 'Algorithm-to-Hardware Mapping', 'DSE and Pareto Search']
INPUT_FOCUS = ['optimization objective and secondary tradeoffs', 'workload shape, reuse structure, and precision assumptions', 'memory hierarchy, PE structure, and bandwidth ceilings', 'evaluation path such as analytic model, simulation, HLS, or RTL']
SUBAGENTS = [{'name': 'roofline-modeler', 'inspired_by': ['performance-engineer', 'knowledge-synthesizer'], 'mission': 'Establish the current regime as compute-bound, memory-bound, synchronization-bound, or control-bound before the search expands.', 'handoff': ['workload summary', 'hardware envelope', 'baseline numbers'], 'returns': ['bottleneck classification', 'intensity cues', 'missing measurement needs'], 'revision_trigger': 'Revise when the main prompt proposes exploration without establishing the dominant bottleneck.'}, {'name': 'mapping-explorer', 'inspired_by': ['workflow-orchestrator', 'multi-agent-coordinator'], 'mission': 'Stress-test candidate mappings, loop transforms, and memory strategies against the actual hardware envelope.', 'handoff': ['candidate search space', 'mapping objective', 'reuse assumptions'], 'returns': ['search-space reductions', 'mapping priorities', 'implementation cautions'], 'revision_trigger': 'Revise when the search space is too broad or ignores critical bank or bandwidth constraints.'}, {'name': 'pareto-critic', 'inspired_by': ['knowledge-synthesizer', 'performance-engineer'], 'mission': 'Challenge whether claimed improvements really move the Pareto frontier once cost-model error and engineering complexity are counted.', 'handoff': ['candidate prompt', 'evaluation path', 'target tradeoff weights'], 'returns': ['Pareto skepticism list', 'evidence gaps', 'validation checkpoints'], 'revision_trigger': 'Revise when gains are asserted without calibrated evidence or when complexity overwhelms benefit.'}]


def bullets(items):
    return "\n".join(f"- {item}" for item in items if item)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Build a prompt pack for {TITLE}.")
    parser.add_argument("--goal", required=True, help="Engineering goal or user ask.")
    parser.add_argument("--route", default=TASK_AXES[0], help="Chosen task route.")
    parser.add_argument("--target", default="", help="Deployment target, runtime, or environment.")
    parser.add_argument("--constraints", nargs="*", default=[], help="Constraint strings.")
    parser.add_argument("--failures", nargs="*", default=[], help="Failure observations.")
    parser.add_argument("--metrics", nargs="*", default=[], help="Metrics or acceptance checks.")
    parser.add_argument("--context", nargs="*", default=[], help="Extra context notes.")
    return parser.parse_args()


def build_main_prompt(args: argparse.Namespace) -> str:
    constraint_lines = args.constraints or ["<fill in constraints>"]
    failure_lines = args.failures or ["<fill in failure evidence>"]
    metric_lines = args.metrics or ["<fill in success metrics>"]
    context_lines = args.context or ["<fill in missing context>"]
    return f"""You are the {TITLE}.
Prioritize prompt generation before solutioning.

Goal:
{args.goal}

Chosen route:
{args.route}

Target environment:
{args.target or '<unspecified>'}

Constraint block:
{bullets(constraint_lines)}

Failure evidence:
{bullets(failure_lines)}

Metrics and acceptance:
{bullets(metric_lines)}

Context notes:
{bullets(context_lines)}

Return:
- revised prompt pack
- ranked solution options
- validation plan
- residual risks"""


def build_subagent_prompts(args: argparse.Namespace) -> list[str]:
    prompts: list[str] = []
    for subagent in SUBAGENTS:
        prompts.append(
            f"""### {subagent['name']}
Mission: {subagent['mission']}
Handoff fields: {', '.join(subagent['handoff'])}
Expected return: {', '.join(subagent['returns'])}
Revision trigger: {subagent['revision_trigger']}

Prompt:
Challenge the draft prompt for {TITLE}.
Goal: {args.goal}
Route: {args.route}
Target: {args.target or '<unspecified>'}
Constraints:
{bullets(args.constraints or ['<fill in constraints>'])}
Failures:
{bullets(args.failures or ['<fill in failure evidence>'])}
Metrics:
{bullets(args.metrics or ["<fill in success metrics>"])}"""
        )
    return prompts


def main() -> None:
    args = parse_args()
    print(f"# {TITLE} Prompt Pack\n")
    print("## Candidate Routes\n")
    print(bullets(TASK_AXES))
    print("\n## Input Focus\n")
    print(bullets(INPUT_FOCUS))
    print("\n## Main Expert Prompt\n")
    print("```text")
    print(build_main_prompt(args).rstrip())
    print("```")
    print("\n## Sub-Agent Prompts\n")
    for prompt in build_subagent_prompts(args):
        print(prompt)
    print("\n## Closed-Loop Revision Gate\n")
    print("- Revise the prompt if routing, feasibility, or verification assumptions are contradicted.")
    print("- Prefer evidence-backed constraints over optimistic wording.")
    print("- Finalize only after the revised prompt still satisfies the original goal.")


if __name__ == "__main__":
    main()
