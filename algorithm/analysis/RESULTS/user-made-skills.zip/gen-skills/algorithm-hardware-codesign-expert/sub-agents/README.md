# Sub-Agents

This folder contains Codex-style sub-agent definitions in `.toml` format plus the higher-level manifest.

## Closed-Loop Order

1. Draft the main prompt with `templates/prompt-template.md` or `templates/prompt-bundles/`.
2. Run `roofline-modeler.toml` to challenge the draft for `Establish the current regime as compute-bound, memory-bound, synchronization-bound, or control-bound before the search expands.`
3. Run `mapping-explorer.toml` to challenge the draft for `Stress-test candidate mappings, loop transforms, and memory strategies against the actual hardware envelope.`
4. Run `pareto-critic.toml` to challenge the draft for `Challenge whether claimed improvements really move the Pareto frontier once cost-model error and engineering complexity are counted.`
5. Run `measured-search-and-roofline-analyst.toml` to challenge the draft for `Challenge the prompt with search-budget, measured-tuning, and roofline-hierarchy questions from TVM and Nsight workflows.`
6. Run `researcher-background-adapter.toml` to challenge the draft for `Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: Vivienne Sze, Jason Cong, Luca Benini.`
7. Revise the main prompt and pass it through `verification/checklist.md` before finalizing.

## Files

- `manifest.toml`: role list, feedback-loop stages, and retry rules.
- `roofline-modeler.toml`: Establish the current regime as compute-bound, memory-bound, synchronization-bound, or control-bound before the search expands.
- `mapping-explorer.toml`: Stress-test candidate mappings, loop transforms, and memory strategies against the actual hardware envelope.
- `pareto-critic.toml`: Challenge whether claimed improvements really move the Pareto frontier once cost-model error and engineering complexity are counted.
- `measured-search-and-roofline-analyst.toml`: Challenge the prompt with search-budget, measured-tuning, and roofline-hierarchy questions from TVM and Nsight workflows.
- `researcher-background-adapter.toml`: Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: Vivienne Sze, Jason Cong, Luca Benini.
