# IDEA-Gen Context

Phase: P1
Domain: LLM Optimization
Parent skill: `attention-kernel-mapper`

## Why This Skill Exists

Attention mapping quality depends on accurate bandwidth estimates.

## Worker Capability

Estimate attention memory bandwidth, operand reuse, sequence length sensitivity, and cache bottlenecks.

## Expected Outputs

- Attention bandwidth model
- Sensitivity table
- Bottleneck analysis

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the cluster and roadmap notes for `LLM Optimization`.
