# Verification Checklist

- [ ] Skill phase `P1` and domain `LLM Optimization` are stated.
- [ ] Parent skill `attention-kernel-mapper` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] Attention bandwidth model is present and traceable.
- [ ] Sensitivity table is present and traceable.
- [ ] Bottleneck analysis is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] Residual risks and missing inputs are listed.
