# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P1

Domain: LLM Optimization

Parent skill: attention-kernel-mapper

Target model, algorithm, hardware, or dataset:

Constraints:

Assumptions:

Required artifact:

Verification evidence:

Risks and missing inputs:
