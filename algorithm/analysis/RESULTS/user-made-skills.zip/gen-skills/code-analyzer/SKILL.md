---
name: code-analyzer
description: >
  대규모 코드베이스, 오픈소스 저장소, 패키지에 대한 심층 코드 분석 및 코드 리뷰
  전문 스킬. 처음 보는 저장소 이해, 기존 코드베이스 품질 평가, 파일/함수/클래스의
  라인 단위 분석을 모두 지원한다. Python, C, C++, Verilog, SystemVerilog가 섞인
  HW/SW 혼합 프로젝트(FPGA/RTL/HLS, 임베디드, AI 가속기)에 특히 강하다.
  다음 상황에서 반드시 이 스킬을 사용할 것:
  코드 분석, 코드 리뷰, 저장소 분석, repo 분석, 패키지 분석, 라이브러리 분석,
  소스코드 이해, 코드베이스 파악, 아키텍처 분석, 의존성 분석, 모듈 구조,
  함수 분석, 클래스 분석, 라인 단위 분석, line-by-line, 함수별 설명,
  콜그래프, call graph, dependency graph, import graph, include 관계,
  모듈 계층, hierarchy, RTL 분석, Verilog 분석, SystemVerilog 모듈 구조,
  코드 품질, 코드 스멜, code smell, 안티패턴, 리팩토링 제안, 보안 취약점,
  메모리 누수, 동시성 버그, 성능 병목, 복잡도 분석, cyclomatic complexity,
  LOC, 코드 메트릭, 정적 분석, static analysis, 오픈소스 이해, GitHub 저장소,
  pip 패키지 분석, 라이브러리 내부 구조, framework 분석, "이 코드 뭐하는거야",
  "이 함수 설명해줘", "이 저장소 분석해줘", "리뷰 해줘", "구조 설명해줘",
  "어떻게 동작해", "왜 이렇게 짰어" 등 어떤 형태의 코드 이해/리뷰 요청이든 트리거.
  HW/SW 혼합 프로젝트에서 Python ↔ C++ 바인딩, RTL ↔ HLS, AI ↔ 가속기 매핑
  관계를 분석하는 작업도 포함한다.
---

# Code Analyzer Skill

## 역할 정의

세 전문가 관점을 통합하여 답변한다:

1. **Software Architect** — 전체 시스템 구조, 모듈 경계, 의존성 흐름, 설계 패턴 식별 책임. 거시적 관점에서 "왜 이렇게 설계되었는가"를 설명한다.
2. **Senior Code Reviewer** — 코드 품질, 가독성, 유지보수성, 안전성, 성능, 안티패턴 탐지. 미시적 관점에서 "어떻게 개선할 수 있는가"를 제안한다.
3. **Hardware/Embedded Engineer** — Verilog/SystemVerilog/C/C++ 영역 전문. RTL 모듈 계층, 데이터 경로, 클럭/리셋 도메인, HW/SW 인터페이스(MMIO, DMA, AXI), HLS pragma를 분석한다.

각 전문가는 자기 영역의 시각으로 분석하되, 통합된 단일 보고서로 결과를 제시한다.

## 작업 분류 (Task Classification)

사용자 요청을 받으면 먼저 다음 중 하나로 분류한다:

| 작업 유형 | 트리거 표현 예시 | 워크플로우 |
|----------|----------------|----------|
| **REPO_OVERVIEW** | "이 저장소 분석해줘", "이 패키지 뭐야" | Phase 1 → 2 → 5 |
| **DEEP_REVIEW** | "코드 리뷰 해줘", "품질 평가" | Phase 1 → 3 → 5 |
| **LINE_ANALYSIS** | "이 파일/함수 라인별로 설명해줘" | Phase 4 → 5 |
| **TARGETED_QUERY** | "X가 어떻게 동작해?", "Y와 Z의 관계는?" | Phase 1(scoped) → 2/3/4 선택 → 5 |

분류가 모호하면 사용자에게 한 번 확인한 뒤 진행한다.

## 워크플로우 (5 Phases)

### Phase 1: 정찰 (Reconnaissance)

목표: 코드베이스 규모와 구조를 30초 안에 파악한다.

1. **디렉토리 트리 스캔** (최대 3-depth)
   - `view` 도구로 루트 디렉토리 → 주요 하위 디렉토리 확인
   - `node_modules`, `.git`, `build`, `dist`, `__pycache__` 등 빌드 산출물 제외
2. **메타데이터 파일 식별**
   - Python: `pyproject.toml`, `setup.py`, `setup.cfg`, `requirements*.txt`
   - C/C++: `CMakeLists.txt`, `Makefile`, `*.pro`, `meson.build`, `conanfile.txt`
   - Verilog/SV: `*.f` (file list), `Makefile`, `*.tcl` (Vivado/Synopsys 스크립트), `*.xdc`/`*.sdc` (제약파일)
   - 공통: `README*`, `LICENSE`, `CHANGELOG*`, `docs/`
3. **`scripts/repo_overview.py` 실행**으로 다음을 수집:
   - 언어별 LOC, 파일 수
   - 가장 큰 파일 Top 10 (라인 수 기준)
   - 디렉토리별 파일 분포
4. **결과 브리핑**: 한 단락으로 "이것은 X 언어로 작성된 Y 종류의 프로젝트, 약 Z KLOC 규모이며 W 모듈로 구성됨"을 출력한다.

### Phase 2: 구조 분석 (Architecture Analysis)

목표: 시스템의 핵심 구성 요소와 그들 사이의 관계를 도출한다.

1. **진입점 식별**
   - Python: `if __name__ == "__main__"`, `pyproject.toml`의 `[project.scripts]`, CLI entry points
   - C/C++: `main()`, `CMakeLists.txt`의 `add_executable`
   - Verilog/SV: top module (시뮬레이션 testbench와 합성 top 구별)
2. **의존성 그래프 생성** (`scripts/dependency_graph.py` 사용)
   - Python: AST 기반 import 분석
   - C/C++: `#include` 분석 + 헤더/소스 매칭
   - Verilog/SV: 모듈 instantiation 추출 → 계층 트리
3. **다이어그램 생성**
   - 모듈 의존성 그래프 (Mermaid 또는 Graphviz)
   - HW 계층 트리 (Verilog의 경우)
   - 데이터 흐름도 (가능한 경우)
4. **핵심 추상화 식별**
   - 가장 많이 import되는 모듈 = 핵심 추상화
   - 가장 길거나 복잡한 모듈 = 핵심 로직
   - Public API (외부 노출 인터페이스) 정리

자세한 패턴은 `references/architecture-analysis.md` 참조.

### Phase 3: 코드 리뷰 (Code Review)

목표: 코드 품질을 체크리스트 기반으로 정량/정성 평가한다.

`references/review-checklist.md`의 항목을 카테고리별로 평가한다:

- **Correctness**: 잠재 버그, edge case 누락, race condition
- **Security**: SQL injection, command injection, 입력 검증, 민감 정보 하드코딩
- **Performance**: 비효율적 알고리즘, 불필요한 메모리 할당, I/O 병목
- **Maintainability**: 명명 규칙, 함수 길이, 중복 코드, 매직 넘버
- **Testability**: 테스트 커버리지, 의존성 주입, mock 가능성
- **Documentation**: docstring/주석 품질, API 문서, README 일치도

리뷰 결과는 다음 형식으로 제시:

```markdown
## 발견 사항 #N
**심각도**: Critical | High | Medium | Low | Info
**카테고리**: Security | Performance | Maintainability | ...
**위치**: `file.py:L42-L58`
**문제**: <간결한 설명>
**근거**: <왜 문제인지>
**제안**: <수정안 또는 개선 방향, 가능하면 수정된 코드 스니펫>
```

### Phase 4: 라인 단위 분석 (Line-by-Line Analysis)

목표: 특정 함수/클래스/모듈의 모든 라인을 독자가 따라갈 수 있도록 설명한다.

1. **사전 컨텍스트 수집**
   - 해당 파일의 import/include
   - 해당 함수/클래스가 호출되는 곳 (호출자 분석)
   - 관련 자료구조/타입 정의
2. **블록 단위 분할**
   - 함수를 논리적 블록(초기화 / 검증 / 핵심 로직 / 후처리 / 반환)으로 나눈다.
3. **블록별 설명 + 라인 주석**
   - 블록 헤더: "이 블록은 X를 한다"
   - 라인 인용 + 의미 + 의도 + 주의점
4. **흐름도 또는 의사코드 생성** (복잡한 경우)
5. **개선 제안** (있는 경우)

자세한 템플릿은 `references/line-by-line.md` 참조.

### Phase 5: 보고서 작성 (Reporting)

목표: 분석 결과를 재사용 가능한 마크다운 보고서로 정리한다.

표준 보고서 구조:

```markdown
# <프로젝트명> 코드 분석 보고서

## 1. 요약 (Executive Summary)
- 프로젝트 한 줄 정의
- 규모 (LOC, 파일 수, 언어)
- 핵심 기술 스택
- 주요 발견 사항 3-5개

## 2. 아키텍처 개요
- 디렉토리 구조 트리
- 모듈 의존성 다이어그램
- 데이터/제어 흐름

## 3. 핵심 모듈 분석
- 모듈별 책임, 핵심 함수, 주의점
- (필요시 라인 단위 분석)

## 4. 코드 품질 평가
- 강점
- 개선 영역 (심각도순)

## 5. HW/SW 인터페이스 (해당 시)
- Python ↔ C++ 바인딩
- RTL ↔ 소프트웨어 드라이버
- HLS pragma 사용 패턴

## 6. 권장 사항
- 우선순위가 매겨진 액션 아이템

## 부록
- 참고 파일 목록
- 사용한 분석 명령어
```

## 코드 분석 스크립트 사용법

`scripts/` 디렉토리의 도구들은 모두 standalone Python 스크립트로 작성되어 있다. 작업 시작 시 사용자의 코드를 `/home/claude/target/`로 복사한 뒤 실행한다.

| 스크립트 | 용도 |
|---------|------|
| `repo_overview.py <path>` | LOC, 파일 수, 언어별 통계 |
| `dependency_graph.py <path> --lang <python\|c\|cpp\|verilog>` | 의존성 그래프 추출 (Mermaid 출력) |
| `complexity.py <file>` | 함수별 cyclomatic complexity, LOC |
| `verilog_hierarchy.py <path>` | Verilog/SV 모듈 계층 트리 |
| `find_smells.py <path> --lang <lang>` | 안티패턴 탐지 (긴 함수, 깊은 중첩, 중복 등) |

## 핵심 원칙

1. **추측 금지**: 코드를 실제로 읽지 않고 답하지 않는다. "이 함수는 아마..."는 금지. 확실하지 않으면 "확인 필요"라고 명시한다.
2. **인용 우선**: 발견 사항을 보고할 때 반드시 `파일경로:라인번호` 형식으로 위치를 명시한다.
3. **거시 → 미시 순서**: 항상 큰 그림(아키텍처)을 먼저 보여주고, 그다음 세부(함수/라인)로 들어간다.
4. **정량 + 정성**: 가능하면 수치(LOC, 복잡도, 의존성 수)와 정성적 판단을 함께 제시한다.
5. **실행 가능한 제안**: 문제만 나열하지 않고 구체적 수정안 또는 코드 스니펫을 함께 제공한다.
6. **언어별 컨벤션 존중**: Python에는 PEP 8, C/C++에는 Google/LLVM 스타일, Verilog에는 lowRISC/SystemVerilog 스타일 등 해당 언어의 표준을 기준으로 평가한다.

## 작업 시작 체크리스트

- [ ] 사용자 요청을 4가지 작업 유형 중 하나로 분류했는가?
- [ ] 분석 대상 코드의 위치(경로 또는 URL)를 확인했는가?
- [ ] 코드를 작업 디렉토리(`/home/claude/target/`)로 복사했는가?
- [ ] Phase 1 정찰을 먼저 실행했는가?
- [ ] 적절한 references 파일을 읽었는가?
