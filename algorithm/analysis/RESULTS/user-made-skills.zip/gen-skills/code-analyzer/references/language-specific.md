# 언어별 분석 패턴

## Python

### 패키지 구조 분석 우선순위
1. `pyproject.toml` 또는 `setup.py` → 패키지 메타데이터, 의존성, entry points
2. `src/<package>/__init__.py` 또는 `<package>/__init__.py` → public API 노출
3. `__main__.py` → CLI 진입점
4. `tests/` 또는 `test_*.py` → 사용 예시 (실제로 자주 도움됨)

### Python 패키지 분석 시 자주 보는 패턴

**Plugin 시스템**
- `pkg_resources.iter_entry_points` 또는 `importlib.metadata.entry_points`
- `setup.py`의 `entry_points={"my_pkg.plugins": [...]}`

**메타클래스/디스크립터**
- `__init_subclass__`, `__set_name__`, `__class_getitem__`
- 보통 라이브러리 내부 깊숙이 위치 → 사용자가 의식 못함

**Async 패턴**
- `asyncio.gather` vs `asyncio.create_task` vs `await`
- `async with`, `async for` 컨텍스트
- `aiofiles`, `httpx.AsyncClient` 등 async 라이브러리 사용

**런타임 코드 생성**
- `exec`/`eval` 사용 → 보안 검토 필요
- `dataclasses.make_dataclass`, `typing.NamedTuple`
- `attrs.make_class`, `pydantic.create_model`

### Python 정적 분석 도구 출력 활용
- `pyflakes`/`flake8`: 사용되지 않는 import, 정의되지 않은 이름
- `mypy`/`pyright`: 타입 일치 오류
- `bandit`: 보안 스캔
- `radon`: 복잡도, 유지보수성 지수

---

## C

### 분석 진입점
1. `Makefile` 또는 `CMakeLists.txt` → 빌드 타겟, 컴파일 플래그
2. `main.c` 또는 `*.c`에서 `int main(`을 grep
3. 헤더 파일(`include/` 또는 `*.h`) → 외부 인터페이스

### C 코드 분석 시 주의점

**메모리 관리 추적**
- `malloc`/`calloc`/`realloc` ↔ `free` 페어
- 함수가 메모리를 반환할 때 누가 해제 책임을 지는가 (caller? callee?)
- 이중 해제, use-after-free 가능성

**전처리기 (Preprocessor)**
- `#ifdef`, `#if defined(...)` 분기 → 빌드 환경별로 다른 코드
- 매크로 함수: `#define MAX(a, b) ((a) > (b) ? (a) : (b))` — side effect 위험
- `#include` 순서 의존성

**Undefined Behavior**
- Signed integer overflow
- Strict aliasing 위반 (`(int*)&float_var`)
- 초기화되지 않은 변수 사용
- 배열 경계 초과

**임베디드 C 특화**
- `volatile` 키워드 (MMIO, ISR 공유 변수)
- `__attribute__((interrupt))`, `__attribute__((section(".text.fast")))`
- 인라인 어셈블리 (`__asm__` 또는 `asm`)
- 비트 필드 구조체 → endian/alignment 주의

---

## C++

### 분석 진입점
1. `CMakeLists.txt` → 모듈 구조, 외부 의존성 (`find_package`)
2. Public 헤더 (`include/<lib>/`) → 클래스/함수 선언
3. `main.cpp` 또는 라이브러리 진입점

### C++ 분석 시 핵심 패턴

**RAII와 자원 관리**
- `std::unique_ptr`, `std::shared_ptr`: 소유권 의미
- `std::lock_guard`, `std::scoped_lock`: 자동 락 해제
- 커스텀 RAII 클래스 (파일 핸들, 그래픽 자원 등)

**현대 C++ 기능 식별**
- `auto`, range-based for, structured bindings (C++17)
- `constexpr`, `consteval` (C++20): 컴파일 타임 계산
- Concepts (C++20): 템플릿 제약
- Coroutines (C++20): `co_await`, `co_yield`, `co_return`
- Modules (C++20): `import`/`export`

**Template 메타프로그래밍**
- SFINAE: `std::enable_if`, `std::void_t`
- Tag dispatch: 컴파일 타임 분기
- CRTP: `class Derived : Base<Derived>` — static polymorphism

**STL 사용 패턴**
- `<algorithm>`: `std::transform`, `std::accumulate`, `std::for_each`
- `<ranges>` (C++20): `views::filter | views::transform`
- 컨테이너 선택: vector vs list vs deque vs unordered_map

**다형성 비용**
- `virtual` 함수 → vtable lookup
- `dynamic_cast` → RTTI 의존
- `std::function` → 타입 소거 + 힙 할당 가능성

### C++ 헤더-소스 매핑
큰 프로젝트에서는 `.hpp`-`.cpp` 페어가 많다:
- 헤더만 있는 헤더 전용 라이브러리
- `pImpl` 이디엄 (헤더는 forward declaration만)
- 템플릿: 정의가 헤더에 있어야 함

---

## Verilog / SystemVerilog

### 분석 진입점
1. **File list (`.f`)** 또는 빌드 스크립트 → 어떤 파일들이 컴파일되는지
2. **Top module** 식별 → 외부 포트가 있고 다른 모듈에 instantiation되지 않는 모듈
3. **Testbench** (`*_tb.v`, `tb_*.sv`) → 사용 예시

### 모듈 계층 추출 절차

```python
# 의사코드
modules = {}  # name -> file path
for file in verilog_files:
    text = read(file)
    for name in find_module_definitions(text):
        modules[name] = file

# 각 모듈에서 instantiation 찾기
hierarchy = {}  # parent_module -> [child_modules]
for parent, file in modules.items():
    text = read(file)
    children = []
    for candidate_name, instance_name in find_instantiations(text):
        if candidate_name in modules:  # 정의된 모듈만 (false positive 제거)
            children.append((candidate_name, instance_name))
    hierarchy[parent] = children
```

자세한 구현은 `scripts/verilog_hierarchy.py` 참조.

### Verilog/SV 코드 리뷰 핵심

**Synthesizable subset 위반**
- `initial` 블록 (testbench에서만 합법)
- `#delay` 문 (timing 모델, 합성 안 됨)
- `force`/`release` (시뮬레이션 전용)
- 동적 메모리 할당 (SV class new() — 합성 시 제한적)

**합성 결과에 영향을 주는 코딩**
- Synchronous reset vs asynchronous reset → flip-flop 형태가 다름
- Latch 추론 vs FF 추론
- Mux 추론: case 문의 default와 모든 분기 명시
- 자원 공유 vs 복제: 동일 산술 연산이 여러 곳에 있을 때

**SystemVerilog vs Verilog**
- `logic` (SV) vs `wire`/`reg` (V)
- `always_comb`/`always_ff`/`always_latch` (SV) vs 단순 `always` (V)
- Packed vs unpacked array
- Interface, modport, clocking block (SV 전용)
- assertion (`assert`, `assume`, `cover`) — SVA

### HW 정적 분석 도구
- **Verilator**: `--lint-only`, 무료, 빠름. 합성 가능성 + 일부 오류
- **Spyglass**, **JasperGold**, **Synopsys VC SpyGlass**: 상용, 더 정교
- **iverilog**: 시뮬레이션 위주, lint는 제한적

리뷰 보고서에 도구 출력을 인용하면 신뢰도가 올라간다. (단, 사용자가 직접 실행 후 결과를 제공해야 한다.)

---

## HW/SW 혼합 분석 패턴

### 인터페이스 매핑 표
혼합 프로젝트 분석 시 다음 형식의 표를 만든다:

| 자료/명령 | SW (C/C++) | HW (Verilog/SV) | 인터페이스 |
|----------|------------|-----------------|----------|
| Status register | `volatile uint32_t* status = (uint32_t*)0x4000_0010;` | `axi_lite_slave.STATUS @ 0x10` | AXI-Lite |
| DMA descriptor | `struct dma_desc { ... }` | `typedef struct packed { ... } dma_desc_t;` | Memory-mapped |
| Interrupt | `void irq_handler(void)` | `output logic irq_o` | Wire |
| Coprocessor command | `coproc_send_cmd(op, data)` | `cmd_fifo.push(...)` | FIFO |

이 표가 만들어지면 SW-HW 간 일치성 검증이 쉬워진다.

### HLS 코드 분석
HLS C++는 일반 C++와 다르게 분석한다:

- `#pragma HLS PIPELINE II=N` → 처리량 (Initiation Interval)
- `#pragma HLS UNROLL [factor=N]` → 루프 펼침
- `#pragma HLS DATAFLOW` → 모듈 간 병렬 실행
- `#pragma HLS ARRAY_PARTITION` → 메모리 분할 (BRAM → 레지스터)
- `#pragma HLS INTERFACE` → 외부 인터페이스 종류 (axi, ap_fifo, ap_memory)

각 pragma가 어떤 RTL 구조로 변환되는지 함께 설명해야 분석이 완전하다.
