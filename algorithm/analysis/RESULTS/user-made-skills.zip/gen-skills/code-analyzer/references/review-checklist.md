# 코드 리뷰 체크리스트

## 심각도 정의

| 심각도 | 의미 | 예시 |
|--------|------|------|
| **Critical** | 데이터 손실, 보안 침해, 시스템 다운 가능 | SQL injection, 인증 우회, race condition으로 인한 corruption |
| **High** | 잘못된 결과, 명확한 버그 | off-by-one, null deref, 메모리 누수, 잘못된 알고리즘 |
| **Medium** | 잠재적 문제, 일부 케이스에서만 발생 | 부분적 입력 검증, 성능 저하, deprecated API |
| **Low** | 개선 권장 | 명명 일관성, 매직 넘버, docstring 누락 |
| **Info** | 정보성 코멘트 | 더 나은 패턴 제안, 대안 라이브러리 |

## 카테고리별 체크리스트

### 1. Correctness (정확성)

- [ ] 경계 조건 처리: 빈 리스트, null, 0, 음수, overflow
- [ ] 예외 처리: 모든 IO/네트워크/파싱 코드에 try-except 또는 RAII
- [ ] 동시성: 공유 변수 보호, 데드락 가능성, race condition
- [ ] 자원 해제: 파일, 소켓, 메모리, lock의 finally/destructor 처리
- [ ] 산술 오버플로우: 정수 곱셈, 시프트 연산
- [ ] 부동소수점 비교: `==` 대신 epsilon 비교
- [ ] 시간/타임존: naive datetime vs timezone-aware

### 2. Security (보안)

- [ ] 입력 검증: 모든 외부 입력(사용자, 네트워크, 파일)에 대해
- [ ] SQL injection: parameterized query 사용 여부
- [ ] Command injection: `shell=True`, `eval`, `exec` 사용 여부
- [ ] Path traversal: 사용자 입력으로 파일 경로 구성 시 정규화
- [ ] 민감 정보: 하드코딩된 비밀번호/API 키/토큰
- [ ] 암호화: 약한 알고리즘(MD5, SHA1, DES) 사용
- [ ] 난수: 보안 용도에 `random` 대신 `secrets` 사용
- [ ] 직렬화: pickle/yaml.load의 임의 코드 실행 위험
- [ ] CORS, CSRF, XSS (웹 코드의 경우)

### 3. Performance (성능)

- [ ] 알고리즘 복잡도: 큰 입력에서 O(n²) 이상은 정당화 필요
- [ ] 불필요한 메모리 할당: 핫 루프 내 객체 생성
- [ ] I/O 패턴: N+1 쿼리, 배치 미사용
- [ ] 캐싱 누락: 반복 계산되는 결과
- [ ] 데이터 구조 선택: list vs set vs dict 적절성
- [ ] Python 특정: list comprehension > map/filter > 명시적 루프 (가독성)
- [ ] C++ 특정: 불필요한 복사 (move 가능한 곳), copy elision
- [ ] Verilog 특정: combinational loop, long path (timing closure)

### 4. Maintainability (유지보수성)

- [ ] 함수 길이: 50라인 초과 시 분할 검토
- [ ] 중첩 깊이: 4단계 이상이면 early return / extract function
- [ ] 매개변수 수: 5개 이상이면 객체로 묶기 검토
- [ ] 매직 넘버: 의미 있는 상수로 추출
- [ ] 명명: 변수/함수/클래스 이름이 의도를 명확히 전달하는가
- [ ] 중복 코드: DRY 원칙, 3회 이상 반복되면 추출
- [ ] 단일 책임 원칙: 한 함수/클래스가 한 가지 일만 하는가
- [ ] 사이드 이펙트: 함수 시그니처에서 예측 가능한가

### 5. Testability (테스트 용이성)

- [ ] 테스트 디렉토리 존재 (`tests/`, `test_*.py`)
- [ ] 의존성 주입 vs 하드코딩된 의존성
- [ ] 순수 함수와 사이드 이펙트 분리
- [ ] Mock/stub이 가능한 구조
- [ ] 테스트 커버리지 측정 도구 사용 흔적 (`pytest-cov`, `gcov`)

### 6. Documentation (문서화)

- [ ] README: 설치, 사용법, 예제 포함
- [ ] Public API의 docstring: 인자, 반환값, 예외 명시
- [ ] 복잡한 알고리즘에 주석으로 의도 설명
- [ ] CHANGELOG 유지 여부
- [ ] 주석과 코드의 일치 (오래된 주석 = 거짓말)

## 언어별 추가 체크리스트

### Python

- [ ] Mutable default arguments (`def f(x=[])` 안티패턴)
- [ ] `==` vs `is` (None 비교는 `is`)
- [ ] List comprehension의 부작용 사용
- [ ] `try-except: pass` (silent failure)
- [ ] `*args`, `**kwargs`의 무분별한 사용
- [ ] Type hint 일관성 (PEP 484)
- [ ] `dataclass`/`pydantic` 활용 여부
- [ ] `pathlib` vs `os.path` 일관성
- [ ] Logger 사용 vs `print`
- [ ] `__init__.py`의 부작용 코드

### C/C++

- [ ] 메모리: `new`/`delete` 페어, `malloc`/`free` 페어, smart pointer 사용
- [ ] RAII: 자원을 객체 lifetime에 묶었는가
- [ ] Const correctness: const 멤버 함수, const 매개변수
- [ ] Rule of 0/3/5: 복사/이동 생성자/소멸자 일관성
- [ ] 헤더 가드: `#pragma once` 또는 include guard
- [ ] Forward declaration 활용 (컴파일 시간 단축)
- [ ] `nullptr` vs `NULL` vs `0`
- [ ] `auto`의 적절한 사용 (반복자 OK, 의도 불명확하면 NG)
- [ ] Range-based for vs index loop
- [ ] Undefined behavior: signed overflow, dangling reference

### Verilog/SystemVerilog

- [ ] Reset 전략: synchronous vs asynchronous, active-high vs active-low
- [ ] Clock domain crossing (CDC): 적절한 동기화 (2-flop synchronizer, FIFO)
- [ ] Latch 추론 회피: combinational always block에서 모든 분기에 할당
- [ ] Blocking(`=`) vs non-blocking(`<=`): combinational에 `=`, sequential에 `<=`
- [ ] Sensitivity list: SystemVerilog의 `always_comb`/`always_ff` 사용 권장
- [ ] 비트폭 일치: assignment, port connection의 width mismatch
- [ ] Signed/unsigned 혼용
- [ ] Reset 값 명시: 모든 register의 초기값
- [ ] Default case: case 문에 default 또는 모든 가능한 값 처리
- [ ] Linting tool 통과 여부 (Verilator, Spyglass 등)

## 보고서 작성 패턴

각 발견 사항은 다음 형식으로 작성한다:

```markdown
### [#{번호}] {한 줄 제목}

| 속성 | 값 |
|------|---|
| 심각도 | High |
| 카테고리 | Security |
| 위치 | `src/auth.py:L42-L58` |

**문제**
사용자 입력 `username`이 SQL 쿼리에 직접 삽입되어 SQL injection이 가능하다.

**근거**
`username = request.args.get("username")`이 `f"SELECT * FROM users WHERE name='{username}'"`에 그대로 사용된다.
공격자가 `' OR '1'='1`을 입력하면 모든 사용자 정보 노출.

**제안**
parameterized query 사용:

\`\`\`python
cursor.execute("SELECT * FROM users WHERE name = %s", (username,))
\`\`\`

또는 ORM (SQLAlchemy) 사용 권장.
```

## 우선순위 결정 가이드

리뷰 결과가 많을 때 우선순위:

1. **Critical/High 이슈를 먼저** — 즉시 수정 필요
2. **노출도가 높은 코드** — public API, 자주 호출되는 함수
3. **변경 빈도가 높은 코드** — git log로 최근 커밋이 많은 파일
4. **테스트가 없는 코드** — 회귀 위험 큼
5. **잘 작성된 새 코드보다 오래된 핵심 모듈** — 부채가 누적되어 있을 가능성
