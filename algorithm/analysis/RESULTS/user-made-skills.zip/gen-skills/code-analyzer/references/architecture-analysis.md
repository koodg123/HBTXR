# 아키텍처 분석 패턴

## 진입점 식별 패턴

### Python
- `pyproject.toml`의 `[project.scripts]` 섹션 → CLI 명령어 진입점
- `setup.py`의 `entry_points={"console_scripts": [...]}`
- `__main__.py` 파일 (패키지를 `python -m pkg`로 실행 시)
- `if __name__ == "__main__":` 블록을 가진 스크립트
- FastAPI/Flask: `app = FastAPI()` 또는 `app = Flask(__name__)`
- Django: `manage.py`, `wsgi.py`, `asgi.py`

### C/C++
- `int main(int argc, char* argv[])` 함수
- CMake: `add_executable(<target> ...)` → 실행파일 타겟 식별
- 라이브러리 진입점: `add_library(...)` → 외부 노출 헤더 확인
- 공유 라이브러리: `__attribute__((constructor))` 또는 DLL의 `DllMain`
- Pybind11/CFFI: `PYBIND11_MODULE(name, m)` 매크로 → Python 바인딩

### Verilog/SystemVerilog
- 합성용 top: 외부 포트(클럭, 리셋, IO)가 가장 많고 instantiation은 안 됨
- 시뮬레이션 top: testbench 파일 (`*_tb.v`, `tb_*.sv`), 보통 `initial` 블록 포함
- File list (`*.f`)에서 마지막에 나오거나 별도 표기된 파일이 top인 경우가 많음
- Vivado/Quartus 프로젝트 파일에서 `top_module` 속성 확인

## 의존성 그래프 도출

### Python (AST 기반)
```python
import ast
from pathlib import Path

def extract_imports(file_path: Path) -> list[str]:
    """파일의 모든 import 문에서 모듈명을 추출한다."""
    with open(file_path, encoding="utf-8") as f:
        tree = ast.parse(f.read(), filename=str(file_path))
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.append(node.module)
    return imports
```

분석 시 구분:
- **표준 라이브러리** (stdlib) — 의존성 그래프에서 제외 가능
- **외부 패키지** (third-party) — `requirements.txt`/`pyproject.toml`과 대조
- **내부 모듈** (project-local) — 의존성 그래프의 핵심

### C/C++ (`#include` 기반)
```python
import re

INCLUDE_RE = re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', re.MULTILINE)

def extract_includes(file_path: Path) -> list[tuple[str, str]]:
    """(헤더명, 형식) 리스트 반환. 형식은 'system' 또는 'local'."""
    text = file_path.read_text(encoding="utf-8", errors="ignore")
    results = []
    for match in INCLUDE_RE.finditer(text):
        header = match.group(1)
        kind = "system" if match.group(0).find("<") != -1 else "local"
        results.append((header, kind))
    return results
```

C++ 추가 분석:
- 클래스 상속 관계 → 클래스 다이어그램
- 템플릿 의존성
- `namespace` 그룹화

### Verilog/SystemVerilog (instantiation 기반)
```python
import re

# module_name instance_name (...);
# module_name #(.PARAM(VALUE)) instance_name (...);
INSTANCE_RE = re.compile(
    r'(\w+)\s*(?:#\s*\([^)]*\))?\s+(\w+)\s*\(',
    re.MULTILINE
)

# 키워드 제외 리스트 (instantiation으로 오인 방지)
KEYWORDS = {
    "always", "begin", "case", "if", "else", "for", "while",
    "assign", "wire", "reg", "logic", "input", "output", "inout",
    "module", "endmodule", "function", "task", "initial",
    "generate", "endgenerate", "genvar", "parameter", "localparam",
    "typedef", "enum", "struct", "union", "package", "import",
    "interface", "modport", "class", "endclass", "program",
    "fork", "join", "join_any", "join_none", "wait", "do",
}

def extract_module_definitions(text: str) -> list[str]:
    """파일 내에서 정의된 module 이름 추출."""
    return re.findall(r'^\s*module\s+(\w+)', text, re.MULTILINE)
```

instantiation 탐지 시 주의:
- `assign foo = bar(x);` 같은 함수 호출과 구별
- 정규식은 false positive 가능 → 정의된 module 이름과 교차 검증 필수
- `generate` 블록 안의 conditional instantiation 처리

## 다이어그램 생성

### Mermaid 다이어그램 (텍스트 기반, GitHub/마크다운 호환)

**모듈 의존성 (작은 그래프, <30개 노드)**
```mermaid
graph LR
    main --> parser
    main --> executor
    parser --> tokenizer
    parser --> ast_builder
    executor --> runtime
    runtime --> memory
```

**계층 트리 (Verilog 모듈)**
```mermaid
graph TD
    top[cpu_top]
    top --> fetch[fetch_unit]
    top --> decode[decode_unit]
    top --> exec[execute_unit]
    exec --> alu[alu]
    exec --> mul[multiplier]
```

### Graphviz DOT (큰 그래프 또는 정밀한 레이아웃)
```dot
digraph deps {
    rankdir=LR;
    node [shape=box, style=rounded];
    "main" -> "parser" [label="imports"];
    "parser" -> "tokenizer";
}
```

### 그래프 단순화 전략
큰 코드베이스는 다이어그램이 hairball이 되어 무용지물이 된다. 다음 중 하나를 적용:

1. **레이어별 분리**: presentation / business / data 레이어로 분리하여 각각 그림
2. **클러스터링**: 같은 디렉토리의 모듈을 하나의 노드로 합쳐서 표현
3. **import 횟수 임계값**: 3회 이상 import되는 모듈만 표시
4. **진입점 중심**: 진입점에서 깊이 N까지만 따라가서 표시

## 핵심 추상화 식별 휴리스틱

다음 신호들을 종합하여 "핵심 모듈"을 찾는다:

| 신호 | 의미 | 측정 방법 |
|------|------|----------|
| 높은 fan-in | 많은 모듈이 의존하는 핵심 | 의존성 그래프에서 들어오는 엣지 수 |
| 큰 LOC | 많은 로직이 집중됨 | 라인 수 |
| 높은 복잡도 | 핵심 알고리즘 위치 | cyclomatic complexity |
| Public API 노출 | 외부 인터페이스 | `__all__`, 헤더 파일, 모듈 포트 |
| README/docs 언급 빈도 | 사용자 관점 중요도 | grep 카운트 |

상위 3-5개를 "핵심 모듈"로 지정하고 Phase 2에서 우선 깊이 분석한다.

## HW/SW 인터페이스 분석 (혼합 프로젝트)

HW/SW 혼합 프로젝트에서 추가 분석 항목:

1. **Python ↔ C++ 바인딩**
   - `pybind11`: `PYBIND11_MODULE` 매크로 위치
   - `cython`: `.pyx` 파일과 `.pxd` 인터페이스
   - `ctypes`/`cffi`: Python 측 함수 시그니처 정의

2. **소프트웨어 ↔ RTL 인터페이스**
   - MMIO 레지스터 맵: 헤더 파일의 `#define REG_*` 또는 `struct`
   - AXI/AXI-Lite 슬레이브 인터페이스: Verilog 측 포트 + 드라이버 코드
   - DMA 디스크립터 구조체

3. **HLS pragma 사용 패턴**
   - `#pragma HLS PIPELINE`, `#pragma HLS UNROLL`, `#pragma HLS DATAFLOW`
   - `#pragma HLS INTERFACE`로 노출되는 인터페이스 → RTL과 매핑

4. **공유 자료 형식**
   - 동일 자료구조가 SW(C struct)와 HW(SystemVerilog struct/packed) 양쪽에 정의되어 있는지
   - 엔디안, 정렬(alignment), bit-width 일치 검증
