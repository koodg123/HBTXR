# 라인 단위 분석 가이드

## 목적과 적용 시점

라인 단위 분석은 다음과 같은 경우에만 사용한다:
- 사용자가 명시적으로 "이 함수/파일을 라인별로 설명해줘"라고 요청
- 핵심 알고리즘이 담긴 짧고 밀도 높은 함수 (예: 손실 함수, FFT 구현, 핵심 RTL 모듈)
- 버그/이슈 진단을 위해 특정 위치의 흐름을 정확히 짚어야 할 때

전체 파일을 무차별 라인별로 설명하는 것은 비효율적이다. 대상은 보통 **함수/클래스/모듈 단위**이며, 한 번에 50-200 라인 정도가 적절하다.

## 분석 템플릿

```markdown
# `<파일경로>::<함수/클래스명>` 라인 단위 분석

## 0. 컨텍스트
- **위치**: `path/to/file.py:L100-L180`
- **언어**: Python 3.10+
- **호출자**: 누가 이 함수를 호출하는가 (3개 이내 핵심)
- **목적**: 한 줄로 이 함수가 무엇을 하는지

## 1. 시그니처 분석
\`\`\`python
def function_name(arg1: Type1, arg2: Type2 = default) -> ReturnType:
\`\`\`
- `arg1` (Type1): 의미와 제약
- `arg2` (Type2, 기본값 X): 의미
- 반환: ReturnType의 의미

## 2. 블록별 분석

### Block A: 입력 검증 (L100-L110)
\`\`\`python
if not isinstance(arg1, list):
    raise TypeError(...)
if len(arg1) == 0:
    return []
\`\`\`
**의도**: 비정상 입력 조기 차단. 빈 리스트는 빈 결과로 단축 처리.
**주의**: `None`은 별도 처리되지 않음 → AttributeError 발생 가능.

### Block B: 핵심 로직 (L111-L150)
[블록을 더 작게 나누어 라인별로 또는 작은 그룹별로 설명]

### Block C: 후처리 및 반환 (L151-L180)
[...]

## 3. 흐름도 (필요시)
\`\`\`mermaid
flowchart TD
    Start --> Validate{유효한 입력?}
    Validate -->|No| Raise[예외 발생]
    Validate -->|Yes| Compute[핵심 계산]
    Compute --> Postprocess[후처리]
    Postprocess --> Return
\`\`\`

## 4. 주의 사항 / 함정
- (있다면) 미묘한 부분, 흔히 오해하는 점

## 5. 개선 제안 (선택)
- (있다면) 가독성/성능 개선 아이디어
```

## 라인 인용 규칙

라인 인용 시 반드시 다음을 지킨다:

1. **원본 그대로 인용**: 띄어쓰기, 들여쓰기 유지
2. **라인 번호 명시**: `L42` 또는 `L42-L58` 형식
3. **블록이 길면 축약 가능**: 단, `# ... (10 lines omitted)` 형식으로 명시
4. **여러 파일에 걸친 흐름이면 파일경로 함께**: `parser.py:L42` → `executor.py:L100`

## 언어별 라인 분석 강조점

### Python
- **타입 힌트의 의미**: `list` vs `Sequence`, `dict[str, X]` vs `Mapping[str, X]`
- **Generator vs List**: lazy evaluation 여부
- **Context manager**: `with` 블록 안의 자원 관리
- **Decorator**: 함수가 어떻게 변형되는지 (`@property`, `@cached_property`, `@functools.wraps`)
- **Async 코드**: `await` 지점에서 일어나는 일

### C/C++
- **포인터 vs 참조 vs 값**: 매개변수 전달 방식의 의미
- **메모리 소유권**: 누가 할당하고 누가 해제하는가 (`unique_ptr`, raw pointer, RAII)
- **Const 의미**: `const T*`, `T* const`, `const T* const`의 차이
- **템플릿 인스턴스화**: 컴파일 타임에 무엇이 일어나는가
- **인라인 어셈블리** (있는 경우): 정확한 동작 설명

### Verilog/SystemVerilog
- **always 블록 종류**: `always_comb` (조합), `always_ff` (순차), `always_latch` (래치)
- **Blocking vs Non-blocking**: 시뮬레이션 시점의 차이
- **클럭 도메인**: 어느 클럭에 동기화되는지
- **리셋 동작**: 동기/비동기, active level
- **Signal width**: 의도와 다르면 truncation/extension 발생
- **Generate 블록**: 컴파일 타임에 펼쳐지는 구조

## 예제: PyTorch 손실 함수 라인 분석

```markdown
# `losses.py::FocalLoss.forward` 라인 단위 분석

## 0. 컨텍스트
- **위치**: `losses.py:L45-L72`
- **언어**: Python 3.9+, PyTorch 2.x
- **호출자**: `train.py:L120` (학습 루프 내부)
- **목적**: Class imbalance 상황에서 사용하는 Focal Loss 계산.

## 1. 시그니처
\`\`\`python
def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
\`\`\`
- `pred`: shape (B, C) 또는 (B, C, H, W), logits (sigmoid/softmax 전)
- `target`: pred와 동일 shape, one-hot 또는 binary
- 반환: scalar tensor (배치 평균)

## 2. 블록별 분석

### Block A: BCE 계산 (L46-L48)
\`\`\`python
bce = F.binary_cross_entropy_with_logits(
    pred, target, reduction='none'
)
\`\`\`
**의도**: 각 원소별 BCE를 구한다. `reduction='none'`이 핵심—
focal weight를 곱한 후에 평균낼 것이므로 미리 평균내면 안 된다.
**수식**: `bce = -[y log σ(x) + (1-y) log(1-σ(x))]`

### Block B: p_t 계산 (L49-L50)
\`\`\`python
p_t = torch.exp(-bce)
\`\`\`
**의도**: `p_t = σ(x) if y=1 else 1-σ(x)` 를 직접 계산하지 않고
`exp(-BCE)`로 우회. 수치 안정성을 위해 logit 단계에서 처리.
**수학적 배경**: BCE = -log(p_t) → exp(-BCE) = p_t.

### Block C: Focal weight (L51-L53)
\`\`\`python
focal_weight = self.alpha * (1 - p_t) ** self.gamma
\`\`\`
**의도**: 잘 맞춘 샘플(p_t→1)의 weight를 줄이고,
틀린 샘플(p_t→0)의 weight를 증폭. `gamma`는 보통 2.0.

### Block D: 최종 손실 (L54)
\`\`\`python
return (focal_weight * bce).mean()
\`\`\`
**주의**: 배치 평균을 사용. 만약 클래스별 가중치를 다르게 주려면
`alpha`를 텐서로 만들어 broadcasting 해야 한다 (현재 코드는 scalar).

## 4. 주의 사항
- `reduction='none'`을 빼면 미리 평균이 나서 focal weight가 무의미해짐
- `gamma=0`이면 일반 BCE와 동일 (가중치 1)
- multi-class의 경우 sigmoid 기반 multi-label 가정 — softmax 기반이면 별도 구현 필요
```
