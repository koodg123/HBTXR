#!/usr/bin/env python3
"""Verilog/SystemVerilog 모듈 계층 트리 추출.

사용법:
    python verilog_hierarchy.py <path>
    python verilog_hierarchy.py <path> --top cpu_top
    python verilog_hierarchy.py <path> --output hierarchy.md
"""
from __future__ import annotations

import argparse
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Set, Tuple

EXCLUDE_DIRS = {".git", "vivado_proj", ".Xil", "build", "sim_build", "obj_dir"}

# 주석 제거 정규식
LINE_COMMENT = re.compile(r'//.*$', re.MULTILINE)
BLOCK_COMMENT = re.compile(r'/\*.*?\*/', re.DOTALL)
STRING_LITERAL = re.compile(r'"(?:[^"\\]|\\.)*"')

MODULE_DEF_RE = re.compile(r'^\s*module\s+(\w+)\b', re.MULTILINE)

# `module_name [#(...)] instance_name (`
INSTANCE_RE = re.compile(
    r'^\s*(\w+)\s*'
    r'(?:#\s*\([^)]*\))?'
    r'\s+(\w+)\s*\(',
    re.MULTILINE,
)

KEYWORDS = {
    "always", "always_comb", "always_ff", "always_latch",
    "assign", "automatic", "begin", "case", "casex", "casez",
    "class", "endclass", "default", "defparam", "do", "else",
    "end", "endcase", "endfunction", "endgenerate", "endinterface",
    "endmodule", "endpackage", "endprogram", "endtask", "enum",
    "event", "final", "for", "force", "foreach", "forever", "fork",
    "function", "generate", "genvar", "if", "import", "initial",
    "inout", "input", "interface", "join", "join_any", "join_none",
    "localparam", "logic", "longint", "modport", "module", "negedge",
    "output", "package", "parameter", "posedge", "primitive",
    "program", "real", "reg", "release", "repeat", "return", "shortint",
    "specify", "supply0", "supply1", "task", "tri", "tri0", "tri1",
    "triand", "trior", "trireg", "type", "typedef", "union", "unique",
    "unique0", "unsigned", "var", "vectored", "virtual", "void", "wait",
    "wand", "weak0", "weak1", "while", "wire", "wor", "xnor", "xor",
    "and", "or", "not", "buf", "bit", "byte", "int", "shortreal",
    "string", "chandle", "ref", "static", "const", "rand", "randc",
    "constraint", "covergroup", "endgroup", "coverpoint", "cross",
    "property", "endproperty", "sequence", "endsequence", "assert",
    "assume", "cover", "expect", "throughout", "within", "intersect",
}


def strip_comments_and_strings(text: str) -> str:
    """주석과 문자열 리터럴을 공백으로 치환해 false positive 줄임."""
    text = STRING_LITERAL.sub('""', text)
    text = LINE_COMMENT.sub('', text)
    text = BLOCK_COMMENT.sub('', text)
    return text


MODULE_BLOCK_RE = re.compile(
    r'^\s*module\s+(\w+)\b(.*?)^\s*endmodule\b',
    re.MULTILINE | re.DOTALL,
)


def parse_file(path: Path) -> Tuple[List[str], Dict[str, List[Tuple[str, str]]]]:
    """파일에서 (정의된 모듈들, {모듈명: [instantiation들]}) 반환.

    각 module ... endmodule 블록 단위로 instantiation을 귀속시켜 정확도를 높인다.
    """
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return [], {}
    text = strip_comments_and_strings(raw)
    defs: List[str] = []
    per_module_insts: Dict[str, List[Tuple[str, str]]] = {}

    for block in MODULE_BLOCK_RE.finditer(text):
        mod_name = block.group(1)
        body = block.group(2)
        defs.append(mod_name)
        insts: List[Tuple[str, str]] = []
        for m in INSTANCE_RE.finditer(body):
            child, inst = m.group(1), m.group(2)
            if child in KEYWORDS or inst in KEYWORDS:
                continue
            if child == mod_name:  # 자기 자신 instantiation은 일반적으로 없음
                continue
            insts.append((child, inst))
        per_module_insts[mod_name] = insts
    return defs, per_module_insts


def collect(root: Path) -> Tuple[Dict[str, Path], Dict[str, List[Tuple[str, str]]]]:
    """전체 저장소 스캔 → (module → file path), (module → [child instantiations])."""
    files = (list(root.rglob("*.v")) + list(root.rglob("*.sv"))
             + list(root.rglob("*.vh")) + list(root.rglob("*.svh")))
    files = [
        f for f in files
        if not any(part in EXCLUDE_DIRS for part in f.relative_to(root).parts)
    ]

    module_to_file: Dict[str, Path] = {}
    module_to_children: Dict[str, List[Tuple[str, str]]] = defaultdict(list)

    # 패스 1: 모든 모듈 정의 + 블록별 instantiation 수집
    file_data: Dict[Path, Tuple[List[str], Dict[str, List[Tuple[str, str]]]]] = {}
    for f in files:
        defs, per_mod = parse_file(f)
        file_data[f] = (defs, per_mod)
        for d in defs:
            if d not in module_to_file:
                module_to_file[d] = f

    # 패스 2: 정의된 모듈만 instantiation으로 인정
    defined = set(module_to_file.keys())
    for f, (defs, per_mod) in file_data.items():
        for parent_mod, insts in per_mod.items():
            for child_mod, inst_name in insts:
                if child_mod in defined:
                    module_to_children[parent_mod].append((child_mod, inst_name))

    return module_to_file, dict(module_to_children)


def find_top_modules(
    module_to_file: Dict[str, Path],
    module_to_children: Dict[str, List[Tuple[str, str]]],
) -> List[str]:
    """다른 모듈에서 instantiation되지 않은 모듈 = top 후보."""
    instantiated: Set[str] = set()
    for parent, children in module_to_children.items():
        for child, _ in children:
            instantiated.add(child)
    tops = sorted(set(module_to_file.keys()) - instantiated)
    return tops


def render_tree(
    module: str,
    children_map: Dict[str, List[Tuple[str, str]]],
    files: Dict[str, Path],
    root: Path,
    prefix: str = "",
    is_last: bool = True,
    visited: Set[str] | None = None,
) -> List[str]:
    """모듈 계층 트리를 텍스트로 렌더링 (ASCII tree)."""
    if visited is None:
        visited = set()
    file_path = files.get(module)
    rel = file_path.relative_to(root) if file_path else "<unknown>"
    branch = "└── " if is_last else "├── "
    out = [f"{prefix}{branch}{module}  ({rel})"]

    if module in visited:
        out[-1] += "  ⟲ cycle"
        return out
    visited = visited | {module}

    children = sorted(children_map.get(module, []))
    next_prefix = prefix + ("    " if is_last else "│   ")
    for i, (child_mod, inst_name) in enumerate(children):
        child_is_last = (i == len(children) - 1)
        # instance 이름은 자식 줄에 함께 표시
        sub = render_tree(child_mod, children_map, files, root,
                          next_prefix, child_is_last, visited)
        # 첫 줄에 instance 이름 추가
        sub[0] = sub[0] + f"  [{inst_name}]"
        out.extend(sub)
    return out


def render_mermaid(
    children_map: Dict[str, List[Tuple[str, str]]],
    tops: List[str],
) -> str:
    """전체 계층을 Mermaid graph로 출력."""
    def nid(s: str) -> str:
        return re.sub(r'\W', '_', s)
    lines = ["```mermaid", "graph TD"]
    all_nodes = set(tops)
    for parent, children in children_map.items():
        all_nodes.add(parent)
        for c, _ in children:
            all_nodes.add(c)
    for n in sorted(all_nodes):
        lines.append(f'    {nid(n)}["{n}"]')
    for parent, children in children_map.items():
        for c, inst in children:
            lines.append(f'    {nid(parent)} -->|{inst}| {nid(c)}')
    lines.append("```")
    return "\n".join(lines)


def main() -> int:
    p = argparse.ArgumentParser(description="Verilog/SV module hierarchy extractor")
    p.add_argument("path", type=Path)
    p.add_argument("--top", help="특정 top 모듈로 지정 (자동 감지 대신)")
    p.add_argument("--output", "-o", type=Path)
    p.add_argument("--mermaid", action="store_true", help="Mermaid 그래프 출력 추가")
    args = p.parse_args()

    root = args.path.resolve()
    if not root.exists():
        print(f"Error: {root} not found", file=sys.stderr)
        return 1

    module_to_file, children_map = collect(root)
    if not module_to_file:
        print("Verilog/SV 파일에서 module 정의를 찾지 못했습니다.")
        return 0

    tops = [args.top] if args.top else find_top_modules(module_to_file, children_map)
    if args.top and args.top not in module_to_file:
        print(f"Warning: '{args.top}'은 정의된 모듈이 아닙니다.", file=sys.stderr)

    out = ["# Verilog/SystemVerilog Module Hierarchy", ""]
    out.append(f"- 정의된 모듈: {len(module_to_file)}개")
    out.append(f"- Top 후보: {', '.join(tops) if tops else '(없음)'}")
    out.append("")

    out.append("## 모듈 → 파일 매핑")
    out.append("")
    out.append("| 모듈 | 파일 |")
    out.append("|------|------|")
    for mod in sorted(module_to_file.keys()):
        rel = module_to_file[mod].relative_to(root)
        out.append(f"| `{mod}` | `{rel}` |")
    out.append("")

    out.append("## 계층 트리")
    out.append("")
    out.append("```")
    for top in tops:
        if top in module_to_file:
            out.extend(render_tree(top, children_map, module_to_file, root))
            out.append("")
    out.append("```")
    out.append("")

    if args.mermaid:
        out.append("## 의존성 그래프 (Mermaid)")
        out.append("")
        out.append(render_mermaid(children_map, tops))
        out.append("")

    text = "\n".join(out)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"Written to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
