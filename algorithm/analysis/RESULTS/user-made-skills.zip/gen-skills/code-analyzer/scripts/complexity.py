#!/usr/bin/env python3
"""Python 함수별 복잡도 분석.

Cyclomatic Complexity 근사치 + LOC + 함수 길이를 측정한다.

사용법:
    python complexity.py <file_or_dir>
    python complexity.py <path> --threshold 10  # 임계값 이상만 출력
"""
from __future__ import annotations

import argparse
import ast
import sys
from pathlib import Path
from typing import List, NamedTuple


class FunctionMetric(NamedTuple):
    file: str
    name: str
    lineno: int
    end_lineno: int
    loc: int
    complexity: int
    params: int
    nesting: int


# Cyclomatic complexity 증가시키는 노드 타입
DECISION_NODES = (
    ast.If, ast.For, ast.AsyncFor, ast.While,
    ast.IfExp,  # 삼항 연산자
    ast.Try,
    ast.ExceptHandler,
    ast.With, ast.AsyncWith,
    ast.Assert,
    ast.BoolOp,  # and/or → 추가 분기
    ast.comprehension,
)


def cyclomatic_complexity(func_node: ast.AST) -> int:
    """간단한 cyclomatic complexity 계산. 시작값 1 + decision points."""
    cc = 1
    for node in ast.walk(func_node):
        if isinstance(node, DECISION_NODES):
            cc += 1
            # BoolOp의 경우 operator 개수만큼 추가 (and a and b and c → +2)
            if isinstance(node, ast.BoolOp):
                cc += len(node.values) - 2  # 첫 +1은 위에서 카운트
    return cc


def max_nesting_depth(func_node: ast.AST) -> int:
    """함수 내 최대 중첩 깊이."""
    NESTING_NODES = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try, ast.With, ast.AsyncWith)

    def walk(node: ast.AST, depth: int) -> int:
        max_d = depth
        for child in ast.iter_child_nodes(node):
            new_depth = depth + (1 if isinstance(child, NESTING_NODES) else 0)
            max_d = max(max_d, walk(child, new_depth))
        return max_d

    return walk(func_node, 0)


def analyze_file(path: Path) -> List[FunctionMetric]:
    try:
        text = path.read_text(encoding="utf-8")
        tree = ast.parse(text, filename=str(path))
    except (SyntaxError, UnicodeDecodeError):
        return []

    metrics: List[FunctionMetric] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            cc = cyclomatic_complexity(node)
            nesting = max_nesting_depth(node)
            end_lineno = getattr(node, "end_lineno", node.lineno)
            loc = (end_lineno or node.lineno) - node.lineno + 1
            params = len(node.args.args) + len(node.args.kwonlyargs)
            if node.args.vararg:
                params += 1
            if node.args.kwarg:
                params += 1
            metrics.append(FunctionMetric(
                file=str(path), name=node.name,
                lineno=node.lineno, end_lineno=end_lineno or node.lineno,
                loc=loc, complexity=cc, params=params, nesting=nesting,
            ))
    return metrics


def render(metrics: List[FunctionMetric], threshold: int) -> str:
    """결과를 마크다운 표로 렌더링."""
    if not metrics:
        return "분석 결과 없음 (파이썬 파일이 없거나 파싱 실패)."
    metrics = [m for m in metrics if m.complexity >= threshold]
    metrics.sort(key=lambda m: (-m.complexity, -m.loc))

    lines = ["# Function Complexity Analysis", ""]
    if threshold > 1:
        lines.append(f"_복잡도 ≥ {threshold} 인 함수만 표시_")
        lines.append("")
    if not metrics:
        lines.append(f"임계값 {threshold} 이상의 함수가 없습니다.")
        return "\n".join(lines)

    lines.append("| 파일:라인 | 함수 | LOC | CC | 파라미터 | 중첩깊이 | 평가 |")
    lines.append("|-----------|------|----:|---:|---------:|---------:|------|")
    for m in metrics:
        verdict = []
        if m.complexity >= 20: verdict.append("🔴 매우 높음")
        elif m.complexity >= 10: verdict.append("🟠 높음")
        elif m.complexity >= 5: verdict.append("🟡 중간")
        if m.loc >= 100: verdict.append("📏 김")
        if m.params >= 6: verdict.append("📦 매개변수 많음")
        if m.nesting >= 4: verdict.append("🪜 깊은 중첩")
        if not verdict: verdict.append("✅ 양호")
        v = ", ".join(verdict)
        rel = m.file
        lines.append(f"| `{rel}:{m.lineno}` | `{m.name}` | {m.loc} | "
                     f"{m.complexity} | {m.params} | {m.nesting} | {v} |")
    lines.append("")
    lines.append("## 권장 임계값")
    lines.append("- Cyclomatic Complexity > 10: 분할 검토")
    lines.append("- LOC > 50: 분할 검토")
    lines.append("- 매개변수 > 5: 객체로 묶기 검토")
    lines.append("- 중첩 깊이 > 3: early return 또는 함수 추출 검토")
    return "\n".join(lines)


def main() -> int:
    p = argparse.ArgumentParser(description="Python function complexity analyzer")
    p.add_argument("path", type=Path)
    p.add_argument("--threshold", type=int, default=1,
                   help="이 복잡도 이상의 함수만 출력 (기본 1=전체)")
    p.add_argument("--output", "-o", type=Path)
    args = p.parse_args()

    if not args.path.exists():
        print(f"Error: {args.path} not found", file=sys.stderr)
        return 1

    if args.path.is_file():
        metrics = analyze_file(args.path)
    else:
        metrics = []
        for f in args.path.rglob("*.py"):
            if any(p in {".git", "__pycache__", ".venv", "venv", "build"}
                   for p in f.parts):
                continue
            metrics.extend(analyze_file(f))
            # 파일 경로를 root 기준 상대경로로 변환
        metrics = [
            m._replace(file=str(Path(m.file).relative_to(args.path)))
            for m in metrics
        ]

    text = render(metrics, args.threshold)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"Written to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
