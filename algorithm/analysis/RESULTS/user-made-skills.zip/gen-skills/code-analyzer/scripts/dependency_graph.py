#!/usr/bin/env python3
"""의존성 그래프 추출 스크립트.

Python AST 기반 import 분석, C/C++ #include 분석, Verilog/SV 모듈 instantiation 분석.

사용법:
    python dependency_graph.py <path> --lang <python|c|cpp|verilog|sv>
    python dependency_graph.py <path> --lang python --output deps.md --format mermaid
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Set, Tuple

EXCLUDE_DIRS = {
    ".git", "__pycache__", "node_modules", "build", "dist",
    ".venv", "venv", ".tox", "vivado_proj", ".Xil",
}

# ---------------------------------------------------------------------------
# Python
# ---------------------------------------------------------------------------

def python_imports(file: Path) -> List[str]:
    try:
        text = file.read_text(encoding="utf-8")
        tree = ast.parse(text, filename=str(file))
    except (SyntaxError, UnicodeDecodeError):
        return []
    out = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out.extend(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            # relative import의 경우 dots 처리
            prefix = "." * (node.level or 0)
            out.append(prefix + node.module)
    return out


def python_module_name(file: Path, root: Path) -> str:
    """파일 경로 → 모듈 이름 (a/b/c.py → a.b.c)."""
    rel = file.relative_to(root)
    parts = list(rel.with_suffix("").parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def build_python_graph(root: Path) -> Dict[str, Set[str]]:
    """프로젝트 내부 모듈 간 import 그래프 생성. 외부 패키지는 제외."""
    files = [
        p for p in root.rglob("*.py")
        if not any(part in EXCLUDE_DIRS for part in p.relative_to(root).parts)
    ]
    internal_modules = {python_module_name(f, root) for f in files}

    graph: Dict[str, Set[str]] = defaultdict(set)
    for f in files:
        mod = python_module_name(f, root)
        for imp in python_imports(f):
            # internal에 매칭되는 prefix 찾기
            for cand in internal_modules:
                if imp == cand or imp.startswith(cand + "."):
                    graph[mod].add(cand)
                    break
                # 같은 패키지 내 from . import X
                if imp.startswith("."):
                    # 단순 처리: relative import는 동일 패키지 표시
                    parent = ".".join(mod.split(".")[:-1]) or "<root>"
                    graph[mod].add(parent + ".(relative)")
                    break
    return graph


# ---------------------------------------------------------------------------
# C / C++
# ---------------------------------------------------------------------------

INCLUDE_RE = re.compile(r'^\s*#\s*include\s*([<"])([^>"]+)[>"]', re.MULTILINE)


def c_includes(file: Path) -> List[Tuple[str, str]]:
    """[(header, kind)] kind in {'system', 'local'}."""
    try:
        text = file.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    out = []
    for m in INCLUDE_RE.finditer(text):
        kind = "system" if m.group(1) == "<" else "local"
        out.append((m.group(2), kind))
    return out


def build_c_graph(root: Path, exts: List[str]) -> Dict[str, Set[str]]:
    files = []
    for ext in exts:
        files.extend(root.rglob(f"*{ext}"))
    files = [
        f for f in files
        if not any(part in EXCLUDE_DIRS for part in f.relative_to(root).parts)
    ]
    file_basenames = {f.name for f in files}

    graph: Dict[str, Set[str]] = defaultdict(set)
    for f in files:
        rel = str(f.relative_to(root))
        for header, kind in c_includes(f):
            # 로컬 헤더이고 프로젝트 내부에 존재하는 것만 표시
            base = Path(header).name
            if base in file_basenames or kind == "local":
                graph[rel].add(header)
    return graph


# ---------------------------------------------------------------------------
# Verilog / SystemVerilog
# ---------------------------------------------------------------------------

MODULE_DEF_RE = re.compile(r'^\s*module\s+(\w+)', re.MULTILINE)

# `module_name [#(...)] instance_name (` 형식
INSTANCE_RE = re.compile(
    r'^\s*(\w+)\s*'                # 모듈 이름 후보
    r'(?:#\s*\([^)]*\))?'          # 파라미터 (옵션)
    r'\s+(\w+)\s*\(',              # 인스턴스 이름 + 여는 괄호
    re.MULTILINE
)

VERILOG_KEYWORDS = {
    "always", "always_comb", "always_ff", "always_latch",
    "assign", "automatic", "begin", "case", "casex", "casez",
    "class", "endclass", "default", "defparam", "do", "else",
    "end", "endcase", "endfunction", "endgenerate", "endinterface",
    "endmodule", "endpackage", "endprogram", "endtask", "enum",
    "event", "final", "for", "force", "foreach", "forever", "fork",
    "function", "generate", "genvar", "if", "import", "initial",
    "inout", "input", "interface", "join", "join_any", "join_none",
    "localparam", "logic", "longint", "modport", "module", "negedge",
    "output", "package", "parameter", "posedge", "primitive",
    "program", "real", "reg", "release", "repeat", "return", "shortint",
    "signed", "specify", "supply0", "supply1", "task", "tri", "tri0",
    "tri1", "triand", "trior", "trireg", "type", "typedef", "union",
    "unique", "unique0", "unsigned", "var", "vectored", "virtual",
    "void", "wait", "wand", "weak0", "weak1", "while", "wire", "wor",
    "xnor", "xor", "and", "or", "not", "buf",
}


def verilog_modules_in_file(file: Path) -> Tuple[List[str], List[Tuple[str, str]]]:
    """파일에서 (정의된 모듈 이름들, instantiation 후보들)을 추출."""
    try:
        text = file.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return [], []
    # 주석 제거 (간단한 처리)
    text = re.sub(r'//.*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    defs = MODULE_DEF_RE.findall(text)
    instances = []
    for m in INSTANCE_RE.finditer(text):
        mod_name = m.group(1)
        inst_name = m.group(2)
        if mod_name in VERILOG_KEYWORDS or inst_name in VERILOG_KEYWORDS:
            continue
        instances.append((mod_name, inst_name))
    return defs, instances


def build_verilog_graph(root: Path) -> Dict[str, Set[str]]:
    files = list(root.rglob("*.v")) + list(root.rglob("*.sv")) \
            + list(root.rglob("*.vh")) + list(root.rglob("*.svh"))
    files = [
        f for f in files
        if not any(part in EXCLUDE_DIRS for part in f.relative_to(root).parts)
    ]

    # 모든 정의된 모듈 수집
    defined_modules: Set[str] = set()
    file_to_modules: Dict[Path, List[str]] = {}
    for f in files:
        defs, _ = verilog_modules_in_file(f)
        defined_modules.update(defs)
        file_to_modules[f] = defs

    # parent_module → set of child_modules
    graph: Dict[str, Set[str]] = defaultdict(set)
    for f in files:
        defs, instances = verilog_modules_in_file(f)
        if not defs:
            continue
        for parent_mod in defs:
            for child_mod, _inst in instances:
                if child_mod in defined_modules and child_mod != parent_mod:
                    graph[parent_mod].add(child_mod)

    return graph


# ---------------------------------------------------------------------------
# 출력 형식
# ---------------------------------------------------------------------------

def render_mermaid(graph: Dict[str, Set[str]], title: str = "Dependency Graph") -> str:
    """Mermaid graph 형식으로 출력."""
    lines = [f"# {title}", "", "```mermaid", "graph LR"]
    # 노드 ID는 mermaid가 허용하는 형식으로 변환 (특수문자 → _)
    def node_id(name: str) -> str:
        return re.sub(r'[^A-Za-z0-9_]', '_', name)

    nodes = set()
    for src, dsts in graph.items():
        nodes.add(src)
        nodes.update(dsts)

    # 노드 정의 (라벨에 원래 이름)
    for n in sorted(nodes):
        lines.append(f'    {node_id(n)}["{n}"]')

    # 엣지
    for src in sorted(graph.keys()):
        for dst in sorted(graph[src]):
            lines.append(f"    {node_id(src)} --> {node_id(dst)}")
    lines.append("```")
    return "\n".join(lines)


def render_text(graph: Dict[str, Set[str]], title: str = "Dependency Graph") -> str:
    lines = [f"# {title}", ""]
    for src in sorted(graph.keys()):
        lines.append(f"## {src}")
        for dst in sorted(graph[src]):
            lines.append(f"  → {dst}")
        lines.append("")
    return "\n".join(lines)


def render_dot(graph: Dict[str, Set[str]], title: str = "deps") -> str:
    def q(s: str) -> str:
        return '"' + s.replace('"', '\\"') + '"'
    lines = [f"digraph {title} {{", "  rankdir=LR;",
             "  node [shape=box, style=rounded];"]
    for src in sorted(graph.keys()):
        for dst in sorted(graph[src]):
            lines.append(f"  {q(src)} -> {q(dst)};")
    lines.append("}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    p = argparse.ArgumentParser(description="Code dependency graph extractor")
    p.add_argument("path", type=Path, help="분석할 디렉토리 루트")
    p.add_argument("--lang", required=True,
                   choices=["python", "c", "cpp", "verilog", "sv"])
    p.add_argument("--format", default="mermaid",
                   choices=["mermaid", "dot", "text"])
    p.add_argument("--output", "-o", type=Path)
    args = p.parse_args()

    root = args.path.resolve()
    if not root.exists():
        print(f"Error: {root} not found", file=sys.stderr)
        return 1

    if args.lang == "python":
        graph = build_python_graph(root)
        title = "Python Module Dependency Graph"
    elif args.lang == "c":
        graph = build_c_graph(root, [".c", ".h"])
        title = "C Header Dependency Graph"
    elif args.lang == "cpp":
        graph = build_c_graph(root, [".cpp", ".cc", ".cxx", ".hpp", ".h", ".hxx"])
        title = "C++ Header Dependency Graph"
    elif args.lang in ("verilog", "sv"):
        graph = build_verilog_graph(root)
        title = "Verilog/SV Module Hierarchy"
    else:
        print(f"Unsupported language: {args.lang}", file=sys.stderr)
        return 1

    if args.format == "mermaid":
        text = render_mermaid(graph, title)
    elif args.format == "dot":
        text = render_dot(graph, "deps")
    else:
        text = render_text(graph, title)

    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"Written to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
