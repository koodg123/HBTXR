#!/usr/bin/env python3
"""저장소 개요 분석 스크립트.

사용법:
    python repo_overview.py <path>

출력:
    - 언어별 파일 수, 라인 수
    - 가장 큰 파일 Top 10
    - 디렉토리별 파일 분포
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

# 언어별 확장자 매핑
LANGUAGE_EXT: Dict[str, List[str]] = {
    "Python": [".py", ".pyx", ".pxd"],
    "C": [".c", ".h"],
    "C++": [".cpp", ".cc", ".cxx", ".hpp", ".hxx", ".h++"],
    "Verilog": [".v", ".vh"],
    "SystemVerilog": [".sv", ".svh"],
    "VHDL": [".vhd", ".vhdl"],
    "Markdown": [".md", ".rst"],
    "YAML": [".yml", ".yaml"],
    "JSON": [".json"],
    "TOML": [".toml"],
    "Shell": [".sh", ".bash"],
    "Make/CMake": ["Makefile", "CMakeLists.txt", ".cmake", ".mk"],
    "Tcl": [".tcl"],
    "TypeScript": [".ts", ".tsx"],
    "JavaScript": [".js", ".jsx"],
    "Rust": [".rs"],
    "Go": [".go"],
    "Java": [".java"],
}

EXCLUDE_DIRS = {
    ".git", ".svn", ".hg",
    "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "build", "dist", "target", "out", "bin", "obj",
    ".venv", "venv", "env", ".tox",
    ".idea", ".vscode",
    "vivado_proj", ".Xil",  # Vivado 산출물
}


def detect_language(path: Path) -> str | None:
    """파일 경로에서 언어를 추론한다."""
    name = path.name
    suffix = path.suffix.lower()
    for lang, patterns in LANGUAGE_EXT.items():
        for p in patterns:
            if p.startswith("."):
                if suffix == p:
                    return lang
            else:
                if name == p or name.endswith(p):
                    return lang
    return None


def count_lines(path: Path) -> int:
    """파일의 라인 수를 센다. 바이너리는 0 반환."""
    try:
        with open(path, "rb") as f:
            return sum(1 for _ in f)
    except (OSError, PermissionError):
        return 0


def is_excluded(path: Path, root: Path) -> bool:
    """경로가 제외 대상인지 판단."""
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    return any(part in EXCLUDE_DIRS or part.startswith(".") for part in rel.parts)


def scan(root: Path) -> Dict:
    """루트 디렉토리를 스캔하고 통계를 수집한다."""
    stats: Dict[str, Dict[str, int]] = defaultdict(lambda: {"files": 0, "lines": 0})
    file_sizes: List[Tuple[int, str]] = []
    dir_counts: Dict[str, int] = defaultdict(int)

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if is_excluded(path, root):
            continue
        lang = detect_language(path)
        if lang is None:
            continue
        lines = count_lines(path)
        stats[lang]["files"] += 1
        stats[lang]["lines"] += lines
        file_sizes.append((lines, str(path.relative_to(root))))
        # 1단계 디렉토리만 카운트
        rel = path.relative_to(root)
        if len(rel.parts) > 1:
            dir_counts[rel.parts[0]] += 1
        else:
            dir_counts["<root>"] += 1

    file_sizes.sort(reverse=True)
    return {
        "stats": dict(stats),
        "top_files": file_sizes[:10],
        "dir_distribution": dict(dir_counts),
        "total_files": sum(s["files"] for s in stats.values()),
        "total_lines": sum(s["lines"] for s in stats.values()),
    }


def render_markdown(result: Dict, root: Path) -> str:
    """결과를 마크다운으로 렌더링한다."""
    lines = [f"# Repository Overview: `{root.name}`", ""]
    lines.append(f"- **루트**: `{root.resolve()}`")
    lines.append(f"- **전체 파일 수**: {result['total_files']:,}")
    lines.append(f"- **전체 라인 수**: {result['total_lines']:,}")
    lines.append("")

    lines.append("## 언어별 통계")
    lines.append("")
    lines.append("| 언어 | 파일 수 | 라인 수 | 비율 |")
    lines.append("|------|--------:|--------:|-----:|")
    total_lines = max(result["total_lines"], 1)
    sorted_langs = sorted(
        result["stats"].items(), key=lambda kv: kv[1]["lines"], reverse=True
    )
    for lang, s in sorted_langs:
        pct = s["lines"] / total_lines * 100
        lines.append(f"| {lang} | {s['files']:,} | {s['lines']:,} | {pct:.1f}% |")
    lines.append("")

    lines.append("## 가장 큰 파일 Top 10 (라인 수 기준)")
    lines.append("")
    lines.append("| 순위 | 라인 | 경로 |")
    lines.append("|----:|----:|------|")
    for i, (n, path) in enumerate(result["top_files"], 1):
        lines.append(f"| {i} | {n:,} | `{path}` |")
    lines.append("")

    lines.append("## 1단계 디렉토리 분포")
    lines.append("")
    lines.append("| 디렉토리 | 파일 수 |")
    lines.append("|---------|--------:|")
    for d, n in sorted(result["dir_distribution"].items(), key=lambda kv: -kv[1]):
        lines.append(f"| `{d}/` | {n:,} |")
    lines.append("")

    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Repository overview analyzer")
    parser.add_argument("path", type=Path, help="분석할 저장소 루트 경로")
    parser.add_argument("--output", "-o", type=Path, help="출력 파일 (기본: stdout)")
    parser.add_argument("--json", action="store_true", help="JSON 형식으로 출력")
    args = parser.parse_args()

    if not args.path.exists():
        print(f"Error: path not found: {args.path}", file=sys.stderr)
        return 1

    result = scan(args.path)

    if args.json:
        import json
        # tuple은 JSON 직렬화 불가 → 변환
        result["top_files"] = [
            {"lines": n, "path": p} for n, p in result["top_files"]
        ]
        text = json.dumps(result, indent=2, ensure_ascii=False)
    else:
        text = render_markdown(result, args.path)

    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"Written to {args.output}", file=sys.stderr)
    else:
        print(text)

    return 0


if __name__ == "__main__":
    sys.exit(main())
