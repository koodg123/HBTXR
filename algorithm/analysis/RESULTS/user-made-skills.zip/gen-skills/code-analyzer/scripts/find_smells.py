#!/usr/bin/env python3
"""안티패턴 / 코드 스멜 탐지 스크립트.

Python AST 기반으로 다음을 탐지:
- 너무 긴 함수 (> 50 LOC)
- 너무 깊은 중첩 (>= 4)
- mutable default arguments
- bare except
- TODO/FIXME/HACK 코멘트
- print 문 (logger 권장)
- 매직 넘버
- 큰 함수의 매개변수 수

C/C++/Verilog는 정규식 기반 휴리스틱으로 처리.

사용법:
    python find_smells.py <path> --lang python
    python find_smells.py <path> --lang verilog
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import List, NamedTuple

EXCLUDE_DIRS = {".git", "__pycache__", ".venv", "venv", "build", "dist",
                "node_modules", "vivado_proj", ".Xil"}


class Smell(NamedTuple):
    severity: str  # high/medium/low/info
    category: str
    file: str
    line: int
    message: str


# ---------------------------------------------------------------------------
# Python
# ---------------------------------------------------------------------------

class PythonSmellVisitor(ast.NodeVisitor):
    def __init__(self, file: str):
        self.file = file
        self.smells: List[Smell] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def _check_function(self, node) -> None:
        end = getattr(node, "end_lineno", node.lineno) or node.lineno
        loc = end - node.lineno + 1
        if loc > 50:
            self.smells.append(Smell(
                "medium" if loc < 100 else "high",
                "Maintainability",
                self.file, node.lineno,
                f"함수 `{node.name}`가 {loc}줄로 너무 길다 (>50). 분할 검토.",
            ))
        n_params = len(node.args.args) + len(node.args.kwonlyargs)
        if n_params >= 6:
            self.smells.append(Smell(
                "medium",
                "Maintainability",
                self.file, node.lineno,
                f"함수 `{node.name}`의 매개변수가 {n_params}개. 객체로 묶기 검토.",
            ))
        # Mutable default
        for default in node.args.defaults:
            if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                self.smells.append(Smell(
                    "high",
                    "Correctness",
                    self.file, node.lineno,
                    f"함수 `{node.name}`에 mutable default argument 사용. "
                    "함수 호출 간 상태가 공유됨.",
                ))
                break

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        if node.type is None:
            self.smells.append(Smell(
                "medium",
                "Correctness",
                self.file, node.lineno,
                "Bare `except:` 사용. 구체적 예외 타입을 명시할 것.",
            ))
        elif (isinstance(node.type, ast.Name) and node.type.id == "Exception"
              and not node.body
              or len(node.body) == 1 and isinstance(node.body[0], ast.Pass)):
            self.smells.append(Smell(
                "high",
                "Correctness",
                self.file, node.lineno,
                "Silent exception swallowing (`except: pass` 등). 로깅 또는 재발생 권장.",
            ))
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        # print 사용 (모듈 최상위 또는 함수 내부 모두)
        if isinstance(node.func, ast.Name) and node.func.id == "print":
            self.smells.append(Smell(
                "low",
                "Maintainability",
                self.file, node.lineno,
                "`print` 사용 — production 코드는 `logging` 모듈 권장.",
            ))
        # eval / exec
        if isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec"}:
            self.smells.append(Smell(
                "high",
                "Security",
                self.file, node.lineno,
                f"`{node.func.id}` 사용 — 임의 코드 실행 위험. 대안 검토 필수.",
            ))
        self.generic_visit(node)


def check_max_nesting(tree: ast.AST, file: str) -> List[Smell]:
    """함수별 최대 중첩 깊이 체크."""
    NESTING = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try, ast.With, ast.AsyncWith)
    smells: List[Smell] = []

    def walk(node: ast.AST, depth: int) -> int:
        m = depth
        for child in ast.iter_child_nodes(node):
            d = depth + (1 if isinstance(child, NESTING) else 0)
            m = max(m, walk(child, d))
        return m

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            d = walk(node, 0)
            if d >= 4:
                smells.append(Smell(
                    "medium" if d == 4 else "high",
                    "Maintainability",
                    file, node.lineno,
                    f"함수 `{node.name}`의 중첩 깊이 {d}. early return 또는 함수 추출 검토.",
                ))
    return smells


TODO_RE = re.compile(r'#\s*(TODO|FIXME|HACK|XXX)\b[: ]*(.*)$')


def check_todos(text: str, file: str) -> List[Smell]:
    smells = []
    for i, line in enumerate(text.splitlines(), 1):
        m = TODO_RE.search(line)
        if m:
            tag = m.group(1)
            msg = m.group(2).strip()
            severity = "high" if tag in {"FIXME", "HACK", "XXX"} else "info"
            smells.append(Smell(
                severity, "TechnicalDebt", file, i,
                f"{tag}: {msg or '(설명 없음)'}",
            ))
    return smells


def analyze_python(root: Path) -> List[Smell]:
    smells: List[Smell] = []
    for f in root.rglob("*.py"):
        if any(part in EXCLUDE_DIRS for part in f.relative_to(root).parts):
            continue
        try:
            text = f.read_text(encoding="utf-8")
            tree = ast.parse(text, filename=str(f))
        except (SyntaxError, UnicodeDecodeError):
            continue
        rel = str(f.relative_to(root))
        v = PythonSmellVisitor(rel)
        v.visit(tree)
        smells.extend(v.smells)
        smells.extend(check_max_nesting(tree, rel))
        smells.extend(check_todos(text, rel))
    return smells


# ---------------------------------------------------------------------------
# C / C++
# ---------------------------------------------------------------------------

def analyze_c_cpp(root: Path, exts: List[str]) -> List[Smell]:
    smells: List[Smell] = []
    files = []
    for ext in exts:
        files.extend(root.rglob(f"*{ext}"))
    for f in files:
        if any(part in EXCLUDE_DIRS for part in f.relative_to(root).parts):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rel = str(f.relative_to(root))

        for i, line in enumerate(text.splitlines(), 1):
            stripped = line.strip()
            # TODO/FIXME
            m = re.search(r'(?://|/\*)\s*(TODO|FIXME|HACK|XXX)\b[: ]*(.*)', line)
            if m:
                tag = m.group(1)
                severity = "high" if tag in {"FIXME", "HACK", "XXX"} else "info"
                smells.append(Smell(severity, "TechnicalDebt", rel, i,
                                    f"{tag}: {m.group(2).strip()[:80]}"))
            # gets() 사용
            if re.search(r'\bgets\s*\(', line):
                smells.append(Smell("high", "Security", rel, i,
                                    "`gets()` 사용 — buffer overflow 위험. `fgets()` 권장."))
            # strcpy / strcat / sprintf
            if re.search(r'\b(strcpy|strcat|sprintf)\s*\(', line):
                smells.append(Smell("medium", "Security", rel, i,
                                    "안전하지 않은 문자열 함수. `strncpy`/`snprintf` 권장."))
            # malloc 결과 미체크 (간단 휴리스틱)
            if re.search(r'\bmalloc\s*\(', line) and "if" not in stripped[:30]:
                # 너무 false positive가 많음 → info 수준
                pass
            # goto (라이브러리 코드에선 정상이지만 일반적으론 주의)
            if re.match(r'^\s*goto\s+\w+', line):
                smells.append(Smell("low", "Maintainability", rel, i,
                                    "`goto` 사용. 정당한 이유가 있는지 검토."))
    return smells


# ---------------------------------------------------------------------------
# Verilog / SV
# ---------------------------------------------------------------------------

def analyze_verilog(root: Path) -> List[Smell]:
    smells: List[Smell] = []
    files = (list(root.rglob("*.v")) + list(root.rglob("*.sv"))
             + list(root.rglob("*.vh")) + list(root.rglob("*.svh")))
    for f in files:
        if any(part in EXCLUDE_DIRS for part in f.relative_to(root).parts):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rel = str(f.relative_to(root))
        for i, line in enumerate(text.splitlines(), 1):
            # 합성 비호환 가능성 신호
            if re.search(r'^\s*initial\b', line) and "tb" not in rel.lower() \
                    and "_tb" not in rel:
                smells.append(Smell("medium", "Synthesizability", rel, i,
                                    "Non-testbench 파일에 `initial` 블록 — "
                                    "합성 도구별로 처리 다름."))
            # blocking assignment in always_ff (단순 휴리스틱)
            if re.search(r'^\s*always_ff\s*@', line):
                # 이후 begin-end 블록 내 = 사용 검사는 단순화
                pass
            # always @* 대신 always_comb 권장 (SV만)
            if rel.endswith(".sv") and re.search(r'^\s*always\s*@\s*\*', line):
                smells.append(Smell("low", "Maintainability", rel, i,
                                    "`always @*` → `always_comb` 권장 (SV)."))
            # Magic literal hex
            # TODO/FIXME
            m = re.search(r'(?://|/\*)\s*(TODO|FIXME|HACK|XXX)\b[: ]*(.*)', line)
            if m:
                tag = m.group(1)
                severity = "high" if tag in {"FIXME", "HACK", "XXX"} else "info"
                smells.append(Smell(severity, "TechnicalDebt", rel, i,
                                    f"{tag}: {m.group(2).strip()[:80]}"))
    return smells


# ---------------------------------------------------------------------------
# 출력
# ---------------------------------------------------------------------------

def render(smells: List[Smell], lang: str) -> str:
    if not smells:
        return f"# Code Smell Report ({lang})\n\n발견된 이슈가 없습니다."

    by_sev = defaultdict(list)
    for s in smells:
        by_sev[s.severity].append(s)

    out = [f"# Code Smell Report ({lang})", ""]
    out.append(f"총 {len(smells)}개 이슈 발견.")
    out.append("")
    out.append("| 심각도 | 개수 |")
    out.append("|--------|----:|")
    for sev in ["high", "medium", "low", "info"]:
        if by_sev[sev]:
            out.append(f"| {sev} | {len(by_sev[sev])} |")
    out.append("")

    for sev in ["high", "medium", "low", "info"]:
        items = by_sev[sev]
        if not items:
            continue
        out.append(f"## {sev.upper()} ({len(items)}개)")
        out.append("")
        out.append("| 파일:라인 | 카테고리 | 메시지 |")
        out.append("|-----------|---------|--------|")
        for s in sorted(items, key=lambda x: (x.file, x.line)):
            out.append(f"| `{s.file}:{s.line}` | {s.category} | {s.message} |")
        out.append("")
    return "\n".join(out)


def main() -> int:
    p = argparse.ArgumentParser(description="Code smell detector")
    p.add_argument("path", type=Path)
    p.add_argument("--lang", required=True,
                   choices=["python", "c", "cpp", "verilog", "sv"])
    p.add_argument("--output", "-o", type=Path)
    args = p.parse_args()

    root = args.path.resolve()
    if not root.exists():
        print(f"Error: {root}", file=sys.stderr)
        return 1

    if args.lang == "python":
        smells = analyze_python(root)
    elif args.lang == "c":
        smells = analyze_c_cpp(root, [".c", ".h"])
    elif args.lang == "cpp":
        smells = analyze_c_cpp(root, [".cpp", ".cc", ".cxx", ".hpp", ".h", ".hxx"])
    elif args.lang in ("verilog", "sv"):
        smells = analyze_verilog(root)
    else:
        print(f"Unsupported: {args.lang}", file=sys.stderr)
        return 1

    text = render(smells, args.lang)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"Written to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
