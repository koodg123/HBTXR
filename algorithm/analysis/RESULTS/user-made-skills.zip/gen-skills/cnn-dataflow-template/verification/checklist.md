# Verification Checklist

- [ ] Skill phase `P1` and domain `Vision Applications` are stated.
- [ ] Parent skill `vision-video-accelerator-factory` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] CNN dataflow template is present and traceable.
- [ ] Reuse strategy is present and traceable.
- [ ] Memory bandwidth estimate is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] Residual risks and missing inputs are listed.
