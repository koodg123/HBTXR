# IDEA-Gen Context

Phase: P1
Domain: Vision Applications
Parent skill: `vision-video-accelerator-factory`

## Why This Skill Exists

CNNs remain the baseline hardware template for many vision and video accelerators.

## Worker Capability

Design CNN dataflow templates for convolution, depthwise convolution, pooling, activation, and feature reuse.

## Expected Outputs

- CNN dataflow template
- Reuse strategy
- Memory bandwidth estimate

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the cluster and roadmap notes for `Vision Applications`.
