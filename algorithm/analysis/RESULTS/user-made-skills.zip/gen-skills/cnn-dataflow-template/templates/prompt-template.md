# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P1

Domain: Vision Applications

Parent skill: vision-video-accelerator-factory

Target model, algorithm, hardware, or dataset:

Constraints:

Assumptions:

Required artifact:

Verification evidence:

Risks and missing inputs:
