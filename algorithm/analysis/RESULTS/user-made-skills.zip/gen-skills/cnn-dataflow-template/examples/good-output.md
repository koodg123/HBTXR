# Good Output

A strong output for `cnn-dataflow-template` includes a concise objective, source mapping, explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: CNN dataflow template; Reuse strategy; Memory bandwidth estimate.
