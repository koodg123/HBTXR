# Common Mistakes

- Producing general advice without a prompt pack or artifact.
- Mixing facts, assumptions, and hypotheses.
- Omitting the verification evidence needed for signoff.
- Creating a plan that requires the next Worker to make product or architecture decisions.
- Forgetting to bind existing skills before inventing new procedures.
