# Production Playbook

## Purpose

This playbook supports `accelerator-cost-model` for accelerator cost modeling. It is written for agents that need a
repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what the user wants changed, analyzed, designed, or generated.
- Inputs: papers, code, diagrams, specs, constraints, datasets, reports, or logs.
- Output format: document, task card, DAG, pseudocode, hardware plan, compiler plan, model, or test plan.
- Success metrics: correctness, traceability, latency, throughput, area, energy, novelty, or acceptance tests.
- Constraints: time, tool availability, target platform, non-goals, compatibility, and validation limits.

## Decision Flow

- Capture source framework, graph format, shapes, operators, target backend, and runtime contract.
- Identify the exact compiler or simulator boundary: import, legalization, scheduling, codegen, runtime, or modeling.
- Preserve a minimal reference graph or workload before proposing transformations.
- Plan optimization, lowering, simulation, or cost modeling with measurable correctness and performance checks.
- Return artifacts that connect graph behavior, backend constraints, and validation metrics.

## Tradeoff Questions

- What decision would be costly to reverse later?
- Which assumption has the highest chance of invalidating the artifact?
- What is the smallest artifact that can be validated now?
- Which existing skill should be bound to this task before execution?

## Output Standard

The output should contain the artifact, evidence, assumptions, risks, and next validation step. Keep
the artifact structured enough for another Worker to use directly.
