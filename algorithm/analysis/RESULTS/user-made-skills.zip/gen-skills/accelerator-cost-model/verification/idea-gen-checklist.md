# IDEA-Gen Checklist

- [ ] Read `references/idea-gen-context.md`.
- [ ] Apply this skill to the relevant IDEA-Gen cluster.
- [ ] Preserve source-linked assumptions from the analysis.
- [ ] Produce a concrete artifact and validation evidence.
- [ ] Explain how this skill complements any newly installed IDEA-Gen skill.
