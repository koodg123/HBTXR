---
name: accelerator-cost-model
description: "Create cost models for accelerator latency, throughput, memory traffic, bandwidth, area, energy, utilization, and bottleneck analysis. Use when Codex needs to compare hardware mappings, dataflows, schedules, or DNN workloads quantitatively before implementation."
---

# Accelerator Cost Model

## Overview

Use this skill for accelerator cost modeling. Build transparent estimates that expose assumptions and rank bottlenecks.

This skill complements dnn-accelerator-expert, hardware-simulator-timeloop-accelergy and should produce reusable artifacts rather than only
free-form advice.

## Prompt-First Rule

Before solving the task, write a compact prompt pack that names the objective, inputs, constraints,
success metrics, and known unknowns. Use `templates/prompt-template.md` or
`scripts/build_prompt.py` when a reusable prompt artifact would help.

## Start Every Task With

1. Restate the user goal as a measurable engineering or research objective.
2. List the source artifacts, constraints, and target deliverables.
3. Identify required skills, roles, and verification evidence.
4. Separate known facts, assumptions, and hypotheses.
5. Decide which output artifact should be produced first.

## Workflow

1. Capture source framework, graph format, shapes, operators, target backend, and runtime contract.
2. Identify the exact compiler or simulator boundary: import, legalization, scheduling, codegen, runtime, or modeling.
3. Preserve a minimal reference graph or workload before proposing transformations.
4. Plan optimization, lowering, simulation, or cost modeling with measurable correctness and performance checks.
5. Return artifacts that connect graph behavior, backend constraints, and validation metrics.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact for accelerator cost modeling with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments.

## Supporting Files

- `references/production-playbook.md` for detailed workflow guidance and decision points.
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` for reusable prompt pack structure.
- `templates/prompt-bundles/intake.md` for intake and handoff prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Numerical correctness is separated from performance and compatibility.
- Shape and operator constraints are explicit.
- Backend assumptions are named before scheduling or cost claims.
- Simulator or compiler outputs can be compared to a reference model.
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result would depend on external measurements, target hardware, private data, or unavailable tools.
- A recommendation would lock the user into a brittle workflow without validation evidence.

## IDEA-Gen Context

For tasks derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, read
`references/idea-gen-context.md` before planning. Use `verification/idea-gen-checklist.md`
to preserve the IDEA-Gen assumptions, target metrics, and validation evidence.

