# IDEA-Gen Context

Phase: P0
Domain: LLM on NPU
Parent skill: `llm-on-npu-accelerator`

## Why This Skill Exists

Attention is the critical algorithmic kernel for LLM on NPU and needs dedicated mapping logic.

## Worker Capability

Map attention kernels to NPU/PIM resources with tiling, softmax handling, memory traffic, and precision assumptions.

## Expected Outputs

- Attention mapping
- Tiling plan
- Bandwidth analysis

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the cluster and roadmap notes for `LLM on NPU`.
