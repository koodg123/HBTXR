# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: LLM on NPU

Parent skill: llm-on-npu-accelerator

Target model, algorithm, hardware, or dataset:

Constraints:

Assumptions:

Required artifact:

Verification evidence:

Risks and missing inputs:
