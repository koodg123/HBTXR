# Good Output

A strong output for `attention-kernel-mapper` includes a concise objective, source mapping, explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: Attention mapping; Tiling plan; Bandwidth analysis.
