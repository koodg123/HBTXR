# Verification Checklist

- [ ] Skill phase `P0` and domain `LLM on NPU` are stated.
- [ ] Parent skill `llm-on-npu-accelerator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] Attention mapping is present and traceable.
- [ ] Tiling plan is present and traceable.
- [ ] Bandwidth analysis is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] Residual risks and missing inputs are listed.
