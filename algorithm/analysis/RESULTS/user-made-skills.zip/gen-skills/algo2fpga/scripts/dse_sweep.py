#!/usr/bin/env python3
"""Generate the DSE design-point matrix with an analytical resource model.
Replace estimate_resources() with real HLS/synthesis numbers once available.
Set TOTAL_OPS to the algorithm's op count. Output: dse_results.json."""
import itertools, json

DSE_SPACE = {
    "II":       [1, 2, 4],
    "unroll":   [1, 2, 4, 8],
    "bitwidth": [8, 16, 32],
}
TOTAL_OPS = 1024  # algorithm-specific; override before running

def estimate_resources(II, unroll, bitwidth):
    base_dsp = max(1, unroll // II)
    base_lut = unroll * bitwidth * 2
    base_ff  = unroll * bitwidth
    latency  = TOTAL_OPS // unroll + II
    throughput = 1.0 / II
    return {"DSP": base_dsp, "LUT": base_lut, "FF": base_ff,
            "Latency": latency, "II": II, "Throughput": throughput}

def main():
    points = []
    for II, unroll, bw in itertools.product(*DSE_SPACE.values()):
        pt = {"II": II, "unroll": unroll, "bitwidth": bw}
        pt.update(estimate_resources(II, unroll, bw))
        points.append(pt)
    with open("dse_results.json", "w") as f:
        json.dump(points, f, indent=2)
    print(f"Generated {len(points)} design points -> dse_results.json")

if __name__ == "__main__":
    main()
