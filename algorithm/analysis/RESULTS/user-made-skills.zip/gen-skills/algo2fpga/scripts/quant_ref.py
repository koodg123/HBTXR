#!/usr/bin/env python3
"""Fixed-point reference model for HLS/RTL bit-exact checking."""
import numpy as np

def to_fixed(x, W=16, F=8):
    """Quantize float -> W.F fixed-point integer representation."""
    scale = 2 ** F
    return np.clip(np.round(x * scale), -(2 ** (W - 1)), 2 ** (W - 1) - 1).astype(np.int32)

def from_fixed(x_int, F=8):
    return x_int / (2 ** F)

def quantize_with_scale(weights, bits=8):
    """Per-tensor quantization with dynamic range scaling (fixes low-bit accuracy)."""
    w_max = np.max(np.abs(weights))
    scale = (2 ** (bits - 1) - 1) / w_max
    w_q = np.clip(np.round(weights * scale), -(2 ** (bits - 1)), 2 ** (bits - 1) - 1)
    return w_q.astype(np.int8), scale

if __name__ == "__main__":
    a = np.array([0.5, -1.25, 3.1415, 7.9])
    q = to_fixed(a); print("to_fixed:", q, "-> from_fixed:", from_fixed(q))
