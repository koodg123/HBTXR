#!/usr/bin/env python3
"""Compute Pareto-optimal design points and plot the frontier.
Input: dse_results.json (from dse_sweep.py). Output: dse_pareto.png + stdout."""
import json
import matplotlib.pyplot as plt

def is_pareto_dominated(point, candidates, objectives):
    for c in candidates:
        if c is point:
            continue
        dominated = all(
            (c[o] <= point[o]) if d == "min" else (c[o] >= point[o])
            for o, d in objectives.items()
        )
        if dominated:
            return True
    return False

def pareto_frontier(points, objectives):
    return [p for p in points if not is_pareto_dominated(p, points, objectives)]

def main():
    with open("dse_results.json") as f:
        points = json.load(f)
    objectives = {"LUT": "min", "Latency": "min"}  # add "Throughput": "max" if desired
    pareto = pareto_frontier(points, objectives)

    plt.figure(figsize=(10, 6))
    plt.scatter([p["LUT"] for p in points], [p["Latency"] for p in points],
                c="lightblue", label="All design points", zorder=2)
    p_luts = [p["LUT"] for p in pareto]; p_lat = [p["Latency"] for p in pareto]
    plt.scatter(p_luts, p_lat, c="red", s=100, zorder=3, label="Pareto frontier")
    paired = sorted(zip(p_luts, p_lat))
    plt.step([x for x, _ in paired], [y for _, y in paired], where="post",
             color="red", linewidth=1.5)
    plt.xlabel("LUT Usage"); plt.ylabel("Latency (cycles)")
    plt.title("Design Space Exploration — Pareto Frontier")
    plt.legend(); plt.grid(True, alpha=0.3); plt.tight_layout()
    plt.savefig("dse_pareto.png", dpi=150)
    print(f"Pareto-optimal points: {len(pareto)} / {len(points)} -> dse_pareto.png")

if __name__ == "__main__":
    main()
