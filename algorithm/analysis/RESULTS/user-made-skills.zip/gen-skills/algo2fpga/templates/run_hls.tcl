# Vitis HLS synthesis + cosim + export. Run: vitis_hls -f run_hls.tcl
open_project hls_proj
set_top [function_name]
add_files [function_name]_hls.cpp
add_files -tb tb_[function_name].cpp
open_solution "solution1"
set_part {xcu250-figd2104-2L-e}     ;# change to target FPGA
create_clock -period 5 -name default ;# 200 MHz
csynth_design
cosim_design
export_design -rtl verilog -format ip_catalog
close_project
