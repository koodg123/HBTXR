# Vitis HLS multi-solution DSE sweep (II x UNROLL). Run: vitis_hls -f run_dse.tcl
open_project dse_proj
set_top [function_name]
add_files [function_name]_hls.cpp
foreach II_val {1 2 4} {
  foreach unroll_val {1 2 4 8} {
    set sol_name "sol_II${II_val}_U${unroll_val}"
    open_solution $sol_name
    set_part {xcu250-figd2104-2L-e}
    create_clock -period 5 -name default
    set_directive_pipeline -II $II_val "[function_name]/OUTER_LOOP"
    set_directive_unroll -factor $unroll_val "[function_name]/INNER_LOOP"
    csynth_design
  }
}
close_project
# Parse: grep -r "LUT\|DSP\|Latency\|II" dse_proj/*/syn/report/*.rpt | python3 parse_hls_reports.py > dse_results.csv
