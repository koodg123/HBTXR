# Vivado timing/IO constraints
create_clock -period 5.000 -name sys_clk [get_ports clk]
set_input_delay  -clock sys_clk 1.0 [get_ports {data_in valid_in}]
set_output_delay -clock sys_clk 1.0 [get_ports {data_out valid_out}]
# set_false_path -from [get_ports rst_n]
