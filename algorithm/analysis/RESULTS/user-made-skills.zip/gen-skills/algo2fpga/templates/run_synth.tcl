# Vivado out-of-context synthesis + reports. Run: vivado -mode batch -source run_synth.tcl
create_project proj ./vivado_proj -part xcu250-figd2104-2L-e
add_files [module_name].sv
set_property top [module_name] [current_fileset]
synth_design -top [module_name] -part xcu250-figd2104-2L-e
report_utilization -file utilization.rpt
report_timing_summary -file timing.rpt
close_project
