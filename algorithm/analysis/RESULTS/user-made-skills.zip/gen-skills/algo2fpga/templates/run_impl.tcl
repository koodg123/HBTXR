# Vivado full implementation + bitstream. Run: vivado -mode batch -source run_impl.tcl
open_project proj ./vivado_proj -part xcu250-figd2104-2L-e
add_files [module_name].sv
add_files constraints.xdc
set_property top [module_name] [current_fileset]
synth_design -top [module_name]
opt_design
place_design
phys_opt_design
route_design
report_utilization    -file impl_utilization.rpt
report_timing_summary -file impl_timing.rpt
report_power          -file power.rpt
write_bitstream -force [module_name].bit
close_project
