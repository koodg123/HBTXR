# algo2fpga — Verification Checklist

Gate each phase before reporting "done". Mark ✅ / ⚠️ / ❌.

## Phase 1 — Analysis
- [ ] Algorithm Profile table produced (I/O shapes, FLOP, memory pattern, parallelism, fixed-point feasibility).
- [ ] Conversion warnings listed (dynamic shapes, recursion, RNG, float64).

## Phase 2/3 — Conversion
- [ ] Generated `.cpp`+`.h` (HLS) or `.sv`+`_tb.sv`+`quant_ref.py` (RTL).
- [ ] Pragma / directive rationale comment block present.
- [ ] Data types mapped (no bare `double` unless justified).

## Phase 4 — Simulation
- [ ] Co-sim runs; accuracy report (pass count, max abs/rel error).
- [ ] Latency + II reported. Python-vs-HW speedup estimate.

## Phase 5 — Synthesis
- [ ] Resource report: LUT/FF/DSP/BRAM/URAM absolute + % of device.
- [ ] Timing: target vs achieved, WNS, MET/VIOLATED.
- [ ] Missing tool → script emitted as template with `[TODO: run with <tool>]`.

## Phase 6 — Implementation
- [ ] Post-route utilization + timing + power.
- [ ] Bitstream produced (or template if tool absent).

## Phase 8 — DSE
- [ ] Design space defined; hard constraints recorded.
- [ ] Infeasible points pruned; Pareto set identified; recommended config + rationale.

## Phase 9 — Feedback
- [ ] Each violation classified to a Python root cause.
- [ ] Before/After Python refactor with HW impact.
- [ ] Next-iteration projection.

## Numbers discipline
- [ ] Any un-synthesized metric marked "확인 필요 / [TODO run tool]" — never fabricated.
