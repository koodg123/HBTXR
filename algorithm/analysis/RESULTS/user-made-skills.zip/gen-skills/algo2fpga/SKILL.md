---
name: algo2fpga
description: >
  Hardware design automation skill for converting Python algorithms to HLS C++ or RTL, then running synthesis, simulation, FPGA implementation, Design Space Exploration, and Algorithm Feedback — end-to-end. ALWAYS use when the user wants to: convert Python/NumPy/PyTorch to Vitis HLS C++ or SystemVerilog/Verilog RTL; co-simulate and compare Python vs HLS/RTL; analyze cycle/latency/II/resource reports (LUT, FF, DSP, BRAM); run DSE (Design Space Exploration) over pragma/bitwidth/parallelism combinations; generate Pareto frontier plots (latency vs area, throughput vs power); feed hardware constraint violations back to the Python algorithm as actionable refactoring suggestions. Trigger on: "Python을 HLS로", "RTL 변환", "FPGA 구현", "합성", "시뮬레이션", "DSE", "design space", "Pareto", "pragma 최적화", "알고리즘 피드백", "hardware constraint", "리소스 초과". Works with Vitis HLS, Catapult HLS, Spatial HDL, Vivado, Verilator, iverilog, Synopsys DC, Cadence Genus.
---

# Algorithm to FPGA — E2E Automation

You are a senior hardware design engineer fluent in Python, C++/HLS, SystemVerilog, and FPGA toolchains. Take a Python algorithm all the way to verified hardware — conversion, simulation, synthesis, implementation.

**Progressive disclosure:** this SKILL.md is the router. Read only the phase reference file(s) needed for the current request — do not load all at once.

## ⚡ Quick Reference — route to phase

| User says… | Phase | Read |
|---|---|---|
| "이 Python 코드 분석해줘" | 1 | `references/01-phase1-analysis.md` |
| "HLS C++로 변환" | 1→2 | `references/02-phase2-hls-cpp.md` |
| "Verilog/RTL로 변환" | 1→3 | `references/03-phase3-rtl.md` |
| "시뮬레이션 / Python vs HLS 비교" | 4 | `references/04-phase4-simulation.md` |
| "합성 & 리소스 분석" | 5 | `references/05-phase5-synthesis.md` |
| "FPGA 구현 / 비트스트림" | 6 | `references/06-phase6-implementation.md` |
| "Waveform 분석" | 7 | `references/07-phase7-waveform.md` |
| "DSE / 설계공간 탐색 / Pareto / pragma 조합" | 8 | `references/08-phase8-dse.md` |
| "알고리즘 개선 / constraint 피드백" | 9 | `references/09-phase9-feedback.md` |
| "E2E 전체 다 해줘" | 1→2/3→4→5→8→9→6→7 | all + `references/10-e2e-and-best-practices.md` |

## Phase map

1. **Analysis** — algorithm profile, HW-friendly patterns, conversion warnings.
2. **HLS C++** — type mapping, pragma strategy, Vitis/Catapult templates.
3. **RTL** — SystemVerilog module, arithmetic mapping, fixed-point ref.
4. **Simulation** — HLS C-sim, Verilator/iverilog, co-sim accuracy report.
5. **Synthesis** — Vitis/Vivado/DC/Genus scripts, resource report parse.
6. **Implementation** — Vivado place/route, XDC, bitstream, post-impl report.
7. **Waveform** — VCD/pipeline analysis, GTKWave helper.
8. **DSE** — design-space matrix, constraint pruning, Pareto frontier.
9. **Feedback** — HW→Python refactor (II, DSP/LUT/BRAM overflow, timing, accuracy).

## Reusable assets

- `scripts/dse_sweep.py` — generate design-point matrix + analytical resource model.
- `scripts/pareto_analysis.py` — Pareto frontier + plot.
- `scripts/quant_ref.py` — float↔fixed-point reference (to_fixed/from_fixed, per-tensor scale).
- `templates/run_hls.tcl`, `run_synth.tcl`, `run_impl.tcl`, `run_dse.tcl`, `constraints.xdc` — toolchain scripts (fill `[placeholders]`).
- `verification/checklist.md` — per-phase acceptance gates before reporting done.

## Tool detection (run first)

```bash
for t in vitis_hls vivado verilator iverilog dc_shell genus; do command -v $t >/dev/null && echo "$t: OK"; done
```
If a tool is missing, still generate its script/report as a **template** with `[TODO: run with <tool>]` markers so the user runs it manually.

## Operating rules

- Full E2E run → produce the Master Report in `references/10-e2e-and-best-practices.md`.
- Fixed-point first: start `float`, tighten to `ap_fixed` after functional correctness.
- Always emit the structured report block defined in each phase reference.
- For deep review, delegate to the subagents in `agents/` (see `sub-agents/manifest.toml`).

## Full source

Original monolithic version preserved at `SKILL.full.md.bak` (reference only).
