## Phase 4: Simulation & Co-Simulation

### 4.1 Vitis HLS C-Simulation

Generate a testbench that runs both Python reference and HLS in the same check:

```cpp
// File: tb_[function_name].cpp
#include "[function_name]_hls.h"
#include <cmath>
#include <cstdio>

int main() {
    data_t input[INPUT_SIZE], output_hls[OUTPUT_SIZE];
    float  output_ref[OUTPUT_SIZE];

    // Load test vectors (generated from Python)
    // ... (read from file or hardcode)

    // Run HLS
    [function_name](input, output_hls, INPUT_SIZE);

    // Compare
    int errors = 0;
    float max_err = 0.0f;
    for (int i = 0; i < OUTPUT_SIZE; i++) {
        float diff = fabs((float)output_hls[i] - output_ref[i]);
        if (diff > 1e-3f) errors++;
        if (diff > max_err) max_err = diff;
    }

    printf("=== Co-Sim Report ===\n");
    printf("Errors: %d / %d\n", errors, OUTPUT_SIZE);
    printf("Max absolute error: %.6f\n", max_err);
    return errors > 0 ? 1 : 0;
}
```

### 4.2 RTL Simulation (Verilator)

Generate a Verilator harness:

```cpp
// File: sim_main.cpp
#include "V[module_name].h"
#include "verilated.h"
#include "verilated_vcd_c.h"

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    V[module_name]* dut = new V[module_name];

    VerilatedVcdC* tfp = new VerilatedVcdC;
    Verilated::traceEverOn(true);
    dut->trace(tfp, 99);
    tfp->open("waveform.vcd");

    // Reset
    dut->rst_n = 0; dut->clk = 0;
    for (int i = 0; i < 5; i++) {
        dut->clk ^= 1; dut->eval(); tfp->dump(i*5);
    }
    dut->rst_n = 1;

    // Apply stimuli and check outputs
    // ... (loop over test vectors)

    tfp->close();
    delete dut;
    printf("Simulation complete. Waveform: waveform.vcd\n");
    return 0;
}
```

### 4.3 iverilog / ModelSim Run Script

```bash
# iverilog
iverilog -g2012 -o sim.vvp [module_name].sv [module_name]_tb.sv && vvp sim.vvp

# ModelSim / Questa
vlog -sv [module_name].sv [module_name]_tb.sv
vsim -c work.[module_name]_tb -do "run -all; quit"
```

### 4.4 Co-Simulation Report Format

After simulation, always generate this structured report:

```
=== Co-Simulation Report ===
Date: [timestamp]
Design: [module/function name]
Tool: [Verilator 5.x / iverilog / Vitis HLS C-sim]

--- Functional Accuracy ---
Test vectors:     [N]
Pass:             [N] (100.0%)
Fail:             [0]
Max abs error:    [X.Xe-X]
Max rel error:    [X.Xe-X] %

--- Timing (HLS estimate) ---
Latency:          [N] cycles  ([X.X ns @ YY MHz])
Initiation Interval (II): [N] cycles
Pipeline depth:   [N] stages

--- Performance vs. Python ---
Python exec time:   [X.X ms]
HLS latency equiv:  [X.X µs @ YY MHz]
Speedup estimate:   [Xx]
```

---

