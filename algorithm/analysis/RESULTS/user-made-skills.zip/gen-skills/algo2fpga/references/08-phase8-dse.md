## Phase 8: Design Space Exploration (DSE)

DSE systematically sweeps the hardware design parameter space to find **Pareto-optimal configurations** — the best tradeoff between throughput, latency, area, and power. Run DSE after Phase 5 (you have at least one baseline synthesis result), or analytically before synthesis to decide which configuration to synthesize.

### 8.1 Define the Design Space

First, establish the axes to explore. The standard dimensions for HLS/RTL designs:

| Dimension | Candidates | Impact |
|-----------|-----------|--------|
| `II` (Initiation Interval) | 1, 2, 4, 8 | Throughput ↕, DSP/LUT ↕ |
| `UNROLL factor` | 1, 2, 4, 8, full | Latency ↓, Area ↑ |
| `ARRAY_PARTITION` | none, cyclic-2, cyclic-4, complete | BW ↑, BRAM/FF ↑ |
| Fixed-point width `<W,I>` | `<8,4>`, `<16,8>`, `<32,16>` | Area ↓↑, Accuracy ↕ |
| Clock frequency | 100, 200, 300 MHz | Timing closure risk |
| Architecture variant | stream, memory-mapped, dataflow | Latency/area tradeoff |

Ask the user which dimensions to sweep, or default to: **II × UNROLL × bitwidth**.

### 8.2 Design Point Matrix

Generate the full combination matrix and annotate each point analytically:

```python
# File: dse_sweep.py
import itertools, json

DSE_SPACE = {
    "II":           [1, 2, 4],
    "unroll":       [1, 2, 4, 8],
    "bitwidth":     [8, 16, 32],
}

def estimate_resources(II, unroll, bitwidth):
    """
    Analytical resource model — replace with actual HLS/synthesis numbers
    when available. Derived from typical Vitis HLS scaling rules.
    """
    base_dsp  = max(1, unroll // II)
    base_lut  = unroll * bitwidth * 2
    base_ff   = unroll * bitwidth
    latency   = TOTAL_OPS // unroll + II   # TOTAL_OPS = algorithm-specific
    throughput = 1.0 / II                  # outputs per cycle
    return {
        "DSP":        base_dsp,
        "LUT":        base_lut,
        "FF":         base_ff,
        "Latency":    latency,
        "II":         II,
        "Throughput": throughput,
    }

points = []
for II, unroll, bw in itertools.product(*DSE_SPACE.values()):
    pt = {"II": II, "unroll": unroll, "bitwidth": bw}
    pt.update(estimate_resources(II, unroll, bw))
    points.append(pt)

with open("dse_results.json", "w") as f:
    json.dump(points, f, indent=2)
print(f"Generated {len(points)} design points")
```

### 8.3 Hardware Constraints

Before filtering, record the user's hard constraints:

```
=== Hardware Constraints ===
Target FPGA / tech node:  [xcu250 / 7nm ...]
Max LUT budget:           [N] ([X%] of device)
Max DSP budget:           [N] ([X%] of device)
Max BRAM budget:          [N] ([X%] of device)
Max power budget:         [X.X W]
Frequency target:         [Y] MHz
Latency constraint:       ≤ [N] cycles  (or "unconstrained")
Throughput target:        ≥ [X] GOPs    (or "unconstrained")
Accuracy floor:           SNR ≥ [X] dB  (for fixed-point sweep)
```

Any design point violating a hard constraint is **pruned** from the Pareto set.

### 8.4 Pareto Frontier Analysis

Identify Pareto-optimal points (no other point is better on all objectives simultaneously):

```python
# File: pareto_analysis.py
import json
import matplotlib.pyplot as plt
import numpy as np

def is_pareto_dominated(point, candidates, objectives):
    """Return True if `point` is dominated by any candidate."""
    for c in candidates:
        if c is point: continue
        # c dominates point if c is at least as good on all objectives
        # and strictly better on at least one
        dominated = all(
            c[obj] <= point[obj] if direction == "min" else c[obj] >= point[obj]
            for obj, direction in objectives.items()
        )
        if dominated: return True
    return False

def pareto_frontier(points, objectives):
    return [p for p in points if not is_pareto_dominated(p, points, objectives)]

# Load DSE results
with open("dse_results.json") as f:
    points = json.load(f)

# Define optimization objectives
objectives = {
    "LUT":      "min",
    "Latency":  "min",
    # "Throughput": "max",  # uncomment to add throughput axis
}

pareto = pareto_frontier(points, objectives)

# Plot Pareto frontier: Latency vs LUT
plt.figure(figsize=(10, 6))
luts     = [p["LUT"]     for p in points]
latencies= [p["Latency"] for p in points]
plt.scatter(luts, latencies, c="lightblue", label="All design points", zorder=2)

p_luts = [p["LUT"]     for p in pareto]
p_lat  = [p["Latency"] for p in pareto]
plt.scatter(p_luts, p_lat, c="red", s=100, zorder=3, label="Pareto frontier")

# Sort and draw frontier line
paired = sorted(zip(p_luts, p_lat))
plt.step([x for x,_ in paired], [y for _,y in paired],
         where="post", color="red", linewidth=1.5)

plt.xlabel("LUT Usage")
plt.ylabel("Latency (cycles)")
plt.title("Design Space Exploration — Pareto Frontier")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("dse_pareto.png", dpi=150)
plt.show()
print(f"Pareto-optimal points: {len(pareto)} / {len(points)}")
```

### 8.5 DSE Report

Generate this report for every DSE run:

```
=== Design Space Exploration Report ===
Algorithm:    [name]
DSE axes:     II ∈ {1,2,4} × UNROLL ∈ {1,2,4,8} × bitwidth ∈ {8,16,32}
Total points: [N]
After constraint pruning: [M] feasible points
Pareto-optimal points: [K]

--- Hardware Constraints Applied ---
LUT  ≤ [budget] : [N_pruned] points pruned
DSP  ≤ [budget] : [N_pruned] points pruned
Freq ≥ [Y] MHz  : [N_pruned] points pruned (timing failure)
Accuracy ≥ [floor]: [N_pruned] points pruned (8-bit insufficient)

--- Pareto-Optimal Configurations ---
Rank  | II | UNROLL | Width | LUT   | DSP | Latency | Throughput | Rec.
------+----+--------+-------+-------+-----+---------+------------+-----
  1   |  1 |      8 |    16 | 2,400 |   8 |    72   |  1.0 out/c | ★★★
  2   |  2 |      4 |    16 | 1,200 |   4 |   136   |  0.5 out/c | ★★☆
  3   |  1 |      4 |     8 |   900 |   4 |    72   |  1.0 out/c | ★★☆ (low accuracy risk)
  4   |  4 |      2 |    16 |   800 |   2 |   264   |  0.25 out/c| ★☆☆

--- Recommended Configuration ---
Point #[K]: II=[N], UNROLL=[M], bitwidth=[W]
Rationale: [Best balance of throughput and area within all constraints]

--- Output Files ---
dse_results.json   — all [N] design points with metrics
dse_pareto.png     — Pareto frontier plot (Latency vs LUT)
dse_pareto.png     — secondary plot (Throughput vs DSP) [optional]
```

### 8.6 Multi-Objective DSE Script (Automated Synthesis Loop)

When synthesis tools are available, automate multi-point synthesis:

```tcl
# File: run_dse.tcl  — Vitis HLS multi-solution sweep
open_project dse_proj
set_top [function_name]
add_files [function_name]_hls.cpp

# Sweep II × UNROLL
foreach II_val {1 2 4} {
    foreach unroll_val {1 2 4 8} {
        set sol_name "sol_II${II_val}_U${unroll_val}"
        open_solution $sol_name
        set_part {xcu250-figd2104-2L-e}
        create_clock -period 5 -name default

        # Inject pragmas via config
        set_directive_pipeline -II $II_val "[function_name]/OUTER_LOOP"
        set_directive_unroll -factor $unroll_val "[function_name]/INNER_LOOP"

        csynth_design
        # Results auto-saved to dse_proj/$sol_name/syn/report/
    }
}
close_project
```

Parse all solution reports after the sweep with:

```bash
# Extract LUT/DSP/Latency from all solution reports
grep -r "LUT\|DSP\|Latency\|II" dse_proj/*/syn/report/*.rpt \
  | python3 parse_hls_reports.py > dse_results.csv
```

---

