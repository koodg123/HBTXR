## Phase 9: Hardware → Algorithm Feedback Loop

This phase closes the loop: DSE and synthesis results reveal **what the hardware cannot meet**, and we translate those findings back into **concrete Python algorithm changes**. The goal is not just to tune pragmas but to restructure the algorithm itself so the next HLS/RTL iteration starts from a better place.

### 9.1 Constraint Violation Diagnosis

Start from the synthesis report and DSE results. Classify each violation:

| Violation type | Symptom | Root cause in Python code |
|---|---|---|
| **Timing failure** | WNS < 0, freq not met | Long combinational chain → too many ops in one loop body |
| **DSP overflow** | DSP > budget | Too many multiplications in parallel (UNROLL too high) |
| **LUT overflow** | LUT > budget | Wide data types + complex logic + large unroll |
| **BRAM overflow** | BRAM > budget | Large arrays not mapped to streams; redundant buffers |
| **II > 1 (unexpected)** | Tool can't pipeline | Loop-carried dependency; memory read-after-write hazard |
| **Latency too high** | Latency >> target | Sequential computation; no parallelism extracted |
| **Accuracy failure** | SNR < floor at low bitwidth | Algorithm sensitive to rounding; needs reordering |

### 9.2 Root Cause → Algorithm Refactor

For each diagnosed violation, generate a paired **Before / After** showing the Python-level change:

---

#### Violation: Loop-Carried Dependency (II > 1)

**Diagnosis**: The HLS tool reports II=4 because the accumulator update `y += ...` creates a read-after-write on every iteration. The tool must serialize 4 pipeline stages before the next accumulation can begin.

**Python Before:**
```python
def fir(x, h, N, M):
    y = np.zeros(N)
    for n in range(N):
        for k in range(M):
            y[n] += h[k] * x[n - k]   # ← accumulated into same y[n] each iteration
    return y
```

**Python After (partial-sum accumulation):**
```python
def fir_parallel(x, h, N, M, LANES=4):
    """Restructure to use LANES independent partial sums → HLS II=1 feasible."""
    y = np.zeros(N)
    for n in range(N):
        partial = np.zeros(LANES)
        for k in range(0, M, LANES):
            for lane in range(LANES):
                if k + lane < M and n - (k + lane) >= 0:
                    partial[lane] += h[k + lane] * x[n - (k + lane)]
        y[n] = np.sum(partial)   # final reduction outside pipeline
    return y
```

**HW impact**: II: 4 → 1, Latency: 4N → N, Throughput: 4× improvement.

---

#### Violation: DSP Overflow (too many parallel multipliers)

**Diagnosis**: UNROLL=8 with 16-bit data maps 8 DSP48Es per loop body. With M=32 coefficients, DSP count = 256, exceeding the budget of 64.

**Python Before:**
```python
output = np.sum(weights * inputs)   # fully parallel dot product
```

**Python After (tiled dot product):**
```python
def tiled_dot(weights, inputs, TILE=4):
    """Tile dot product into TILE-wide chunks → maps to TILE DSPs, not N."""
    N = len(weights)
    acc = np.zeros(N // TILE)
    for t in range(N // TILE):
        acc[t] = np.sum(weights[t*TILE:(t+1)*TILE] * inputs[t*TILE:(t+1)*TILE])
    return np.sum(acc)
```

**HW impact**: DSP: 256 → 4 × TILE, area reduced 16×, throughput ~4× lower (acceptable if II=4 was already target).

---

#### Violation: Timing Failure (critical path too long)

**Diagnosis**: Critical path runs through 5 sequential multiplications in one combinational cloud. At 200 MHz (5 ns period), each multiply needs ~1.2 ns, so 5 chained = 6 ns → timing violation.

**Python Before:**
```python
result = a * b * c * d * e   # 4 chained multiplications in one expression
```

**Python After (pipelined chain):**
```python
# Explicitly break into stages → HLS maps each stage to one pipeline register
stage1 = a * b
stage2 = stage1 * c
stage3 = stage2 * d
result = stage3 * e
# With PIPELINE II=1, each stage occupies one cycle → no timing violation
```

**HW impact**: WNS: −1.0 ns → +0.3 ns, frequency: 166 MHz → 200+ MHz achieved.

---

#### Violation: BRAM Overflow (large array mapped to block RAM)

**Diagnosis**: A 4096-element float32 weight array consumes 128 KB → 32 BRAMs. Budget is 8 BRAMs.

**Python Before:**
```python
weights = np.random.randn(4096).astype(np.float32)   # 16 KB @ float32
```

**Python After (quantized + streamed):**
```python
# 1. Quantize weights to int8 → 4× smaller → 8 BRAMs
weights_q = np.clip(np.round(weights * 128), -128, 127).astype(np.int8)

# 2. Stream weights in tiles → HLS maps to FIFO, not block RAM
def process_tiled(x, weights_q, TILE=64):
    """Process in TILE-sized chunks; only TILE weights live in registers."""
    result = 0
    for t in range(0, len(weights_q), TILE):
        w_tile = weights_q[t:t+TILE].astype(np.float32) / 128.0
        result += np.dot(w_tile, x[t:t+TILE])
    return result
```

**HW impact**: BRAM: 32 → 8 (within budget), accuracy loss: SNR ≈ 40 dB (acceptable for most inference).

---

#### Violation: Accuracy Failure at Low Bitwidth

**Diagnosis**: 8-bit fixed-point (Q4.4) results in SNR = 18 dB, below the required 30 dB floor. Cause: weight distribution spans ±10.0, but Q4.4 saturates at ±8.0.

**Python After (per-layer scaling):**
```python
def quantize_with_scale(weights, bits=8):
    """Per-tensor quantization with dynamic range scaling."""
    w_max = np.max(np.abs(weights))
    scale = (2**(bits-1) - 1) / w_max          # e.g., 127 / 10.0 = 12.7
    w_q   = np.clip(np.round(weights * scale), -(2**(bits-1)), 2**(bits-1)-1)
    return w_q.astype(np.int8), scale

# For PyTorch: enable Quantization-Aware Training (QAT)
# model.qconfig = torch.quantization.get_default_qat_qconfig('fbgemm')
# torch.quantization.prepare_qat(model, inplace=True)
```

**HW impact**: SNR: 18 dB → 38 dB (Q4.4 with per-tensor scale), bitwidth stays 8 bits.

---

### 9.3 Algorithm Feedback Report

After diagnosing all violations and generating fixes, produce this structured report:

```
╔══════════════════════════════════════════════════════╗
║        Hardware → Algorithm Feedback Report          ║
╠══════════════════════════════════════════════════════╣
║ Source:  Phase 5 synthesis + Phase 8 DSE results     ║
║ Design:  [function_name]  Target: [FPGA/tech]        ║
╠══════════════════════════════════════════════════════╣
║  CONSTRAINT VIOLATIONS DETECTED                      ║
╠══════════════════════════════════════════════════════╣
║ ❌ Timing: WNS = -1.2 ns  (target: ≥ 0 ns)          ║
║ ❌ DSP:    312 / 64  (overuse: 4.9×)                 ║
║ ⚠️  LUT:   18,400 / 28,800 (64%, near limit)         ║
║ ✅ BRAM:   12 / 32  (OK)                             ║
║ ✅ Accuracy: SNR = 42 dB  (floor: 30 dB)             ║
╠══════════════════════════════════════════════════════╣
║  ALGORITHM REFACTORING RECOMMENDATIONS               ║
╠══════════════════════════════════════════════════════╣
║ [P0 — Critical] Fix loop-carried dependency          ║
║   File: algorithm.py, Line 23                        ║
║   Change: y[n] += ... → partial_sum[lane] +=        ║
║   Expected: II 4→1, Latency 4×better                ║
║                                                      ║
║ [P0 — Critical] Reduce unroll to match DSP budget    ║
║   Change: UNROLL=8 → UNROLL=2 (or tile dot product) ║
║   Expected: DSP 312 → 64 (within budget)            ║
║                                                      ║
║ [P1 — High] Break 5-stage multiply chain             ║
║   File: algorithm.py, Line 41                        ║
║   Change: a*b*c*d*e → staged intermediate regs      ║
║   Expected: WNS -1.2 → +0.5 ns                      ║
║                                                      ║
║ [P2 — Medium] Consider int8 quantization for weights ║
║   Current: float32 (64 DSPs/inference)               ║
║   After QAT: int8 (8 DSPs/inference, SNR ~40 dB)    ║
╠══════════════════════════════════════════════════════╣
║  NEXT ITERATION PROJECTION                           ║
╠══════════════════════════════════════════════════════╣
║ After applying P0+P1 fixes:                          ║
║   DSP:     312 → ~64  ✅                             ║
║   WNS:    -1.2 → ~+0.4 ns  ✅                        ║
║   Latency: 4N  → N  (4× improvement)                ║
║   LUT:  18,400 → ~10,000  (35% — comfortable)       ║
║                                                      ║
║ Recommended DSE config for next run:                 ║
║   II=1, UNROLL=2, bitwidth=16                        ║
╚══════════════════════════════════════════════════════╝
```

### 9.4 Iterative Refinement Loop

Phase 9 is not a one-shot pass — feed the refactored Python back through the pipeline:

```
Python (v1) → Phase 1 → Phase 2/3 → Phase 4 → Phase 5
                                                   ↓
                                             Phase 8 (DSE)
                                                   ↓
                                        Phase 9 (Feedback)
                                                   ↓
Python (v2) → Phase 1 → Phase 2/3 → Phase 4 → Phase 5
                                                   ↓
                                        [Constraints met? → Phase 6]
```

At each iteration, track the delta:

```
=== Iteration Summary ===
         | v1 (original) | v2 (after P0+P1) | Delta
---------+---------------+------------------+-------
DSP      | 312           | 64               | -79%
LUT      | 18,400        | 9,800            | -47%
Latency  | 256 cycles    | 68 cycles        | -73%
WNS      | -1.2 ns       | +0.4 ns          | FIXED
Accuracy | SNR 42 dB     | SNR 41 dB        | ~OK
```

Repeat until all constraints are met. Typical convergence: 2–3 iterations.

---

