## E2E Workflow Summary

When the user asks for a full E2E run, execute phases in order and produce a **Master Report**:

```
╔══════════════════════════════════════════╗
║       E2E Hardware Automation Report     ║
╠══════════════════════════════════════════╣
║ Algorithm:   [name]                      ║
║ Input:       Python [type] → HLS/RTL     ║
║ Target:      [FPGA part / tech node]     ║
║ Frequency:   [target MHz]                ║
╠══════════════════════════════════════════╣
║ Phase 1 — Analysis          ✅ / ⚠️ / ❌ ║
║ Phase 2 — HLS C++ Gen       ✅ / ⚠️ / ❌ ║
║ Phase 3 — RTL Gen           ✅ / ⚠️ / ❌ ║
║ Phase 4 — Co-Simulation     ✅ / ⚠️ / ❌ ║
║   Accuracy:   [X.X%] pass                ║
║   Latency:    [N] cycles                 ║
║   II:         [N] cycles                 ║
║ Phase 5 — Synthesis         ✅ / ⚠️ / ❌ ║
║   LUT/FF/DSP/BRAM: [N/N/N/N]            ║
║   Timing: [WNS X.Xns]                   ║
║ Phase 8 — DSE               ✅ / ⚠️ / ❌ ║
║   Points explored: [N]                   ║
║   Pareto-optimal:  [K]                   ║
║   Best config: II=[x] UNROLL=[y] W=[z]  ║
║ Phase 9 — Algo Feedback     ✅ / ⚠️ / ❌ ║
║   Violations: [N] (P0:[x] P1:[y] P2:[z])║
║   Python v[N] → v[N+1] refactor ready   ║
║ Phase 6 — FPGA Impl         ✅ / ⚠️ / ❌ ║
║   Bitstream: [filename].bit              ║
║ Phase 7 — Waveform          ✅ / ⚠️ / ❌ ║
╠══════════════════════════════════════════╣
║ Python time:  [X ms] → HW: [X µs]       ║
║ Speedup:      ~[Xx] @ [Y MHz]            ║
║ Iterations:   [N] (constraints met ✅)   ║
╚══════════════════════════════════════════╝
```

---

## Tool Detection

At the start of any run, check which tools are available:

```bash
which vitis_hls   && echo "Vitis HLS: OK"
which vivado      && echo "Vivado: OK"
which verilator   && echo "Verilator: OK"
which iverilog    && echo "iverilog: OK"
which dc_shell    && echo "Synopsys DC: OK"
which genus       && echo "Cadence Genus: OK"
```

If a tool is not found, generate the script files and report files as **templates** with clear `[TODO: run with <toolname>]` markers, so the user can run them manually.

---

## Warnings & Best Practices

- **Fixed-point first**: Always start with `float` in HLS, then tighten to `ap_fixed` once functional correctness is verified
- **II=1 is not always best**: II=2 or II=4 can save 40-60% area with minimal throughput impact for non-latency-critical paths
- **DATAFLOW requires ping-pong buffers**: each function reads from and writes to different arrays; add `#pragma HLS STREAM` for FIFOs
- **Avoid pointer aliasing**: HLS tools assume no aliasing — use `restrict` or pass arrays explicitly
- **`ap_int` vs `ap_fixed`**: use `ap_int` for integer datapaths (indices, counters), `ap_fixed` for fractional computation
- **Cadence/Synopsys ASIC**: always specify `set_dont_use` for cells not in your library; check for latch inference
