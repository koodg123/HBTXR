## Phase 7: Waveform & Pipeline Analysis

### 7.1 VCD Waveform Analysis Script

```python
# File: analyze_waveform.py
# Requires: pip install pyDigitalWaveTools (or pyvcd)
import subprocess, re

def parse_vcd_cycles(vcd_file: str, signal: str = "valid_out") -> dict:
    """Extract cycle count between valid_in assertion and valid_out assertion."""
    # Use GTKWave or python-vcd to parse
    result = {}
    with open(vcd_file) as f:
        content = f.read()
    # Find first valid_in=1 → valid_out=1 delta
    # ... parsing logic ...
    return result

def report_pipeline_stages(vcd_file: str):
    """Identify pipeline fill, steady-state, and drain cycles."""
    print("=== Pipeline Waveform Report ===")
    print(f"VCD file:      {vcd_file}")
    print(f"Fill cycles:   [N]  (pipeline latency)")
    print(f"Steady-state:  II = [N] cycles")
    print(f"Drain cycles:  [N]")
```

### 7.2 GTKWave Launch Helper

```bash
# Auto-open waveform with signal groups
gtkwave waveform.vcd --script signals.gtkw &
```

Generate a `.gtkw` signal group file:
```
# signals.gtkw — GTKWave saved state
[timestart] 0
[size] 1200 700
[signals]
clk
rst_n
valid_in
data_in[15:0]
valid_out
data_out[15:0]
```

---

