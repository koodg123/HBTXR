## Phase 3: Python → SystemVerilog / Verilog RTL

Generate synthesizable RTL directly from the algorithm.

### 3.1 Module Template

```systemverilog
// File: [module_name].sv
// Converted from Python: [original_function_name]
// Latency: [N] cycles | II: [M] cycles | Precision: [W].[I] fixed-point

module [module_name] #(
    parameter DATA_W  = 16,
    parameter FRAC_W  = 8,
    parameter N       = 64
) (
    input  logic                  clk,
    input  logic                  rst_n,
    input  logic                  valid_in,
    input  logic [DATA_W-1:0]     data_in,
    output logic [DATA_W-1:0]     data_out,
    output logic                  valid_out
);

    // Pipeline registers
    logic [DATA_W-1:0] stage_reg [0:LATENCY-1];

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // reset
        end else if (valid_in) begin
            // pipeline logic
        end
    end

endmodule
```

### 3.2 Arithmetic Mapping

| Python op | SystemVerilog | Notes |
|-----------|--------------|-------|
| `a + b` | `a + b` | Carry-safe width |
| `a * b` | `a * b` (→ DSP) | Watch overflow |
| `a >> n` | `a >>> n` (arithmetic) | Sign extension |
| `np.clip(x,lo,hi)` | Saturation logic | Dedicated sat block |
| `np.sum(arr)` | Tree adder | Log2(N) stages |
| ReLU | `(x[MSB]) ? 0 : x` | 1 cycle |

### 3.3 Fixed-Point Quantization Helper

Generate a Python quantization reference alongside the RTL:

```python
import numpy as np

def to_fixed(x, W=16, F=8):
    """Quantize float to W.F fixed-point, return integer representation."""
    scale = 2 ** F
    return np.clip(np.round(x * scale), -(2**(W-1)), 2**(W-1)-1).astype(np.int32)

def from_fixed(x_int, F=8):
    return x_int / (2 ** F)
```

### Output
- `[module_name].sv` (or `.v` for Verilog-2001)
- `[module_name]_tb.sv` — testbench scaffold
- `quant_ref.py` — Python fixed-point reference model

---

