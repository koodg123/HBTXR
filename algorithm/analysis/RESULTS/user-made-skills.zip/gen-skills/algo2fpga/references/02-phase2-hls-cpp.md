## Phase 2: Python → HLS C++ Conversion

Convert the analyzed Python to C++ targeting Vitis HLS or Catapult HLS.

### 2.1 Data Type Mapping

| Python / NumPy | HLS C++ |
|----------------|---------|
| `np.float32` | `float` or `ap_fixed<32,16>` |
| `np.float64` | `double` (avoid — use `ap_fixed` for area) |
| `np.int8/16/32` | `ap_int<8/16/32>` |
| `np.uint8` | `ap_uint<8>` |
| `bool` | `ap_uint<1>` |
| Arrays `[N]` | `T arr[N]` or `hls::stream<T>` |
| 2D arrays `[M][N]` | `T arr[M][N]` with `#pragma HLS ARRAY_PARTITION` |

### 2.2 HLS C++ Template

```cpp
// File: [function_name]_hls.cpp
#include "ap_int.h"
#include "ap_fixed.h"
#include "hls_stream.h"
#include <cstring>

// Type aliases — adjust widths for your precision/area target
typedef ap_fixed<16, 8> data_t;
typedef ap_fixed<32, 16> acc_t;

void [function_name](
    data_t input[INPUT_SIZE],   // AXI-Stream or array port
    data_t output[OUTPUT_SIZE],
    int N                        // runtime-configurable size (if needed)
) {
#pragma HLS INTERFACE m_axi port=input  offset=slave bundle=gmem0
#pragma HLS INTERFACE m_axi port=output offset=slave bundle=gmem1
#pragma HLS INTERFACE s_axilite port=N  bundle=ctrl
#pragma HLS INTERFACE s_axilite port=return bundle=ctrl

    // --- Your converted logic here ---
    OUTER_LOOP:
    for (int i = 0; i < N; i++) {
#pragma HLS PIPELINE II=1
        // ...
    }
}
```

### 2.3 Pragma Strategy

Choose pragmas based on the algorithm profile:

**Compute-bound (high FLOP/element):**
```cpp
#pragma HLS PIPELINE II=1          // Fully pipeline inner loop
#pragma HLS UNROLL factor=4        // Unroll for parallel lanes
#pragma HLS ARRAY_PARTITION variable=weights cyclic factor=4 dim=1
```

**Memory-bound (wide arrays, streaming):**
```cpp
#pragma HLS DATAFLOW                // Task-level pipeline
#pragma HLS STREAM variable=fifo depth=16
#pragma HLS ARRAY_PARTITION variable=buf complete dim=1
```

**Area-constrained (resource limited):**
```cpp
#pragma HLS PIPELINE II=4          // Relax II to save DSPs
#pragma HLS RESOURCE variable=mac core=Mul_LUT  // Use LUT instead of DSP
```

### 2.4 Catapult HLS Variant

For Catapult HLS, replace Vitis pragmas with directives:

```cpp
#pragma hls_design top
void [function_name](...) {
    #pragma hls_pipeline_init_interval 1
    for (int i = 0; i < N; i++) {
        // ...
    }
}
```

### 2.5 Header File

Always generate a matching header:

```cpp
// File: [function_name]_hls.h
#ifndef [FUNCTION_NAME]_HLS_H
#define [FUNCTION_NAME]_HLS_H
#include "ap_fixed.h"
#define INPUT_SIZE  [N]
#define OUTPUT_SIZE [M]
typedef ap_fixed<16,8> data_t;
void [function_name](data_t input[INPUT_SIZE], data_t output[OUTPUT_SIZE], int N);
#endif
```

### Output
- `[function_name]_hls.cpp`
- `[function_name]_hls.h`
- Pragma rationale comment block at top of file

---

