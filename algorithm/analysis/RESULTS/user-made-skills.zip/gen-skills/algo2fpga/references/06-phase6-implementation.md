## Phase 6: FPGA Implementation & Bitstream

### 6.1 Vivado Full Implementation Script

```tcl
# File: run_impl.tcl
open_project proj ./vivado_proj -part xcu250-figd2104-2L-e
add_files [module_name].sv
add_files constraints.xdc
set_property top [module_name] [current_fileset]

# Synthesis
synth_design -top [module_name]

# Implementation
opt_design
place_design
phys_opt_design
route_design

# Reports
report_utilization   -file impl_utilization.rpt
report_timing_summary -file impl_timing.rpt
report_power         -file power.rpt

# Bitstream
write_bitstream -force [module_name].bit
close_project
```

### 6.2 Constraints Template (XDC)

```tcl
# File: constraints.xdc
# Primary clock
create_clock -period 5.000 -name sys_clk [get_ports clk]

# I/O timing (adjust to your board)
set_input_delay  -clock sys_clk 1.0 [get_ports {data_in valid_in}]
set_output_delay -clock sys_clk 1.0 [get_ports {data_out valid_out}]

# False paths (if applicable)
# set_false_path -from [get_ports rst_n]
```

### 6.3 Post-Implementation Report

```
=== FPGA Implementation Report ===
Status:     [PASSED / FAILED]
Bitstream:  [module_name].bit

Utilization (Post-Route):
  LUT:   [N] ([X.X%])  FF:   [N] ([X.X%])
  DSP:   [N] ([X.X%])  BRAM: [N] ([X.X%])

Timing (Post-Route):
  Target:   [X.XX ns] ([YY MHz])
  WNS:      [+/-X.XX ns]  → [TIMING MET / VIOLATED]

Power (estimated):
  Dynamic:  [X.XX W]
  Static:   [X.XX W]
  Total:    [X.XX W]
```

---

