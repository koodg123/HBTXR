## Phase 1: Python Algorithm Analysis

Before converting, deeply understand the algorithm's hardware implications.

### 1.1 Extract Algorithm Profile

Analyze the Python code and produce this profile:

```
## Algorithm Profile
- Name: [function/class name]
- Type: [NumPy numeric / PyTorch layer / General Python]
- I/O shapes: input=[shape, dtype], output=[shape, dtype]
- Compute intensity: [FLOP count estimate]
- Memory access pattern: [sequential / strided / random / streaming]
- Data dependencies: [loop-carried? / independent?]
- Parallelism opportunities: [SIMD / pipeline / dataflow / none]
- Fixed-point feasibility: [yes/no + suggested bit-widths]
```

### 1.2 Identify Hardware-Friendly Patterns

| Pattern | HW mapping | Pragma hint |
|---------|-----------|-------------|
| `np.dot` / `@` | DSP MAC array | `PIPELINE II=1` |
| `np.fft` | Pipelined butterfly | `DATAFLOW` |
| Nested for loops | Systolic array / loop tiling | `UNROLL`, `PIPELINE` |
| Conv2d | Weight-stationary PE | `ARRAY_PARTITION` |
| Reduce (sum/max) | Tree reduction | `PIPELINE` + partial sum |
| if/else on data | Mux logic | Avoid divergent branches |

### 1.3 Flag Conversion Warnings

Identify patterns that require manual intervention:
- Dynamic shapes → must be fixed at compile time
- Python objects / dicts → must be flattened to arrays
- Recursive calls → must be unrolled or converted to iterative
- `float64` → suggest `ap_fixed<W,I>` width
- Random number generation → replace with LFSR or pre-computed LUT

### Output
Produce the Algorithm Profile table + a list of conversion warnings before proceeding.

---

