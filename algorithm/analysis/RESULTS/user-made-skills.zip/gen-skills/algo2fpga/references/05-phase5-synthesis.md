## Phase 5: Synthesis & Resource Analysis

### 5.1 Vitis HLS Synthesis Script

```tcl
# File: run_hls.tcl
open_project hls_proj
set_top [function_name]
add_files [function_name]_hls.cpp
add_files -tb tb_[function_name].cpp
open_solution "solution1"
set_part {xcu250-figd2104-2L-e}   ;# change to your target FPGA
create_clock -period 5 -name default  ;# 200 MHz
csynth_design
cosim_design
export_design -rtl verilog -format ip_catalog
close_project
```

Run: `vitis_hls -f run_hls.tcl`

### 5.2 Vivado Synthesis Script

```tcl
# File: run_synth.tcl
create_project proj ./vivado_proj -part xcu250-figd2104-2L-e
add_files [module_name].sv
set_property top [module_name] [current_fileset]
synth_design -top [module_name] -part xcu250-figd2104-2L-e
report_utilization -file utilization.rpt
report_timing_summary -file timing.rpt
close_project
```

### 5.3 Synopsys Design Compiler Script

```tcl
# File: run_dc.tcl
set_app_var target_library "your_tech.db"
set_app_var link_library   "* your_tech.db"
read_verilog [module_name].sv
elaborate [module_name]
create_clock -period 5 [get_ports clk]
compile_ultra
report_area   > area.rpt
report_timing > timing.rpt
write -f verilog -o [module_name]_mapped.v
```

### 5.4 Cadence Genus Script

```tcl
# File: run_genus.tcl
read_libs your_tech.lib
read_hdl [module_name].sv
elaborate
syn_generic
syn_map
syn_opt
report_area    > area.rpt
report_timing  > timing.rpt
```

### 5.5 Resource Report Parser

After synthesis, parse and format reports:

```
=== Synthesis Resource Report ===
Design:    [module_name]
Tool:      [Vivado / DC / Genus / Vitis HLS]
Target:    [FPGA part / technology node]
Frequency: [target MHz] → [achieved MHz] ([WNS: X.X ns])

--- FPGA Resources (Vivado) ---
LUT:       [N] / [total] ([X.X%])
FF:        [N] / [total] ([X.X%])
DSP:       [N] / [total] ([X.X%])
BRAM:      [N] / [total] ([X.X%])
URAM:      [N] / [total] ([X.X%])

--- ASIC Area (DC/Genus) ---
Combinational:  [X.XX] µm²
Sequential:     [X.XX] µm²
Total:          [X.XX] µm²

--- Performance ---
Critical path:  [X.XX ns]
Slack:          [X.XX ns] [MET / VIOLATED]
Throughput:     [X.X GOPs]
Power estimate: [X.X mW]
```

---

