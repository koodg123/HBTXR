# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P1

Domain: Research Workflow

Parent skill: evaluator-verification-manager

Target model, algorithm, hardware, or dataset:

Constraints:

Assumptions:

Required artifact:

Verification evidence:

Risks and missing inputs:
