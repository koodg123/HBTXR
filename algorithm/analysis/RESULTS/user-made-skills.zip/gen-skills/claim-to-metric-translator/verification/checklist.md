# Verification Checklist

- [ ] Skill phase `P1` and domain `Research Workflow` are stated.
- [ ] Parent skill `evaluator-verification-manager` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] Claim metric table is present and traceable.
- [ ] Validation experiments is present and traceable.
- [ ] Evidence checklist is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] Residual risks and missing inputs are listed.
