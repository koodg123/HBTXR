# IDEA-Gen Context

Phase: P1
Domain: Research Workflow
Parent skill: `evaluator-verification-manager`

## Why This Skill Exists

IDEA-Gen ideas must become testable claims before implementation or paper writing.

## Worker Capability

Translate research claims into measurable metrics, experiments, ablations, and validation evidence.

## Expected Outputs

- Claim metric table
- Validation experiments
- Evidence checklist

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the cluster and roadmap notes for `Research Workflow`.
