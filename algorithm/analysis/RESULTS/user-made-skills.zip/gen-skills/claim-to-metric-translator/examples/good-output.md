# Good Output

A strong output for `claim-to-metric-translator` includes a concise objective, source mapping, explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: Claim metric table; Validation experiments; Evidence checklist.
