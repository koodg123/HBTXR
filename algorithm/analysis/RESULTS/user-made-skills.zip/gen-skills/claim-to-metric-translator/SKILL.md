---
name: claim-to-metric-translator
description: "Translate research claims into measurable metrics, experiments, ablations, and validation evidence. Use when IDEA-Gen Research Workflow work needs this Worker capability."
---

# Claim To Metric Translator

## Overview

Use this skill for translate research claims into measurable metrics, experiments, ablations, and validation evidence. It is a P1 IDEA-Gen leaf skill under `Research Workflow` and should produce Worker-sized artifacts, not broad strategy notes.

## Prompt-First Rule

Start by creating a compact prompt pack that states the objective, source artifact, target hardware or model, assumptions, expected deliverables, and verification evidence. If the task is underspecified, list the missing inputs before making design choices.

## Start Every Task With

1. Restate the target problem as a measurable research or engineering objective.
2. Identify the parent skill, upstream artifacts, and downstream consumers.
3. Separate known facts from assumptions about models, hardware, datasets, tools, and metrics.
4. Choose the smallest artifact that will unblock the next Worker or evaluator.
5. Define evidence required for signoff before producing the main artifact.

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Build the prompt pack using `templates/prompt-template.md` or `scripts/build_prompt.py`.
3. Produce the primary artifact with explicit inputs, constraints, decisions, and rejected alternatives.
4. Map the artifact to validation criteria in `verification/checklist.md`.
5. Return provenance: source note, parent skill, assumptions, generated artifact, and remaining risks.

## Deliverables

- Claim metric table
- Validation experiments
- Evidence checklist
- Prompt pack and assumption ledger.
- Validation evidence and unresolved risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Hardware, compiler, model, or data constraints are not silently invented.
- The artifact names parent skill `evaluator-verification-manager` and IDEA-Gen domain `Research Workflow`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The target hardware, workload, precision, dataset, or metric is missing.
- Multiple plausible designs would change the result materially.
- Verification depends on unavailable synthesis, simulation, profiling, or paper evidence.
- The task should be split into a new leaf skill rather than handled inside this one.
