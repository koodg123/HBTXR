# Sub-Agents

This folder contains Codex-style sub-agent definitions in `.toml` format plus the higher-level manifest.

## Closed-Loop Order

1. Draft the main prompt with `templates/prompt-template.md` or `templates/prompt-bundles/`.
2. Run `compression-strategy-planner.toml` to challenge the draft for `Break the request into the smallest compression experiments that preserve clear attribution for wins and regressions.`
3. Run `runtime-compatibility-analyst.toml` to challenge the draft for `Challenge the prompt against operator support, precision coverage, export semantics, and kernel availability on the target stack.`
4. Run `accuracy-retention-critic.toml` to challenge the draft for `Interrogate whether calibration, distillation, or partial fine-tuning is sufficient to preserve the agreed quality bar.`
5. Run `calibration-and-backend-mapper.toml` to challenge the draft for `Challenge the prompt using official calibration and backend-compatibility concerns from modern quantization workflows.`
6. Run `researcher-background-adapter.toml` to challenge the draft for `Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: Song Han, Vivienne Sze.`
7. Revise the main prompt and pass it through `verification/checklist.md` before finalizing.

## Files

- `manifest.toml`: role list, feedback-loop stages, and retry rules.
- `compression-strategy-planner.toml`: Break the request into the smallest compression experiments that preserve clear attribution for wins and regressions.
- `runtime-compatibility-analyst.toml`: Challenge the prompt against operator support, precision coverage, export semantics, and kernel availability on the target stack.
- `accuracy-retention-critic.toml`: Interrogate whether calibration, distillation, or partial fine-tuning is sufficient to preserve the agreed quality bar.
- `calibration-and-backend-mapper.toml`: Challenge the prompt using official calibration and backend-compatibility concerns from modern quantization workflows.
- `researcher-background-adapter.toml`: Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: Song Han, Vivienne Sze.
