# Verification Checklist

## Prompt Pack

- The user request was rewritten into a measurable engineering objective.
- The chosen route is explicit and the nearest rejected route is mentally considered.
- Constraints, failure evidence, and success metrics are stated clearly.

## Closed-Loop Review

- A routing-oriented sub-agent challenged the framing.
- A system or feasibility-oriented sub-agent challenged execution realism.
- A critic sub-agent challenged evidence quality and verification coverage.
- The main prompt was revised after feedback instead of just appending comments.

## Domain Checks

- The prompt includes the deployment runtime and supported precision path by name.
- One sub-agent focuses on compatibility and another on accuracy-recovery risk.
- Final output defines what counts as a failed compression attempt and when to roll back.

## Final Answer

- The response separates prompt pack, recommendation, validation, and residual risk.
- Unknowns that still require measurement or external validation are explicit.
- The final recommendation is the smallest credible next step, not the broadest redesign.
