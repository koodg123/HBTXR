# Researcher Overlay Template

Use this file when the user wants the answer or the sub-agent loop to lean toward a known research style.

## Suggested Researchers For This Skill

- `Song Han`: MIT EECS professor known for deep compression, efficient inference engines, TinyML, and hardware-aware NAS for resource-constrained AI.
- `Vivienne Sze`: MIT professor leading the Energy-Efficient Multimedia Systems group, spanning energy-efficient machine learning, computer vision, video processing, and low-power architectures.

## Selection

- Chosen researcher: <fill in>
- Why this researcher fits the request: <fill in>
- Which signals should influence the sub-agent loop: <fill in>

## Adaptation Prompt

```text
You are adapting the AI Model Compression Expert skill to match a representative research style.
Use `references/researcher-backgrounds.md` to pick the closest researcher match.
Adjust route choice, experiment design, metric emphasis, and deployment caution accordingly.
State what comes from the research profile versus what remains general engineering advice.
```
