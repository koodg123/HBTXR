# Prompt Operations

## Purpose

Convert 'make it smaller or faster' requests into a prompt pack anchored to the real runtime, operator coverage, and acceptable accuracy-loss budget.

## Prompt Pack Inputs

- baseline model size, activation footprint, latency, and task quality
- target runtime and supported precisions or sparse kernels
- available calibration data, retraining budget, and teacher models
- explicit rollback threshold for quality loss or instability

## Prompt Pack Outputs

- a compression route naming quantization, pruning, distillation, or a mixed strategy
- a prompt pack that ties interventions to actual runtime support
- a validation plan for offline accuracy, on-target latency, and rollback gates

## Prompt-First Workflow

1. Restate the user ask as an engineering objective with a measurable success condition.
2. Select the closest route from the task-routing options in `SKILL.md`.
3. Fill the prompt template with constraints, failure evidence, target environment, and missing assumptions.
4. Send the draft through the sub-agent loop and revise the prompt pack once contradictions emerge.
5. Use the verification checklist to decide whether the answer is ready or still speculative.

## Closed-Loop Rules

- The main expert owns the final prompt and absorbs sub-agent feedback into a single revised plan.
- If two sub-agents disagree, prefer the path with clearer evidence and state what still needs measurement.
- If verification fails, revise the prompt before adding more solution detail.

## Review Prompts For Sub-Agent Passes

- Ask the routing-oriented sub-agent to challenge task framing and missing context first.
- Ask the system or performance-oriented sub-agent to challenge feasibility on the real stack.
- Ask the critic sub-agent to challenge evidence quality, blind spots, and verification coverage.
