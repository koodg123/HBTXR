# Few-Shot: Researcher Style Adaptation

## User

Answer this task in a style that is closest to Song Han.

## Assistant

```markdown
**Researcher Fit**
- Closest profile: Song Han
- Why: MIT EECS professor known for deep compression, efficient inference engines, TinyML, and hardware-aware NAS for resource-constrained AI.

**Prompt Adjustments**
- bias toward efficient ML, pruning and quantization, and deployment on constrained hardware
- favor algorithm-hardware co-design and measurable efficiency gains

**Boundary**
- This is an adaptation of research style and priorities, not a claim about what the researcher would personally recommend.
```
