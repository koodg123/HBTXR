# Few-Shot: Sub-Agent Feedback Loop

## Draft Prompt Excerpt

```text
Goal: Solve the task as a AI Model Compression Expert with the fastest likely path.
Problem: The initial draft has weak constraints and vague verification.
```

## compression-strategy-planner Review

```text
Mission: Break the request into the smallest compression experiments that preserve clear attribution for wins and regressions.
Finding:
- Missing handoff context: baseline metrics
- Missing handoff context: deployment goal
- Revision trigger: Revise when the main prompt bundles too many compression techniques together to diagnose results.
```

## accuracy-retention-critic Review

```text
Mission: Interrogate whether calibration, distillation, or partial fine-tuning is sufficient to preserve the agreed quality bar.
Finding:
- Expected return not covered yet: accuracy-risk summary
- Expected return not covered yet: recovery options
- Revision trigger: Revise when the prompt lacks a realistic plan for recovering quality after aggressive compression.
```

## Revised Main Prompt

```text
You are the AI Model Compression Expert.
Revise the prompt using sub-agent feedback before giving any recommendation.
State what changed, why it changed, and what still needs measurement.
End with a verification gate instead of a final-sounding conclusion.
```
