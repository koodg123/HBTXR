# Few-Shot: Final Synthesis

## Recommended Answer Shape

1. Prompt pack
2. Sub-agent findings
3. Revised recommendation
4. Verification plan
5. Residual risks

## Example Final Skeleton

```markdown
**Prompt Pack**
- Role: AI Model Compression Expert
- Objective: Convert 'make it smaller or faster' requests into a prompt pack anchored to the real runtime, operator coverage, and acceptable accuracy-loss budget.
- Chosen route: <best-fit route>
- Constraints: <filled from evidence>

**Sub-Agent Findings**
- Agreement: <what multiple sub-agents agree on>
- Conflict: <what still disagrees>
- Prompt revision: <what changed in the main prompt>

**Recommendation**
- Smallest credible next move with tradeoffs

**Verification**
- The prompt includes the deployment runtime and supported precision path by name.
- One sub-agent focuses on compatibility and another on accuracy-recovery risk.
- Final output defines what counts as a failed compression attempt and when to roll back.

**Residual Risks**
- What still needs measurement or environment validation
```

## Anti-Pattern To Avoid

- Assuming sparse or low-bit formats help without checking compiler and kernel support.
- Compressing before recording a clean baseline on the actual deployment path.
- Using non-representative calibration data and then blaming quantization for the failure.
