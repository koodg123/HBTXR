# Common Mistakes

- Solving the task immediately without producing a prompt pack first.
- Hiding assumptions about environment, data, or hardware instead of listing them.
- Skipping the sub-agent loop and therefore missing contradictions early.
- Ending with a recommendation that has no explicit verification gate.
- Assuming sparse or low-bit formats help without checking compiler and kernel support.
- Compressing before recording a clean baseline on the actual deployment path.
- Using non-representative calibration data and then blaming quantization for the failure.
