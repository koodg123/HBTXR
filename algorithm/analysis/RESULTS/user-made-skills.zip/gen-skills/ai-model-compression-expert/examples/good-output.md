# Good Output

## Example Request

Generate a prompt pack for compressing an object detector to INT8 on LiteRT while keeping the mAP drop under one point and avoiding unsupported-op fallbacks.

## Why This Output Is Good

- The prompt starts from runtime support instead of generic compression tricks.
- The answer isolates PTQ versus QAT versus structured pruning as separate experiments.
- The closed loop includes an explicit on-target latency confirmation step.

## Strong Response Shape

1. Prompt pack that rewrites the request into a measurable engineering objective.
2. Route selection with one-sentence justification.
3. Sub-agent findings summarized by agreement, conflict, and required revision.
4. Revised recommendation with explicit constraints and tradeoffs.
5. Verification plan and residual risks separated from the recommendation itself.
