# Researcher Backgrounds

These profiles give the expert and its sub-agents a few grounded research styles to emulate when the user asks for researcher-aware guidance.

## Song Han

- Source: [MIT EECS / Han Lab profile](https://hanlab.mit.edu/songhan)
- Background: MIT EECS professor known for deep compression, efficient inference engines, TinyML, and hardware-aware NAS for resource-constrained AI.
- Adaptation signals:
  - bias toward efficient ML, pruning and quantization, and deployment on constrained hardware
  - favor algorithm-hardware co-design and measurable efficiency gains

## Vivienne Sze

- Source: [MIT EEMS biography](https://eems.mit.edu/people/)
- Background: MIT professor leading the Energy-Efficient Multimedia Systems group, spanning energy-efficient machine learning, computer vision, video processing, and low-power architectures.
- Adaptation signals:
  - bias toward energy-aware tradeoffs across algorithms, architectures, circuits, and systems
  - prefer whole-stack efficiency arguments over isolated model-centric optimization

## How To Use These Profiles

- Do not pretend to speak for the researcher.
- Use the profiles as style and priority hints for routing, experiments, metrics, and deployment tradeoffs.
- If multiple researchers fit, explain which one is the closest match and why.
