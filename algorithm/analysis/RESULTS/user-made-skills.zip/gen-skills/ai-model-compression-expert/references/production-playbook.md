# Production Playbook

## When To Read This File

Read this file when compression choices need to be grounded in runtime support, calibration discipline, and measurable quality retention rather than generic 'make it smaller' advice.

## Prompt-First Translation

- Primary goal: Convert 'make it smaller or faster' requests into a prompt pack anchored to the real runtime, operator coverage, and acceptable accuracy-loss budget.
- Always convert the user request into a scoped prompt pack before ranking solutions.
- Capture which sub-agent should challenge the draft first and why.

## Intake Checklist

- Baseline metrics: parameter size, activation memory, throughput, latency, and current accuracy or task score.
- Target stack: training framework, export format, compiler/runtime, accelerator, and supported precisions or sparse kernels.
- Compression goal: fit-in-memory, speedup, bandwidth reduction, battery savings, or model distribution footprint.
- Data availability: calibration set size, fine-tuning budget, teacher availability, and domain-shift concerns.
- Rollback threshold: maximum acceptable accuracy drop and non-functional regression budget.

## Domain-Specific Prompt Inputs

- baseline model size, activation footprint, latency, and task quality
- target runtime and supported precisions or sparse kernels
- available calibration data, retraining budget, and teacher models
- explicit rollback threshold for quality loss or instability

## Routing And Failure Patterns

### PTQ is unstable

- Preferred investigation path: Check activation outliers, representative calibration coverage, unsupported operators, and preprocessing mismatch.

### QAT is too expensive

- Preferred investigation path: Check whether mixed precision or partial QAT on sensitive blocks can recover most benefits.

### Pruning gives no speedup

- Preferred investigation path: Check whether sparsity is structured enough and whether the runtime has kernels that exploit it.

### Distillation fails to recover quality

- Preferred investigation path: Check teacher quality, student capacity, supervision layers, temperature, and task-specific losses.

### Compression passes offline but fails on target

- Preferred investigation path: Check export semantics, precision fallback, kernel coverage, and memory-planning differences on the deployment stack.

## Closed-Loop Review Gates

- Gate 1: Does the draft prompt name the real task route and success metric?
- Gate 2: Did at least one sub-agent challenge feasibility or runtime reality?
- Gate 3: Did at least one sub-agent challenge evidence quality or verification coverage?
- Gate 4: Was the final prompt revised to absorb conflicts instead of merely listing them?

## Common Failure Patterns

- Optimizing only model size while ignoring activation memory or memory bandwidth, which may dominate runtime.
- Assuming a sparse or low-bit representation is useful without verifying kernel and compiler support.
- Calibrating with unrepresentative data and then blaming quantization for deployment failures.
- Comparing student and teacher under different preprocessing or post-processing pipelines.
- Assuming sparse or low-bit formats help without checking compiler and kernel support.
- Compressing before recording a clean baseline on the actual deployment path.
- Using non-representative calibration data and then blaming quantization for the failure.

## Validation Checklist

- Compare baseline and compressed models on the same evaluation slices and the same deployment path.
- Measure end-to-end latency on target hardware, not only framework-level microbenchmarks.
- Track both aggregate metrics and worst-case regressions on sensitive classes or edge cases.
- Keep an explicit rollback criterion if accuracy or stability drops beyond the agreed threshold.
- The prompt includes the deployment runtime and supported precision path by name.
- One sub-agent focuses on compatibility and another on accuracy-recovery risk.
- Final output defines what counts as a failed compression attempt and when to roll back.

## Local Reference Anchors

- claude-skills/docs/skills/engineering-team/senior-computer-vision.md: concrete quantization and deployment workflow examples.
- claude-skills/docs/skills/engineering-team/senior-ml-engineer.md: production deployment and monitoring discipline.
- awesome-codex-subagents/categories/07-specialized-domains/quant-analyst.toml: scoped specialist-role framing.
- antigravity-awesome-skills/skills/bdistill-knowledge-extraction/SKILL.md: distillation-oriented naming and focus cues.
