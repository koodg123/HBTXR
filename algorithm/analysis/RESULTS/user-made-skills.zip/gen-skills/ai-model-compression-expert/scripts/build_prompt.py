from __future__ import annotations

import argparse


TITLE = 'AI Model Compression Expert'
TASK_AXES = ['Quantization', 'Pruning', 'Distillation', 'Mixed Compression Strategy']
INPUT_FOCUS = ['baseline model size, activation footprint, latency, and task quality', 'target runtime and supported precisions or sparse kernels', 'available calibration data, retraining budget, and teacher models', 'explicit rollback threshold for quality loss or instability']
SUBAGENTS = [{'name': 'compression-strategy-planner', 'inspired_by': ['multi-agent-coordinator', 'knowledge-synthesizer'], 'mission': 'Break the request into the smallest compression experiments that preserve clear attribution for wins and regressions.', 'handoff': ['baseline metrics', 'deployment goal', 'acceptable accuracy drop'], 'returns': ['experiment order', 'sensitive-layer hypotheses', 'compression ladder'], 'revision_trigger': 'Revise when the main prompt bundles too many compression techniques together to diagnose results.'}, {'name': 'runtime-compatibility-analyst', 'inspired_by': ['performance-engineer', 'build-engineer'], 'mission': 'Challenge the prompt against operator support, precision coverage, export semantics, and kernel availability on the target stack.', 'handoff': ['candidate compression path', 'runtime stack', 'export format'], 'returns': ['compatibility risks', 'fallback warnings', 'required target-side checks'], 'revision_trigger': 'Revise when the requested compression path cannot be executed natively on the target runtime.'}, {'name': 'accuracy-retention-critic', 'inspired_by': ['knowledge-synthesizer', 'performance-engineer'], 'mission': 'Interrogate whether calibration, distillation, or partial fine-tuning is sufficient to preserve the agreed quality bar.', 'handoff': ['candidate prompt', 'data budget', 'teacher or fine-tune options'], 'returns': ['accuracy-risk summary', 'recovery options', 'validation slices'], 'revision_trigger': 'Revise when the prompt lacks a realistic plan for recovering quality after aggressive compression.'}]


def bullets(items):
    return "\n".join(f"- {item}" for item in items if item)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Build a prompt pack for {TITLE}.")
    parser.add_argument("--goal", required=True, help="Engineering goal or user ask.")
    parser.add_argument("--route", default=TASK_AXES[0], help="Chosen task route.")
    parser.add_argument("--target", default="", help="Deployment target, runtime, or environment.")
    parser.add_argument("--constraints", nargs="*", default=[], help="Constraint strings.")
    parser.add_argument("--failures", nargs="*", default=[], help="Failure observations.")
    parser.add_argument("--metrics", nargs="*", default=[], help="Metrics or acceptance checks.")
    parser.add_argument("--context", nargs="*", default=[], help="Extra context notes.")
    return parser.parse_args()


def build_main_prompt(args: argparse.Namespace) -> str:
    constraint_lines = args.constraints or ["<fill in constraints>"]
    failure_lines = args.failures or ["<fill in failure evidence>"]
    metric_lines = args.metrics or ["<fill in success metrics>"]
    context_lines = args.context or ["<fill in missing context>"]
    return f"""You are the {TITLE}.
Prioritize prompt generation before solutioning.

Goal:
{args.goal}

Chosen route:
{args.route}

Target environment:
{args.target or '<unspecified>'}

Constraint block:
{bullets(constraint_lines)}

Failure evidence:
{bullets(failure_lines)}

Metrics and acceptance:
{bullets(metric_lines)}

Context notes:
{bullets(context_lines)}

Return:
- revised prompt pack
- ranked solution options
- validation plan
- residual risks"""


def build_subagent_prompts(args: argparse.Namespace) -> list[str]:
    prompts: list[str] = []
    for subagent in SUBAGENTS:
        prompts.append(
            f"""### {subagent['name']}
Mission: {subagent['mission']}
Handoff fields: {', '.join(subagent['handoff'])}
Expected return: {', '.join(subagent['returns'])}
Revision trigger: {subagent['revision_trigger']}

Prompt:
Challenge the draft prompt for {TITLE}.
Goal: {args.goal}
Route: {args.route}
Target: {args.target or '<unspecified>'}
Constraints:
{bullets(args.constraints or ['<fill in constraints>'])}
Failures:
{bullets(args.failures or ['<fill in failure evidence>'])}
Metrics:
{bullets(args.metrics or ["<fill in success metrics>"])}"""
        )
    return prompts


def main() -> None:
    args = parse_args()
    print(f"# {TITLE} Prompt Pack\n")
    print("## Candidate Routes\n")
    print(bullets(TASK_AXES))
    print("\n## Input Focus\n")
    print(bullets(INPUT_FOCUS))
    print("\n## Main Expert Prompt\n")
    print("```text")
    print(build_main_prompt(args).rstrip())
    print("```")
    print("\n## Sub-Agent Prompts\n")
    for prompt in build_subagent_prompts(args):
        print(prompt)
    print("\n## Closed-Loop Revision Gate\n")
    print("- Revise the prompt if routing, feasibility, or verification assumptions are contradicted.")
    print("- Prefer evidence-backed constraints over optimistic wording.")
    print("- Finalize only after the revised prompt still satisfies the original goal.")


if __name__ == "__main__":
    main()
