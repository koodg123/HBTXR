---
name: ai-model-compression-expert
description: "Provide production-grade guidance for AI model compression through quantization, pruning, and distillation. Use when Codex needs to reduce model size, latency, bandwidth, or memory footprint while preserving acceptable task quality on a specific training or deployment stack."
---

# AI Model Compression Expert

## Overview

Treat compression as an end-to-end compatibility problem, not a bag of isolated tricks. Start from the target runtime and failure budget, then choose quantization, pruning, distillation, or mixed strategies that the deployment stack can actually execute.

## Prompt-First Rule

Convert 'make it smaller or faster' requests into a prompt pack anchored to the real runtime, operator coverage, and acceptable accuracy-loss budget.

Start by drafting or mentally simulating the prompt pack in `templates/prompt-template.md` or `scripts/build_prompt.py` before solving the technical problem.

## Use This Skill When

- The user needs to shrink a model for edge, mobile, server cost, or accelerator compatibility reasons.
- You need to choose between PTQ, QAT, structured pruning, sparse deployment, or teacher-student distillation.
- You need a calibration, retraining, or validation plan that connects compression decisions to runtime and quality outcomes.

## Do Not Use This Skill When

- The request is only about training a larger or more accurate model with no deployment or efficiency pressure.
- The target runtime cannot support the proposed compression path and the task is really a compiler or hardware integration issue.

## Closed-Loop Orchestration

1. Draft the prompt pack with scope, constraints, failures, metrics, and deployment context.
2. Route the draft through the domain sub-agents in `sub-agents/manifest.toml`.
3. Merge disagreements into a revised prompt instead of jumping straight to implementation advice.
4. Run the final recommendation through `verification/checklist.md`.
5. Deliver the answer with the prompt artifact, technical recommendation, and unresolved risks separated clearly.

## Start Every Task With

1. Capture the user's ask in one sentence, then rewrite it as an engineering prompt with explicit success criteria.
2. Identify the deployment target, supported precisions, operator coverage, memory budget, latency budget, and throughput target.
3. Establish a clean baseline for model size, activation memory, end-to-end latency, and task quality before compressing anything.
4. Clarify what quality drop is acceptable and whether calibration data or retraining budget is available.
5. Separate weight-only, activation, structural, and teacher-student interventions so the tradeoffs stay measurable.
6. Record what the first closed-loop review should challenge before you finalize any recommendation.

## Task Routing

- **Quantization**: Use for INT8/FP16/INT4 style compression, calibration, activation-range analysis, and hardware-supported precision paths.
- **Pruning**: Use for channel pruning, block pruning, unstructured sparsity, and topology simplification when runtime or memory benefits are realistic.
- **Distillation**: Use for student-model design, teacher signal choice, loss balancing, and accuracy recovery after aggressive compression.
- **Mixed Compression Strategy**: Use when the deployment goal requires combined quantization, pruning, export, and fallback analysis.

For richer routing, prompt strategy, and failure analysis, read `references/production-playbook.md` and `resources/prompt-operations.md`.

## Supporting Files

- `resources/prompt-operations.md` for prompt-design rules, loop gates, and escalation logic.
- `templates/prompt-template.md` for reusable main-expert and sub-agent prompt structure.
- `templates/prompt-bundles/` for production intake, routing, closed-loop, and signoff prompt packs.
- `templates/few-shot/` for thicker request-to-prompt, feedback-loop, and final-answer examples.
- `scripts/build_prompt.py` for a local prompt-pack generator you can run or emulate.
- `examples/good-output.md` and `examples/common-mistakes.md` for output style anchors.
- `verification/checklist.md` for the final quality gate.
- `sub-agents/manifest.toml` and the individual `.toml` files for the role split and feedback-loop contract.
- `references/web-subagent-research.md` for the web-sourced rationale behind the expanded sub-agent set.
- `resources/researcher-overlay-template.md` for adapting the skill to a specific research style.
- `references/researcher-backgrounds.md` for representative researcher profiles tied to this domain.

## Working Mode

1. Draft the prompt pack before selecting the approach so the problem statement is measurable and reviewable.
2. Use the sub-agent loop to challenge routing, runtime or system assumptions, and verification coverage.
3. Profile the baseline and identify whether size, activation memory, bandwidth, or kernel latency is the real bottleneck.
4. Choose the smallest compression strategy that the target compiler/runtime stack supports natively.
5. Test compression layer-sensitivity and quality recovery instead of assuming every block tolerates the same intervention.
6. Define validation gates for offline quality, on-target runtime, numerical stability, and rollback conditions.
7. Return a revised prompt and recommendation only after contradictions or missing evidence are surfaced explicitly.

## Deliverables

- A reusable prompt pack that frames the task, route, constraints, and open questions.
- Problem framing with constraints, assumptions, and success metrics.
- A ranked set of solution options with explicit technical tradeoffs.
- An implementation and validation plan with the next concrete actions.
- Residual risks, missing evidence, and follow-up experiments or measurements.

## Quality Checks

- State missing assumptions explicitly instead of silently filling critical gaps.
- Tie every recommendation to measurable constraints such as latency, memory, throughput, power, area, engineering effort, or validation cost.
- Separate observed evidence from hypotheses and rank unknowns that still need experiments or hardware checks.
- Prefer the smallest credible intervention before proposing a broad redesign.
- Make prompt generation visible in the answer instead of hiding the problem framing step.
- Use the closed-loop feedback to revise assumptions when sub-agents surface contradictions.
- Do not collapse routing, implementation, and verification into one unstructured paragraph.

## Escalate When

- The target hardware/runtime stack is unknown, making compression recommendations likely to fail during deployment.
- The available calibration or retraining dataset is too small or too biased to support safe compression decisions.
- Sparse or low-bit formats are requested even though the serving stack cannot realize the theoretical wins.

## IDEA-Gen Context

For tasks derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, read
`references/idea-gen-context.md` before planning. Use `verification/idea-gen-checklist.md`
to preserve the IDEA-Gen assumptions, target metrics, and validation evidence.

