# IDEA-Gen Context

Phase: P1
Domain: Compiler/Simulator
Parent skill: `dnn-compiler-mlir-tvm`

## Why This Skill Exists

PIM-NPU and DNN compiler work require an explicit pass sequence to make experiments reproducible.

## Worker Capability

Design compiler pass pipelines from graph import through lowering, optimization, scheduling, and code generation.

## Expected Outputs

- Pass pipeline
- IR transition map
- Validation hooks

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the cluster and roadmap notes for `Compiler/Simulator`.
