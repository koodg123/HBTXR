from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for compiler-pass-pipeline-designer.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    args = parser.parse_args()
    print(f"Skill: compiler-pass-pipeline-designer")
    print("Phase: P1")
    print("Domain: Compiler/Simulator")
    print("Parent skill: dnn-compiler-mlir-tvm")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
