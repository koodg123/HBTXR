# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P1

Domain: Compiler/Simulator

Parent skill: dnn-compiler-mlir-tvm

Target model, algorithm, hardware, or dataset:

Constraints:

Assumptions:

Required artifact:

Verification evidence:

Risks and missing inputs:
