# Verification Checklist

- [ ] Skill phase `P1` and domain `Compiler/Simulator` are stated.
- [ ] Parent skill `dnn-compiler-mlir-tvm` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] Pass pipeline is present and traceable.
- [ ] IR transition map is present and traceable.
- [ ] Validation hooks is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] Residual risks and missing inputs are listed.
