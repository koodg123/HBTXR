---
name: agent-hierarchy-runtime-manager
description: "Design and manage Master, Expert Council, Leader, Team, Worker, Evaluator, Artifact Manager, and Skill Pool runtime hierarchies. Use when Codex needs to normalize user intent into an execution hierarchy, define role contracts, coordinate runtime ownership, or connect agent roles to execution DAGs, task cards, verification, and provenance."
---

# Agent Hierarchy Runtime Manager

## Overview

Use this skill for agent hierarchy runtime orchestration. Turn a user request into a role-aware runtime plan with explicit ownership and handoff contracts.

This skill complements agentops, aegis, orchestration, team-agents and should produce reusable artifacts rather than only
free-form advice.

## Prompt-First Rule

Before solving the task, write a compact prompt pack that names the objective, inputs, constraints,
success metrics, and known unknowns. Use `templates/prompt-template.md` or
`scripts/build_prompt.py` when a reusable prompt artifact would help.

## Start Every Task With

1. Restate the user goal as a measurable engineering or research objective.
2. List the source artifacts, constraints, and target deliverables.
3. Identify required skills, roles, and verification evidence.
4. Separate known facts, assumptions, and hypotheses.
5. Decide which output artifact should be produced first.

## Workflow

1. Normalize the user goal into role responsibilities and explicit success criteria.
2. Create or update the relevant role contract, task card, DAG, registry entry, or verification gate.
3. Bind required skills and artifacts before assigning execution.
4. Identify concurrency boundaries, critical path items, and handoff evidence.
5. Return the runtime artifact plus risks, unresolved decisions, and validation steps.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact for agent hierarchy runtime orchestration with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments.

## Supporting Files

- `references/production-playbook.md` for detailed workflow guidance and decision points.
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` for reusable prompt pack structure.
- `templates/prompt-bundles/intake.md` for intake and handoff prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Every role has one owner and one reason to exist.
- Task boundaries are small enough for a Worker and large enough to deliver a coherent artifact.
- Dependencies and verification gates are explicit.
- The plan preserves provenance from input request to final artifact.
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result would depend on external measurements, target hardware, private data, or unavailable tools.
- A recommendation would lock the user into a brittle workflow without validation evidence.

## IDEA-Gen Context

For tasks derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, read
`references/idea-gen-context.md` before planning. Use `verification/idea-gen-checklist.md`
to preserve the IDEA-Gen assumptions, target metrics, and validation evidence.

