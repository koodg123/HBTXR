# Good Output Example

## Prompt Pack

Skill: `agent-hierarchy-runtime-manager`
Objective: Produce a decision-ready artifact for agent hierarchy runtime orchestration.
Constraints: State all tool, data, target, and scope limits.
Verification: Define evidence required for signoff.

## Artifact

Provide structured decisions, ordered steps, tradeoffs, and a validation plan.

## Risks

List uncertain assumptions and the next experiment or source check needed to resolve each one.
