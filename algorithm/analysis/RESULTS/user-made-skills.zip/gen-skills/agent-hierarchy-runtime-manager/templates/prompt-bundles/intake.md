# Intake Prompt Bundle

Use `$agent-hierarchy-runtime-manager` for this request.

1. Normalize the request into a measurable objective.
2. Identify source artifacts and missing inputs.
3. Select required supporting skills.
4. Produce the first usable artifact.
5. Define the verification gate and residual risks.
