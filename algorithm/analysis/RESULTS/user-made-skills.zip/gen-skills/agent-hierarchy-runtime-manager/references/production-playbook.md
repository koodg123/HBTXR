# Production Playbook

## Purpose

This playbook supports `agent-hierarchy-runtime-manager` for agent hierarchy runtime orchestration. It is written for agents that need a
repeatable workflow, not a one-off answer.

## Intake Contract

- Objective: what the user wants changed, analyzed, designed, or generated.
- Inputs: papers, code, diagrams, specs, constraints, datasets, reports, or logs.
- Output format: document, task card, DAG, pseudocode, hardware plan, compiler plan, model, or test plan.
- Success metrics: correctness, traceability, latency, throughput, area, energy, novelty, or acceptance tests.
- Constraints: time, tool availability, target platform, non-goals, compatibility, and validation limits.

## Decision Flow

- Normalize the user goal into role responsibilities and explicit success criteria.
- Create or update the relevant role contract, task card, DAG, registry entry, or verification gate.
- Bind required skills and artifacts before assigning execution.
- Identify concurrency boundaries, critical path items, and handoff evidence.
- Return the runtime artifact plus risks, unresolved decisions, and validation steps.

## Tradeoff Questions

- What decision would be costly to reverse later?
- Which assumption has the highest chance of invalidating the artifact?
- What is the smallest artifact that can be validated now?
- Which existing skill should be bound to this task before execution?

## Output Standard

The output should contain the artifact, evidence, assumptions, risks, and next validation step. Keep
the artifact structured enough for another Worker to use directly.
