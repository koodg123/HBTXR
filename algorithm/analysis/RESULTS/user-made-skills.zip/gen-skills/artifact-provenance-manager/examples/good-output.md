# Good Output Example

## Prompt Pack

Skill: `artifact-provenance-manager`
Objective: Produce a decision-ready artifact for artifact provenance and traceability.
Constraints: State all tool, data, target, and scope limits.
Verification: Define evidence required for signoff.

## Artifact

Provide structured decisions, ordered steps, tradeoffs, and a validation plan.

## Risks

List uncertain assumptions and the next experiment or source check needed to resolve each one.
