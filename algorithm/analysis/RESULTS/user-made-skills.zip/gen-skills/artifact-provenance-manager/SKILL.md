---
name: artifact-provenance-manager
description: "Track artifact ownership, provenance, decisions, evidence, and verification history across research, algorithm reconstruction, hardware design, and agent workflows. Use when Codex needs to manage outputs, link claims to sources, record transformations, or prepare handoffs that preserve why an artifact exists."
---

# Artifact Provenance Manager

## Overview

Use this skill for artifact provenance and traceability. Create auditable artifact records that connect inputs, transformations, decisions, and validation evidence.

This skill complements agentops provenance, documents, github and should produce reusable artifacts rather than only
free-form advice.

## Prompt-First Rule

Before solving the task, write a compact prompt pack that names the objective, inputs, constraints,
success metrics, and known unknowns. Use `templates/prompt-template.md` or
`scripts/build_prompt.py` when a reusable prompt artifact would help.

## Start Every Task With

1. Restate the user goal as a measurable engineering or research objective.
2. List the source artifacts, constraints, and target deliverables.
3. Identify required skills, roles, and verification evidence.
4. Separate known facts, assumptions, and hypotheses.
5. Decide which output artifact should be produced first.

## Workflow

1. Normalize the user goal into role responsibilities and explicit success criteria.
2. Create or update the relevant role contract, task card, DAG, registry entry, or verification gate.
3. Bind required skills and artifacts before assigning execution.
4. Identify concurrency boundaries, critical path items, and handoff evidence.
5. Return the runtime artifact plus risks, unresolved decisions, and validation steps.

## Deliverables

- Prompt pack with task framing, assumptions, and missing inputs.
- Main artifact for artifact provenance and traceability with explicit decisions and tradeoffs.
- Verification checklist with evidence required for signoff.
- Risk list with unresolved assumptions and recommended next experiments.

## Supporting Files

- `references/production-playbook.md` for detailed workflow guidance and decision points.
- `resources/prompt-operations.md` for prompt framing, review loops, and escalation rules.
- `templates/prompt-template.md` for reusable prompt pack structure.
- `templates/prompt-bundles/intake.md` for intake and handoff prompts.
- `scripts/build_prompt.py` for generating a local prompt pack.
- `sub-agents/manifest.toml` for suggested reviewer roles.
- `verification/checklist.md` for the final quality gate.
- `examples/good-output.md` and `examples/common-mistakes.md` for output anchors.

## Quality Checks

- Every role has one owner and one reason to exist.
- Task boundaries are small enough for a Worker and large enough to deliver a coherent artifact.
- Dependencies and verification gates are explicit.
- The plan preserves provenance from input request to final artifact.
- Start with a prompt artifact so assumptions are visible before technical recommendations.
- Escalate missing evidence instead of inventing facts.
- Deliver concrete next actions and residual risks.

## Escalate When

- Required source artifacts or constraints are missing.
- Multiple plausible interpretations would materially change the artifact.
- The result would depend on external measurements, target hardware, private data, or unavailable tools.
- A recommendation would lock the user into a brittle workflow without validation evidence.
