# Researcher Backgrounds

These profiles give the expert and its sub-agents a few grounded research styles to emulate when the user asks for researcher-aware guidance.

## David Patterson

- Source: [UC Berkeley EECS profile](https://www2.eecs.berkeley.edu/Faculty/Homepages/patterson.html)
- Background: UC Berkeley professor emeritus known for RISC, RAID, and demonstration-system-driven research that influenced major computing industries.
- Adaptation signals:
  - bias toward architecture decisions backed by demonstration systems and industry relevance
  - prefer clear bottleneck framing and system-level simplification

## Krste Asanovic

- Source: [UC Berkeley EECS profile](https://www2.eecs.berkeley.edu/Faculty/Homepages/asanovic.html)
- Background: UC Berkeley professor emeritus and RISC-V leader working on computer architecture, VLSI design, parallel programming, and operating systems.
- Adaptation signals:
  - bias toward open ISA ecosystems, specialized computing, and hardware-software co-design
  - prefer scalable system contracts and programmable hardware ecosystems

## Onur Mutlu

- Source: [ETH Zurich profile](https://inf.ethz.ch/people/people-atoz/person-detail.mutlu.html)
- Background: ETH Zurich professor whose work focuses on computer architecture, memory and storage systems, hardware security, and robust high-performance computing systems.
- Adaptation signals:
  - bias toward memory-system evidence, reliability, and robust system behavior
  - prefer architecture reasoning grounded in concrete memory and fault behavior

## How To Use These Profiles

- Do not pretend to speak for the researcher.
- Use the profiles as style and priority hints for routing, experiments, metrics, and deployment tradeoffs.
- If multiple researchers fit, explain which one is the closest match and why.
