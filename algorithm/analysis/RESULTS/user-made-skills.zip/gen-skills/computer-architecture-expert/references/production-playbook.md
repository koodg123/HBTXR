# Production Playbook

## When To Read This File

Read this file when you need more than general 'optimize performance' advice and must reason about CPU/GPU/NPU behavior, memory traffic, and cache hierarchy explicitly.

## Prompt-First Translation

- Primary goal: Turn architecture questions into a prompt pack that names the workload, suspected bottleneck layer, and evidence needed from counters, traces, or memory behavior before redesign advice.
- Always convert the user request into a scoped prompt pack before ranking solutions.
- Capture which sub-agent should challenge the draft first and why.

## Intake Checklist

- Workload type: scalar control-heavy, SIMD/vector, dense tensor, sparse tensor, streaming, or irregular graph-like access.
- Platform and topology: core count, cache levels, memory channels, NUMA, GPU model, NPU type, and host-device links.
- Observed symptom: low IPC, high cache miss, bandwidth saturation, occupancy loss, transfer overhead, or poor scaling.
- Measurement path: perf counters, vendor profilers, timeline traces, power logs, or synthetic microbenchmarks.
- Optimization budget: code changes only, runtime changes, system configuration, or architecture proposal.

## Domain-Specific Prompt Inputs

- workload or kernel shape and throughput target
- platform facts such as CPU, GPU, NPU, memory, and cache topology
- counter, trace, or profiler evidence that points to a bottleneck
- power, cost, or utilization constraints that change the tradeoff

## Routing And Failure Patterns

### Cache thrash or poor locality

- Preferred investigation path: Check working-set size, data layout, traversal order, false sharing, and prefetchability.

### Low GPU utilization

- Preferred investigation path: Check occupancy, launch granularity, memory coalescing, synchronization, and transfer overlap.

### Accelerator underperforms CPU

- Preferred investigation path: Check operator support, partitioning overhead, tiny batch sizes, and host-device copy costs.

### Bandwidth wall

- Preferred investigation path: Check operational intensity, reuse strategy, memory layout, compression/quantization opportunities, and contention sources.

### Scaling stalls with more cores

- Preferred investigation path: Check lock contention, cache coherence traffic, NUMA locality, and work partition imbalance.

## Closed-Loop Review Gates

- Gate 1: Does the draft prompt name the real task route and success metric?
- Gate 2: Did at least one sub-agent challenge feasibility or runtime reality?
- Gate 3: Did at least one sub-agent challenge evidence quality or verification coverage?
- Gate 4: Was the final prompt revised to absorb conflicts instead of merely listing them?

## Common Failure Patterns

- Treating all slowdowns as 'compute too weak' when the real limit is locality or data movement.
- Comparing CPU, GPU, and NPU results without including transfer and runtime overhead.
- Using synthetic microbenchmarks to justify architecture changes that do not match the real workload shape.
- Ignoring power and thermal behavior in sustained workloads.
- Recommending wider compute without proving compute is the limiting resource.
- Ignoring cache, bandwidth, or locality evidence while focusing only on peak TOPS or FLOPs.
- Blending software and hardware causes without marking which layer owns the fix.

## Validation Checklist

- Use a mix of end-to-end measurements and targeted microbenchmarks tied back to the real bottleneck hypothesis.
- When recommending a new target or memory strategy, quantify both best-case benefit and likely integration cost.
- Check whether the proposed optimization helps the common case or only a narrow benchmark slice.
- Document any hardware or firmware assumptions that still need bench-level confirmation.
- The prompt requests or infers evidence at the right hierarchy level.
- One loop pass checks memory or cache interpretation and another checks tradeoff realism.
- Final output clearly separates measured facts from architectural hypotheses.

## Local Reference Anchors

- antigravity-awesome-skills/skills/arm-cortex-expert/SKILL.md: memory, cache, and embedded performance discipline.
- antigravity-awesome-skills/skills/memory-systems/SKILL.md: memory-centric specialist framing.
- antigravity-awesome-skills/skills/cpp-pro/references/memory-performance.md: concrete locality and memory-performance examples.
- awesome-codex-subagents/categories/07-specialized-domains/embedded-systems.toml: hardware-adjacent decision-quality pattern.
