from __future__ import annotations

import argparse


TITLE = 'Computer Architecture Expert'
TASK_AXES = ['CPU and Cache Locality', 'GPU Throughput and Occupancy', 'NPU and Accelerator Placement', 'Memory-System Analysis']
INPUT_FOCUS = ['workload or kernel shape and throughput target', 'platform facts such as CPU, GPU, NPU, memory, and cache topology', 'counter, trace, or profiler evidence that points to a bottleneck', 'power, cost, or utilization constraints that change the tradeoff']
SUBAGENTS = [{'name': 'memory-hierarchy-analyst', 'inspired_by': ['performance-engineer', 'knowledge-synthesizer'], 'mission': 'Anchor the prompt to cache, bandwidth, and locality evidence so architecture advice matches the real bottleneck layer.', 'handoff': ['workload summary', 'platform topology', 'counter evidence'], 'returns': ['memory-side diagnosis', 'counter gaps', 'locality questions'], 'revision_trigger': 'Revise when the prompt leaps to compute scaling without explaining memory behavior.'}, {'name': 'throughput-bottleneck-modeler', 'inspired_by': ['workflow-orchestrator', 'performance-engineer'], 'mission': 'Stress-test whether bottlenecks come from compute width, pipeline utilization, contention, or queueing.', 'handoff': ['candidate hypothesis', 'throughput target', 'observed stalls'], 'returns': ['bottleneck ranking', 'measurement additions', 'smallest next experiment'], 'revision_trigger': 'Revise when the throughput argument lacks enough evidence to rank alternatives.'}, {'name': 'architecture-tradeoff-critic', 'inspired_by': ['knowledge-synthesizer', 'multi-agent-coordinator'], 'mission': 'Challenge whether the recommended architectural change is justified against cost, power, and complexity budgets.', 'handoff': ['candidate prompt', 'budget constraints', 'expected gain'], 'returns': ['tradeoff risks', 'cost realism check', 'fallback recommendation'], 'revision_trigger': 'Revise when the proposal overreaches the stated power or implementation budget.'}]


def bullets(items):
    return "\n".join(f"- {item}" for item in items if item)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Build a prompt pack for {TITLE}.")
    parser.add_argument("--goal", required=True, help="Engineering goal or user ask.")
    parser.add_argument("--route", default=TASK_AXES[0], help="Chosen task route.")
    parser.add_argument("--target", default="", help="Deployment target, runtime, or environment.")
    parser.add_argument("--constraints", nargs="*", default=[], help="Constraint strings.")
    parser.add_argument("--failures", nargs="*", default=[], help="Failure observations.")
    parser.add_argument("--metrics", nargs="*", default=[], help="Metrics or acceptance checks.")
    parser.add_argument("--context", nargs="*", default=[], help="Extra context notes.")
    return parser.parse_args()


def build_main_prompt(args: argparse.Namespace) -> str:
    constraint_lines = args.constraints or ["<fill in constraints>"]
    failure_lines = args.failures or ["<fill in failure evidence>"]
    metric_lines = args.metrics or ["<fill in success metrics>"]
    context_lines = args.context or ["<fill in missing context>"]
    return f"""You are the {TITLE}.
Prioritize prompt generation before solutioning.

Goal:
{args.goal}

Chosen route:
{args.route}

Target environment:
{args.target or '<unspecified>'}

Constraint block:
{bullets(constraint_lines)}

Failure evidence:
{bullets(failure_lines)}

Metrics and acceptance:
{bullets(metric_lines)}

Context notes:
{bullets(context_lines)}

Return:
- revised prompt pack
- ranked solution options
- validation plan
- residual risks"""


def build_subagent_prompts(args: argparse.Namespace) -> list[str]:
    prompts: list[str] = []
    for subagent in SUBAGENTS:
        prompts.append(
            f"""### {subagent['name']}
Mission: {subagent['mission']}
Handoff fields: {', '.join(subagent['handoff'])}
Expected return: {', '.join(subagent['returns'])}
Revision trigger: {subagent['revision_trigger']}

Prompt:
Challenge the draft prompt for {TITLE}.
Goal: {args.goal}
Route: {args.route}
Target: {args.target or '<unspecified>'}
Constraints:
{bullets(args.constraints or ['<fill in constraints>'])}
Failures:
{bullets(args.failures or ['<fill in failure evidence>'])}
Metrics:
{bullets(args.metrics or ["<fill in success metrics>"])}"""
        )
    return prompts


def main() -> None:
    args = parse_args()
    print(f"# {TITLE} Prompt Pack\n")
    print("## Candidate Routes\n")
    print(bullets(TASK_AXES))
    print("\n## Input Focus\n")
    print(bullets(INPUT_FOCUS))
    print("\n## Main Expert Prompt\n")
    print("```text")
    print(build_main_prompt(args).rstrip())
    print("```")
    print("\n## Sub-Agent Prompts\n")
    for prompt in build_subagent_prompts(args):
        print(prompt)
    print("\n## Closed-Loop Revision Gate\n")
    print("- Revise the prompt if routing, feasibility, or verification assumptions are contradicted.")
    print("- Prefer evidence-backed constraints over optimistic wording.")
    print("- Finalize only after the revised prompt still satisfies the original goal.")


if __name__ == "__main__":
    main()
