# Common Mistakes

- Solving the task immediately without producing a prompt pack first.
- Hiding assumptions about environment, data, or hardware instead of listing them.
- Skipping the sub-agent loop and therefore missing contradictions early.
- Ending with a recommendation that has no explicit verification gate.
- Recommending wider compute without proving compute is the limiting resource.
- Ignoring cache, bandwidth, or locality evidence while focusing only on peak TOPS or FLOPs.
- Blending software and hardware causes without marking which layer owns the fix.
