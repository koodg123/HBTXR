# Good Output

## Example Request

Create a prompt pack for a memory-bound transformer inference workload where cache behavior and DRAM traffic dominate more than raw compute throughput.

## Why This Output Is Good

- The prompt names the memory hierarchy and likely stall source.
- The answer asks for concrete counter evidence instead of guessing at cache behavior.
- A sub-agent explicitly tests whether the issue is architectural or just poor locality in software.

## Strong Response Shape

1. Prompt pack that rewrites the request into a measurable engineering objective.
2. Route selection with one-sentence justification.
3. Sub-agent findings summarized by agreement, conflict, and required revision.
4. Revised recommendation with explicit constraints and tradeoffs.
5. Verification plan and residual risks separated from the recommendation itself.
