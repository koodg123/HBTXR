# Sub-Agents

This folder contains Codex-style sub-agent definitions in `.toml` format plus the higher-level manifest.

## Closed-Loop Order

1. Draft the main prompt with `templates/prompt-template.md` or `templates/prompt-bundles/`.
2. Run `memory-hierarchy-analyst.toml` to challenge the draft for `Anchor the prompt to cache, bandwidth, and locality evidence so architecture advice matches the real bottleneck layer.`
3. Run `throughput-bottleneck-modeler.toml` to challenge the draft for `Stress-test whether bottlenecks come from compute width, pipeline utilization, contention, or queueing.`
4. Run `architecture-tradeoff-critic.toml` to challenge the draft for `Challenge whether the recommended architectural change is justified against cost, power, and complexity budgets.`
5. Run `memory-workload-and-occupancy-profiler.toml` to challenge the draft for `Challenge the prompt with hierarchy-level memory, occupancy, and roofline evidence requirements from modern architecture profiling tools.`
6. Run `researcher-background-adapter.toml` to challenge the draft for `Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: David Patterson, Krste Asanovic, Onur Mutlu.`
7. Revise the main prompt and pass it through `verification/checklist.md` before finalizing.

## Files

- `manifest.toml`: role list, feedback-loop stages, and retry rules.
- `memory-hierarchy-analyst.toml`: Anchor the prompt to cache, bandwidth, and locality evidence so architecture advice matches the real bottleneck layer.
- `throughput-bottleneck-modeler.toml`: Stress-test whether bottlenecks come from compute width, pipeline utilization, contention, or queueing.
- `architecture-tradeoff-critic.toml`: Challenge whether the recommended architectural change is justified against cost, power, and complexity budgets.
- `memory-workload-and-occupancy-profiler.toml`: Challenge the prompt with hierarchy-level memory, occupancy, and roofline evidence requirements from modern architecture profiling tools.
- `researcher-background-adapter.toml`: Adapt the draft prompt and recommendation style to the backgrounds of representative researchers in this domain: David Patterson, Krste Asanovic, Onur Mutlu.
