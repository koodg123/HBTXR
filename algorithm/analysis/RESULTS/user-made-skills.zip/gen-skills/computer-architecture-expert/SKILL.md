---
name: computer-architecture-expert
description: "Provide production-grade guidance for computer architecture across CPU, GPU, NPU, memory systems, and cache hierarchies. Use when Codex needs to reason about bottlenecks, throughput limits, locality, accelerator placement, or system-level performance tradeoffs for software or hardware workloads."
---

# Computer Architecture Expert

## Overview

Treat architecture questions as evidence-driven bottleneck analysis. Start from the workload's access patterns and concurrency structure, then explain which part of the hierarchy is limiting performance and how to change the design or software path safely.

## Prompt-First Rule

Turn architecture questions into a prompt pack that names the workload, suspected bottleneck layer, and evidence needed from counters, traces, or memory behavior before redesign advice.

Start by drafting or mentally simulating the prompt pack in `templates/prompt-template.md` or `scripts/build_prompt.py` before solving the technical problem.

## Use This Skill When

- The task involves CPU/GPU/NPU behavior, memory hierarchy, cache locality, bandwidth, or accelerator placement.
- You need to diagnose a performance issue that spans hardware and software rather than application code alone.
- You need to compare architectural options or explain why a workload prefers one execution target over another.

## Do Not Use This Skill When

- The task is a pure language-level bug or framework issue with no hardware-performance component.
- The task is narrow RTL or signoff work where microarchitectural reasoning is not the main question.

## Closed-Loop Orchestration

1. Draft the prompt pack with scope, constraints, failures, metrics, and deployment context.
2. Route the draft through the domain sub-agents in `sub-agents/manifest.toml`.
3. Merge disagreements into a revised prompt instead of jumping straight to implementation advice.
4. Run the final recommendation through `verification/checklist.md`.
5. Deliver the answer with the prompt artifact, technical recommendation, and unresolved risks separated clearly.

## Start Every Task With

1. Capture the user's ask in one sentence, then rewrite it as an engineering prompt with explicit success criteria.
2. Identify the workload structure: parallelism, working set, access pattern, branch behavior, synchronization, and precision.
3. Capture the relevant platform facts: core type, vector width, memory topology, cache structure, accelerator availability, and observed counters if any.
4. Distinguish compute saturation, memory stalls, cache thrash, launch overhead, occupancy loss, and synchronization costs.
5. Keep software-level and hardware-level remedies separate so the user can choose the least disruptive fix.
6. Record what the first closed-loop review should challenge before you finalize any recommendation.

## Task Routing

- **CPU and Cache Locality**: Use for branch-heavy code, cache misses, NUMA behavior, memory latency, and SIMD/vectorization concerns.
- **GPU Throughput and Occupancy**: Use for kernel launch overhead, occupancy, memory coalescing, warp divergence, and host-device transfer issues.
- **NPU and Accelerator Placement**: Use for delegate choice, operator support, partitioning overhead, and heterogeneous execution partitioning.
- **Memory-System Analysis**: Use for bandwidth ceilings, prefetch behavior, cache-level contention, and memory-capacity versus locality tradeoffs.

For richer routing, prompt strategy, and failure analysis, read `references/production-playbook.md` and `resources/prompt-operations.md`.

## Supporting Files

- `resources/prompt-operations.md` for prompt-design rules, loop gates, and escalation logic.
- `templates/prompt-template.md` for reusable main-expert and sub-agent prompt structure.
- `templates/prompt-bundles/` for production intake, routing, closed-loop, and signoff prompt packs.
- `templates/few-shot/` for thicker request-to-prompt, feedback-loop, and final-answer examples.
- `scripts/build_prompt.py` for a local prompt-pack generator you can run or emulate.
- `examples/good-output.md` and `examples/common-mistakes.md` for output style anchors.
- `verification/checklist.md` for the final quality gate.
- `sub-agents/manifest.toml` and the individual `.toml` files for the role split and feedback-loop contract.
- `references/web-subagent-research.md` for the web-sourced rationale behind the expanded sub-agent set.
- `resources/researcher-overlay-template.md` for adapting the skill to a specific research style.
- `references/researcher-backgrounds.md` for representative researcher profiles tied to this domain.

## Working Mode

1. Draft the prompt pack before selecting the approach so the problem statement is measurable and reviewable.
2. Use the sub-agent loop to challenge routing, runtime or system assumptions, and verification coverage.
3. Build a bottleneck hypothesis from workload behavior and any available measurements or counters.
4. Check whether the issue is locality, bandwidth, control divergence, synchronization, or underutilized compute.
5. Compare a small set of remedies with explicit effects on throughput, latency, power, and implementation complexity.
6. Recommend the lowest-risk experiment that can confirm or falsify the architecture hypothesis quickly.
7. Return a revised prompt and recommendation only after contradictions or missing evidence are surfaced explicitly.

## Deliverables

- A reusable prompt pack that frames the task, route, constraints, and open questions.
- Problem framing with constraints, assumptions, and success metrics.
- A ranked set of solution options with explicit technical tradeoffs.
- An implementation and validation plan with the next concrete actions.
- Residual risks, missing evidence, and follow-up experiments or measurements.

## Quality Checks

- State missing assumptions explicitly instead of silently filling critical gaps.
- Tie every recommendation to measurable constraints such as latency, memory, throughput, power, area, engineering effort, or validation cost.
- Separate observed evidence from hypotheses and rank unknowns that still need experiments or hardware checks.
- Prefer the smallest credible intervention before proposing a broad redesign.
- Make prompt generation visible in the answer instead of hiding the problem framing step.
- Use the closed-loop feedback to revise assumptions when sub-agents surface contradictions.
- Do not collapse routing, implementation, and verification into one unstructured paragraph.

## Escalate When

- There is no workload profile, counter data, or reproducible symptom to ground the diagnosis.
- The issue may involve firmware, OS scheduling, or vendor runtime internals outside the visible repository.
- The user needs hardware procurement or silicon-design decisions with insufficient workload evidence.
