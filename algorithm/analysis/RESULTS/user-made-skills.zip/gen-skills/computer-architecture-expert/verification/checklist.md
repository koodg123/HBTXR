# Verification Checklist

## Prompt Pack

- The user request was rewritten into a measurable engineering objective.
- The chosen route is explicit and the nearest rejected route is mentally considered.
- Constraints, failure evidence, and success metrics are stated clearly.

## Closed-Loop Review

- A routing-oriented sub-agent challenged the framing.
- A system or feasibility-oriented sub-agent challenged execution realism.
- A critic sub-agent challenged evidence quality and verification coverage.
- The main prompt was revised after feedback instead of just appending comments.

## Domain Checks

- The prompt requests or infers evidence at the right hierarchy level.
- One loop pass checks memory or cache interpretation and another checks tradeoff realism.
- Final output clearly separates measured facts from architectural hypotheses.

## Final Answer

- The response separates prompt pack, recommendation, validation, and residual risk.
- Unknowns that still require measurement or external validation are explicit.
- The final recommendation is the smallest credible next step, not the broadest redesign.
