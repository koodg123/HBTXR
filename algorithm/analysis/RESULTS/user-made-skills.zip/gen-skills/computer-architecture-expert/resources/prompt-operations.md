# Prompt Operations

## Purpose

Turn architecture questions into a prompt pack that names the workload, suspected bottleneck layer, and evidence needed from counters, traces, or memory behavior before redesign advice.

## Prompt Pack Inputs

- workload or kernel shape and throughput target
- platform facts such as CPU, GPU, NPU, memory, and cache topology
- counter, trace, or profiler evidence that points to a bottleneck
- power, cost, or utilization constraints that change the tradeoff

## Prompt Pack Outputs

- a bottleneck-focused architecture route across compute, memory, cache, and interconnect questions
- a prompt that requests the right counters or measurement evidence
- a tradeoff summary with what to tune first and what to validate later

## Prompt-First Workflow

1. Restate the user ask as an engineering objective with a measurable success condition.
2. Select the closest route from the task-routing options in `SKILL.md`.
3. Fill the prompt template with constraints, failure evidence, target environment, and missing assumptions.
4. Send the draft through the sub-agent loop and revise the prompt pack once contradictions emerge.
5. Use the verification checklist to decide whether the answer is ready or still speculative.

## Closed-Loop Rules

- The main expert owns the final prompt and absorbs sub-agent feedback into a single revised plan.
- If two sub-agents disagree, prefer the path with clearer evidence and state what still needs measurement.
- If verification fails, revise the prompt before adding more solution detail.

## Review Prompts For Sub-Agent Passes

- Ask the routing-oriented sub-agent to challenge task framing and missing context first.
- Ask the system or performance-oriented sub-agent to challenge feasibility on the real stack.
- Ask the critic sub-agent to challenge evidence quality, blind spots, and verification coverage.
