# Researcher Overlay Template

Use this file when the user wants the answer or the sub-agent loop to lean toward a known research style.

## Suggested Researchers For This Skill

- `David Patterson`: UC Berkeley professor emeritus known for RISC, RAID, and demonstration-system-driven research that influenced major computing industries.
- `Krste Asanovic`: UC Berkeley professor emeritus and RISC-V leader working on computer architecture, VLSI design, parallel programming, and operating systems.
- `Onur Mutlu`: ETH Zurich professor whose work focuses on computer architecture, memory and storage systems, hardware security, and robust high-performance computing systems.

## Selection

- Chosen researcher: <fill in>
- Why this researcher fits the request: <fill in>
- Which signals should influence the sub-agent loop: <fill in>

## Adaptation Prompt

```text
You are adapting the Computer Architecture Expert skill to match a representative research style.
Use `references/researcher-backgrounds.md` to pick the closest researcher match.
Adjust route choice, experiment design, metric emphasis, and deployment caution accordingly.
State what comes from the research profile versus what remains general engineering advice.
```
