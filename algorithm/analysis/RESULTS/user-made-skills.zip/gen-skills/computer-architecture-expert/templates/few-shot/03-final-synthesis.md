# Few-Shot: Final Synthesis

## Recommended Answer Shape

1. Prompt pack
2. Sub-agent findings
3. Revised recommendation
4. Verification plan
5. Residual risks

## Example Final Skeleton

```markdown
**Prompt Pack**
- Role: Computer Architecture Expert
- Objective: Turn architecture questions into a prompt pack that names the workload, suspected bottleneck layer, and evidence needed from counters, traces, or memory behavior before redesign advice.
- Chosen route: <best-fit route>
- Constraints: <filled from evidence>

**Sub-Agent Findings**
- Agreement: <what multiple sub-agents agree on>
- Conflict: <what still disagrees>
- Prompt revision: <what changed in the main prompt>

**Recommendation**
- Smallest credible next move with tradeoffs

**Verification**
- The prompt requests or infers evidence at the right hierarchy level.
- One loop pass checks memory or cache interpretation and another checks tradeoff realism.
- Final output clearly separates measured facts from architectural hypotheses.

**Residual Risks**
- What still needs measurement or environment validation
```

## Anti-Pattern To Avoid

- Recommending wider compute without proving compute is the limiting resource.
- Ignoring cache, bandwidth, or locality evidence while focusing only on peak TOPS or FLOPs.
- Blending software and hardware causes without marking which layer owns the fix.
