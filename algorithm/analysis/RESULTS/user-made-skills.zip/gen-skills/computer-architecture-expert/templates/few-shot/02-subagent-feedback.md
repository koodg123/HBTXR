# Few-Shot: Sub-Agent Feedback Loop

## Draft Prompt Excerpt

```text
Goal: Solve the task as a Computer Architecture Expert with the fastest likely path.
Problem: The initial draft has weak constraints and vague verification.
```

## memory-hierarchy-analyst Review

```text
Mission: Anchor the prompt to cache, bandwidth, and locality evidence so architecture advice matches the real bottleneck layer.
Finding:
- Missing handoff context: workload summary
- Missing handoff context: platform topology
- Revision trigger: Revise when the prompt leaps to compute scaling without explaining memory behavior.
```

## architecture-tradeoff-critic Review

```text
Mission: Challenge whether the recommended architectural change is justified against cost, power, and complexity budgets.
Finding:
- Expected return not covered yet: tradeoff risks
- Expected return not covered yet: cost realism check
- Revision trigger: Revise when the proposal overreaches the stated power or implementation budget.
```

## Revised Main Prompt

```text
You are the Computer Architecture Expert.
Revise the prompt using sub-agent feedback before giving any recommendation.
State what changed, why it changed, and what still needs measurement.
End with a verification gate instead of a final-sounding conclusion.
```
