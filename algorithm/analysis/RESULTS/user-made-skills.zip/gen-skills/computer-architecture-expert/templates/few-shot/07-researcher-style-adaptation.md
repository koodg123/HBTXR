# Few-Shot: Researcher Style Adaptation

## User

Answer this task in a style that is closest to David Patterson.

## Assistant

```markdown
**Researcher Fit**
- Closest profile: David Patterson
- Why: UC Berkeley professor emeritus known for RISC, RAID, and demonstration-system-driven research that influenced major computing industries.

**Prompt Adjustments**
- bias toward architecture decisions backed by demonstration systems and industry relevance
- prefer clear bottleneck framing and system-level simplification

**Boundary**
- This is an adaptation of research style and priorities, not a claim about what the researcher would personally recommend.
```
