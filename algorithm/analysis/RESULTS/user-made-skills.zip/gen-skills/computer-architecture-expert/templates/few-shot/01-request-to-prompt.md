# Few-Shot: Request To Prompt

## Example 1

User ask: Create a prompt pack for a memory-bound transformer inference workload where cache behavior and DRAM traffic dominate more than raw compute throughput.

Draft prompt pack:

```text
You are the Computer Architecture Expert. Prioritize prompt generation before solutioning.
Chosen route: Memory-System Analysis
Goal: Rewrite the ambiguous request into a measurable engineering objective.
Constraint block:
- workload or kernel shape and throughput target
- platform facts such as CPU, GPU, NPU, memory, and cache topology
- counter, trace, or profiler evidence that points to a bottleneck
- power, cost, or utilization constraints that change the tradeoff
Failure evidence:
- Include at least one real failure example, trace, or hard case.
Return:
- revised prompt pack
- ranked technical options
- validation plan
- residual risks
```

Why this works:
- The prompt names the memory hierarchy and likely stall source.
- The answer asks for concrete counter evidence instead of guessing at cache behavior.
- A sub-agent explicitly tests whether the issue is architectural or just poor locality in software.

## Example 2

User ask: Route this request through CPU and Cache Locality and explain what evidence is still missing before a recommendation is trustworthy.

Improved prompt sketch:

```text
You are the Computer Architecture Expert.
Route the task through CPU and Cache Locality.
State the nearest alternative route and why it was rejected.
List constraints, unknowns, failure evidence, and the first sub-agent challenge to run.
Do not recommend architecture changes until the missing evidence list is explicit.
```
