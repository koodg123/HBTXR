#!/usr/bin/env python3
"""Sparse event-patch tokenizer for event transformers.

Splits an event tensor [C, H, W] into non-overlapping PxP patches, flattens each
patch to a vector of length C*P*P, and KEEPS only the non-empty (active) patches
as tokens. Empty regions -- which dominate a sparse event field -- are skipped,
shrinking the sequence length the transformer must process. Returns the token
matrix [N_tokens, C*P*P] together with each token's (patch_row, patch_col)
position so spatial position can be preserved through tokenization.

This is the event-specific tokenization step that standard vision transformers
lack: a ViT keeps every patch; an event transformer keeps only active patches.

Definitions
-----------
- A patch is "non-empty" if any element in it is non-zero (configurable via
  --threshold for a count/energy threshold instead of strict non-zero).
- H and W must be divisible by P (the tensor is cropped down to a multiple of P
  if not, with a printed note).
- sparsity_kept = N_tokens / N_total_patches (fraction of patches retained).

Examples
--------
    python patch_tokenize.py --help
    python patch_tokenize.py --demo
    python patch_tokenize.py --demo --patch 4 --channels 2 --height 32 --width 32 --threshold 1.0
"""
from __future__ import annotations

import argparse

import numpy as np


def tokenize(tensor, P, threshold=0.0):
    """Tokenize an event tensor [C,H,W] into active PxP patch tokens.

    Returns (tokens, positions, n_total):
      tokens    -- [N_tokens, C*P*P] float array of kept patches
      positions -- [N_tokens, 2] int array of (patch_row, patch_col)
      n_total   -- total number of patches in the grid (kept + dropped)
    A patch is kept if its summed absolute value is strictly greater than
    `threshold` (threshold=0 means keep any patch with a non-zero element).
    """
    tensor = np.asarray(tensor, dtype=np.float64)
    C, H, W = tensor.shape
    Hc, Wc = (H // P) * P, (W // P) * P
    if (Hc, Wc) != (H, W):
        tensor = tensor[:, :Hc, :Wc]            # crop to a multiple of P
    gh, gw = Hc // P, Wc // P                    # patch-grid dimensions
    n_total = gh * gw

    tokens = []
    positions = []
    for pr in range(gh):
        for pc in range(gw):
            patch = tensor[:, pr * P:(pr + 1) * P, pc * P:(pc + 1) * P]   # [C,P,P]
            if np.abs(patch).sum() > threshold:
                tokens.append(patch.reshape(-1))                          # C*P*P
                positions.append((pr, pc))

    if tokens:
        tok = np.stack(tokens, axis=0)
        pos = np.asarray(positions, dtype=np.int64)
    else:
        tok = np.zeros((0, C * P * P), dtype=np.float64)
        pos = np.zeros((0, 2), dtype=np.int64)
    return tok, pos, n_total


def _demo(args):
    rng = np.random.default_rng(2)
    C, H, W, P = args.channels, args.height, args.width, args.patch
    # fabricate a sparse event tensor: a few active blobs, mostly empty
    tensor = np.zeros((C, H, W), dtype=np.float64)
    n_events = max(1, (H * W) // 20)            # ~5% pixels carry events
    ys = rng.integers(0, H, n_events)
    xs = rng.integers(0, W, n_events)
    cs = rng.integers(0, C, n_events)
    tensor[cs, ys, xs] = rng.normal(1.0, 0.3, n_events)

    tokens, positions, n_total = tokenize(tensor, P, threshold=args.threshold)
    kept = tokens.shape[0]
    print("input event tensor [C,H,W]:", tensor.shape, " patch size P:", P,
          " threshold:", args.threshold)
    print("token-tensor shape [N_tokens, C*P*P]:", tokens.shape,
          " (token dim = C*P*P =", C * P * P, ")")
    print("positions shape [N_tokens, 2]:", positions.shape)
    print(f"patches kept: {kept} / {n_total}  "
          f"-> sparsity_kept = {100.0 * kept / n_total:.1f}% of patches retained")
    print(f"sequence-length reduction vs dense ViT: {n_total} -> {kept} tokens "
          f"({100.0 * (1 - kept / n_total):.1f}% fewer)")
    if kept:
        print("first kept token position (row,col):", tuple(int(v) for v in positions[0]))
        print("first kept token L2 norm:", round(float(np.linalg.norm(tokens[0])), 4))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a synthetic sparse event tensor")
    p.add_argument("--patch", type=int, default=4, help="patch size P (PxP)")
    p.add_argument("--channels", type=int, default=2, help="event tensor channels C")
    p.add_argument("--height", type=int, default=32, help="tensor height H")
    p.add_argument("--width", type=int, default=32, help="tensor width W")
    p.add_argument("--threshold", type=float, default=0.0,
                   help="keep patch if sum|.| > threshold (0 = any non-zero element)")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
