from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for event-transformer-builder.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--variant", default="sparse-patch",
                        help="sparse-patch|patch-embed|relative-attn|bidirectional-attn|spatial-enc-temporal-dec")
    args = parser.parse_args()
    print("Skill: event-transformer-builder")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Transformer variant: {args.variant}")
    print("Pin: patch size, token-selection rule, positional scheme (abs/rel), layers/heads/dim/MLP-ratio, causality.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
