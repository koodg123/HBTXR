---
name: event-transformer-builder
description: Build transformer architectures specialized for event-based eye tracking, including event-specific tokenization and attention variants. Use this whenever the model uses a sparse event-patch representation and a corresponding patch transformer, patch embedding of event tensors, relative or bidirectional positional attention over spatio-temporal event sequences, or a spatial-encoder-plus-temporal-decoder transformer design. Trigger on "build a sparse event-patch transformer", "tokenize events for a transformer", "relative positional attention for events", "bidirectional attention eye tracker", "spatial encoder temporal decoder transformer", or any reproduction whose model is transformer-based on events, even without exact wording. Assumes the representation builder provides the event tensor, and hands attention features to an output head.
---

# Event Transformer Builder

## Overview

Transformers on events are not standard vision transformers: events are sparse, irregular, and carry
strong temporal structure, so the tokenization and positional encoding are where event transformers
differ and where reproductions go wrong. This skill builds those event-specific parts correctly. It is a
P0 IDEA-Gen leaf skill under `Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not
broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/hardware/dataset,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
patch size, token-selection rule, or positional scheme is unknown -- list the missing inputs before
making design choices. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "produce a sparse event-patch tokenizer + transformer feeding head X").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (the event tensor), and downstream consumers (the output head).
3. Separate known facts from assumptions about patch size, positional scheme, layers/heads/dim, and causality.
4. Choose the smallest artifact that unblocks the next Worker: the tokenizer + positional encoding + transformer blocks, with a one-line config spec.
5. Define the evidence required for signoff before producing the artifact (token-tensor shape, sparsity kept, positional scheme, layer/head/dim).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the tokenization and attention variants and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/patch_tokenize.py` to build/validate the sparse event-patch tokenizer and confirm the token count and sparsity (or adapt it to the chosen tokenization).
5. Produce the transformer module with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Reproduce the event-specific tokenization and positional encoding first; the attention stack is more
standard but its causality and configuration still matter.

**Tokenization** (full detail in `references/methods.md`): **sparse event-patch tokens** -- partition the
event field into patches and keep only active (non-empty) patches as tokens, exploiting sparsity to cut
sequence length and compute (reproduce how patches are selected, sized, padded, and how empty regions are
skipped); **patch embedding of event tensors** -- a conv or linear stem projecting patches into token
embeddings (reproduce stem type and stride). Record the token count, patch size, and how spatial position
is preserved.

**Attention variants**: **relative positional attention** -- encode relative spatial/temporal offsets
between tokens, suited to the irregular event layout (reproduce the relative-position parameterization);
**bidirectional attention** -- attend across the full window both directions (implies offline/windowed);
**spatial encoder plus temporal decoder** -- a spatial encoder extracts per-instant geometric features
and a temporal decoder (attention over time) models the sequence (preserve the split and interface).

Details that decide reproduction: positional scheme (absolute vs relative; spatial vs temporal vs joint);
number of layers, heads, embedding dimension, MLP ratio; how sparsity is exploited (token pruning/
selection) and whether attention is full or windowed; causality (bidirectional/offline vs causal/
streaming, kept consistent with evaluation). Match patch size, token-selection rule, positional scheme,
and layer/head/dim configuration exactly, and flag any unstated detail rather than guessing. For
efficiency claims, hand the sparsity accounting to `sparse-event-compute` and `on-device-ai`.

## Deliverables

- A tokenizer, positional encoding, and transformer blocks as modules, returning sequence features for an output head.
- A one-line spec of the variant and ALL configuration (patch size, token-selection rule, positional scheme, layers/heads/dim/MLP-ratio, causality).
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Patch size, token-selection rule, positional scheme, and causality are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The target patch size, token-selection rule, positional scheme, or layer/head/dim is missing.
- Multiple plausible tokenizations or positional schemes would materially change the result.
- Verification depends on unavailable paper detail or reference token tensors.
- The task should be split into a new leaf skill (e.g. a dedicated positional-encoding study).
