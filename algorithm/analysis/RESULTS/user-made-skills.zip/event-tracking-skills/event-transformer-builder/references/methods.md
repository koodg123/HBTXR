# Methods -- Event Transformers

Transformers on events are not standard vision transformers: events are sparse, irregular, and carry
strong temporal structure. Tokenization and positional encoding are where event transformers differ and
where reproductions break. Reproduce those parts first; the attention stack is more standard but its
causality and configuration still matter.

## Tokenization

### Sparse event-patch tokens
Partition the event field into PxP patches and keep only active (non-empty) patches as tokens, exploiting
sparsity to reduce sequence length and compute. Empty regions -- which dominate a sparse event field --
are skipped, so the token count is far below the dense patch grid. Reproduce how patches are selected
(non-zero vs count/energy threshold), how they are sized and padded, and how empty regions are skipped.
- Pin: patch size `P`, selection threshold, padding policy, max-token cap if any.
- Token dimension is `C*P*P` for a `[C,H,W]` event tensor; record the kept-token count and sparsity.

### Patch embedding of event tensors
A convolutional or linear stem projects event-representation patches into token embeddings. Reproduce the
stem type (conv vs linear) and stride; a strided conv stem both embeds and downsamples.
- Pin: stem type, stride, output embedding dimension.

### Position preservation
Record each token's spatial (and temporal) index so position can be re-injected after tokenization. With
sparse tokenization the kept tokens are a subset of the grid, so positions must be carried explicitly.

## Attention variants

### Relative positional attention
Encode relative (rather than absolute) spatial/temporal offsets between tokens, which suits the irregular
event layout. Reproduce the relative-position parameterization (learned bias table vs computed offsets).
- Pin: relative-position scheme, table size / range, spatial vs temporal vs joint.

### Bidirectional attention
Attend across the full window in both directions, capturing context before and after each instant. This
implies an offline/windowed setting -- it cannot run causally online.
- Pin: window length, full vs windowed attention.

### Spatial encoder plus temporal decoder
A CNN or attention spatial encoder extracts per-instant geometric features; a temporal decoder (attention
over time) models the sequence. Preserve the split and the interface (feature shape) between the two.
- Pin: encoder type/output shape, decoder depth, where temporal attention is applied.

## Details that decide reproduction
- Positional encoding scheme: absolute vs relative; spatial vs temporal vs joint.
- Number of layers, heads, embedding dimension, and MLP ratio.
- How sparsity is exploited (token pruning/selection) and whether attention is full or windowed.
- Causality: bidirectional/offline vs causal/streaming, kept consistent with evaluation.

## Choosing quickly
- Sparse event field, want short sequences -> sparse event-patch tokens.
- Reuse a CNN backbone for the stem -> patch embedding (strided conv stem).
- Irregular layout, want translation-aware attention -> relative positional attention.
- Offline windowed accuracy -> bidirectional attention.
- Separate geometry from dynamics -> spatial encoder + temporal decoder.

For efficiency claims, hand the sparsity accounting to `sparse-event-compute` and `on-device-ai`.
