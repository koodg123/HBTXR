# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Event transformers differ from vision transformers exactly at tokenization and positional encoding,
which is where event-based reproductions go wrong. The orchestrator pulls in this skill after the
representation builder, because the transformer consumes an event tensor of known shape and produces the
attention features an output head needs.

## Worker Capability

Build event-specific tokenization (sparse active-patch tokens, patch embedding) and attention variants
(relative positional, bidirectional, spatial-encoder-plus-temporal-decoder) matching the paper.

## Expected Outputs

- A tokenizer, positional encoding, and transformer blocks as modules returning sequence features.
- A one-line spec of the variant and full configuration (patch size, token-selection rule, positional scheme, layers/heads/dim).

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (transformer / architecture cluster).
