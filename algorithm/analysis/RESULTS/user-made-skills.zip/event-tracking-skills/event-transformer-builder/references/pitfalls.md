# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Patch size `P` and the token-selection rule (non-zero vs count/energy threshold).
- Stem type (conv vs linear) and stride for patch embedding.
- Positional scheme: absolute vs relative; spatial vs temporal vs joint.
- Layers, heads, embedding dimension, MLP ratio.
- Attention scope (full vs windowed) and causality (bidirectional/offline vs causal/streaming).

## Failure modes
- **Keeping every patch like a ViT** -> tokenizing densely instead of dropping empty patches loses the
  sparsity advantage and inflates sequence length and compute. Confirm the kept-token count is below the
  dense grid and matches the paper's reported token budget.
- **Wrong token-selection threshold** -> using strict non-zero when the paper uses a count/energy
  threshold (or vice versa) changes which patches survive. Reproduce the exact rule and log sparsity_kept.
- **Lost positions after sparse selection** -> dropping patches without carrying their (row,col) index
  scrambles spatial position. Keep an explicit positions array alongside the tokens.
- **Absolute vs relative positional mismatch** -> a learned absolute table behaves differently from
  relative offsets on the irregular event layout. Reproduce the exact positional parameterization.
- **Bidirectional claimed as online** -> bidirectional attention attends to future tokens and cannot run
  causally; reporting it as streaming/low-latency is wrong. If bidirectional, the setting is offline.
- **Token-dimension drift** -> a `[C,H,W]` tensor gives token dim `C*P*P`; mismatching C, P, or the
  flatten order breaks the embedding stem. Assert the token dimension explicitly.
- **Guessed layer/head/dim** -> silently inventing depth, heads, embedding dim, or MLP ratio the paper
  omits. Flag the missing value to the orchestrator instead of guessing.

## Detection recipe
For any built tokenizer/transformer, log: input tensor shape; patch size; token-tensor shape
`[N_tokens, C*P*P]`; sparsity_kept (N_tokens / N_total_patches); the positions array shape; the positional
scheme; and the layer/head/dim configuration. These catch most reproduction-breaking bugs in event
transformers.
