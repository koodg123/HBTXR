# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The tokenizer / positional encoding / transformer blocks are present and traceable.
- [ ] A one-line variant + full-configuration spec is present.
- [ ] Token-tensor shape [N_tokens, C*P*P] is stated and asserted.
- [ ] Token-selection rule and sparsity_kept (N_tokens / N_total_patches) are reported.
- [ ] Each token's spatial (and temporal) position is preserved.
- [ ] Positional scheme (absolute vs relative) matches the paper.
- [ ] Causality is declared (bidirectional/offline vs causal/streaming) and consistent with evaluation.
- [ ] Residual risks and missing inputs are listed.
