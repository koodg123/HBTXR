# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Transformer variant (sparse-patch / patch-embed / relative-attention / bidirectional-attention / spatial-encoder-temporal-decoder):

Tokenization (patch size P, token-selection rule, padding, stem type/stride, position preservation):

Attention configuration (layers, heads, embed dim, MLP ratio, positional scheme abs/rel, full vs windowed, causality):

Constraints:

Assumptions:

Required artifact:

Verification evidence (token-tensor shape, sparsity kept, positional scheme, layer/head/dim, parity with reference):

Risks and missing inputs:
