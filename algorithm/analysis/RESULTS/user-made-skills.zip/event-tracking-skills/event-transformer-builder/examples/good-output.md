# Good Output

A strong output for `event-transformer-builder` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a sparse event-patch tokenizer + positional encoding + transformer blocks;
a one-line variant + full-configuration spec.

## Worked mini-example

**Objective:** sparse event-patch transformer encoder for a pupil regressor on EV-Eye, windowed offline.

**Spec (one line):**
`sparse event-patch tokens | P=4 | C=2 -> token dim=32 | selection=non-zero | positions kept (row,col) |
relative positional attention | layers=6 heads=4 dim=128 MLP-ratio=4 | attention=full (bidirectional, offline)`

**Module sketch:**
```python
tokens, positions, n_total = tokenize(event_tensor, P=4, threshold=0.0)   # [N,32], [N,2]
assert tokens.shape[1] == 2 * 4 * 4                                        # C*P*P
# embed -> add relative positional bias -> transformer blocks -> sequence features
```

**Validation evidence:** input `[2,32,32]`; token-tensor `[34,32]`; sparsity_kept 53.1% (34/64 patches);
positions `[34,2]`; relative positional scheme; 6 layers / 4 heads / dim 128. Sequence length reduced
64 -> 34 tokens vs a dense ViT.

**Residual risks:** paper does not state the MLP ratio -> assumed 4; flagged for the orchestrator.
