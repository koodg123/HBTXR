# Common Mistakes

- Treating `event-transformer-builder` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing patch size, layers, heads, embedding dim, or MLP ratio without marking assumptions.
- Producing prose without a concrete tokenizer/transformer module another Worker or evaluator can use.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Tokenizing densely like a ViT instead of keeping only active (non-empty) patches, losing the sparsity advantage.
- Dropping each token's (row,col) position after sparse selection, scrambling spatial structure.
- Using absolute positional encoding when the paper uses relative offsets (or vice versa).
- Claiming online/streaming while using bidirectional attention, which attends to future tokens.
