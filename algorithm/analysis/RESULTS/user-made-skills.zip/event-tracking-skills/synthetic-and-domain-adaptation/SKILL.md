---
name: synthetic-and-domain-adaptation
description: Overcome labeled-data scarcity for event-based or near-eye models by generating synthetic data and adapting from synthetic to real, including with unlabeled real recordings. Use this whenever a reproduction relies on synthetic events from video (V2E) or simulation, training on synthetic and finetuning on real, semi-supervised use of unlabeled real data, distilling a foundation or teacher model with synthetic labels plus unlabeled real images, or otherwise bridging a synthetic-to-real domain gap. Trigger on "generate synthetic events for training", "train on synthetic then finetune on real", "use my unlabeled recordings", "bridge the sim-to-real gap", "distill a foundation model for gaze", or any data-scarcity reproduction, even without exact wording. Pairs with the representation builder (it produces the representations) and the training harness (it runs the optimization).
---

# Synthetic Data and Domain Adaptation

## Overview

Event-based eye tracking is chronically short on labeled real data, so many strong results come from a data
strategy rather than a new architecture. Reproducing those results means reproducing the data strategy
faithfully: how synthetic data is generated, how the synthetic-to-real gap is closed, and how unlabeled real
data is exploited. This skill standardizes that. It is a P0 IDEA-Gen leaf skill under
`Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/dataset, assumptions,
expected deliverables, verification evidence). If the task is underspecified -- e.g. the V2E contrast
threshold or the synthetic/real split is unknown -- list the missing inputs before choosing a generation or
adaptation recipe. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "match the adapted-vs-synthetic-only delta on real EV-Eye").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (frame video / rendered eyes / unlabeled real), and downstream consumers (the representation builder and training harness).
3. Separate known facts from assumptions about contrast threshold, noise model, label convention, and the synthetic/real and labeled/unlabeled split.
4. Choose the smallest artifact that unblocks the next Worker: a synthetic-generation config plus an adaptation recipe.
5. Define the evidence required for signoff before producing the artifact (synthetic-only baseline vs adapted result, label-convention parity).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the generation and adaptation menu and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/v2e_stub.py` to generate synthetic events from frame pairs via log-intensity-change thresholding, the core V2E primitive.
5. Produce the synthetic-generation config and adaptation recipe with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Reproduce the data strategy, not just the architecture.

**Synthetic data generation.** *V2E from video*: convert frame video to event streams by thresholding
log-intensity change per pixel; record contrast threshold C, noise/leak model, and frame interpolation,
since these dominate realism and are the parameters that decide whether synthetic events transfer.
*Rendered/simulated eyes*: generate labeled eye images or events with full control of pupil/gaze ground
truth; record renderer settings and label conventions. Always keep synthetic labels in the same target
convention as the real evaluation (pupil center / ellipse / gaze), or define an explicit mapping.

**Synthetic-to-real strategies (pick and document one).** *Train-synthetic then finetune-real*: pretrain on
abundant synthetic, finetune on the small labeled real set; record how much real data and which layers are
unfrozen. *Semi-supervised with unlabeled real*: combine labeled synthetic with unlabeled real via
consistency / pseudo-labeling so the model adapts to real sensor statistics without real labels.
*Distillation from a teacher / foundation model*: a strong (possibly frozen) teacher supervises a small
student on synthetic labels and unlabeled real images, transferring robustness while keeping the student
light. *Feature/style alignment*: match representation-level statistics when finetuning is insufficient.

**Reproduction discipline.** State the exact split between synthetic and real, and what is labeled vs
unlabeled. Report the synthetic-only baseline and the adapted result so the gain from adaptation is visible.
Watch for label-convention mismatches and resolution/representation differences between synthetic and real,
which masquerade as domain gap.

**Honesty rule.** If the real data is proprietary or the synthetic generator is not fully specified, the
absolute numbers may not be matchable; reproduce the method and the relative improvement, and flag the data
dependency explicitly.

## Deliverables

- A synthetic-generation configuration (V2E threshold/noise/interpolation, or renderer settings + label convention).
- An adaptation recipe with the synthetic/real and labeled/unlabeled split, and the synthetic-only-vs-adapted comparison.
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Contrast threshold, noise model, label convention, and the data split are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The V2E parameters, renderer settings, or synthetic/real split are missing.
- Multiple plausible adaptation recipes would materially change the result.
- Verification depends on proprietary real data or an unspecified synthetic generator.
- The task should be split into a new leaf skill (e.g. a dedicated distillation skill).
