# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The synthetic-generation configuration is present and traceable.
- [ ] The adaptation recipe (with split) is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] V2E contrast threshold, noise model, and interpolation are pinned.
- [ ] Label convention is identical (or explicitly mapped) between synthetic and real.
- [ ] The synthetic-only baseline and the adapted result are both reported.
- [ ] Proprietary-data / unspecified-generator dependencies are flagged.
- [ ] Residual risks and missing inputs are listed.
