# Good Output

A strong output for `synthetic-and-domain-adaptation` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a synthetic-generation config; an adaptation recipe with the data split and a
synthetic-only-vs-adapted comparison.

## Worked mini-example

**Objective:** synthetic-event pretraining + real finetune for a CNN pupil regressor, scarce real labels.

**Synthetic-generation config (one line):**
`V2E from rendered eyes | contrast C=0.20 (log) | noise=shot+leak | interp=8x | label=pupil-center (px) |
out=events (x,y,t,p) -> voxel via representation-builder`

**Adaptation recipe:**
`pretrain synthetic (50k clips) -> finetune real (800 labeled clips, unfreeze head + last block, lr=1e-4) |
split: 100% synthetic labeled + 800 real labeled | report synthetic-only vs adapted`

**Comparison (the point of the artifact):**
```
setting          mean-euclid (px)   p10
synthetic-only        4.8           0.71
adapted (finetune)    2.1           0.93   <- gain attributable to adaptation
```

**Validation evidence:** V2E demo on a frame pair gives balanced +/- polarity counts at C=0.20; label
convention identical synthetic/real; synthetic and real built through the same 64x64 voxel encoding.

**Residual risks:** real set is proprietary -> absolute numbers may not be matchable; relative gain
reported and flagged for the orchestrator.
