# Common Mistakes

- Treating `synthetic-and-domain-adaptation` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing the V2E threshold, noise model, or data split without marking assumptions.
- Producing prose without a concrete artifact (generation config + adaptation recipe) a Worker can use.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Setting the contrast threshold by guesswork so synthetic events do not resemble real ones in rate/balance.
- Using different label conventions or resolutions for synthetic and real, then blaming the "domain gap".
- Omitting the synthetic-only baseline, so the adaptation gain is unverifiable.
- Claiming matched absolute numbers on proprietary real data instead of reporting the relative improvement.
