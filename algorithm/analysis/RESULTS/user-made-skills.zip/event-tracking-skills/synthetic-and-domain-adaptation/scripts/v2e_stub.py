#!/usr/bin/env python3
"""Generate synthetic events from a pair of grayscale frames (V2E threshold core).

This implements the core V2E primitive used to turn frames into events: for each pixel
compare the log-intensity of two frames and emit a polarity event when the change crosses
a contrast threshold C.

    delta(x,y) = log(I2(x,y) + eps) - log(I1(x,y) + eps)
    emit (+) event where delta >  C
    emit (-) event where delta < -C

Multiple threshold crossings (|delta| > k*C) optionally emit k events at that pixel, the
behaviour real V2E uses for large brightness jumps. Output is an (x, y, p) event list plus
summary counts. This is the same threshold core that a full V2E pipeline applies between
every interpolated sub-frame; here it runs on a single pair for clarity and testability.

Examples
--------
    python v2e_stub.py --help
    python v2e_stub.py --demo
    python v2e_stub.py --demo --threshold 0.10
"""
from __future__ import annotations

import argparse

import numpy as np


def frames_to_events(frame1, frame2, threshold=0.2, eps=1e-3, multi=True):
    """Convert a grayscale frame pair to synthetic events via log-intensity change.

    Parameters
    ----------
    frame1, frame2 : 2D arrays of intensities (any non-negative scale, e.g. 0..255).
    threshold      : contrast threshold C on the log-intensity change.
    eps            : guard added inside the log so log(0) is finite.
    multi          : if True, emit floor(|delta|/C) events per pixel (large jumps -> more
                     events); if False, at most one event per pixel.

    Returns
    -------
    xs, ys, ps : arrays of event x, y, and polarity (+1 / -1).
    delta      : the per-pixel log-intensity-change map (for inspection).
    """
    f1 = np.asarray(frame1, dtype=np.float64)
    f2 = np.asarray(frame2, dtype=np.float64)
    if f1.shape != f2.shape:
        raise ValueError("frame1 and frame2 must have the same shape")
    f1 = np.clip(f1, 0.0, None)
    f2 = np.clip(f2, 0.0, None)
    delta = np.log(f2 + eps) - np.log(f1 + eps)

    if multi:
        counts = np.floor(np.abs(delta) / threshold).astype(np.int64)
    else:
        counts = (np.abs(delta) > threshold).astype(np.int64)

    ys_idx, xs_idx = np.nonzero(counts > 0)
    xs_list, ys_list, ps_list = [], [], []
    for y, x in zip(ys_idx, xs_idx):
        n = int(counts[y, x])
        pol = 1 if delta[y, x] > 0 else -1
        for _ in range(n):
            xs_list.append(int(x))
            ys_list.append(int(y))
            ps_list.append(pol)
    xs = np.asarray(xs_list, dtype=np.int64)
    ys = np.asarray(ys_list, dtype=np.int64)
    ps = np.asarray(ps_list, dtype=np.int64)
    return xs, ys, ps, delta


def polarity_counts(ps):
    """Return (n_positive, n_negative) for an event polarity array."""
    ps = np.asarray(ps)
    pos = int(np.sum(ps > 0))
    neg = int(np.sum(ps < 0))
    return pos, neg


def _synthetic_frames(h=16, w=16, seed=0):
    """Fabricate two frames: a bright disk that moves and brightens (the 'pupil')."""
    rng = np.random.default_rng(seed)
    base = rng.uniform(20.0, 40.0, size=(h, w))  # noisy dark background
    f1 = base.copy()
    f2 = base.copy()
    yy, xx = np.mgrid[0:h, 0:w]

    def disk(cy, cx, r, val, frame):
        m = (yy - cy) ** 2 + (xx - cx) ** 2 <= r * r
        frame[m] = val
        return frame

    f1 = disk(7, 6, 3, 180.0, f1)   # pupil position in frame 1
    f2 = disk(8, 9, 3, 220.0, f2)   # moved right+down and brighter in frame 2
    return f1, f2


def _demo(args):
    f1, f2 = _synthetic_frames(seed=args.seed)
    xs, ys, ps, delta = frames_to_events(
        f1, f2, threshold=args.threshold, multi=not args.single)
    pos, neg = polarity_counts(ps)
    print("frame shape:", f1.shape, " threshold C:", args.threshold)
    print("delta log-intensity range:", round(float(delta.min()), 3),
          "to", round(float(delta.max()), 3))
    print("total events:", len(ps))
    print("positive (+) events:", pos)
    print("negative (-) events:", neg)
    bal = round(pos / len(ps), 3) if len(ps) else 0.0
    print("positive fraction:", bal)
    print("unique pixels firing:", len(set(zip(xs.tolist(), ys.tolist()))))


def main():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on two synthetic frames")
    p.add_argument("--threshold", type=float, default=0.2, help="contrast threshold C (log)")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--single", action="store_true",
                   help="at most one event per pixel (no multi-crossing)")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
