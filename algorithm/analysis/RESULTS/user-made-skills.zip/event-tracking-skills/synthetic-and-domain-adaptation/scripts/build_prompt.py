from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for synthetic-and-domain-adaptation.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--gen", default="v2e",
                        help="synthetic generation: v2e|rendered-eyes")
    parser.add_argument("--adapt", default="finetune",
                        help="adaptation: finetune|semi-supervised|distillation|feature-alignment")
    args = parser.parse_args()
    print("Skill: synthetic-and-domain-adaptation")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Generation: {args.gen}")
    print(f"Adaptation: {args.adapt}")
    print("Pin: contrast threshold C, noise/leak model, interpolation, label convention,")
    print("synthetic/real and labeled/unlabeled split; report synthetic-only vs adapted.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
