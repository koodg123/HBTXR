# Methods -- Synthetic Data and Domain Adaptation

Event-based eye tracking is chronically short on labeled real data, so many strong results come from a data
strategy rather than a new architecture. Reproducing those results means reproducing the data strategy
faithfully. Each entry below gives the construction, when to use it, and the parameters that must be pinned.

## Synthetic data generation

### V2E from video
Convert a frame video to a realistic event stream. The core primitive: for each pixel, emit a positive
event when log-intensity rises by more than a contrast threshold C since the last event there, and a
negative event when it falls by more than C. Sub-frame timing comes from interpolating between frames.
- When to use: only frame datasets (or rendered eyes) exist, but the model consumes events.
- Pin: contrast threshold C (often per-polarity), noise/leak model (shot noise, leak events,
  threshold mismatch), frame-interpolation factor, and the intensity-to-log mapping.
- The functional script `scripts/v2e_stub.py` implements the threshold core on a frame pair: per-pixel
  `delta = log(I2 + eps) - log(I1 + eps)`, with `+` events where `delta > C` and `-` events where
  `delta < -C`.

### Rendered / simulated eyes
Generate labeled eye images or events with full control of pupil/gaze ground truth. Use a renderer (eye
model + camera) to produce frames, then optionally pass them through V2E.
- When to use: you need dense, exact labels that real data cannot give.
- Pin: renderer settings (eye geometry, lighting, camera), the label convention, and the V2E settings if
  events are derived from rendered frames.

### Label convention
Always keep synthetic labels in the same target convention as the real evaluation (pupil center, ellipse,
gaze), or define an explicit mapping. A convention mismatch is a silent accuracy killer.

## Synthetic-to-real strategies
Pick and document one recipe:

### Train-synthetic then finetune-real
Pretrain on abundant synthetic data, then finetune on the small labeled real set.
- Pin: how much real data is used, which layers are unfrozen, and the finetune learning rate.

### Semi-supervised with unlabeled real
Combine labeled synthetic with unlabeled real via consistency regularization or pseudo-labeling, so the
model adapts to real sensor statistics without real labels.
- Pin: consistency/pseudo-label scheme, confidence threshold, and the labeled:unlabeled ratio.

### Distillation from a teacher / foundation model
A strong (possibly frozen) teacher supervises a small student on synthetic labels and unlabeled real
images, transferring robustness while keeping the student lightweight.
- Pin: teacher identity, what is distilled (logits/features), and the synthetic-label + unlabeled-real mix.

### Feature / style alignment
Reduce the domain gap at the representation level (matching statistics) when finetuning alone is
insufficient.
- Pin: which statistics are aligned and at which layer.

## Reproduction discipline
- State the exact split between synthetic and real, and what is labeled vs unlabeled.
- Report the synthetic-only baseline AND the adapted result so the gain from adaptation is visible.
- Watch for label-convention mismatches and resolution/representation differences between synthetic and
  real, which masquerade as domain gap.

## Honesty rule
If the real data is proprietary or the synthetic generator is not fully specified, the absolute numbers may
not be matchable; reproduce the method and the relative improvement, and flag the data dependency
explicitly.

## Output
Deliver the synthetic-generation configuration, the adaptation recipe (with the synthetic/real and
labeled/unlabeled split), and a before/after comparison (synthetic-only vs adapted). Hand representations to
the representation builder and optimization to the training harness.
