# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Event-based eye tracking is chronically short on labeled real data, so many strong reproductions hinge on a
data strategy -- synthetic generation plus synthetic-to-real adaptation -- rather than a new architecture.
The orchestrator pulls in this skill when a reproduction depends on synthetic events, sim-to-real transfer,
or unlabeled real recordings.

## Worker Capability

Generate synthetic event data (V2E from video or rendered eyes) and adapt from synthetic to real, including
with unlabeled real data, so a model can be reproduced despite labeled-data scarcity.

## Expected Outputs

- A synthetic-generation configuration (V2E threshold/noise/interpolation, or renderer + label convention).
- An adaptation recipe with the synthetic/real, labeled/unlabeled split, and a synthetic-only-vs-adapted comparison.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (data-scarcity / synthetic cluster).
