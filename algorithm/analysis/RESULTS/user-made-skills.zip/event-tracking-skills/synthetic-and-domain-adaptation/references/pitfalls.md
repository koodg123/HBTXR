# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- V2E contrast threshold C (and whether it differs per polarity).
- Noise/leak model: shot noise, leak events, per-pixel threshold mismatch.
- Frame-interpolation factor and the intensity-to-log mapping (and the eps that guards log(0)).
- Label convention (pupil center / ellipse / gaze), identical between synthetic and real evaluation.
- The synthetic/real split and the labeled/unlabeled split; how much real data, which layers unfrozen.

## Failure modes
- **Contrast-threshold mismatch** -> too-low C floods the stream with noise events, too-high C produces a
  near-empty stream; either way synthetic events stop resembling real ones. Detect: print #events and the
  +/- polarity balance and compare to a real recording's event rate.
- **Label-convention mismatch** between synthetic and real -> the model learns the wrong target geometry and
  the "domain gap" is really a labeling bug. Detect/avoid: assert both use the same convention or apply an
  explicit, documented mapping.
- **Resolution/representation drift** between synthetic and real -> coordinates and event density differ,
  inflating the apparent gap. Detect/avoid: build synthetic and real through the same representation builder
  at the same resolution.
- **Missing synthetic-only baseline** -> the adaptation gain is unverifiable; you cannot tell the recipe
  from the architecture. Detect/avoid: always report synthetic-only vs adapted side by side.
- **Forgetting the noise/leak model** -> clean V2E events overfit to artifact-free input and collapse on
  real, noisy sensors. Detect/avoid: include and record a noise model; ablate it.
- **Log of zero / negative intensity** -> NaNs in delta. Detect/avoid: add eps inside the log and clamp
  intensities to a non-negative range.
- **Claiming matched absolute numbers on proprietary real data** -> not reproducible. Detect/avoid: report
  the relative improvement and flag the data dependency.

## Detection recipe
For any synthetic batch, log: #events, +/- polarity counts and balance, event rate vs a real reference, and
the synthetic-only-vs-adapted metric pair. These catch the threshold, label, and baseline mistakes that
break most synthetic reproductions.
