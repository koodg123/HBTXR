# Prompt Template

Objective:

Source artifacts (frame video / rendered eyes / unlabeled real recordings):

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Synthetic-generation method (V2E from video / rendered-simulated eyes):

V2E / renderer parameters (contrast threshold C, noise/leak model, frame interpolation, label convention):

Adaptation recipe (finetune / semi-supervised / distillation / feature alignment):

Data split (synthetic vs real; labeled vs unlabeled; how much real, which layers unfrozen):

Constraints:

Assumptions:

Required artifact:

Verification evidence (synthetic-only baseline vs adapted result, label-convention parity, polarity counts):

Risks and missing inputs:
