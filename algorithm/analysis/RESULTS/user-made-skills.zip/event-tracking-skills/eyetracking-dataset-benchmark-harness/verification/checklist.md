# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The dataset loader + explicit split specification are present and traceable.
- [ ] The metrics module with documented definitions is present and traceable.
- [ ] Metrics or verification evidence are defined.
- [ ] The split records #subjects/sequences/frames and subject-independence.
- [ ] p-accuracy thresholds and the error resolution are stated.
- [ ] Online vs offline evaluation mode is stated.
- [ ] Private-test (non-reproducible) numbers are flagged as such.
- [ ] Residual risks and missing inputs are listed.
