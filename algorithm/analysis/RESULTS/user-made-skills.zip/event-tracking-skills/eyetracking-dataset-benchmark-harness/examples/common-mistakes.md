# Common Mistakes

- Treating `eyetracking-dataset-benchmark-harness` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing the split partition, subject-independence, or metric thresholds without marking assumptions.
- Producing prose without a concrete artifact (loader + split spec + metrics module) a Worker can use.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Letting a subject appear in both train and test while claiming a subject-independent result.
- Comparing p-accuracy or pixel error measured at different thresholds or resolutions as if equivalent.
- Mixing online (streaming) and offline (whole-window) numbers in the same comparison.
- Reporting a private-test / leaderboard score as if it were locally reproduced.
