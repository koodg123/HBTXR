# Good Output

A strong output for `eyetracking-dataset-benchmark-harness` includes a concise objective, source mapping,
explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: a dataset loader + explicit split spec; a metrics module with documented
definitions.

## Worked mini-example

**Objective:** evaluate a pupil-center tracker on 3ET+ public test, subject-independent.

**Split spec (one line):**
`3ET+ | subjects=13 | sequences=156 | train/test subject-independent (no overlap) | public test |
resolution=64x64`

**Metric definitions (one line):**
`p10/p5/p1 = fraction of Euclid dist <= {10,5,1} px @ 64x64 | mean-Euclid = mean pixel distance @ 64x64 |
IoU/F1 = on boolean pupil mask`

**Metrics module sketch:**
```python
m = compute_metrics(pred_xy, gt_xy)            # -> p10, p5, p1, mean_euclidean
iou, f1 = mask_iou_f1(pred_mask, gt_mask)
assert 0.0 <= m["p10"] <= 1.0
```

**Validation evidence:** train/test subject sets asserted disjoint; thresholds and resolution recorded;
evaluation deterministic (seed fixed); metrics.py --demo reproduces p10/p5/p1, mean Euclidean, and IoU/F1
on synthetic preds/gt.

**Residual risks:** AIS2024 private-test number is not locally reproducible -> public-test result reported
and flagged for the orchestrator.
