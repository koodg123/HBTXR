# Methods -- Datasets, Splits, and Metrics

Two reproductions can implement the same model and report different numbers purely because of split and
metric differences. This file catalogs the standard datasets and metric definitions so the harness removes
that ambiguity. Make the dataset, split, and metric explicit and consistent -- it is the precondition for
any honest comparison.

## Common datasets (record exactly what you use)
- **EV-Eye**: large multimodal near-eye set with grayscale frames and events plus pupil/gaze labels;
  supports hybrid and frame/event evaluation.
- **ThreeET-plus (3ET+)**: the event-based eye-tracking challenge benchmark used by many recent trackers.
- **AIS2024 challenge**: event eye-tracking competition with a Kaggle-style public/private test split;
  private-set scores are not locally reproducible.
- **SEET (synthetic)**: synthetic event eye-tracking data, useful where real data is scarce.
- **Ini-30**: DVS eye-tracking set from a small subject pool, used for low-power/SNN evaluation.
- **OpenEDS**: near-eye frame dataset with semantic segmentation labels (pupil/iris/sclera/skin).
- **EyeGraph**: wearable event near-eye set emphasizing real-world conditions and label sparsity.

For each, record the number of subjects, sequences, and frames; the train/val/test partition; and crucially
whether the split is **subject-independent** (no subject in both train and test), since that single choice
often explains large accuracy differences.

## Metric definitions (state the exact form)
- **p-accuracy (p10/p5/p1)**: fraction of predictions whose pupil center is within n pixels of ground truth
  (n = 10, 5, 1). Define n in the dataset's pixel scale. Computed by `scripts/metrics.py` as the fraction of
  Euclidean distances `<= n`.
- **Pixel / Euclidean error**: mean Euclidean distance between predicted and true pupil center; state the
  image resolution it is measured at, because the same error in pixels means different things at different
  resolutions.
- **Mean Euclidean Distance (MED)**: common on challenge leaderboards; identical idea to mean pixel error,
  named per competition.
- **IoU / F1**: for pupil masks or regions (segmentation/occlusion studies). IoU = |A and B| / |A or B|;
  F1 = 2|A and B| / (|A| + |B|) on the binary mask. `scripts/metrics.py` computes both from boolean masks.
- **Angular gaze error**: degrees between predicted and true gaze direction, when the task is gaze rather
  than pupil.

A frequent error is comparing pixel errors measured at different resolutions, or p-accuracy with different
thresholds, as if directly comparable; normalize or clearly scope these.

## Harness structure
Provide:
- a **loader per dataset** returning a uniform sample (representation input plus target in a canonical
  convention -- pupil center / ellipse / gaze / mask);
- a **split definition file** that records the exact partition and subject-independence;
- a **metrics module** computing the exact definitions above.

Keep evaluation deterministic and seed-controlled, and support both offline (whole-window) and online
(streaming) evaluation where the task demands it -- the two can give different numbers for the same model.

## Output
Deliver dataset loaders, an explicit split specification (with subject-independence noted), and a metrics
module with documented definitions. When reproducing a paper, match its split and metric definitions
exactly and hand discrepancies to the fair-benchmarking-auditor and experimental-rigor-stats skills.
