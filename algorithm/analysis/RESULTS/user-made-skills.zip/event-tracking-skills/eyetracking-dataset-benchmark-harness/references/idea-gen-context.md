# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Two reproductions can implement the same model and report different numbers purely because of split and
metric differences. The orchestrator stands up this harness early (Phase 2, before the model) so every
result is measured against a fixed, documented dataset/split/metric and is comparable to the paper.

## Worker Capability

Set up standard event/near-eye eye-tracking datasets, define the exact split, and compute the right metric
with the right definition (p10/p5/p1, mean Euclidean distance, IoU/F1, angular gaze error).

## Expected Outputs

- Dataset loaders + an explicit split specification (subject-independence noted).
- A metrics module with documented definitions matching the target paper exactly.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (dataset/benchmark cluster).
