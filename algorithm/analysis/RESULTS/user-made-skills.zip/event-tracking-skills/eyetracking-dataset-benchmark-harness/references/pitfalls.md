# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Dataset name and version, and the exact #subjects / #sequences / #frames used.
- The train/val/test partition AND whether it is subject-independent.
- Whether the test set is public (locally reproducible) or private (leaderboard-only).
- The p-accuracy thresholds (p10/p5/p1) in the dataset's pixel scale.
- The resolution at which pixel / Euclidean error is measured.
- Online (streaming) vs offline (whole-window) evaluation.

## Failure modes
- **Subject leakage across the split** -> a subject in both train and test inflates accuracy far above the
  paper's subject-independent number. Detect/avoid: assert the train and test subject sets are disjoint when
  the protocol is subject-independent; log the split file.
- **Threshold/resolution mismatch in p-accuracy or pixel error** -> p10 at 64x64 is not p10 at 240x180, and
  comparing them is meaningless. Detect/avoid: record the threshold scale and resolution with every metric;
  normalize before comparing.
- **Naming confusion (MED vs mean pixel error)** -> reporting them as different metrics. Detect/avoid: state
  the formula, not just the name; treat MED as mean Euclidean distance.
- **Non-deterministic evaluation** -> shuffled loaders or unseeded sampling make numbers wobble run to run.
  Detect/avoid: seed everything and fix loader order in eval.
- **Comparing online and offline numbers** -> streaming/causal evaluation usually scores below whole-window
  evaluation; mixing them is unfair. Detect/avoid: state the mode and compare like with like.
- **Reporting a private-test (leaderboard) number as locally reproduced** -> not verifiable. Detect/avoid:
  mark private-set scores as non-reproducible and report the public-set result.
- **IoU/F1 on empty masks** -> a frame with no pupil mask gives 0/0. Detect/avoid: define the empty-mask
  convention (skip, or treat empty-vs-empty as 1.0) and apply it consistently.

## Detection recipe
For any evaluation, log: dataset+version, the split file and subject-disjointness check, the metric formulas
with their thresholds and resolution, the eval mode (online/offline), and the seed. These catch the split
and metric-definition mistakes that make two correct models look different.
