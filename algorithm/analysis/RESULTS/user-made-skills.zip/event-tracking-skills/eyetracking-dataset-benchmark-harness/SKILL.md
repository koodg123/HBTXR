---
name: eyetracking-dataset-benchmark-harness
description: Set up the standard datasets, splits, and evaluation metrics for event-based and near-eye eye tracking so reproductions are measured correctly and comparably. Use this whenever a reproduction needs to load a benchmark (EV-Eye, ThreeET-plus / 3ET+, the AIS2024 challenge, SEET synthetic, Ini-30, OpenEDS, EyeGraph), define the exact split (number of subjects/sequences/frames, subject-independent or not, public vs private test), or compute the right metric with the right definition (p-accuracy such as p10/p5/p1, pixel or Euclidean error, mean Euclidean distance, IoU and F1 for masks, angular gaze error). Trigger on "load EV-Eye", "set up the 3ET+ benchmark", "what split does this dataset use", "compute p10 accuracy", "evaluate with the right metric", or any reproduction whose comparability depends on the data and metric, even without exact wording. Pairs with the rigor and fair-benchmarking skills.
---

# Eye-Tracking Dataset and Benchmark Harness

## Overview

Two reproductions can implement the same model and report different numbers purely because of split and
metric differences. This skill removes that ambiguity by making the dataset, split, and metric definitions
explicit and consistent, which is a precondition for any honest comparison. It is a P0 IDEA-Gen leaf skill
under `Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target dataset/metric, assumptions,
expected deliverables, verification evidence). If the task is underspecified -- e.g. the split partition or
the exact metric threshold is unknown -- list the missing inputs before building the harness. Use
`templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "compute p10/p5/p1 + mean Euclidean on 3ET+ public test").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (raw dataset, representation), and downstream consumers (training harness, rigor/fair-benchmarking skills).
3. Separate known facts from assumptions about #subjects/sequences/frames, subject-independence, public/private test, and metric thresholds/resolution.
4. Choose the smallest artifact that unblocks the next Worker: a loader + split spec + a metrics module.
5. Define the evidence required for signoff before producing the artifact (exact split, exact metric definitions, determinism).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the dataset and metric catalog and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/metrics.py` to compute p-accuracy (p10/p5/p1), mean Euclidean distance, and mask IoU/F1 with the exact definitions.
5. Produce the loader + split spec + metrics module with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Make the dataset, split, and metric explicit -- it is the precondition for honest comparison.

**Datasets (record exactly what you use).** *EV-Eye*: large multimodal near-eye set with grayscale frames
and events plus pupil/gaze labels; supports hybrid and frame/event evaluation. *ThreeET-plus (3ET+)*: the
event-based eye-tracking challenge benchmark used by many recent trackers. *AIS2024 challenge*: event
eye-tracking competition with a Kaggle-style public/private split; private-set scores are not locally
reproducible. *SEET (synthetic)*: synthetic event eye-tracking data, useful where real data is scarce.
*Ini-30*: DVS set from a small subject pool, used for low-power/SNN evaluation. *OpenEDS*: near-eye frame
dataset with semantic segmentation labels (pupil/iris/sclera/skin). *EyeGraph*: wearable event near-eye set
emphasizing real-world conditions and label sparsity. For each, record #subjects, #sequences, #frames; the
train/val/test partition; and crucially whether the split is **subject-independent** (no subject in both
train and test), since that single choice often explains large accuracy differences.

**Metric definitions (state the exact form).** *p-accuracy (p10/p5/p1)*: fraction of predictions whose
pupil center is within n pixels of ground truth; define n in the dataset's pixel scale. *Pixel / Euclidean
error*: mean distance between predicted and true pupil center; state the resolution it is measured at.
*Mean Euclidean Distance (MED)*: common on challenge leaderboards; same idea, named per competition. *IoU /
F1*: for pupil masks or regions (segmentation/occlusion). *Angular gaze error*: degrees between predicted
and true gaze direction when the task is gaze rather than pupil. A frequent error is comparing pixel errors
at different resolutions, or p-accuracy with different thresholds, as if directly comparable; normalize or
clearly scope these.

**Harness structure.** Provide a loader per dataset returning a uniform sample (representation input plus
target in a canonical convention), a split definition file, and a metrics module computing the exact
definitions above. Keep evaluation deterministic and seed-controlled, and support both offline and online
(streaming) evaluation where the task demands it.

## Deliverables

- Dataset loaders returning a uniform sample, plus an explicit split specification (subject-independence noted).
- A metrics module with documented definitions (p10/p5/p1, mean Euclidean, IoU/F1, angular error).
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Split partition, subject-independence, and metric thresholds/resolution are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The dataset split partition, subject-independence, or exact metric definition is missing.
- Multiple plausible split/metric choices would materially change the result.
- Verification depends on a private test set or unavailable dataset access.
- A discrepancy needs the fair-benchmarking-auditor or experimental-rigor-stats skill.
