#!/usr/bin/env python3
"""Eye-tracking evaluation metrics with the exact definitions used in the literature.

Implements the canonical metrics so two reproductions measure the same way:

  * p-accuracy p10/p5/p1 : fraction of predictions whose pupil center is within n
                           pixels of ground truth (n = 10, 5, 1), i.e. fraction of
                           Euclidean distances <= n, in the dataset's pixel scale.
  * mean Euclidean dist  : mean L2 distance between predicted and true pupil center,
                           at a stated resolution (also called MED on leaderboards).
  * mask IoU / F1        : on boolean pupil masks. IoU = |A&B| / |A|B|;
                           F1 = 2|A&B| / (|A| + |B|). Empty-vs-empty -> 1.0.

All inputs are plain numpy arrays so the module has no framework dependency.

Examples
--------
    python metrics.py --help
    python metrics.py --demo
    python metrics.py --demo --n 500
"""
from __future__ import annotations

import argparse

import numpy as np


def euclidean(pred_xy, gt_xy):
    """Per-sample Euclidean distance between predicted and ground-truth (x, y)."""
    pred = np.asarray(pred_xy, dtype=np.float64).reshape(-1, 2)
    gt = np.asarray(gt_xy, dtype=np.float64).reshape(-1, 2)
    if pred.shape != gt.shape:
        raise ValueError("pred and gt must have the same shape (N, 2)")
    return np.sqrt(np.sum((pred - gt) ** 2, axis=1))


def p_accuracy(pred_xy, gt_xy, thresholds=(10.0, 5.0, 1.0)):
    """Return {p<thr>: fraction of distances <= thr} for each threshold (pixel scale)."""
    d = euclidean(pred_xy, gt_xy)
    out = {}
    for thr in thresholds:
        key = "p" + str(int(thr)) if float(thr).is_integer() else "p" + str(thr)
        out[key] = float(np.mean(d <= thr)) if d.size else 0.0
    return out


def mean_euclidean_distance(pred_xy, gt_xy):
    """Mean Euclidean (pixel) distance, a.k.a. MED. State the resolution separately."""
    d = euclidean(pred_xy, gt_xy)
    return float(np.mean(d)) if d.size else 0.0


def mask_iou(pred_mask, gt_mask):
    """Intersection-over-union on boolean masks. Empty-vs-empty returns 1.0."""
    a = np.asarray(pred_mask).astype(bool)
    b = np.asarray(gt_mask).astype(bool)
    if a.shape != b.shape:
        raise ValueError("pred_mask and gt_mask must have the same shape")
    inter = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()
    if union == 0:
        return 1.0  # both empty: perfect agreement by convention
    return float(inter) / float(union)


def mask_f1(pred_mask, gt_mask):
    """Dice / F1 on boolean masks. Empty-vs-empty returns 1.0."""
    a = np.asarray(pred_mask).astype(bool)
    b = np.asarray(gt_mask).astype(bool)
    if a.shape != b.shape:
        raise ValueError("pred_mask and gt_mask must have the same shape")
    inter = np.logical_and(a, b).sum()
    denom = a.sum() + b.sum()
    if denom == 0:
        return 1.0  # both empty
    return 2.0 * float(inter) / float(denom)


def compute_metrics(pred_xy, gt_xy, thresholds=(10.0, 5.0, 1.0)):
    """Bundle the coordinate metrics: p-accuracy + mean Euclidean distance."""
    out = p_accuracy(pred_xy, gt_xy, thresholds)
    out["mean_euclidean"] = mean_euclidean_distance(pred_xy, gt_xy)
    return out


def _demo(args):
    rng = np.random.default_rng(0)
    n = args.n
    # Fabricate ground-truth pupil centers and predictions with small Gaussian error.
    gt = rng.uniform(0, 64, size=(n, 2))
    noise = rng.normal(0, 3.0, size=(n, 2))   # ~3 px std error
    pred = gt + noise
    m = compute_metrics(pred, gt)
    print("samples:", n, " resolution assumed: 64x64 px")
    print("p10:", round(m["p10"], 3),
          " p5:", round(m["p5"], 3),
          " p1:", round(m["p1"], 3))
    print("mean Euclidean distance (px):", round(m["mean_euclidean"], 3))

    # Fabricate boolean pupil masks: a ground-truth disk and a slightly offset prediction.
    h = w = 32
    yy, xx = np.mgrid[0:h, 0:w]
    gt_mask = (yy - 16) ** 2 + (xx - 16) ** 2 <= 6 * 6
    pred_mask = (yy - 17) ** 2 + (xx - 18) ** 2 <= 6 * 6
    print("mask IoU:", round(mask_iou(pred_mask, gt_mask), 3))
    print("mask F1 :", round(mask_f1(pred_mask, gt_mask), 3))


def main():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on synthetic preds/gt")
    p.add_argument("--n", type=int, default=1000, help="number of synthetic samples")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
