from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for eyetracking-dataset-benchmark-harness.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--dataset", default="3ET+",
                        help="EV-Eye|3ET+|AIS2024|SEET|Ini-30|OpenEDS|EyeGraph")
    parser.add_argument("--metric", default="p10,p5,p1,mean-euclidean,iou,f1")
    args = parser.parse_args()
    print("Skill: eyetracking-dataset-benchmark-harness")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Dataset: {args.dataset}")
    print(f"Metrics: {args.metric}")
    print("Pin: #subjects/sequences/frames, subject-independence, public/private test,")
    print("p-accuracy thresholds + scale, error resolution, online vs offline eval.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
