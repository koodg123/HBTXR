# Prompt Template

Objective:

Source artifacts (raw dataset / representation):

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target dataset (EV-Eye / 3ET+ / AIS2024 / SEET / Ini-30 / OpenEDS / EyeGraph):

Split (#subjects/sequences/frames, subject-independent?, public/private test):

Metrics (p10/p5/p1 + threshold scale, mean Euclidean + resolution, IoU/F1, angular gaze error):

Online or offline evaluation:

Constraints:

Assumptions:

Required artifact:

Verification evidence (exact split, exact metric definitions, determinism/seed, resolution):

Risks and missing inputs:
