#!/usr/bin/env python3
"""Spatial soft-argmax heatmap decode plus coordinate and ellipse-angle losses.

Implements the core output-head primitives for pupil localization:
  - soft_argmax: differentiable sub-pixel decode of a 2D heatmap to (x, y).
  - coord_l2:    squared-Euclidean (L2) coordinate loss vs a target.
  - angle_loss:  angle-aware / trigonometric ellipse-orientation loss that is
                 continuous across the theta -> theta + pi wrap-around.

soft-argmax:
    p = softmax(H / T) over all pixels   (T = temperature)
    x = sum_i p_i * x_i,  y = sum_i p_i * y_i
A lower temperature sharpens the distribution toward the peak (accurate sub-pixel
localization); a higher temperature smears it toward the grid centroid (a bias to
watch -- see references/pitfalls.md).

ellipse-angle (trigonometric) loss:
    L = 1 - cos(2 * (theta_pred - theta_gt))
    This is 0 when the predicted orientation equals the target OR differs by pi
    (the same ellipse), avoiding the discontinuity of a raw-angle L2 loss.

Examples
--------
    python soft_argmax.py --demo
    python soft_argmax.py --demo --temperature 1.0
    python soft_argmax.py --help
"""
from __future__ import annotations

import argparse

import numpy as np


def soft_argmax(heatmap, temperature=1.0):
    """Decode a 2D heatmap [H, W] to a sub-pixel (x, y) coordinate.

    Returns (x, y) in pixel units with the same origin as the array indices
    (x = column, y = row).
    """
    H = np.asarray(heatmap, dtype=np.float64)
    h, w = H.shape
    flat = H.reshape(-1) / float(temperature)
    flat = flat - flat.max()                     # numerical stability
    p = np.exp(flat)
    p = p / p.sum()
    p = p.reshape(h, w)
    xs = np.arange(w, dtype=np.float64)
    ys = np.arange(h, dtype=np.float64)
    x = float((p.sum(axis=0) * xs).sum())
    y = float((p.sum(axis=1) * ys).sum())
    return x, y


def gaussian_heatmap(h, w, cx, cy, sigma=2.0):
    """Build a Gaussian target heatmap centered at (cx, cy)."""
    ys, xs = np.mgrid[0:h, 0:w]
    g = np.exp(-(((xs - cx) ** 2 + (ys - cy) ** 2) / (2.0 * sigma * sigma)))
    return g


def coord_l2(pred_xy, target_xy):
    """Squared-Euclidean (L2) coordinate loss."""
    px, py = pred_xy
    tx, ty = target_xy
    return float((px - tx) ** 2 + (py - ty) ** 2)


def coord_euclidean(pred_xy, target_xy):
    """Euclidean distance (the usual pixel-error metric)."""
    return float(np.sqrt(coord_l2(pred_xy, target_xy)))


def angle_loss(theta_pred, theta_gt):
    """Angle-aware trigonometric ellipse-orientation loss in [0, 2].

    L = 1 - cos(2 * (theta_pred - theta_gt)); zero at a 0 or pi offset.
    """
    return float(1.0 - np.cos(2.0 * (theta_pred - theta_gt)))


def _demo(args):
    h, w = args.height, args.width
    cx, cy = 40.0, 24.0                            # true pupil center
    H = gaussian_heatmap(h, w, cx, cy, sigma=args.sigma)
    x, y = soft_argmax(H, temperature=args.temperature)
    target = (38.0, 26.0)                          # a slightly-off ground truth
    l2 = coord_l2((x, y), target)
    eu = coord_euclidean((x, y), target)

    theta_gt = np.deg2rad(30.0)
    theta_pred_good = np.deg2rad(30.0)
    theta_pred_pi = theta_gt + np.pi               # same ellipse, pi offset
    theta_pred_bad = np.deg2rad(75.0)

    print("heatmap shape:", H.shape, " sigma:", args.sigma, " temperature:", args.temperature)
    print("true center:", (cx, cy))
    print("soft-argmax decoded (x, y):", (round(x, 3), round(y, 3)))
    print("coord L2 vs target", target, ":", round(l2, 4))
    print("euclidean (pixel error) vs target:", round(eu, 4))
    print("angle loss (pred == gt):", round(angle_loss(theta_pred_good, theta_gt), 6),
          "(expected ~0)")
    print("angle loss (pred == gt + pi):", round(angle_loss(theta_pred_pi, theta_gt), 6),
          "(expected ~0, wrap-safe)")
    print("angle loss (pred 75 deg vs gt 30 deg):", round(angle_loss(theta_pred_bad, theta_gt), 4))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="build a synthetic Gaussian heatmap and decode it")
    p.add_argument("--height", type=int, default=48)
    p.add_argument("--width", type=int, default=64)
    p.add_argument("--sigma", type=float, default=2.0, help="target Gaussian sigma (pixels)")
    p.add_argument("--temperature", type=float, default=0.05,
                   help="soft-argmax temperature T (low = sharp/accurate; high = centroid bias)")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
