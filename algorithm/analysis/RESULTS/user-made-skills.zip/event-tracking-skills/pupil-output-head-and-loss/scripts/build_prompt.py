from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for pupil-output-head-and-loss.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--head", default="heatmap",
                        help="coordinate|heatmap|ellipse|segmentation|roi-detection")
    parser.add_argument("--loss", default="L2",
                        help="L1|L2|smooth-L1|heatmap-mse|ce+dice|trig-angle|multi-term")
    args = parser.parse_args()
    print("Skill: pupil-output-head-and-loss")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Output head: {args.head}")
    print(f"Loss: {args.loss}")
    print("Pin: target sigma, soft-argmax temperature, ellipse convention+angle loss, loss weights, metric.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
