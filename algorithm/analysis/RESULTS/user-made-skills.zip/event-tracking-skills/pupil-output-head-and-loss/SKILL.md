---
name: pupil-output-head-and-loss
description: Design the output formulation and matching loss for eye-tracking models, choosing among coordinate regression, heatmap regression, ellipse-parameter regression, and semantic segmentation. Use this whenever a reproduction must decide what the model predicts and how it is supervised, spanning direct pupil-center coordinates, a heatmap with soft-argmax decoding plus probabilistic post-processing, pupil ellipse parameters with an angle-aware or trigonometric loss, an eye-region segmentation map, or an RoI/detection output. Trigger on "regress the pupil center", "heatmap head for eye tracking", "predict pupil ellipse parameters", "trigonometric/angle loss for the ellipse", "segmentation head for the eye", "soft-argmax decoding", or any reproduction that hinges on the output head and loss, even without exact wording. Pairs with the training harness (which runs optimization) and the fitting skill (for geometric decoding).
---

# Pupil Output Head and Loss

## Overview

The output formulation is a major design axis that recurs across eye-tracking papers, and the matching
loss is where subtle but decisive choices live: angle wrap-around, heatmap decoding, ellipse conventions,
and multi-term loss weighting. This skill makes the head and loss an explicit, faithful, parameterized
choice rather than an afterthought. It is a P0 IDEA-Gen leaf skill under `Event Eye-Tracking Reproduction`
and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/hardware/dataset,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
heatmap target sigma, soft-argmax temperature, ellipse parameter convention, or loss-term weights are
unknown -- list the missing inputs before making design choices. Use `templates/prompt-template.md` or
`scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "heatmap head, soft-argmax decode -> (x,y), L2 + ellipse-angle loss").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (backbone features), and downstream consumers (training harness, fitting/geometric decode, metrics).
3. Separate known facts from assumptions about head type, decoding parameters, ellipse convention, and loss weighting.
4. Choose the smallest artifact that unblocks the next Worker: a head + loss module plus a one-line prediction-convention spec.
5. Define the evidence required for signoff before producing the main artifact (decoded coordinate, loss values, metric definition consistency).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the head/loss options and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/soft_argmax.py` to decode a heatmap to (x,y) and compute the coordinate L2 and ellipse-angle losses.
5. Produce the head + loss module with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Match the head to the paper's task and downstream use, and keep the loss and metric consistent with it.

**Output formulations.** *Coordinate regression* predicts the pupil center (and optionally size)
directly; simple, supervised with L1/L2/smooth-L1; watch the coordinate normalization. *Heatmap
regression* predicts a spatial likelihood map, decoded with argmax or soft-argmax (differentiable,
sub-pixel), optionally with probabilistic post-processing over the distribution; supervised with a
per-pixel loss against a Gaussian target -- reproduce the temperature and target sigma. *Ellipse-parameter
regression* predicts center, axes, and orientation end to end for downstream geometric trackers; the
orientation needs an angle-aware loss -- a trigonometric loss supervises sine/cosine (or equivalent)
rather than the raw angle to avoid the wrap-around discontinuity -- and the parameter convention (axis
order, angle range) must be reproduced. *Semantic segmentation* predicts per-pixel eye-region classes
(pupil/iris/sclera/skin), from which the pupil is derived; supervised with cross-entropy plus
boundary/region-aware terms -- reproduce the class set and auxiliary losses. *RoI / detection* predicts a
region of interest to gate or localize the pupil, often to cut downstream compute.

**Choosing the head.** Segmentation for region labeling; ellipse for geometric trackers; heatmap for
robust sub-pixel localization; coordinate for the simplest regressors. The head also sets the metric
(center error, IoU/F1, angular), so keep loss and metric consistent.

**Loss details that decide reproduction.** Coordinate/heatmap: distance type, normalization, target
sigma, soft-argmax temperature. Ellipse: parameter convention and the exact angle-aware (trigonometric)
formulation. Segmentation: class weighting and auxiliary boundary/region terms. Multi-term losses: the
weighting between terms, which is frequently decisive and often under-specified in papers -- pin it or
flag it.

## Deliverables

- An output head and its matching loss as modules, with the prediction convention explicit.
- Any decoding (soft-argmax temperature, ellipse decode, segmentation->pupil) made explicit.
- A one-line spec of head type, decoding parameters, and loss weights.
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Target sigma, soft-argmax temperature, ellipse convention, and loss weights are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- The loss and the reported metric are consistent with the chosen head.

## Escalate When

- The head type, decoding parameters, ellipse convention, or loss weights are missing.
- Multiple plausible heads/losses would materially change the result.
- Verification depends on unavailable paper detail or reference predictions.
- The task should be split into a new leaf skill (e.g. a dedicated segmentation-post-processing skill).
