# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Output head (coordinate / heatmap / ellipse-parameter / segmentation / RoI-detection):

Decoding (argmax / soft-argmax temperature, ellipse decode, segmentation -> pupil):

Heatmap parameters (target sigma, soft-argmax temperature, post-processing):

Ellipse convention (center, axis order, angle range) and angle-aware/trigonometric loss form:

Loss terms and weights (distance type, class weighting, auxiliary terms, multi-term weights):

Metric (center error / IoU / F1 / angular) -- must be consistent with the head:

Constraints:

Assumptions:

Required artifact:

Verification evidence (decoded coordinate, loss values, loss-metric consistency):

Risks and missing inputs:
