# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The output head + matching loss module is present and traceable.
- [ ] A one-line head / decoding / loss-weight spec is present.
- [ ] The prediction convention (what each output means) is explicit.
- [ ] Heatmap target sigma and soft-argmax temperature are stated (or flagged) when a heatmap is used.
- [ ] Ellipse uses an angle-aware/trigonometric loss; angle loss is ~0 at a pi offset.
- [ ] Coordinate normalization is consistent between training and the reported metric.
- [ ] The loss and the reported metric are consistent with the chosen head.
- [ ] Every multi-term loss weight is stated or marked as an assumption.
- [ ] Residual risks and missing inputs are listed.
