# Good Output

A strong output for `pupil-output-head-and-loss` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: an output head + matching loss module; a one-line head/decoding/loss spec.

## Worked mini-example

**Objective:** heatmap head for a CNN pupil localizer on EV-Eye, soft-argmax decode, L2 + ellipse-angle loss.

**Spec (one line):**
`head=heatmap [1,H,W] | target sigma=2.0 px | decode=soft-argmax (T=1.0) | coord loss=L2 (pixels) |
ellipse angle loss=1-cos(2*dtheta) | weights: coord=1.0, angle=0.5 | metric=center px error`

**Module sketch:**
```python
H = model(features)                       # heatmap logits [H, W]
xy = soft_argmax(H, temperature=1.0)      # differentiable sub-pixel coordinate
loss = l2(xy, xy_gt) + 0.5 * angle_loss(theta_pred, theta_gt)   # trig angle loss, wrap-safe
```

**Validation evidence:** synthetic Gaussian peak at (40,24) decoded to (40.0, 24.0); coordinate L2 to a
target (38,26) = 8.0; ellipse-angle loss at a pi offset ~= 0 (wrap-safe). Metric (pixel error) is
consistent with the coordinate loss.

**Residual risks:** paper does not state the soft-argmax temperature -> assumed `T=1.0`; coord/angle
weight assumed 1.0/0.5 -> flagged for the orchestrator with a sensitivity note.
