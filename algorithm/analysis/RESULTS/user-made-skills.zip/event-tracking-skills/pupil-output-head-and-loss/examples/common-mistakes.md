# Common Mistakes

- Treating `pupil-output-head-and-loss` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing target sigma, soft-argmax temperature, ellipse convention, or loss weights without flagging.
- Producing prose without a concrete head + loss module another Worker or evaluator can run.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Using a raw-angle loss for ellipse orientation, which breaks at the angle wrap-around.
- Picking a soft-argmax temperature blindly so the decoded coordinate is biased toward the center.
- Mismatching coordinate normalization between training and the reported pixel-error metric.
- Reporting a metric (IoU vs center error) that is inconsistent with the chosen head and loss.
- Leaving multi-term loss weights unstated and unmarked, hiding a decisive hyperparameter.
