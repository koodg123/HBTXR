# Methods -- Pupil Output Heads and Losses

The output formulation decides what the model predicts; the matching loss decides how it is supervised.
Both must match the paper, and the head also fixes the metric. Each section gives the construction, when
to use it, the matching loss, and the parameters that must be pinned.

## Coordinate regression
Predict the pupil center `(x, y)` (and optionally size/radius) directly as a small vector.
- Loss: L1, L2 (squared Euclidean), or smooth-L1 (Huber) on the coordinate distance.
- Watch coordinate normalization: predict in pixels, in `[0,1]` of the ROI, or in `[-1,1]`? Train and
  eval must use the same convention, and the metric (pixel error) must be de-normalized consistently.
- Pin: distance type, coordinate normalization, whether size is also regressed.

## Heatmap regression
Predict a spatial likelihood map `H` over the image for the pupil center, then decode a coordinate.
- Decoding: hard argmax (non-differentiable, integer-pixel) or soft-argmax (differentiable, sub-pixel):
  `p = softmax(H / T)` over pixels, then `x = sum_i p_i * x_i`, `y = sum_i p_i * y_i`. The temperature
  `T` sharpens (`T<1`) or smooths (`T>1`) the distribution.
- Probabilistic post-processing: treat the softmax map as a distribution and report its mean/mode and
  spread (uncertainty), or refine with a local window around the peak.
- Supervision: per-pixel loss (MSE or KL/cross-entropy) against a Gaussian target centered at the
  ground-truth coordinate with standard deviation `sigma` (the target sigma).
- Pin: target `sigma`, soft-argmax temperature `T`, the per-pixel loss type, the heatmap resolution, and
  any post-processing.

## Ellipse-parameter regression
Predict the pupil ellipse end to end: center `(cx, cy)`, axes `(a, b)`, and orientation `theta`. Directly
usable by downstream ellipse/geometric trackers.
- Angle wrap-around: `theta` and `theta + pi` describe the same ellipse, so a raw-angle L2 loss is
  discontinuous at the wrap boundary and penalizes equivalent orientations.
- Angle-aware / trigonometric loss: supervise `(sin 2*theta, cos 2*theta)` (or `(sin theta, cos theta)`
  for full-circle conventions) instead of the raw angle, which is continuous across the wrap. Equivalent
  forms penalize `1 - cos(2*(theta_pred - theta_gt))` or the chord distance between unit vectors.
- Pin: the parameter convention (axis order major/minor, the angle range and reference axis), the exact
  angle-aware formulation, and the relative weight of center vs axes vs angle terms.

## Semantic segmentation
Predict per-pixel eye-region classes (e.g. pupil / iris / sclera / skin); derive the pupil from the
pupil-class mask (centroid or fitted ellipse).
- Loss: cross-entropy (optionally class-weighted for the small pupil class) plus auxiliary boundary or
  region-aware terms (Dice, boundary loss) that the paper may add.
- Metric: IoU and/or F1 on the mask, plus any derived center error.
- Pin: the class set, class weighting, and every auxiliary loss term.

## RoI / detection
Predict a region of interest (bounding box or coarse location) to gate or localize the pupil, often to
reduce downstream compute (crop then regress at higher resolution).
- Loss: box regression (IoU / L1) plus an objectness/classification term as in standard detectors.
- Pin: the box parameterization and the gating policy (how the RoI feeds the downstream head).

## Multi-term losses
Most heads above combine several terms (e.g. heatmap MSE + soft-argmax coordinate L2, or ellipse center +
axes + angle). The weighting between terms is frequently decisive and often under-specified in papers.
- Pin: every term weight; if a weight is unstated, mark it as an assumption and note the sensitivity.

## Choosing quickly
- Region labeling / multi-structure -> segmentation.
- Downstream geometric/ellipse tracker -> ellipse-parameter regression with a trigonometric angle loss.
- Robust sub-pixel localization -> heatmap + soft-argmax.
- Simplest, lowest-overhead regressor -> direct coordinate regression.
- Compute budget tight, large frame -> RoI/detection gate then a finer head.
