# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Head type and the prediction convention (what each output channel means).
- Coordinate normalization (pixels vs `[0,1]` vs `[-1,1]`) and how the metric de-normalizes it.
- Heatmap target sigma, soft-argmax temperature, per-pixel loss type, heatmap resolution.
- Ellipse parameter convention (axis order, angle range, reference axis) and the angle-aware loss form.
- Segmentation class set, class weighting, and auxiliary boundary/region terms.
- Every multi-term loss weight (or an explicit assumption if unstated).

## Failure modes
- **Angle wrap-around** -- using a raw-angle L2 loss for ellipse orientation penalizes `theta` vs
  `theta + pi` even though they are the same ellipse, and is discontinuous at the wrap boundary. Detect
  by checking the loss is near zero when prediction differs from target by exactly pi; fix with a
  trigonometric `(sin 2theta, cos 2theta)` loss. The functional script demonstrates this.
- **Soft-argmax temperature wrong** -- too high smears the distribution (biased toward the center,
  blurry localization); too low collapses to near-argmax (loses sub-pixel benefit and gradient). Detect
  by checking the decoded coordinate matches a known Gaussian peak; sweep `T` if the paper omits it.
- **Target sigma mismatch** -- the Gaussian target width controls how sharp the model must be; a
  different sigma changes both training difficulty and the effective localization precision. Pin it.
- **Coordinate-normalization mismatch** -- training in `[0,1]` but reporting pixel error without
  de-normalizing (or vice versa) silently scales the error. Confirm one convention end to end.
- **Loss-metric inconsistency** -- supervising a heatmap but reporting only IoU, or supervising
  segmentation but reporting only center error, makes the loss and metric measure different things. Keep
  them consistent with the head.
- **Ellipse axis-order ambiguity** -- swapping major/minor axes or changing the angle reference flips
  `theta` by 90 degrees. Pin the convention and verify a round-trip (encode then decode) is identity.
- **Multi-term weight guessing** -- inventing the relative weight of heatmap vs coordinate, or center vs
  angle terms, without flagging it. State assumed weights and note sensitivity.
- **Class imbalance in segmentation** -- the pupil is a small fraction of pixels; unweighted
  cross-entropy under-trains it. Use class weighting or Dice and report per-class IoU.

## Detection recipe
For any built head, log: the decoded coordinate vs a known target, every loss-term value (and that the
angle loss is ~0 at a pi offset), the coordinate-normalization convention, and that the reported metric
matches the head. These catch most head/loss reproduction bugs.
