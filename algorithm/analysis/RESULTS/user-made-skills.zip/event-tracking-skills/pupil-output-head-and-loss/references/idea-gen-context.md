# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

What an eye-tracking model predicts -- a coordinate, a heatmap, ellipse parameters, or a segmentation
map -- and how it is supervised is a recurring design axis where small, under-specified choices (target
sigma, soft-argmax temperature, ellipse angle convention, loss weights) decide whether a reproduction
matches its numbers. The orchestrator pulls in this skill to make the head and loss an explicit, faithful
choice, alongside the training harness that runs optimization and the fitting skill that decodes geometry.

## Worker Capability

Choose and implement the output head (coordinate / heatmap / ellipse-parameter / segmentation / RoI) and
its matching loss, with decoding (soft-argmax, ellipse decode) and the prediction convention pinned, so
loss and metric stay consistent.

## Expected Outputs

- An output head + matching loss as modules, with the prediction convention explicit.
- A one-line spec of head type, decoding parameters, and loss weights.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (output-head / supervision cluster).
