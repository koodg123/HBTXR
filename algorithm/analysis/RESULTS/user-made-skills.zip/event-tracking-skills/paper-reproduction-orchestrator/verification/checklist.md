# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-research` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] A filled reproduction spec (all slots) is present and traceable.
- [ ] A dependency-ordered leaf-skill call plan is present.
- [ ] Metrics or verification evidence are defined.
- [ ] KNOWN GAPS are listed explicitly, not silently filled.
- [ ] The metric harness is scheduled before the model build.
- [ ] The dataset split is stated and asserted subject-independent if the paper requires it.
- [ ] The reproduction log changes one variable per row (target vs obtained).
- [ ] Residual risks and missing inputs are listed.
