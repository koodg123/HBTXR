# Common Mistakes

- Treating `paper-reproduction-orchestrator` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing target hardware/workload/metrics/measurements without marking assumptions or gaps.
- Producing prose without a concrete artifact (spec / call plan / log) another Worker or evaluator can use.
- Ignoring the parent skill `paper-research` and duplicating higher-level planning.
- Filling unstated hyperparameters silently instead of recording them as KNOWN GAPS.
- Building the model before the metric harness, so you train blind and cannot attribute changes.
- Chasing a number by changing the architecture before re-reading the spec and probing one gap at a time.
- Reporting a private-test / leaderboard number as if it were locally reproducible.
