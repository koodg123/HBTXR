# Good Output

A strong output for `paper-reproduction-orchestrator` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a filled reproduction spec with known gaps; a dependency-ordered leaf-skill call
plan; a target-vs-obtained reproduction log.

## Worked mini-example

**Objective:** reproduce an event-transformer pupil tracker to match Table 2 p10 on 3ET+ (subject-independent).

**Reproduction spec (excerpt):**
```
task=pupil-center (px)        dataset=3ET+ split=subject-independent (public test)
representation=voxel B=8 2ch  arch=event-transformer d=128 heads=4 depth=6
losses=L2(center) w=1.0       train=AdamW lr=3e-4 cosine 100ep bs=32 seed=0
eval=p10/p5/p1 + mean-euclid  headline=Table2: p10=0.97
KNOWN GAPS: crop origin; augmentation list; exact lr warmup
```

**Leaf-skill call plan:**
`event-representation-builder -> eyetracking-dataset-benchmark-harness -> event-transformer-builder ->
pupil-output-head-and-loss -> eyetracking-training-harness -> ablation-and-experiment-designer`

**Reproduction log (excerpt):**
```
row  change                target_p10  obtained_p10  note
1    baseline (spec)       0.97        0.93          gap suspected: window len
2    window 20ms->40ms     0.97        0.96          closer; matches paper text
```

**Validation evidence:** spec has all slots + 3 listed gaps; harness stood up before model; split asserted
subject-independent; log has one variable per row.

**Residual risks:** crop origin unstated -> assumed sensor-centered; flagged. Private-test number not
locally reproducible; reported public-test result instead.
