# Prompt Template

Objective:

Source artifacts (paper PDF / prior spec):

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-research

Target model, algorithm, hardware, or dataset:

Reproduction-spec slots to fill (task/output, dataset+split, representation, architecture, losses, training, evaluation, headline numbers, known gaps):

Leaf-skill call plan (which building-block skills, in what order):

Constraints:

Assumptions:

Required artifact:

Verification evidence (spec completeness, gap list, target-vs-obtained log):

Risks and missing inputs:
