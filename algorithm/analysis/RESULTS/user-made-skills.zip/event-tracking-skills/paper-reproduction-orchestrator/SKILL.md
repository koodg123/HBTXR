---
name: paper-reproduction-orchestrator
description: Reproduce a machine-learning paper from scratch by turning the PDF into a structured reproduction spec, scaffolding a runnable repository, then training, evaluating, and matching the paper's tables and figures. Use this whenever the goal is to re-implement or replicate a paper end to end (model design, data pipeline, training recipe, evaluation, and ablations) starting from little or nothing, especially for event-based or near-eye eye-tracking work but applicable to any deep-learning paper. Trigger on "reproduce this paper", "re-implement X from scratch", "replicate the results in this PDF", "build a repo that matches this method", or "I want to redo this paper's experiments", even without exact wording. This is the umbrella skill that coordinates the representation, model-family, training, benchmark, and ablation skills; consult it first, then pull in the specific building-block skills it points to.
---

# Paper Reproduction Orchestrator

## Overview

Reproducing a paper fails most often not on the model but on everything around it: an undocumented data
split, a representation detail, a loss term, an evaluation protocol. This skill imposes a disciplined order
so reproduction is a controlled process with explicit gaps, not a guess -- it is the conductor that parses
the paper into a spec, then pulls in the specialized leaf skills in dependency order. It is a P0 IDEA-Gen
umbrella skill under `Event Eye-Tracking Reproduction` and produces Worker-sized artifacts (a spec, a
scaffold plan, a reproduction log), not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source paper/PDF, target model/hardware/dataset,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
headline numbers to match or the dataset split are unknown -- list the missing inputs before scaffolding.
Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "match Table 2 p10 within 1 pixel on 3ET+").
2. Identify the parent skill (`paper-research`), upstream artifacts (the PDF/spec), and downstream consumers (the leaf builder skills).
3. Separate known facts from assumptions about model, data, representation, training, evaluation, and metrics.
4. Choose the smallest artifact that unblocks the next Worker: a filled reproduction spec and a dependency-ordered call plan.
5. Define the evidence required for signoff before producing the artifact (spec completeness, gap list, target-vs-obtained log).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the phase-by-phase orchestration recipe and `references/pitfalls.md` for the failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/repro_spec.py` to emit a structured reproduction-spec JSON skeleton (model/data/representation/training/evaluation/ablation/metrics slots).
5. Produce the primary artifact -- the filled spec plus a leaf-skill call plan -- with explicit inputs, constraints, decisions, and known gaps.
6. Map the artifact to `verification/checklist.md`, then return provenance (source paper, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Reproduction proceeds in phases; do not skip ahead.

**Phase 0 -- Extract the spec.** Read the paper and fill a single spec before writing code; mark anything
missing as an explicit GAP rather than inventing it. Slots: task and output (pupil center / ellipse / gaze
/ segmentation, with units); dataset(s) and split (name, #subjects/sequences/frames, subject-independent?,
public/private); input representation (encoding, resolution, temporal window, normalization); architecture
(backbone, blocks, depths, dims, heads, recurrence/SSM, params); losses (each term + weight); training
(optimizer, lr, schedule, epochs, batch, augmentation, seeds); evaluation (metrics + exact definitions,
online/offline, latency conditions); headline numbers to match (table/figure refs); KNOWN GAPS.

**Phase 1 -- Scaffold.** Clean structure for reproducible experiments: `data/`, `representations/`,
`models/`, `losses/`, `train.py`, `eval.py`, `configs/` (one YAML per experiment, all hyperparameters),
`results/`. Seed everything and log configs with results.

**Phase 2 -- Build bottom-up, delegating to leaf skills.** In dependency order: (1) data + representation
(event-vision-data-pipeline, event-representation-builder; synthetic-and-domain-adaptation if synthetic/
unlabeled data); (2) benchmark + metrics harness (eyetracking-dataset-benchmark-harness) so you measure
from day one; (3) model family (spatiotemporal-recurrent-ssm-builder, event-transformer-builder,
point-and-graph-event-builder, or snn-neuromorphic-builder); (4) output head + loss
(pupil-output-head-and-loss; online-pupil-fitting-and-gaze-mapping for geometric pipelines); (5) training
harness (eyetracking-training-harness); efficiency (sparse-event-compute, on-device-ai) where relevant.

**Phase 3 -- Match, then close gaps.** Run eval against headline numbers. When you miss: re-check the spec
for a misread detail before changing the model; probe known gaps one at a time (usual culprits:
representation window, normalization, split, loss weighting, augmentation); keep a reproduction log of
target vs obtained per metric and what each change did.

**Phase 4 -- Ablations and reporting.** Use ablation-and-experiment-designer to reproduce ablations and
experimental-rigor-stats / fair-benchmarking-auditor for distributions, confidence intervals, and honest
comparisons.

**Honesty rule.** If a number cannot be matched (private test set, proprietary data, missing
hyperparameters, hardware dependence), state it plainly and report the closest faithful result. A
reproduction that documents its gaps beats one that papers over them.

## Deliverables

- A filled reproduction spec (JSON or table) with every slot and an explicit KNOWN GAPS list.
- A dependency-ordered leaf-skill call plan and a scaffolded-repo layout.
- A reproduction log (target vs obtained per metric).
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions or gaps.
- Model/data/representation/training/evaluation constraints are not silently invented.
- The artifact names parent skill `paper-research` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The headline numbers, dataset split, or evaluation protocol are missing from the paper.
- Multiple plausible design choices would materially change the result.
- Verification depends on a private test set, proprietary data, or unavailable hardware.
- The task should be split into (or delegated to) a specific leaf skill.
