# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-research`

## Why This Skill Exists

Event-based eye-tracking reproductions span many moving parts (representation, model, training, evaluation).
This umbrella skill is consulted first: it parses the paper into a structured spec and then decides which
leaf skills to call and in what order, so the reproduction is a controlled process with explicit gaps
rather than an unordered guess.

## Worker Capability

Turn a paper PDF into a structured reproduction spec, scaffold a runnable repository layout, and coordinate
the representation, model-family, training, benchmark, and ablation leaf skills to match the paper's tables.

## Expected Outputs

- A filled reproduction spec (model/data/representation/training/evaluation/ablation/metrics slots + known gaps).
- A dependency-ordered leaf-skill call plan and a reproduction log (target vs obtained).

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (it is the entry point that the other
clusters hang off).
