# Methods -- Orchestrating a Paper Reproduction

Reproducing a paper fails most often not on the model but on everything around it: an undocumented data
split, a representation detail, a loss term, an evaluation protocol. The orchestrator imposes a disciplined
phase order so reproduction is a controlled process with explicit gaps, not a guess. It is the conductor;
the actual building blocks live in dedicated leaf skills, and this skill decides which to call and when.

## Phase 0: Extract the reproduction spec
Read the paper and fill a single spec before writing any code. Pull every reproducible detail and mark
anything missing as an explicit gap rather than inventing it.

```
Reproduction Spec
- Task & output:        (pupil center / ellipse / gaze / segmentation; units)
- Dataset(s) & split:   (name, #subjects/sequences/frames, subject-independent?, public/private)
- Input representation: (event encoding, resolution, temporal window, normalization)
- Architecture:         (backbone, blocks, depths, dims, heads, recurrence/SSM, params)
- Losses:               (each term + weight)
- Training:             (optimizer, lr, schedule, epochs, batch, augmentation, seeds)
- Evaluation:           (metrics + exact definitions, online/offline, latency conditions)
- Headline numbers:     (table/figure references to match)
- Ablations:            (which factors the paper ablates, and the reported deltas)
- Metrics:              (p10/p5/p1, mean Euclidean distance, IoU/F1, angular error -- exact form)
- KNOWN GAPS:           (anything the paper does not state)
```

The functional script `scripts/repro_spec.py` emits exactly this structure as a JSON skeleton with empty
slots, so the spec can be filled programmatically and version-controlled.

## Phase 1: Scaffold the repository
Create a clean structure so experiments are reproducible and comparable:
`data/` (loaders), `representations/`, `models/`, `losses/`, `train.py`, `eval.py`, `configs/` (one YAML per
experiment, all hyperparameters), `results/`. Seed everything (numpy, framework, dataloader workers) and
log the resolved config alongside every result so a run is fully recoverable.

## Phase 2: Build bottom-up, calling the specialized skills
Reproduce in dependency order, each step delegated to its leaf skill:
1. **Data + representation** -- event-vision-data-pipeline, event-representation-builder;
   synthetic-and-domain-adaptation if synthetic or unlabeled data is used.
2. **Benchmark + metrics harness** -- eyetracking-dataset-benchmark-harness, so you can measure from day one
   and never code blind.
3. **Model family** -- spatiotemporal-recurrent-ssm-builder, event-transformer-builder,
   point-and-graph-event-builder, or snn-neuromorphic-builder (choose by the paper's architecture).
4. **Output head + loss** -- pupil-output-head-and-loss; online-pupil-fitting-and-gaze-mapping for
   geometric (ellipse-fit + gaze-map) pipelines.
5. **Training harness** -- eyetracking-training-harness; efficiency techniques (sparse-event-compute,
   on-device-ai) where the paper claims low power or low latency.

## Phase 3: Match, then close gaps
Run eval and compare to the headline numbers. When you miss:
- Re-check the spec for a misread detail before changing the model.
- Probe the known gaps one at a time. Usual culprits, in order of frequency: representation temporal window,
  normalization statistics, dataset split (subject-independence), loss weighting, augmentation.
- Keep a reproduction log: target vs obtained per metric, and what each change did. One variable per row.

## Phase 4: Ablations and reporting
Use ablation-and-experiment-designer to reproduce the paper's ablations one factor at a time, and
experimental-rigor-stats / fair-benchmarking-auditor to report distributions, confidence intervals, and
honest apples-to-apples comparisons.

## Honesty rule
If a number cannot be matched because of a private test set, proprietary data, missing hyperparameters, or
hardware dependence, state that plainly and report the closest faithful result. A reproduction that
documents its gaps is far more valuable than one that papers over them.

## Output
Deliver the filled spec, the scaffolded repo layout, a reproduction log (target vs obtained), and a short
note on remaining gaps. Treat the spec and log as living documents updated as reproduction proceeds.
