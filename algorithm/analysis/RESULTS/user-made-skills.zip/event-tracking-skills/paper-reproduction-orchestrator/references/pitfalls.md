# Pitfalls & Reproduction-Discipline Checklist

## Slots to pin before any code
- Task and output convention (pupil center vs ellipse vs gaze vs segmentation) and its units.
- Dataset name, exact split, and whether the split is subject-independent.
- Input representation, resolution, temporal window, and normalization source.
- Every loss term and its weight; the optimizer, schedule, epochs, batch, and seeds.
- The exact metric definitions and the specific table/figure numbers to match.

## Failure modes
- **Inventing missing details instead of flagging gaps** -> the reproduction looks complete but is built on
  guesses. Why: papers omit hyperparameters routinely. Detect/avoid: every unstated detail goes in KNOWN
  GAPS, never silently filled; the spec must distinguish stated facts from assumptions.
- **Coding the model before the metric harness** -> you train blind and cannot tell if a change helped.
  Detect/avoid: stand up eyetracking-dataset-benchmark-harness in Phase 2 step 2, before the model.
- **Changing the architecture to chase a number** before re-reading the spec -> you drift away from the
  paper and the gain is not attributable. Detect/avoid: re-check the spec and probe one known gap per
  experiment row.
- **Subject-dependent split masquerading as the paper's result** -> a leaked subject inflates accuracy far
  beyond the paper. Detect/avoid: assert no subject appears in both train and test; log the split file.
- **Comparing against private/leaderboard numbers you cannot reproduce locally** -> the target is
  unreachable by construction. Detect/avoid: mark private-test numbers as non-reproducible and report the
  closest public-set result.
- **Untracked configs / seeds** -> runs are not recoverable and "improvements" are noise. Detect/avoid: log
  the resolved YAML and all seeds with every result.

## Detection recipe
Maintain a reproduction log with one row per experiment: changed variable, target metric, obtained metric,
delta, and a note. If a row changes more than one variable, split it. Before claiming a match, confirm the
metric definition and the split are identical to the paper's.
