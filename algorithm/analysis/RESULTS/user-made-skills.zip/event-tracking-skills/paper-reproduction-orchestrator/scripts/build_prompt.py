from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for paper-reproduction-orchestrator.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--paper", default="unspecified",
                        help="path or title of the paper PDF to reproduce")
    args = parser.parse_args()
    print("Skill: paper-reproduction-orchestrator")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-research")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Paper: {args.paper}")
    print("Fill the reproduction spec (task/output, dataset+split, representation, architecture,")
    print("losses, training, evaluation, ablations, metrics, headline numbers, KNOWN GAPS).")
    print("Plan the leaf-skill call order; stand up the metric harness before the model.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
