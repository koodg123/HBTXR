#!/usr/bin/env python3
"""Emit a structured reproduction-spec JSON skeleton for a paper reproduction.

The orchestrator's Phase-0 artifact is a single spec with slots for model, data,
representation, training, evaluation, ablation, and metrics, plus an explicit list of
KNOWN GAPS (anything the paper does not state). This script emits that skeleton as JSON
so it can be filled programmatically and version-controlled. Slots left unset are emitted
as null (an explicit gap), never silently invented.

The metric slot is normalized to the canonical eye-tracking set:
p-accuracy (p10/p5/p1), mean Euclidean distance, IoU/F1, angular gaze error.

Examples
--------
    python repro_spec.py --help
    python repro_spec.py --demo
    python repro_spec.py --task pupil-center --dataset 3ET+ --arch event-transformer
"""
from __future__ import annotations

import argparse
import json


SLOT_ORDER = [
    "task_and_output",
    "dataset_and_split",
    "representation",
    "architecture",
    "losses",
    "training",
    "evaluation",
    "ablation",
    "metrics",
    "headline_numbers",
    "known_gaps",
]


def empty_spec():
    """Return a spec skeleton: every slot present, unset slots are None (an explicit gap)."""
    return {
        "task_and_output": {"task": None, "output": None, "units": None},
        "dataset_and_split": {
            "name": None, "subjects": None, "sequences": None, "frames": None,
            "subject_independent": None, "public_or_private": None,
        },
        "representation": {
            "encoding": None, "resolution": None, "temporal_window": None, "normalization": None,
        },
        "architecture": {
            "backbone": None, "blocks": None, "depth": None, "dim": None,
            "heads": None, "recurrence_or_ssm": None, "params": None,
        },
        "losses": [],
        "training": {
            "optimizer": None, "lr": None, "schedule": None, "epochs": None,
            "batch_size": None, "augmentation": None, "seeds": None,
        },
        "evaluation": {"online_or_offline": None, "latency_conditions": None},
        "ablation": [],
        "metrics": {
            "p_accuracy": ["p10", "p5", "p1"],
            "mean_euclidean_distance": None,
            "iou_f1": None,
            "angular_gaze_error": None,
        },
        "headline_numbers": [],
        "known_gaps": [],
    }


def fill_spec(args):
    """Fill the slots provided on the CLI; everything else stays None (a gap)."""
    spec = empty_spec()
    if args.task:
        spec["task_and_output"]["task"] = args.task
        spec["task_and_output"]["output"] = args.task
    if args.units:
        spec["task_and_output"]["units"] = args.units
    if args.dataset:
        spec["dataset_and_split"]["name"] = args.dataset
    if args.subject_independent is not None:
        spec["dataset_and_split"]["subject_independent"] = args.subject_independent
    if args.representation:
        spec["representation"]["encoding"] = args.representation
    if args.arch:
        spec["architecture"]["backbone"] = args.arch
    for term in args.loss or []:
        spec["losses"].append({"term": term, "weight": None})
    for factor in args.ablate or []:
        spec["ablation"].append({"factor": factor, "reported_delta": None})
    for gap in args.gap or []:
        spec["known_gaps"].append(gap)
    return spec


def count_gaps(spec):
    """Count unset (None) leaf slots plus empty lists -- a crude completeness signal."""
    gaps = 0

    def walk(node):
        nonlocal gaps
        if node is None:
            gaps += 1
        elif isinstance(node, dict):
            for v in node.values():
                walk(v)
        elif isinstance(node, list) and len(node) == 0:
            gaps += 1

    walk(spec)
    return gaps


def _demo():
    spec = empty_spec()
    # Fabricate a filled example so --demo prints real, non-trivial output.
    spec["task_and_output"] = {"task": "pupil-center", "output": "(x,y)", "units": "pixels"}
    spec["dataset_and_split"] = {
        "name": "3ET+", "subjects": 13, "sequences": 156, "frames": None,
        "subject_independent": True, "public_or_private": "public",
    }
    spec["representation"] = {
        "encoding": "voxel-grid B=8 2ch", "resolution": "64x64",
        "temporal_window": "40ms", "normalization": "per-sample-max",
    }
    spec["architecture"] = {
        "backbone": "event-transformer", "blocks": "patch+attn", "depth": 6,
        "dim": 128, "heads": 4, "recurrence_or_ssm": None, "params": "1.2M",
    }
    spec["losses"] = [{"term": "L2-center", "weight": 1.0}]
    spec["training"] = {
        "optimizer": "AdamW", "lr": 3e-4, "schedule": "cosine", "epochs": 100,
        "batch_size": 32, "augmentation": None, "seeds": [0],
    }
    spec["evaluation"] = {"online_or_offline": "online", "latency_conditions": "causal-binning"}
    spec["ablation"] = [{"factor": "temporal-window", "reported_delta": "p10 -0.03 at 20ms"}]
    spec["metrics"]["mean_euclidean_distance"] = "px @ 64x64"
    spec["headline_numbers"] = [{"ref": "Table2", "metric": "p10", "value": 0.97}]
    spec["known_gaps"] = ["crop origin unstated", "augmentation list unstated", "lr warmup unstated"]
    print(json.dumps(spec, indent=2))
    print("---")
    print("slot order:", ", ".join(SLOT_ORDER))
    print("remaining unset slots (gaps):", count_gaps(spec))


def main():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="print a filled example spec")
    p.add_argument("--task", default=None, help="pupil-center | ellipse | gaze | segmentation")
    p.add_argument("--units", default=None)
    p.add_argument("--dataset", default=None)
    p.add_argument("--subject-independent", dest="subject_independent",
                   type=lambda s: s.lower() in ("1", "true", "yes"), default=None)
    p.add_argument("--representation", default=None)
    p.add_argument("--arch", default=None)
    p.add_argument("--loss", action="append", help="repeatable loss term")
    p.add_argument("--ablate", action="append", help="repeatable ablation factor")
    p.add_argument("--gap", action="append", help="repeatable known-gap note")
    args = p.parse_args()
    if args.demo:
        _demo()
    else:
        spec = fill_spec(args)
        print(json.dumps(spec, indent=2))
        print("---")
        print("remaining unset slots (gaps):", count_gaps(spec))


if __name__ == "__main__":
    main()
