---
name: snn-neuromorphic-builder
description: Build and train spiking neural networks for event eye tracking and map them to neuromorphic hardware. Use this whenever the model uses spiking neurons (for example integrate-and-fire), surrogate-gradient training of an SNN, a temporal readout that converts spike trains to continuous outputs, or deployment to a neuromorphic processor such as Speck for low-power inference. Trigger on "build a spiking network for eye tracking", "train an SNN with surrogate gradients", "integrate-and-fire pupil regressor", "spike-train readout", "deploy to Speck/neuromorphic chip", or any reproduction whose model is spiking or neuromorphic, even without exact wording. Pairs with on-device-ai and the FPGA/HLS skill for the hardware side, and assumes the representation builder feeds events to the spiking layers.
---

# SNN / Neuromorphic Builder

## Overview

Spiking networks are a distinct modeling and training regime: neurons carry state and emit spikes,
gradients do not flow through the spike, and the payoff is extreme low power on neuromorphic hardware.
This skill reproduces the four parts that decide an SNN eye tracker -- the neuron model, the
surrogate-gradient training, the temporal readout, and the hardware mapping -- as explicit,
parameterized choices. It is a P0 IDEA-Gen leaf skill under `Event Eye-Tracking Reproduction` and
produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/hardware/dataset,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
neuron threshold/leak/reset, the number of simulation time steps, or the readout form is unknown --
list the missing inputs before making design choices. Use `templates/prompt-template.md` or
`scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "IAF pupil regressor, T=20 steps, readout -> (x,y)").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (event representation), and downstream consumers (training harness, hardware/power reporting).
3. Separate known facts from assumptions about neuron parameters, time steps, surrogate, and readout.
4. Choose the smallest artifact that unblocks the next Worker: a spiking module plus a one-line neuron/readout spec.
5. Define the evidence required for signoff before producing the main artifact (spike rate, readout shape, time-step count, hardware constraints).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the neuron/training/readout/hardware options and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/iaf_neuron.py` to simulate the integrate-and-fire layer over T steps and compute the temporal readout.
5. Produce the spiking model + training + readout artifact with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Reproduce four things faithfully; none of them looks like standard deep learning.

**Neuron and network.** Use an integrate-and-fire (IAF) neuron or a leaky variant with explicit
membrane state, threshold, and reset; the threshold, leak, and reset rule set the firing behavior, so
pin them. Build spiking conv/recurrent layers that consume the event representation directly, and keep
parameter count and layer config faithful -- SNN trackers are often very small, which is part of the
contribution.

**Training.** Train through time with surrogate-gradient learning: a smooth surrogate (e.g.
fast-sigmoid, arctan, triangular) stands in for the non-differentiable spike during backprop-through-time
(BPTT). Reproduce the surrogate function and the BPTT window. The number of simulation time steps `T`
per sample materially affects accuracy, latency, and energy -- record it.

**Readout.** Convert output spike trains to a continuous pupil/gaze estimate, for example a non-spiking
1D temporal convolution slid over the output spikes, or an exponentially-weighted (leaky) spike count
that emphasizes recent activity. Reproduce the readout so the regression output is continuous and smooth.

**Hardware mapping.** Map the trained SNN to a processor such as Speck, respecting neuron/connectivity
constraints; report measured power and latency and the event-recording slicing that affects them. Hand
resource/power reporting and any FPGA route to the dedicated hardware skills.

Details that decide reproduction: neuron parameters (threshold, leak, reset) and `T`; surrogate-gradient
choice and BPTT window; readout method and its parameters; hardware constraints and the event-slicing
that sets latency. Honesty rule: neuromorphic power/latency depend on the specific chip and toolchain;
without equivalent hardware those numbers may not be reproducible -- reproduce model and training
faithfully and state the hardware dependence explicitly.

## Deliverables

- A spiking model (IAF/leaky layers) of known neuron parameters and time-step count.
- A surrogate-gradient training setup and a temporal readout module mapping spikes -> continuous output.
- A hardware-mapping note (constraints, event-slicing, power/latency dependence).
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Neuron parameters, time steps, surrogate, and readout are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The target neuron parameters, time-step count, surrogate, or readout are missing.
- Multiple plausible neuron/readout designs would materially change the result.
- Verification depends on unavailable neuromorphic hardware or measured power/latency.
- The task should be split into a new leaf skill (e.g. a dedicated hardware-mapping skill).
