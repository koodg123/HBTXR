# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Neuron model (IAF / leaky-IAF / other) and parameters (threshold, leak/tau, reset rule):

Time steps T per sample and BPTT window:

Surrogate-gradient function (fast-sigmoid / arctan / triangular / other):

Temporal readout (1D temporal conv / exponentially-weighted spike count / rate) and its parameters:

Hardware target (Speck / other neuromorphic / FPGA) and constraints:

Constraints:

Assumptions:

Required artifact:

Verification evidence (spike rate, readout shape/value, T, power/latency dependence):

Risks and missing inputs:
