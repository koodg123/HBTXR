# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The spiking model is present and traceable.
- [ ] The surrogate-gradient training setup and temporal readout module are present.
- [ ] Neuron parameters (threshold, leak, reset rule) are stated and pinned.
- [ ] Number of simulation time steps `T` is stated and reported with every metric.
- [ ] The surrogate-gradient function and width are stated (or flagged as assumed).
- [ ] Mean spike rate is nonzero and moderate (no dead/saturated network).
- [ ] The readout produces a continuous, smooth output (not spike-step jitter).
- [ ] Hardware power/latency are labeled measured vs simulated and the event-slice policy is stated.
- [ ] Residual risks and missing inputs are listed.
