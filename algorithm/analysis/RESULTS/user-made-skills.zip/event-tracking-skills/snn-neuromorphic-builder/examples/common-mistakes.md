# Common Mistakes

- Treating `snn-neuromorphic-builder` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing neuron parameters, time steps, surrogate, or hardware numbers without marking assumptions.
- Producing prose without a concrete spiking module another Worker or evaluator can run.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Using the wrong reset rule (hard vs subtract), which changes spike rate and accuracy.
- Leaving `T` (time-step count) unstated, so accuracy/latency/energy are not comparable.
- Substituting a different surrogate gradient (or width) than the paper without flagging it.
- Treating the readout as an afterthought and emitting jittery, spike-discretized coordinates.
- Reporting simulated spike/energy proxies as if they were measured on-chip power and latency.
