# Good Output

A strong output for `snn-neuromorphic-builder` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a spiking model with pinned neuron parameters; a surrogate-gradient training
setup; a temporal readout module; a hardware-mapping note.

## Worked mini-example

**Objective:** integrate-and-fire pupil regressor on EV-Eye, T=20 steps, online leaky-count readout.

**Spec (one line):**
`neuron=LIF | V_th=1.0 | beta=0.9 (tau_m~=9.5*dt) | reset=subtract | T=20 | surrogate=arctan (a=2.0) |
BPTT=full-window | readout=leaky-count (lambda=0.8) -> affine -> (x,y) | params~=42k`

**Module sketch:**
```python
spikes = iaf_forward(I, V_th=1.0, beta=0.9, reset="subtract", T=20)   # [T, N]
rate   = leaky_count(spikes, lam=0.8)                                  # emphasizes recent spikes
xy     = affine(rate)                                                  # map to coordinate units
assert spikes.shape[0] == 20
```

**Validation evidence:** mean spike rate 0.18 spikes/neuron/step (nonzero, moderate); readout value
2.41 for the synthetic current; T=20 reported with the metric; output is continuous (no spike-step
jitter). Accuracy validated in simulation only.

**Residual risks:** paper does not state the surrogate width -> assumed `a=2.0`; on-chip power/latency
not reproducible without Speck hardware -> flagged for the orchestrator and hardware skills.
