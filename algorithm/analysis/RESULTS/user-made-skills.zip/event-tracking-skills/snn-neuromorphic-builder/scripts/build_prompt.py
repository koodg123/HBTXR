from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for snn-neuromorphic-builder.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--neuron", default="LIF", help="IAF|LIF")
    parser.add_argument("--timesteps", type=int, default=20, help="simulation time steps T per sample")
    parser.add_argument("--readout", default="leaky-count",
                        help="temporal-conv|leaky-count|rate")
    args = parser.parse_args()
    print("Skill: snn-neuromorphic-builder")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Neuron model: {args.neuron}")
    print(f"Time steps T: {args.timesteps}")
    print(f"Readout: {args.readout}")
    print("Pin: threshold/leak/reset, T, surrogate+width, BPTT window, readout params, hardware constraints.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
