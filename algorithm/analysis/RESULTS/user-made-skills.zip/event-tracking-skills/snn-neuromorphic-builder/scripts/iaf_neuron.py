#!/usr/bin/env python3
"""Integrate-and-fire spiking layer forward pass plus a temporal readout.

Implements the core SNN primitive: a layer of (leaky) integrate-and-fire neurons
simulated over T time steps, producing spike trains, then a temporal readout that
converts the output spikes into a continuous regression value.

Neuron update per step t:
    V[t] = beta * V[t-1] + I[t]              (beta = 1.0 -> non-leaky IAF; beta < 1 -> LIF)
    s[t] = 1 if V[t] >= V_th else 0          (spike)
    reset: hard      -> V[t] <- V_reset on spike
           subtract  -> V[t] <- V[t] - V_th on spike   (keeps residual charge)

Temporal readout (spike train -> continuous output):
    leaky-count: r[t] = lam * r[t-1] + sum_neurons(s[t]); output = scale * r[T-1]
    rate:        output = scale * mean over t and neurons of s[t]

Examples
--------
    python iaf_neuron.py --demo
    python iaf_neuron.py --demo --neuron IAF --reset hard --readout rate
    python iaf_neuron.py --help
"""
from __future__ import annotations

import argparse

import numpy as np


def iaf_forward(current, V_th=1.0, beta=1.0, reset="subtract", V_reset=0.0):
    """Simulate an IAF/LIF layer.

    Parameters
    ----------
    current : array [T, N]  input current per time step per neuron.
    V_th    : float         firing threshold.
    beta    : float         membrane leak in (0, 1]; 1.0 = non-leaky IAF.
    reset   : str           "subtract" (reset-by-subtraction) or "hard".
    V_reset : float         membrane value after a hard reset.

    Returns
    -------
    spikes  : array [T, N]  binary spike train (0/1).
    V_trace : array [T, N]  membrane potential after each step's reset.
    """
    current = np.asarray(current, dtype=np.float64)
    T, N = current.shape
    V = np.zeros(N, dtype=np.float64)
    spikes = np.zeros((T, N), dtype=np.float64)
    V_trace = np.zeros((T, N), dtype=np.float64)
    for t in range(T):
        V = beta * V + current[t]
        fired = V >= V_th
        spikes[t] = fired.astype(np.float64)
        if reset == "hard":
            V = np.where(fired, V_reset, V)
        else:  # reset-by-subtraction preserves residual charge above threshold
            V = np.where(fired, V - V_th, V)
        V_trace[t] = V
    return spikes, V_trace


def leaky_count_readout(spikes, lam=0.8, scale=1.0):
    """Exponentially-weighted spike count -> continuous output.

    r[t] = lam * r[t-1] + (total spikes across neurons at t); output = scale * r[T-1].
    Recent spikes dominate, giving a smooth, recency-weighted regression value.
    """
    spikes = np.asarray(spikes, dtype=np.float64)
    per_step = spikes.sum(axis=1)
    r = 0.0
    for v in per_step:
        r = lam * r + v
    return float(scale * r)


def rate_readout(spikes, scale=1.0):
    """Mean firing rate over time and neurons -> continuous output."""
    spikes = np.asarray(spikes, dtype=np.float64)
    return float(scale * spikes.mean())


def spike_rate(spikes):
    """Mean spikes per neuron per time step (a sparsity / liveness diagnostic)."""
    spikes = np.asarray(spikes, dtype=np.float64)
    return float(spikes.mean())


def _demo(args):
    rng = np.random.default_rng(0)
    T, N = args.timesteps, args.neurons
    # Synthetic input current: a baseline drive plus noise, mildly time-varying.
    base = np.linspace(0.2, 0.6, T).reshape(T, 1)
    current = base + 0.5 * rng.random((T, N))
    beta = 1.0 if args.neuron == "IAF" else args.beta
    spikes, V_trace = iaf_forward(current, V_th=args.threshold, beta=beta,
                                  reset=args.reset)
    rate = spike_rate(spikes)
    if args.readout == "rate":
        out = rate_readout(spikes, scale=args.scale)
    else:
        out = leaky_count_readout(spikes, lam=args.lam, scale=args.scale)
    print(f"neuron: {args.neuron}  T: {T}  N: {N}  V_th: {args.threshold}  beta: {beta}  reset: {args.reset}")
    print("spike train shape:", spikes.shape, " dtype:", spikes.dtype)
    print("mean spike rate (spikes/neuron/step):", round(rate, 4))
    print("total spikes:", int(spikes.sum()))
    print("membrane value range:", round(float(V_trace.min()), 3), "..", round(float(V_trace.max()), 3))
    print(f"readout ({args.readout}) value:", round(out, 4))
    live = 0.0 < rate < 1.0
    print("network is live (nonzero, non-saturated spike rate):", bool(live))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a synthetic input current")
    p.add_argument("--neuron", default="LIF", choices=["IAF", "LIF"])
    p.add_argument("--timesteps", type=int, default=20, help="simulation steps T")
    p.add_argument("--neurons", type=int, default=32, help="neurons N in the layer")
    p.add_argument("--threshold", type=float, default=1.0, help="firing threshold V_th")
    p.add_argument("--beta", type=float, default=0.9, help="LIF membrane leak in (0,1]")
    p.add_argument("--reset", default="subtract", choices=["subtract", "hard"])
    p.add_argument("--readout", default="leaky-count", choices=["leaky-count", "rate"])
    p.add_argument("--lam", type=float, default=0.8, help="leaky-count decay lambda")
    p.add_argument("--scale", type=float, default=1.0, help="readout output scale")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
