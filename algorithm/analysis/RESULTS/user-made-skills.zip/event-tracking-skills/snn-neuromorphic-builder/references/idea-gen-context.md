# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Some event eye-tracking reproductions are spiking from end to end: the contribution is extreme low power
on a neuromorphic processor, not accuracy alone. The orchestrator pulls in this skill when the model
family is spiking, because the neuron model, surrogate-gradient training, temporal readout, and hardware
mapping are a regime apart from standard deep learning and must be reproduced as a unit.

## Worker Capability

Build and train a spiking eye-tracking model (integrate-and-fire or leaky neurons) with surrogate-gradient
BPTT, attach a temporal readout that turns spike trains into continuous pupil/gaze output, and produce a
faithful neuromorphic hardware-mapping note.

## Expected Outputs

- A spiking model with pinned neuron parameters and time-step count.
- A surrogate-gradient training setup and a spike-train temporal readout module.
- A hardware-mapping note stating constraints, event-slicing, and power/latency dependence.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (spiking / neuromorphic model-family cluster).
