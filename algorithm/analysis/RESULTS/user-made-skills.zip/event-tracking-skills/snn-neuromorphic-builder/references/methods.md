# Methods -- SNN / Neuromorphic Eye Tracking

Reproducing a spiking eye tracker means reproducing four interlocking parts: the neuron model, the
network, the surrogate-gradient training, and the temporal readout, plus a hardware-mapping note. Each
section below gives the construction, when it matters, and the parameters that must be pinned.

## Neuron model

### Integrate-and-fire (IAF)
Each neuron integrates input current into a membrane potential `V`. When `V` crosses a threshold
`V_th`, the neuron emits a spike and `V` is reset.
- Non-leaky IAF: `V[t] = V[t-1] + I[t]`; spike when `V >= V_th`.
- Reset rule: either hard reset (`V <- V_reset`, usually 0) or reset-by-subtraction (`V <- V - V_th`,
  which preserves residual charge and is common in accuracy-sensitive SNNs).
- Pin: `V_th`, reset rule (`hard` vs `subtract`), `V_reset`, and any refractory period.

### Leaky integrate-and-fire (LIF)
Adds a membrane leak so old input decays: `V[t] = beta * V[t-1] + I[t]`, with leak factor
`beta = exp(-dt/tau_m)` in `(0,1)`. Lower `beta` (shorter `tau_m`) forgets faster; this trades temporal
memory for noise rejection.
- Pin: `beta` (or `tau_m` and `dt`), in addition to all IAF parameters.

The threshold, leak, and reset together set the firing behavior, so reproduce them exactly -- a small
change in `V_th` or reset rule changes spike rate, accuracy, and energy.

## Network

Spiking convolutional and/or recurrent layers consume the event representation directly (the
representation builder provides the input tensor over `T` time steps). Keep parameter count and layer
config faithful: SNN trackers are often deliberately tiny (a few thousand to a few hundred-thousand
parameters), and that smallness is frequently part of the contribution. Spiking recurrence is implicit
in the membrane state -- do not add a separate RNN unless the paper does.
- Pin: layer types/widths/strides, total parameter count, whether recurrence is membrane-only.

## Training (surrogate-gradient learning)

Spikes are non-differentiable (a step function), so the forward pass uses the hard threshold but the
backward pass substitutes a smooth surrogate derivative. Training is backpropagation-through-time (BPTT)
over the `T` simulation steps.

Common surrogates (the derivative used in the backward pass):
- Fast sigmoid / SuperSpike: `1 / (1 + a*|V - V_th|)^2`.
- Arctan: derivative `1 / (1 + (pi*a*(V - V_th))^2)`.
- Triangular / piecewise-linear: nonzero within a window `|V - V_th| < w`.
- Boxcar: constant within a window.
- Pin: surrogate function, its width/scale hyperparameter `a` (or `w`), and the BPTT window length.

The number of simulation time steps `T` per sample materially affects accuracy, latency, and energy
(more steps -> more spikes -> more compute and power). Record `T` explicitly; it is a first-class
hyperparameter, not an implementation detail.

## Readout (spike train -> continuous output)

The output layer emits spikes, but pupil/gaze is continuous, so a temporal readout converts the output
spike train to a smooth estimate.
- Non-spiking 1D temporal convolution slid over the output spikes (learned smoothing kernel).
- Exponentially-weighted (leaky) spike count: accumulate spikes with decay `r[t] = lambda*r[t-1] + s[t]`,
  emphasizing recent activity; the final or per-step `r` is the continuous output (optionally scaled).
- Rate readout: mean spike count over the window (simplest; loses within-window timing).
- Pin: readout type, kernel/decay parameters, and any output scaling/affine mapping to coordinate units.

## Hardware mapping (neuromorphic)

Map the trained SNN to a processor such as Speck, respecting its neuron-model and connectivity
constraints (fan-in/out limits, supported neuron types, quantized weights). Report measured power and
latency together with the slicing of the event recording that produces them, because event density per
slice drives spike count and therefore energy.
- Pin: target chip, neuron-model constraints honored, weight quantization, event-slice policy.
- Hand detailed resource/power reporting and any FPGA route to the dedicated hardware skills.

## Honesty rule

Neuromorphic power and latency depend on the specific chip and toolchain. Without equivalent hardware,
those numbers may not be reproducible. Reproduce the model and training faithfully, validate accuracy in
simulation, and state the hardware dependence explicitly rather than presenting simulated energy as
measured.

## Choosing quickly
- Accuracy-sensitive, deeper SNN -> reset-by-subtraction LIF with arctan/fast-sigmoid surrogate.
- Ultra-low-power, tiny tracker -> non-leaky or short-tau IAF, small `T`, rate or leaky-count readout.
- Smooth high-rate output -> 1D temporal-conv readout over output spikes.
- Online/low-latency -> small `T`, leaky-count readout updated per step.
