# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Neuron model (IAF vs LIF) and its parameters: threshold `V_th`, leak `beta`/`tau_m`, reset rule
  (hard vs subtract), `V_reset`, refractory period.
- Number of simulation time steps `T` per sample, and the BPTT window.
- Surrogate-gradient function and its width/scale hyperparameter.
- Readout type (1D temporal conv / leaky spike count / rate) and its kernel/decay parameters.
- Output scaling/affine mapping from spike statistics to coordinate units.
- Hardware constraints honored and the event-slice policy that sets latency/energy.

## Failure modes
- **Wrong reset rule** -- hard reset vs reset-by-subtraction changes residual charge and spike rate.
  Detect by comparing simulated spike rate against the paper's reported sparsity/firing rate.
- **Dead or saturated network** -- threshold too high yields no spikes (zero gradient, no learning);
  too low yields a spike every step (loses temporal code). Detect by logging mean spike rate per layer;
  target a moderate, nonzero rate. The functional script reports spike rate for exactly this check.
- **Time-step count drift** -- changing `T` silently changes accuracy, latency, and energy. Pin `T`
  and report it alongside every metric; never treat it as a free implementation knob.
- **Surrogate mismatch** -- a different surrogate (or width) changes training dynamics and final
  accuracy. Reproduce the exact surrogate; if unstated, mark it as an assumption and try a standard one.
- **Vanishing/exploding BPTT** -- long `T` with a poorly scaled surrogate destabilizes training.
  Detect via gradient-norm logging; mitigate with surrogate-width tuning or detached state.
- **Readout treated as an afterthought** -- a rate-only readout loses within-window timing and produces
  jittery coordinates; a temporal-conv or leaky-count readout smooths output. Pin the readout and verify
  the output is continuous and smooth, not discretized to spike events.
- **Simulated energy reported as measured** -- presenting simulation FLOP/spike counts as on-chip power.
  Separate simulated proxies from measured hardware numbers and label each.
- **Event-slice mismatch** -- power/latency depend on events per slice; a different slice length is not
  comparable. Pin and report the slice policy.

## Detection recipe
For any built spiking layer, log: mean spike rate per layer (target nonzero and moderate), membrane
value range, the continuous readout value vs the target, `T`, and the surrogate width. Spike rate plus
readout value catch most reproduction-breaking SNN bugs before any hardware step.
