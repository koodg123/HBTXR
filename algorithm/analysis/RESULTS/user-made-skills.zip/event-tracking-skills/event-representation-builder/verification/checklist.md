# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The representation module is present and traceable.
- [ ] A one-line variant + full-parameter spec is present.
- [ ] Output shape and dtype are stated and asserted.
- [ ] Polarity handling matches the model's input channels.
- [ ] Normalization source is fixed and identical for train and deployment.
- [ ] Causality is verified (append-future invariance) if online inference is claimed.
- [ ] Timestamp units are confirmed against the dataset.
- [ ] Residual risks and missing inputs are listed.
