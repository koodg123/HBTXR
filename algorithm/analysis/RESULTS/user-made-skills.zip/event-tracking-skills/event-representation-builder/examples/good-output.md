# Good Output

A strong output for `event-representation-builder` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a parameterized representation module; a one-line variant+parameter spec.

## Worked mini-example

**Objective:** input encoding for a CNN pupil regressor on EV-Eye, online inference.

**Spec (one line):**
`voxel grid | H×W=64×64 (eye ROI crop) | B=8 bins | polarity=2 separate channels | binning=causal |
norm=per-sample max | bilinear-in-time=on | dtype=float32 → tensor [8,2,64,64]`

**Module sketch:**
```python
grid = build_voxel(events_xytp, H=64, W=64, B=8, polarity_split=True, causal=True)
grid = grid / (grid.max() + 1e-6)          # per-sample normalization, frozen for deployment
assert grid.shape == (8, 2, 64, 64)
```

**Validation evidence:** shape `[8,2,64,64]`; non-zero fraction per bin `[0.21,0.19,...]`; implied window
20 ms; append-future invariance holds (causal); same normalization reused at deployment.

**Residual risks:** paper does not state crop origin → assumed centered on sensor; flagged for the
orchestrator.
