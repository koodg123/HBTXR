# Common Mistakes

- Treating `event-representation-builder` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing target resolution, window, or metrics without marking assumptions.
- Producing prose without a concrete representation module another Worker or evaluator can use.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Picking a representation by habit (always voxel) instead of matching the target model's expected input.
- Building a non-causal encoding (bilinear-in-time / centered kernel) while claiming online inference.
- Letting timestamp units (us vs ns) or normalization statistics differ between training and deployment.
- Collapsing polarity into one channel when the model's first layer expects two.
