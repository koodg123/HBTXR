# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Representation variant (voxel / time-surface / count / Bina-rep / causal volume / causal binning / 3-ch frame / point-cloud / graph):

Parameters (H×W, window length, #bins, causal?, polarity handling, normalization source, subsample/capacity):

Constraints:

Assumptions:

Required artifact:

Verification evidence (shape, dtype, causality, normalization, parity with reference):

Risks and missing inputs:
