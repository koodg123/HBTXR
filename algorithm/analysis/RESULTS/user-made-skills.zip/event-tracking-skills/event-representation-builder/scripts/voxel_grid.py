#!/usr/bin/env python3
"""Build a temporal voxel-grid representation from an event stream.

Implements the field-standard voxel grid: events (x, y, t, p) accumulated into B
temporal bins with bilinear interpolation in time, polarity either split into two
channels or encoded as signed values. Also provides a causal (fixed absolute-time
edges) variant used for the online-inference invariance check.

Examples
--------
    python voxel_grid.py --demo
    python voxel_grid.py --demo --bins 5 --no-polarity-split
"""
from __future__ import annotations

import argparse

import numpy as np


def build_voxel(xs, ys, ts, ps, H, W, B, polarity_split=True, bilinear_time=True):
    """Return a voxel grid.

    Shape is [B, 2, H, W] if polarity_split else [B, H, W] (signed).
    ps is expected in {0, 1} or {-1, +1}; 0 maps to negative polarity.
    """
    xs = np.asarray(xs, dtype=np.int64)
    ys = np.asarray(ys, dtype=np.int64)
    ts = np.asarray(ts, dtype=np.float64)
    ps = np.asarray(ps)
    pol = np.where(ps > 0, 1.0, -1.0)

    if ts.max() > ts.min():
        tn = (ts - ts.min()) / (ts.max() - ts.min()) * (B - 1)  # bin coord in [0, B-1]
    else:
        tn = np.zeros_like(ts)

    if polarity_split:
        grid = np.zeros((B, 2, H, W), dtype=np.float64)
    else:
        grid = np.zeros((B, H, W), dtype=np.float64)

    valid = (xs >= 0) & (xs < W) & (ys >= 0) & (ys < H)
    xs, ys, tn, pol = xs[valid], ys[valid], tn[valid], pol[valid]

    for x, y, tb, pl in zip(xs, ys, tn, pol):
        lo = int(np.floor(tb))
        if bilinear_time and lo + 1 < B:
            w_hi = tb - lo
            contribs = [(lo, 1.0 - w_hi), (lo + 1, w_hi)]
        else:
            contribs = [(min(lo, B - 1), 1.0)]
        for b, w in contribs:
            if polarity_split:
                ch = 1 if pl > 0 else 0
                grid[b, ch, y, x] += w
            else:
                grid[b, y, x] += w * pl
    return grid


def build_voxel_abs(xs, ys, ts, ps, H, W, edges):
    """Causal voxel grid binned on FIXED absolute-time edges (no future leakage)."""
    xs = np.asarray(xs, dtype=np.int64)
    ys = np.asarray(ys, dtype=np.int64)
    ts = np.asarray(ts, dtype=np.float64)
    ps = np.asarray(ps)
    pol = np.where(ps > 0, 1.0, -1.0)
    B = len(edges) - 1
    grid = np.zeros((B, 2, H, W), dtype=np.float64)
    b = np.searchsorted(edges, ts, side="right") - 1
    valid = (xs >= 0) & (xs < W) & (ys >= 0) & (ys < H) & (b >= 0) & (b < B)
    for x, y, bb, pl in zip(xs[valid], ys[valid], b[valid], pol[valid]):
        ch = 1 if pl > 0 else 0
        grid[bb, ch, y, x] += 1.0
    return grid


def causal_invariance_check(xs, ys, ts, ps, H, W, B):
    """True if a time-prefix of the stream never exceeds the full stream, bin for bin."""
    edges = np.linspace(float(np.min(ts)), float(np.max(ts)) + 1e-6, B + 1)
    g_full = build_voxel_abs(xs, ys, ts, ps, H, W, edges)
    half = len(ts) // 2
    g_half = build_voxel_abs(xs[:half], ys[:half], ts[:half], ps[:half], H, W, edges)
    return bool(np.all(g_half <= g_full + 1e-9))


def _demo(args):
    rng = np.random.default_rng(0)
    n = 2000
    xs = rng.integers(0, args.width, n)
    ys = rng.integers(0, args.height, n)
    ts = np.sort(rng.uniform(0, 20_000, n))      # microseconds, ~20 ms window
    ps = rng.integers(0, 2, n)
    grid = build_voxel(xs, ys, ts, ps, args.height, args.width, args.bins,
                       polarity_split=not args.no_polarity_split)
    print("events:", n, " window_ms:", round((ts.max() - ts.min()) / 1000, 2), "(assumed microseconds)")
    print("voxel shape:", grid.shape, " dtype:", grid.dtype)
    nz = [round(float((grid[b] != 0).mean()), 3) for b in range(args.bins)]
    print("non-zero fraction per bin:", nz)
    print("total mass:", round(float(np.abs(grid).sum()), 1))
    print("causal-binning invariance holds:",
          causal_invariance_check(xs, ys, ts, ps, args.height, args.width, args.bins))


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a synthetic event stream")
    p.add_argument("--bins", type=int, default=8)
    p.add_argument("--height", type=int, default=64)
    p.add_argument("--width", type=int, default=64)
    p.add_argument("--no-polarity-split", action="store_true", help="signed single-channel grid")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
