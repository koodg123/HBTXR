from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for event-representation-builder.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--variant", default="voxel",
                        help="voxel|time-surface|count|bina-rep|causal-volume|causal-binning|frame3|point-cloud|graph")
    args = parser.parse_args()
    print("Skill: event-representation-builder")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Representation variant: {args.variant}")
    print("Pin: HxW, window length, #bins, causal?, polarity, normalization source, subsample/capacity.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
