---
name: event-representation-builder
description: Convert raw event-camera streams into the exact tensor, point, or graph representation a model expects, with the precise variant and parameters used in the literature. Use this whenever the task needs an event encoding such as a voxel grid, time surface or surface-of-active-events, event-count or two-channel polarity image, binary representation (Bina-rep), (causal) event volume, causal temporal binning for online inference, a 3-channel event frame, a point-cloud representation, or a spatio-temporal graph built from events. Trigger on "build the voxel grid", "make a Bina-rep tensor", "turn events into a point cloud", "causal event volume", "construct an event graph", "what event representation should I use", or any reproduction that hinges on the input encoding, even without exact wording. This is the representation home that the model-family skills assume has already produced their input.
---

# Event Representation Builder

## Overview

The single most common reason an event-based reproduction misses its numbers is the input
representation: the wrong temporal window, missing polarity, the wrong normalization, or non-causal
binning. This skill makes the representation an explicit, parameterized choice and implements the
specific variants used across the field. It is a P0 IDEA-Gen leaf skill under
`Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model, assumptions,
expected deliverables, verification evidence). If the task is underspecified -- e.g. the target model's
expected input shape or temporal window is unknown -- list the missing inputs before choosing a
representation. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "produce a [B,2,H,W] causal voxel grid feeding model X").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (raw event stream), and downstream consumers (the model-family builder).
3. Separate known facts from assumptions about resolution, window length, polarity handling, and normalization.
4. Choose the smallest artifact that unblocks the next Worker: a parameterized representation module plus a one-line spec.
5. Define the evidence required for signoff before producing the artifact (shape, dtype, causality, normalization source).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the menu of representations and `references/pitfalls.md` for the failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/voxel_grid.py` to build/validate the default voxel encoding (or adapt it to the chosen variant).
5. Produce the representation module with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Match the representation to what the target model consumes, and record every parameter.

Menu (full detail in `references/methods.md`): **voxel grid** (B temporal bins, polarity split or signed --
the general default for CNN/transformer inputs); **time surface / SAE** (per-pixel timestamp of the most
recent event, exponentially decayed -- good for fast local motion); **event-count / two-channel polarity
image** (per-pixel +/- counts; cheap, loses fine timing); **Bina-rep** (stack of binary presence maps over
sub-windows, packed compactly -- used by recurrent/SSM trackers); **(causal) event volume** (causal kernel,
no future leakage -- low latency); **causal temporal binning** (ordered bins consumed online); **3-channel
event frame** (reuse standard image CNN backbones); **point cloud** (set of (x,y,t,p) points, normalized/
subsampled -- resolution-independent); **spatio-temporal graph** (nodes from events/clusters, edges from
proximity -- for GNNs/clustering).

Parameters to pin every time: spatial size HxW (and any crop/resize to the eye region); temporal window
length and number of bins; whether binning is causal; polarity handling (separate channels vs signed vs
ignored); normalization (per-sample vs dataset stats -- keep train and deployment identical);
subsampling/voxel capacity and overflow handling. For low-latency/streaming reproductions the
representation must be causal: bin only past events and run incrementally; always state offline
(whole window) vs online (incremental) because it changes both latency and accuracy.

## Deliverables

- A parameterized representation module (tensor / point-set / graph) of known shape and semantics.
- A one-line spec of the chosen variant and ALL parameters.
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Resolution, window, polarity, normalization, and causality are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The target model's expected input shape, window, or normalization is missing.
- Multiple plausible representations would materially change the result.
- Verification depends on unavailable paper detail or reference tensors.
- The task should be split into a new leaf skill (e.g. a dedicated graph-construction skill).
