# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Event-based eye-tracking reproductions live or die on the input encoding. The orchestrator pulls in this
skill first, before any model-family builder, because the model skills assume a tensor/point-set/graph of
known shape and semantics has already been produced.

## Worker Capability

Convert raw event-camera streams into the exact representation a target model expects, with the precise
variant and every parameter pinned, matching the literature.

## Expected Outputs

- A parameterized representation module (voxel / time-surface / count / Bina-rep / causal volume / causal binning / 3-ch frame / point-cloud / graph).
- A one-line spec of the chosen variant and all parameters.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (data/representation cluster).
