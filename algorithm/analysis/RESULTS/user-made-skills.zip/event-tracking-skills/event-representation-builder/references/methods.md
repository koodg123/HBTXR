# Methods — Event Representations

Match the representation to what the target model consumes, and record every parameter. Each entry below
gives the construction, when to use it, and the parameters that must be pinned.

## Voxel grid
Events accumulated into `B` temporal bins; polarity either split into separate channels (`[B,2,H,W]`) or
encoded as signed values (`[B,H,W]`). Bilinear interpolation in time (an event at fractional bin position
contributes to its two neighboring bins) reduces quantization artifacts. **Default** for CNN/transformer
inputs.
- Pin: `B`, polarity mode, interpolation (nearest vs bilinear-in-time), normalization.

## Time surface / Surface of Active Events (SAE)
Per-pixel value = timestamp of the most recent event at that pixel, exponentially decayed:
`S(x,y) = exp(-(t_now - t_last(x,y)) / tau)`. Encodes recency; strong for fast local motion.
- Pin: decay constant `tau`, whether per-polarity, normalization of the time origin.

## Event-count / two-channel polarity image
Per-pixel positive/negative counts over a window (`[2,H,W]`). Cheap; loses fine timing.
- Pin: window length, count clipping/saturation.

## Binary representation (Bina-rep)
Stack of binary event-presence maps over `N` sub-windows, optionally bit-packed into a compact integer
per pixel. Used by recurrent/SSM trackers for a compact temporal code.
- Pin: number of sub-windows `N`, packing scheme, presence threshold.

## (Causal) event volume
A fixed-size volume aggregating events with a causal kernel so no future events leak in. Supports
low-latency inference because the volume at time `t` depends only on events `<= t`.
- Pin: kernel shape, support length, bin count, causality guarantee.

## Causal temporal binning
Split a stream into ordered bins consumed online, minimizing buffering and latency for streaming
inference. The model sees bins one at a time and updates state incrementally.
- Pin: bin duration (or event-count per bin for adaptive binning), state-carry policy.

## 3-channel event frame
Encode events into a 3-channel image (e.g. positive count, negative count, and a timing channel) so a
standard ImageNet-pretrained CNN backbone can be reused.
- Pin: channel definitions, normalization to backbone's expected range.

## Point cloud
Treat events as a set of `(x, y, t, p)` points, optionally normalized (t to [0,1] within the window) and
subsampled to a fixed `N`. Consumed by point-based networks; resolution-independent.
- Pin: subsample size `N`, normalization of t, overflow/undersample handling.

## Spatio-temporal graph
Nodes from events or event clusters; edges from spatio-temporal proximity (kNN in `(x,y,alpha*t)` space).
Consumed by GNNs or graph clustering.
- Pin: node-construction (raw events vs clustered), `k` and the temporal scale `alpha`, edge features.

## Choosing quickly
- CNN/ViT backbone → voxel grid or 3-channel frame.
- Recurrent/SSM tracker → Bina-rep or causal binning.
- Online/low-latency → causal event volume or causal binning.
- Point/graph network → point cloud or spatio-temporal graph.
- Fast local motion → time surface / SAE.
