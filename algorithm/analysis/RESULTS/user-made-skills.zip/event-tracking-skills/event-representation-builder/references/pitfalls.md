# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Spatial size H×W and any resizing/cropping to the eye region.
- Temporal window length and number of bins; whether binning is causal.
- Polarity handling: separate channels vs signed vs ignored.
- Normalization: per-sample vs dataset statistics; train and deployment must be identical.
- Subsampling/voxel capacity for point and voxel forms; how overflow is handled.

## Failure modes
- **Timestamp-unit mismatch** (microseconds vs nanoseconds vs seconds) → silently corrupts binning and
  decay constants. Detect by printing min/max timestamp and the implied window duration; assert it matches
  the dataset's documented unit.
- **Empty or near-empty bins during fixation** → zero-filled bins can dominate normalization and starve
  the model. Decide zero-fill vs adaptive (event-count) windowing and state it.
- **Normalization leakage** → using evaluation-set statistics, or different stats between the PyTorch
  training tensor and the deployed/quantized tensor. Freeze normalization at train time and reuse it.
- **Accidental non-causality** → bilinear-in-time interpolation or a centered kernel can pull in future
  events. For online claims, verify the value at time `t` is unchanged when future events are appended.
- **Polarity dropped by accident** → collapsing +/- into a single count when the model expects two
  channels halves the information; check channel count against the model's first-layer `in_channels`.
- **Resolution/crop mismatch** → encoding at sensor resolution when the model expects a cropped eye ROI
  (or vice versa) shifts every coordinate. Pin the crop and the coordinate origin.

## Detection recipe
For any built representation, log: shape, dtype, value range, fraction of non-zero pixels per bin,
implied window duration, and a causality check (append-future invariance). These five numbers catch most
reproduction-breaking bugs.
