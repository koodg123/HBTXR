---
name: inference-time-postprocessing
description: Reproduce model-agnostic, inference-time post-processing that improves eye-tracking outputs without retraining the model. Use this whenever a method refines an existing gaze or pupil prediction stream after the network, such as motion-aware median filtering to suppress blink-induced spikes, optical-flow-based local refinement that aligns predictions with cumulative event motion to reduce jitter, temporal smoothing of trajectories, or evaluation with temporal-smoothness metrics like a jitter metric. Trigger on "post-process the gaze predictions", "motion-aware median filter for blinks", "optical-flow refinement of the gaze", "reduce temporal jitter without retraining", "jitter metric for smoothness", or any reproduction that adds a model-agnostic refinement stage, even without exact wording. Operates on the output of any model produced by the other skills.
---

# Inference-Time Post-Processing

## Overview

A class of methods improves eye-tracking quality purely at inference, leaving the model untouched: they
drop onto any tracker, so reproducing them means reproducing the filters and the smoothness metrics, not
training anything. The value is temporal cleanliness -- fewer blink spikes, less jitter -- traded against
a little added latency that must be reported honestly. It is a P0 IDEA-Gen leaf skill under
`Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target prediction stream,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
median window, the motion-awareness threshold, or the jitter-metric definition is unknown -- list the
missing inputs before fixing the filter. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "cut jitter by half with <=1 frame added latency, no accuracy loss").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (a prediction stream from any model), and downstream consumers (the reproduction log / evaluator).
3. Separate known facts from assumptions about the median window, motion threshold, flow method, and jitter definition.
4. Choose the smallest artifact that unblocks the next Worker: a post-processing module plus a before/after report.
5. Define the evidence required for signoff before producing the artifact (spatial accuracy and jitter before/after, added latency).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the post-processing modules and `references/pitfalls.md` for the failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/motion_median.py` to apply the motion-aware median filter and compute the jitter metric before vs after.
5. Produce the post-processing module(s) plus a before/after comparison with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

These methods refine the prediction stream after the network; reproduce the filters and the smoothness
metric, and report the latency they add.

The post-processing modules (full detail in `references/methods.md`): **motion-aware median filtering** --
a median filter over the prediction stream whose behavior adapts to motion, so it suppresses blink-induced
spikes and outliers while preserving genuine fast gaze dynamics (saccades); reproduce the window size and
the motion-awareness rule that decides when to smooth versus pass through. **Optical-flow-based local
refinement** -- estimate cumulative event motion (optical flow on the event stream) and nudge the
predicted pupil/gaze to be consistent with it, reducing spatial jitter and temporal discontinuities;
reproduce the flow estimation and the correction rule. **Trajectory smoothing** -- general temporal
smoothing of the predicted trajectory; reproduce the smoother and its strength, balancing latency against
smoothness.

Spatial accuracy alone does not capture temporal quality, so reproduce the smoothness metric too: the
**jitter metric** quantifies temporal smoothness based on velocity/derivative behavior (e.g. the mean
absolute second difference of the trajectory), capturing how steady the predictions are over time. Report
spatial accuracy and the jitter/smoothness metric together, since post-processing trades a little latency
for much better temporal behavior. The details that decide reproduction: the median-filter window and the
motion-awareness threshold; the optical-flow method and correction rule; the smoothness/jitter definition;
and any added latency from the filtering window, reported honestly for streaming use.

## Deliverables

- The post-processing module(s) operating on a prediction stream (motion-aware median / flow refine / smoother).
- The smoothness/jitter metric and a before/after comparison on both spatial accuracy and temporal smoothness.
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics (jitter, accuracy, latency) or explicitly marked as assumptions.
- The median window, motion threshold, flow method, and jitter definition are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The filter window, motion threshold, flow method, or jitter definition is missing from the source.
- Multiple plausible filters would materially change the smoothness/accuracy tradeoff.
- The added latency makes a streaming/online claim untenable (route to latency-characterization).
- The task should be split into a new leaf skill (e.g. a dedicated optical-flow-refinement skill).
