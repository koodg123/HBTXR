# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The post-processing module is present and traceable.
- [ ] The jitter / smoothness metric is defined with an exact formula.
- [ ] A before/after comparison is reported for BOTH spatial accuracy and jitter.
- [ ] Accuracy on fast-motion (saccade) segments is reported, not only the global mean.
- [ ] The added latency (window half-width / group delay) is stated; online claims use a causal window.
- [ ] Blink spikes are suppressed and saccades preserved (median, not mean, for impulsive spikes).
- [ ] The metric definition matches the paper's.
- [ ] Residual risks and missing inputs are listed.
