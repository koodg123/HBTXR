#!/usr/bin/env python3
"""Motion-aware median filter and jitter metric for eye-tracking trajectories.

Model-agnostic, inference-time post-processing for a 2D prediction stream (a
trajectory of (x, y) points over time):

  * jitter(traj)             -- temporal-smoothness metric: mean absolute second
    difference (frame-to-frame acceleration magnitude). Lower is smoother.
  * motion_median(traj, ...) -- a median filter whose window WIDENS when local
    motion is small (fixation/blink, where spikes are artifacts) and NARROWS when
    motion is large (saccade, where the signal is real). Median rejects impulsive
    blink spikes; the window is causal/trailing so added latency is explicit.

The --demo path builds a noisy synthetic trajectory with injected blink spikes and
prints the jitter before vs after filtering.

Examples
--------
    python motion_median.py --demo
    python motion_median.py --demo --n 200 --wmax 11 --speed-thresh 1.5
"""
from __future__ import annotations

import argparse

import numpy as np


def jitter(traj):
    """Mean absolute second difference of a [T, 2] trajectory (acceleration magnitude)."""
    t = np.asarray(traj, dtype=np.float64)
    if t.shape[0] < 3:
        return 0.0
    second = t[2:] - 2.0 * t[1:-1] + t[:-2]
    return float(np.mean(np.linalg.norm(second, axis=1)))


def _local_speed(traj, i, look=2):
    """Local speed at index i: mean step length over the preceding `look` steps."""
    t = np.asarray(traj, dtype=np.float64)
    lo = max(1, i - look + 1)
    steps = t[lo:i + 1] - t[lo - 1:i]
    if steps.shape[0] == 0:
        return 0.0
    return float(np.mean(np.linalg.norm(steps, axis=1)))


def _odd(n):
    n = int(n)
    return n if n % 2 == 1 else n + 1


def motion_median(traj, base=3, wmax=9, speed_thresh=1.0):
    """Motion-aware causal median filter on a [T, 2] trajectory.

    For each sample the trailing window is `wmax` when local speed is below
    `speed_thresh` (slow -> smooth hard to kill spikes) and shrinks toward `base`
    as speed rises (fast -> preserve the signal). Causal/trailing, so added latency
    is at most (wmax - 1) samples.
    """
    t = np.asarray(traj, dtype=np.float64)
    n = t.shape[0]
    base = _odd(base)
    wmax = _odd(max(wmax, base))
    out = t.copy()
    for i in range(n):
        speed = _local_speed(t, i, look=2)
        frac = 0.0 if speed_thresh <= 0 else min(1.0, speed / speed_thresh)
        w = int(round(wmax - frac * (wmax - base)))
        w = _odd(max(base, min(wmax, w)))
        lo = max(0, i - w + 1)
        window = t[lo:i + 1]
        out[i, 0] = np.median(window[:, 0])
        out[i, 1] = np.median(window[:, 1])
    return out


def _demo(args):
    rng = np.random.default_rng(0)
    n = args.n
    t = np.linspace(0, 4 * np.pi, n)
    base_path = np.stack([10.0 * np.sin(t * 0.3) + 32.0,
                          6.0 * np.cos(t * 0.2) + 32.0], axis=1)
    noisy = base_path + rng.normal(0, args.noise, size=base_path.shape)
    spike_idx = rng.choice(np.arange(5, n - 5), size=4, replace=False)
    noisy[spike_idx] += rng.uniform(15, 25, size=(4, 2)) * rng.choice([-1, 1], size=(4, 2))

    clean = motion_median(noisy, base=args.base, wmax=args.wmax, speed_thresh=args.speed_thresh)

    j_before = jitter(noisy)
    j_after = jitter(clean)
    print("trajectory length:", n, " injected blink spikes at:", sorted(int(i) for i in spike_idx))
    print("jitter (mean abs 2nd diff) before:", round(j_before, 3))
    print("jitter (mean abs 2nd diff) after :", round(j_after, 3))
    if j_before > 0:
        print("jitter reduction:", str(round(100.0 * (1 - j_after / j_before), 1)) + "%")
    print("max spike residual before:",
          round(float(np.max(np.abs(noisy[spike_idx] - base_path[spike_idx]))), 2))
    print("max spike residual after :",
          round(float(np.max(np.abs(clean[spike_idx] - base_path[spike_idx]))), 2))
    print("added latency (worst-case trailing window):", _odd(args.wmax) - 1, "samples")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a noisy synthetic trajectory")
    p.add_argument("--n", type=int, default=120, help="trajectory length")
    p.add_argument("--noise", type=float, default=1.0, help="gaussian noise std")
    p.add_argument("--base", type=int, default=3, help="min (fast-motion) window")
    p.add_argument("--wmax", type=int, default=9, help="max (slow-motion) window")
    p.add_argument("--speed-thresh", type=float, default=1.0, help="speed at which window reaches base")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
