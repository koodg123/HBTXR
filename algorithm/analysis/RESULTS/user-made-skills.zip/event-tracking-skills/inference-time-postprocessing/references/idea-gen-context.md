# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Some event eye-tracking gains come purely from post-processing the prediction stream, not from the model.
The orchestrator pulls in this skill to reproduce those model-agnostic refinement stages (and their
smoothness metrics), because they drop onto any tracker and the reported improvement depends on the exact
filter parameters and metric definition.

## Worker Capability

Reproduce inference-time, model-agnostic refinement (motion-aware median filtering, optical-flow
refinement, trajectory smoothing) plus the smoothness/jitter metric, and report the latency it adds.

## Expected Outputs

- The post-processing module(s) operating on a prediction stream.
- The smoothness/jitter metric and a before/after comparison on accuracy and smoothness.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (output/post-processing cluster).
