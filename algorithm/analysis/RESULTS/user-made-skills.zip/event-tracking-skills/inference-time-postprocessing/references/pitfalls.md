# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- The median-filter base/maximum window and the motion-awareness rule (motion measure + threshold).
- The optical-flow method, its window, and the correction rule (and any blink gating).
- The trajectory-smoother type and strength (window or time constant).
- The jitter / smoothness metric definition (e.g. mean abs second difference).
- The added latency (group delay) from each filtering window.

## Failure modes
- **Over-smoothing saccades** -> a too-wide or non-adaptive window flattens genuine fast gaze motion, so
  accuracy on saccades drops while jitter looks great. Detect by reporting accuracy on fast-motion
  segments separately, not just the global mean.
- **Hidden added latency** -> a centered median/smoothing window adds group delay; claiming an online/
  low-latency result while using a centered window is dishonest. Detect by stating the window half-width
  as added latency, or use a causal (trailing) window for online claims.
- **Mean instead of median for blink spikes** -> a mean filter smears impulsive blink spikes across
  neighbors instead of removing them. Detect by checking spike suppression on blink intervals; the median
  should reject them.
- **Jitter improved but accuracy unreported** -> reporting only the smoothness metric hides an accuracy
  regression. Detect by always reporting accuracy AND jitter before/after.
- **Flow correction during blinks** -> nudging the prediction by optical flow when the eye is closed
  injects garbage. Detect by gating flow refinement off during detected blinks.
- **Metric definition drift** -> using a different jitter definition than the paper makes the numbers
  incomparable. Detect by writing the exact formula and diffing against the source.

## Detection recipe
For any post-processing, log: spatial accuracy before/after (overall and on fast-motion segments), jitter
before/after with the exact definition, and the added latency (window half-width / group delay). Confirm
blink spikes are suppressed and saccades are preserved.
