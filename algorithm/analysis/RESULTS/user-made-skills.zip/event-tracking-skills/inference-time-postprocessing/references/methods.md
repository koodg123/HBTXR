# Methods -- Inference-Time Post-Processing

These methods improve eye-tracking quality purely at inference, leaving the model untouched. Because they
are model-agnostic, reproducing them means reproducing the filters and the smoothness metrics, not
training anything. The value is temporal cleanliness, traded against a little added latency.

## Motion-aware median filtering
Apply a median filter over the prediction stream whose behavior adapts to motion, so it suppresses
blink-induced spikes and outliers while preserving genuine fast gaze dynamics (saccades). The key idea is
that a fixed median window either over-smooths fast motion or under-smooths during fixations; a
motion-aware window widens when motion is small (fixation/blink, where spikes are artifacts) and narrows
when motion is large (saccade, where the signal is real).
- Pin: the base/maximum window size, the motion measure (e.g. local speed = frame-to-frame displacement),
  and the motion-awareness rule (the threshold/mapping from motion to window size).
- Note: a median is robust to the impulsive spikes that blinks produce, which a mean filter would smear.

## Optical-flow-based local refinement
Estimate cumulative event motion (optical flow on the event stream) and nudge the predicted pupil/gaze to
be consistent with that motion, reducing spatial jitter and temporal discontinuities. The prediction is
corrected toward where the flow-implied motion says it should be.
- Pin: the optical-flow method (and its window), the correction rule (how strongly the prediction is moved
  toward the flow-consistent position), and any gating that disables correction during blinks.

## Trajectory smoothing
General temporal smoothing of the predicted trajectory (e.g. a moving average, exponential smoothing, or a
low-pass filter). Reproduce the smoother and its strength, balancing latency against smoothness.
- Pin: the smoother type and its strength (window or time constant), and the resulting group delay.

## Metrics for smoothness
Spatial accuracy alone does not capture temporal quality, so reproduce the smoothness metric too:
- **Jitter metric**: quantifies temporal smoothness of the predicted trajectory based on velocity/
  derivative behavior. A common, simple definition is the mean absolute second difference of the
  trajectory (the magnitude of frame-to-frame acceleration); lower is smoother. Report it alongside
  spatial accuracy.
Report spatial accuracy and the jitter/smoothness metric together, since post-processing trades a little
latency for much better temporal behavior.

## Details that decide reproduction
- The median-filter window and the motion-awareness threshold.
- The optical-flow method and the correction rule.
- The smoothness/jitter metric definition.
- Any added latency from the filtering window, which must be reported honestly for streaming use (a
  centered window of half-width w adds ~w frames of latency).
