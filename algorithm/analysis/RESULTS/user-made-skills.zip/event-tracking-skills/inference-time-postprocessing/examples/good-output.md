# Good Output

A strong output for `inference-time-postprocessing` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a motion-aware median / flow-refine / smoothing module; a jitter metric and a
before/after comparison on accuracy and smoothness.

## Worked mini-example

**Objective:** suppress blink spikes and reduce jitter on a pupil-trajectory stream, online use.

**Module spec (one line):**
`motion-aware median | base window=3, max window=9 | motion=local speed (px/frame) | rule: window widens
when speed < 1.0 px/frame (fixation/blink), narrows when speed high (saccade) | causal trailing window
(added latency = window-1 frames) | jitter = mean abs 2nd difference`

**Call sketch:**
```python
j_before = jitter(traj)                       # mean abs second difference
clean    = motion_median(traj, base=3, wmax=9, speed_thresh=1.0)
j_after  = jitter(clean)
```

**Validation evidence:** jitter 4.81 -> 1.27 px/frame^2 (-74%); spatial accuracy unchanged on saccade
segments (mean Euclidean 1.9 -> 1.9 px); blink spikes removed (3 impulse outliers suppressed); added
latency = 8 frames (max trailing window), reported for streaming use.

**Residual risks:** paper does not state the motion threshold -> assumed 1.0 px/frame to match the reported
jitter reduction; flagged for the orchestrator.
