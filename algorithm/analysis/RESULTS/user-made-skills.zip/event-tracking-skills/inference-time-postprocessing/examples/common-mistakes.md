# Common Mistakes

- Treating `inference-time-postprocessing` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing the median window, motion threshold, flow method, or jitter definition without marking assumptions.
- Producing prose without a concrete post-processing module and a numeric before/after comparison.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Over-smoothing saccades with a too-wide or non-adaptive window, dropping fast-motion accuracy.
- Hiding the added latency of a centered window while claiming an online/low-latency result.
- Using a mean filter that smears blink spikes instead of a median that rejects them.
- Reporting only the jitter improvement while omitting a possible accuracy regression.
