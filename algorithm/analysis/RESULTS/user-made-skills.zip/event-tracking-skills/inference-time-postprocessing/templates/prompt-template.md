# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Post-processing module (motion-aware-median / optical-flow-refine / trajectory-smoothing):

Parameters (median window, motion-awareness threshold, flow method, correction rule, jitter-metric definition):

Constraints:

Assumptions:

Required artifact:

Verification evidence (spatial accuracy before/after, jitter before/after, added latency):

Risks and missing inputs:
