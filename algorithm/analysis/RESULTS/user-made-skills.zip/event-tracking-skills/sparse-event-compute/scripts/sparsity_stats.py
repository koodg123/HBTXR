#!/usr/bin/env python3
"""Activation-sparsity meter and submanifold active-site mask for event models.

Two primitives that underlie the efficiency claims of sparse event eye-tracking
models (separate from quantization):

  * layer_sparsity(tensors)  -- fraction of (near-)zero entries per layer/tensor,
    the achieved activation sparsity that the efficiency claim depends on.

  * active_site_mask(tensor) -- the set of spatial sites (h, w) that contain any
    non-zero channel; this is exactly the active set a submanifold sparse
    convolution keeps fixed (it does NOT dilate the active region with depth).
    From the mask we derive the active-site count and the MAC reduction versus a
    dense convolution that computes every site.

The --demo path fabricates a small synthetic sparse activation tensor and prints
the per-layer sparsity %, the number of active sites, and the dense-vs-sparse MAC
reduction.

Examples
--------
    python sparsity_stats.py --demo
    python sparsity_stats.py --demo --channels 16 --height 32 --width 32 --sparsity 0.95
"""
from __future__ import annotations

import argparse

import numpy as np


def layer_sparsity(tensor, eps=1e-12):
    """Return the fraction of entries with absolute value <= eps (the sparsity)."""
    t = np.asarray(tensor)
    if t.size == 0:
        return 0.0
    return float(np.mean(np.abs(t) <= eps))


def active_site_mask(tensor, eps=1e-12):
    """Boolean [H, W] mask of spatial sites with any non-zero channel.

    `tensor` is expected as [C, H, W]. A site is active iff at least one channel is
    non-zero there. This is the active set a submanifold sparse conv preserves.
    """
    t = np.asarray(tensor)
    if t.ndim != 3:
        raise ValueError("expected a [C, H, W] tensor")
    return np.any(np.abs(t) > eps, axis=0)


def active_site_count(tensor, eps=1e-12):
    """Number of active spatial sites in a [C, H, W] tensor."""
    return int(active_site_mask(tensor, eps=eps).sum())


def mac_reduction(tensor, kernel=3, out_channels=None, eps=1e-12):
    """Dense-vs-submanifold MAC ratio for a conv over a [C_in, H, W] tensor.

    Dense conv computes H*W output sites; submanifold conv computes only the active
    sites. The per-site cost (C_in * k * k * C_out) cancels, so the ratio is just
    (H*W) / active_sites. Returns the speedup factor (>= 1).
    """
    t = np.asarray(tensor)
    c_in, h, w = t.shape
    if out_channels is None:
        out_channels = c_in
    per_site = c_in * kernel * kernel * out_channels
    active = max(1, active_site_count(t, eps=eps))
    dense_macs = h * w * per_site
    sparse_macs = active * per_site
    return float(dense_macs) / float(sparse_macs)


def _make_sparse_tensor(rng, c, h, w, sparsity):
    """A [C, H, W] tensor where a fraction `sparsity` of SITES are entirely zero."""
    t = rng.standard_normal((c, h, w))
    n_sites = h * w
    sparsity = min(max(sparsity, 0.0), 1.0)
    n_zero = int(round(sparsity * n_sites))
    flat_idx = rng.permutation(n_sites)[:n_zero]
    mask = np.zeros(n_sites, dtype=bool)
    mask[flat_idx] = True
    mask = mask.reshape(h, w)
    t[:, mask] = 0.0
    return t


def _demo(args):
    rng = np.random.default_rng(0)
    # Three "layers" with similar site-sparsity, like a submanifold stack.
    layers = {
        "conv1": _make_sparse_tensor(rng, args.channels, args.height, args.width, args.sparsity - 0.05),
        "conv2": _make_sparse_tensor(rng, args.channels, args.height, args.width, args.sparsity),
        "conv3": _make_sparse_tensor(rng, args.channels, args.height, args.width, args.sparsity + 0.02),
    }
    print("tensor shape per layer: [%d, %d, %d]" % (args.channels, args.height, args.width))
    print("name    sparsity%  active_sites  MAC_reduction_vs_dense")
    for name, t in layers.items():
        sp = layer_sparsity(t) * 100.0
        ac = active_site_count(t)
        red = mac_reduction(t, kernel=3)
        print("%-7s %8.1f  %12d  %17.2fx" % (name, sp, ac, red))
    total = args.height * args.width
    print("total spatial sites per layer:", total)
    print("note: active-site count stays bounded across depth -> submanifold conv does not dilate.")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a synthetic sparse tensor")
    p.add_argument("--channels", type=int, default=8)
    p.add_argument("--height", type=int, default=16)
    p.add_argument("--width", type=int, default=16)
    p.add_argument("--sparsity", type=float, default=0.9, help="target site-sparsity (0..1)")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
