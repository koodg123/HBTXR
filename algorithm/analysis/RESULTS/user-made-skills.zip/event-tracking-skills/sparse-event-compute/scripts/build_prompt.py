from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for sparse-event-compute.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--mechanism", default="submanifold",
                        help="submanifold|activation-sparsity-reg|delta-encoding|sparse-dataflow")
    args = parser.parse_args()
    print("Skill: sparse-event-compute")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Sparsity mechanism: {args.mechanism}")
    print("Pin: active-site rule, regularizer+weight, delta gating, buffering trigger, target sparsity %.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
