# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Sparsity mechanism (submanifold-sparse-conv / activation-sparsity-reg / change-delta-encoding / sparse-dataflow-buffered):

Parameters (active-site rule, regularizer + weight, delta gating, buffering trigger, target sparsity %):

Constraints:

Assumptions:

Required artifact:

Verification evidence (achieved sparsity %, active-site count, MAC/op reduction vs dense, hardware utilization/latency):

Risks and missing inputs:
