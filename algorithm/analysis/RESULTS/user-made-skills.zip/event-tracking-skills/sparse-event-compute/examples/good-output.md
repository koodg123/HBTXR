# Good Output

A strong output for `sparse-event-compute` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a submanifold sparse operator or activation-sparsity regularizer; an
efficiency report (achieved sparsity %, active-site count, op-reduction vs dense).

## Worked mini-example

**Objective:** reproduce the >90% activation-sparsity efficiency claim of a change-based event tracker.

**Mechanism spec (one line):**
`submanifold-sparse-conv (active-site preserved through depth) + activation-sparsity reg
(L1 on activations, lambda=1e-4, all conv blocks) | dense baseline = same net, ordinary conv`

**Measurement sketch:**
```python
stats = layer_sparsity(activations)        # per-layer fraction of zeros
mask  = active_site_mask(input_tensor)     # set of non-zero (c?,h,w) sites kept by submanifold conv
report = {"sparsity_pct": stats, "active_sites": mask.sum(),
          "mac_reduction_vs_dense": dense_macs / sparse_macs}
```

**Validation evidence:** achieved activation sparsity 92.4% (mean over representative streams);
active-site count stable across depth (1024 -> 1010 -> 998, no dilation); MAC reduction 8.1x vs the dense
baseline; accuracy delta -0.3 p10 (within noise).

**Residual risks:** paper does not state the regularizer weight -> assumed lambda=1e-4 to hit the reported
sparsity; flagged for the orchestrator. Hardware latency routed to the latency-characterization skill.
