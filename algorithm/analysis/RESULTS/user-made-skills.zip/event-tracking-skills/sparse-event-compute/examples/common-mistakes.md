# Common Mistakes

- Treating `sparse-event-compute` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing the active-site rule, regularizer weight, or buffering trigger without marking assumptions.
- Producing prose without a concrete sparse operator/regularizer and a numeric efficiency report.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Confusing a sparsity saving with a quantization saving (or reporting one as the other).
- Using ordinary sparse convolution where submanifold was intended, so the active set dilates with depth.
- Reporting activation sparsity on dense or unrepresentative inputs, inflating the number.
- Claiming an op-reduction or latency without stating the dense baseline or the sparse dataflow.
