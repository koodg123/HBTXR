# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- The active-site rule for submanifold convolution (and whether downsampling changes it).
- The activation-sparsity regularizer form, its weight (lambda), target layers, and annealing.
- The delta gating rule for change-based recurrence and where it is applied.
- The buffering scheme and active-data trigger for sparse dataflow.
- The dense baseline used for the op-reduction comparison.

## Failure modes
- **Confusing sparsity with quantization** -> reporting a quantization saving as a sparsity saving (or vice
  versa). Detect by attributing each part of the efficiency claim to its mechanism and reporting them
  separately.
- **Active-set dilation** -> using ordinary sparse convolution where submanifold was intended, so the
  active region grows with depth and sparsity collapses. Detect by measuring active-site count per layer;
  it should stay roughly constant for submanifold conv.
- **Sparsity reported on the wrong input** -> measuring activation sparsity on dense / unrepresentative
  inputs inflates the number. Detect by reporting sparsity under representative event streams (including
  fixation and saccade intervals).
- **Missing regularizer weight** -> guessing lambda changes both the achieved sparsity and the accuracy.
  Detect by recording lambda and the achieved sparsity together and diffing against the paper.
- **Op-reduction without a stated baseline** -> "5x fewer MACs" is meaningless without the dense reference.
  Detect by stating the dense baseline and how MACs are counted.
- **Latency claimed without the dataflow** -> claiming a streaming latency that the offline/dense path
  cannot achieve. Detect by routing the latency measurement to the latency-characterization skill under the
  actual sparse dataflow.
- **Delta gating without reporting effective work** -> claiming change-based savings without the per-step
  changed-unit fraction. Detect by logging that fraction.

## Detection recipe
For any sparse mechanism, log: per-layer active-site count, achieved activation sparsity % under
representative inputs, MAC/op count vs the dense baseline, and (for streaming) latency under the sparse
dataflow. A submanifold layer should show stable active-site count across depth.
