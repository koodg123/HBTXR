# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Event eye-tracking efficiency claims usually come from exploiting sparsity, not from quantization. The
orchestrator pulls in this skill when a reproduction must reproduce the speed/power claim, because the
sparsity mechanism (submanifold conv, activation-sparsity regularization, delta encoding, sparse
dataflow) is what produces the saving and is easy to reproduce incorrectly.

## Worker Capability

Reproduce the sparsity-exploiting mechanism and report the achieved sparsity and operation reduction,
distinct from quantization, with hardware realization routed to the FPGA/resource/latency skills.

## Expected Outputs

- The sparse operators (submanifold conv / delta gating) or the sparsity regularization.
- An efficiency report: achieved activation sparsity %, active-site count, op-reduction vs dense.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (efficiency/sparsity cluster).
