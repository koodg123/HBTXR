# Methods -- Sparsity-Exploiting Compute

Events are intrinsically sparse; the efficiency comes from never computing on empty space. These
techniques are separate from quantization. Reproduce the mechanism, then report the achieved sparsity in
numbers.

## Submanifold sparse convolution
A convolution that computes outputs only at the input's already-active sites and keeps that active set
fixed across the layer, rather than letting the receptive field "dilate" the active region (which ordinary
sparse convolution does and which destroys sparsity through depth).
- Active-site rule: an output site is computed iff the corresponding input site is active; the active-site
  set is preserved layer to layer.
- Why it matters: this is what keeps sparsity high through depth and yields the speedup on a sparse
  accelerator. Reproduce the exact active-site rule and how features at active sites are gathered and
  scattered.
- Pin: the active-site definition, kernel size/stride, and whether any downsampling changes the active set.

## Activation-sparsity regularization
Penalize non-zero activations during training (e.g. an L1/L0-surrogate penalty on activations, or a
target-sparsity loss) to push activation sparsity very high -- often well above 90 percent -- enabling
large savings on event-based / neuromorphic processors.
- Pin: the regularizer form and its weight (lambda), the layers it applies to, and any annealing schedule.
- Report: the achieved activation sparsity under representative inputs, because the efficiency claim
  depends on it.

## Change / delta encoding
In recurrent paths, propagate only the changes between time steps; units whose state does not change cost
nothing. This is what makes change-based recurrent trackers cheap.
- Pin: the delta gating rule (threshold on the change, or exact-zero detection) and where in the recurrent
  cell it is applied.
- Report: the fraction of units that change per step (the effective work).

## Sparse dataflow / online buffered inference
Process events incrementally, buffering layer outputs so that only active or newly-arrived data is
recomputed; this minimizes latency and redundant work for streaming inputs.
- Pin: the buffering scheme (what is cached between steps) and the active-data trigger (what marks data as
  needing recompute).
- Report: latency and redundant-work reduction under the sparse dataflow.

## Reporting the efficiency
Sparsity claims need numbers, not adjectives:
- Achieved activation sparsity (percentage) under representative inputs.
- Arithmetic-operation reduction (for example MAC count) versus a dense baseline.
- For hardware, the utilization and latency under the sparse dataflow -- hand to the FPGA/HLS,
  resource-reporting, and latency-characterization skills.

## Details that decide reproduction
- The exact active-site / change rule and how sparsity is maintained through layers.
- The sparsity regularizer and weight, and the achieved sparsity.
- The buffering / online trigger for streaming inference.
