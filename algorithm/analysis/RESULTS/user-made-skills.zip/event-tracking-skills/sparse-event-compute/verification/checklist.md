# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The sparse operator or sparsity regularization is present and traceable.
- [ ] The efficiency report (achieved sparsity %, active-site count) is present.
- [ ] The op-reduction is stated against an explicit dense baseline.
- [ ] The active-site count is stable across depth for submanifold convolution (no dilation).
- [ ] Achieved sparsity is measured under representative inputs (fixation and saccade intervals).
- [ ] The sparsity saving is distinguished from any quantization saving.
- [ ] Hardware latency/utilization is routed to the FPGA/resource/latency skills.
- [ ] Residual risks and missing inputs are listed.
