---
name: sparse-event-compute
description: Reproduce the sparsity-exploiting efficiency techniques that make event eye-tracking models fast and low-power, distinct from quantization. Use this whenever a method relies on submanifold sparse convolution, activation-sparsity regularization to reach very high sparsity (for example over 90 percent), change or delta encoding of recurrent paths, sparse dataflow or online buffered inference that processes only active sites, or otherwise turns event sparsity into compute savings. Trigger on "submanifold sparse convolution", "regularize for activation sparsity", "change-based delta encoding", "sparse dataflow accelerator", "online buffered sparse inference", "exploit event sparsity for efficiency", or any reproduction whose efficiency claim comes from sparsity, even without exact wording. Pairs with on-device-ai, quantization-error-analysis, and the FPGA/HLS and resource-reporting skills for hardware realization.
---

# Sparse Event Compute

## Overview

Events are intrinsically sparse, and much of the efficiency in event eye tracking comes from never
computing on empty space. These techniques are separate from quantization and easy to get wrong, so
reproducing the efficiency claim means reproducing the sparsity mechanism -- not just the accuracy -- and
reporting the achieved sparsity in numbers. It is a P0 IDEA-Gen leaf skill under
`Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/hardware, assumptions,
expected deliverables, verification evidence). If the task is underspecified -- e.g. the active-site rule,
the sparsity regularizer weight, or the buffering trigger is unknown -- list the missing inputs before
choosing a mechanism. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "reach >90% activation sparsity with <1 point p10 loss").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (model, representation), and downstream consumers (FPGA/HLS, resource-reporting, latency).
3. Separate known facts from assumptions about the active-site rule, regularizer weight, delta gating, and buffering trigger.
4. Choose the smallest artifact that unblocks the next Worker: a sparse operator or regularizer plus an efficiency report.
5. Define the evidence required for signoff before producing the artifact (achieved sparsity %, active-site count, op-reduction vs dense).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the sparsity techniques and `references/pitfalls.md` for the failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/sparsity_stats.py` to measure activation sparsity per layer/tensor and to derive the submanifold active-site mask.
5. Produce the sparse operators / regularization plus an efficiency report with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Reproduce the sparsity mechanism exactly and report the achieved sparsity; route hardware speedups to the
FPGA/HLS, resource-reporting, and latency skills.

The techniques (full detail in `references/methods.md`): **submanifold sparse convolution** -- compute
only at active sites and keep the active set fixed, avoiding the dilation ordinary sparse convolution
causes; reproduce the active-site rule and how features propagate, since this preserves sparsity through
depth. **Activation-sparsity regularization** -- penalize non-zero activations during training to push
activation sparsity very high (often well above 90 percent); reproduce the regularizer and its weight and
report the achieved sparsity. **Change/delta encoding** -- in recurrent paths, propagate only the changes
between steps so unchanged units cost nothing; reproduce the delta gating. **Sparse dataflow / online
buffered inference** -- process events incrementally, buffering layer outputs so only active or
newly-arrived data is recomputed; reproduce the buffering scheme and the active-data trigger.

Report the efficiency in numbers, not adjectives: achieved activation sparsity (percentage) under
representative inputs; arithmetic-operation reduction (e.g. MAC count) versus a dense baseline; and for
hardware, the utilization and latency under the sparse dataflow. The details that decide reproduction are
the exact active-site/change rule and how sparsity is maintained through layers, the sparsity regularizer
and weight (and achieved sparsity), and the buffering/online trigger for streaming inference.

## Deliverables

- The sparse operators (submanifold conv / delta gating) or the sparsity regularization.
- An efficiency report: achieved sparsity %, active-site count, op-reduction vs a dense baseline.
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics (achieved sparsity, op-reduction) or explicitly marked as assumptions.
- The active-site rule, regularizer weight, and buffering trigger are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The active-site/change rule, regularizer weight, or buffering trigger is missing from the source.
- Multiple plausible mechanisms would materially change the efficiency claim.
- Verification depends on unavailable hardware synthesis/profiling (route to the FPGA/resource/latency skills).
- The task should be split into a new leaf skill (e.g. a dedicated sparse-accelerator-dataflow skill).
