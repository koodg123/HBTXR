# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The ablation matrix is present and each row changes exactly one factor.
- [ ] Held-fixed factors are explicit per row.
- [ ] A seed plan (same seed set across variants) is present.
- [ ] The metric definition and evaluation regime are constant across all variants.
- [ ] Deltas carry effect sizes and confidence intervals, not single-run numbers.
- [ ] Deltas within the CI are flagged as "not essential", not as real effects.
- [ ] The paper's own ablation table is reproduced before any new ablation.
- [ ] Residual risks and missing inputs are listed.
