# Common Mistakes

- Treating `ablation-and-experiment-designer` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing the component list, held-fixed factors, or metric/regime without marking assumptions.
- Producing prose without a concrete ablation matrix and seed plan another Worker or evaluator can run.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Changing two factors in one row, so the delta cannot be attributed to a single component.
- Reporting a single-seed delta as a real effect when it is within run-to-run noise.
- Letting schedule/budget/data-split drift between the full model and a variant (confounder drift).
- Reporting only the direction of an effect, not its size and confidence interval.
