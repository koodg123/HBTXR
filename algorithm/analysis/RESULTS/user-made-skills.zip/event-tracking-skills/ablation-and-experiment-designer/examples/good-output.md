# Good Output

A strong output for `ablation-and-experiment-designer` includes a concise objective, source mapping,
explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: a one-factor-at-a-time ablation matrix with held-fixed factors explicit; a
seed and reporting plan; the resulting table with deltas, effect sizes, and CIs.

## Worked mini-example

**Objective:** reproduce the paper's ablation showing representation, recurrence, and Event-Cutout each matter.

**Ablation matrix (one factor per row):**
```
| variant            | change vs full        | held fixed                       | metric | delta |
| ------------------ | --------------------- | -------------------------------- | ------ | ----- |
| full               | (reference)           | all                              | p10    | 0     |
| - recurrence       | remove recurrent block| data,repr,loss,aug,sched,seeds   | p10    | ?     |
| swap voxel->count  | representation        | model,loss,aug,sched,seeds       | p10    | ?     |
| - event-cutout     | remove augmentation   | data,model,loss,sched,seeds      | p10    | ?     |
```

**Seed plan:** seeds = {0, 1, 2, 3, 4} applied to EVERY variant (paired); report mean +/- 95% CI; flag any
delta whose CI crosses 0 as "not essential".

**Validation evidence (after runs):** full p10 = 93.0; - recurrence -3.1 (CI [-3.6,-2.6], essential);
swap voxel->count -1.2 (CI [-1.9,-0.5], matters); - event-cutout -0.3 (CI [-0.8,+0.2], within noise, not
essential). Single-factor-per-row confirmed; paper's table reproduced before extensions.

**Residual risks:** paper does not state its seed count -> assumed 5 seeds; flagged for the orchestrator.
