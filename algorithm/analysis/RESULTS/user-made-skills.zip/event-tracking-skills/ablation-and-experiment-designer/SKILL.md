---
name: ablation-and-experiment-designer
description: Design the ablation studies and controlled experiments needed to reproduce and validate a paper's claims about which components matter. Use this whenever a reproduction must build an ablation matrix (which components to remove or vary one at a time), set up controlled comparisons with proper baselines and fixed confounders, choose what to sweep (representation, architecture block, loss term, augmentation, training stage), or structure the seeds and reporting so ablation conclusions are trustworthy. Trigger on "design the ablations", "which components should I ablate", "set up a controlled experiment", "build the ablation table", "what should I vary to show this matters", or any reproduction that needs to demonstrate component contributions, even without exact wording. Pairs with experimental-rigor-stats (for distributions and confidence intervals) and the training/benchmark harness.
---

# Ablation and Experiment Designer

## Overview

A reproduction is not complete when the headline number matches; the paper's claims usually rest on
ablations showing each component earns its place. This skill makes reproducing those ablations -- and
designing new ones to probe gaps -- disciplined: controlled experiments where exactly one thing changes at
a time, with confounders held fixed and conclusions backed by seeds and effect sizes. It is a P0 IDEA-Gen
leaf skill under `Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, components to credit, assumptions,
expected deliverables, verification evidence). If the task is underspecified -- e.g. the component list,
the held-fixed factors, or the metric/regime is unknown -- list the missing inputs before designing the
matrix. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "show each of components A,B,C changes p10 beyond noise").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (the full model and recipe), and downstream consumers (experimental-rigor-stats, the reproduction log).
3. Separate known facts from assumptions about the component list, held-fixed factors, metric definition, and evaluation regime.
4. Choose the smallest artifact that unblocks the next Worker: a one-factor-at-a-time ablation matrix plus a seed plan.
5. Define the evidence required for signoff before producing the artifact (per-variant mean + CI across seeds, effect sizes).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for how to build the matrix and control confounders and `references/pitfalls.md` for the failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/ablation_matrix.py` to generate the one-factor-at-a-time ablation table (baseline + each component removed/varied) and a seed assignment.
5. Produce the ablation matrix with held-fixed factors explicit, the seed/reporting plan, and (after runs) the table with effect sizes and confidence intervals.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Change exactly one factor per row, hold everything else fixed, and back each conclusion with multiple
seeds and an effect size -- not a single run.

Build the ablation matrix (full detail in `references/methods.md`): list the components the paper credits
and define a row per controlled variant, removing or swapping one component while holding everything else
fixed (a full-model reference row, then `- component A`, `swap repr X to Y`, etc.), each row recording the
change vs full, the held-fixed factors, the metric, and the delta. Common axes to ablate in this domain:
the event representation, a specific architecture block (recurrence, SSM, attention variant), a loss term
(and its weight), an augmentation, and a training stage (pretraining, finetuning, distillation).

Control the confounders -- the conclusion is only valid if nothing else moved: same data split, same seeds
(or seed sweep), same training budget and schedule across variants; change exactly one factor per row (if
two must change together, say so and interpret cautiously); use the same metric definition and evaluation
regime (online/offline) throughout. Make conclusions trustworthy: run each variant across multiple seeds
and report mean plus a confidence interval (hand the statistics to experimental-rigor-stats), state the
effect size (a component that changes the metric within noise is not "essential"), and reproduce the
paper's ablation table first, then design additional gap-hunting ablations (often the most informative).

## Deliverables

- A one-factor-at-a-time ablation matrix with held-fixed factors made explicit.
- A seed and reporting plan (seeds per variant, mean + CI, effect-size reporting).
- The resulting table with deltas, effect sizes, and confidence intervals (after runs).
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Each row changes exactly one factor; held-fixed factors are explicit.
- Conclusions are backed by seeds and effect sizes, not single runs, or marked as assumptions.
- The metric definition and evaluation regime are constant across variants.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.

## Escalate When

- The component list, held-fixed factors, metric, or evaluation regime is missing from the source.
- Two factors cannot be separated, so no single-factor row is possible.
- The compute budget cannot support the seed sweep the conclusions require.
- The task should be split into a new leaf skill (e.g. a dedicated hyperparameter-sweep skill).
