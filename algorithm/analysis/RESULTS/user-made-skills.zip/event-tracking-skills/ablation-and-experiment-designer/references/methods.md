# Methods -- Ablation Matrix and Controlled Experiments

A reproduction is complete only when the paper's component claims hold up. Reproduce the ablations as
controlled experiments where exactly one thing changes at a time, then design new ones to probe gaps.

## Build the ablation matrix
List the components the paper credits and define a row per controlled variant, removing or swapping one
component while holding everything else fixed:

```
| Variant            | Change vs full | Held fixed                | Metric | Delta |
| ------------------ | -------------- | ------------------------- | ------ | ----- |
| Full model         | (reference)    | all                       |        | 0     |
| - component A      | remove A       | data, training, eval, seed|        |       |
| swap repr X to Y   | representation | model, training, eval     |        |       |
```

Each row records: the change vs the full model, the factors held fixed, the metric, and the resulting
delta. The full-model row is the reference (delta 0). A "remove" row deletes a component; a "swap" row
replaces one design choice with an alternative while keeping the rest.

## What to ablate in this domain
Common axes for event eye tracking:
- **Event representation** (voxel vs time-surface vs count vs graph, or its parameters).
- **Architecture block** (recurrence, SSM, a specific attention variant, an output head).
- **Loss term** (presence/absence and its weight).
- **Augmentation** (each event-aware augmentation, or the whole set).
- **Training stage** (pretraining, finetuning, distillation -- with vs without).

## Control the confounders
The conclusion is valid only if nothing else moved:
- Same data split, same seeds (or the same seed sweep), same training budget and schedule across variants.
- Change exactly one factor per row; if two must change together, say so and interpret cautiously.
- Use the same metric definition and evaluation regime (online/offline) throughout (coordinate with the
  benchmark harness and training harness).

## Make conclusions trustworthy
- Run each variant across multiple seeds and report mean plus a confidence interval, not a single run, so a
  small ablation delta is not noise (hand the statistics to experimental-rigor-stats).
- State the effect size, not just the direction; a component that changes the metric within noise is not
  "essential."
- Reproduce the paper's ablation table first, then design additional ablations to probe any reproduction
  gap. The gap-hunting ablations are often the most informative.

## Seed plan
Assign a fixed, reproducible set of seeds to every variant (the same set, so variants are paired). Record
the seeds with the matrix so the run is repeatable and the CI is computed over the intended replicates.
