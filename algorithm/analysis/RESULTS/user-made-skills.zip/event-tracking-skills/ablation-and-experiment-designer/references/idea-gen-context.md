# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Matching a paper's headline number does not validate its claims; the ablations do. The orchestrator pulls
in this skill to reproduce the paper's ablation table (and to design gap-hunting ablations) as controlled,
one-factor-at-a-time experiments, because that is what shows each component earns its place.

## Worker Capability

Build a one-factor-at-a-time ablation matrix with confounders held fixed, plus a seed and reporting plan
so the resulting deltas carry effect sizes and confidence intervals (statistics handed to
experimental-rigor-stats).

## Expected Outputs

- A one-factor-at-a-time ablation matrix with held-fixed factors explicit.
- A seed and reporting plan, and (after runs) the table with deltas, effect sizes, and CIs.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (validation/experiment-design cluster).
