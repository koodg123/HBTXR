# Pitfalls & Parameter-Pinning Checklist

## Factors to pin every time
- The component list the paper credits (and the alternative for each swap row).
- The held-fixed factors per row (data split, schedule, budget, seeds, metric, eval regime).
- The metric definition and evaluation regime, constant across all variants.
- The seed set assigned to every variant (the same set, for paired comparison).
- How effect size and confidence interval are computed and reported.

## Failure modes
- **Two factors moved at once** -> the delta cannot be attributed to a single component. Detect by checking
  each row differs from the full model in exactly one factor; if not, label it a combined variant and
  interpret cautiously.
- **Single-seed ablation** -> a small delta is reported as a real effect when it is within run-to-run
  noise. Detect by requiring multiple seeds and reporting mean + CI; deltas inside the CI are not
  "essential."
- **Confounder drift** -> different schedule/budget/data split between the full model and a variant
  silently causes the delta. Detect by recording the held-fixed factors per row and diffing them.
- **Metric/regime inconsistency** -> comparing an online variant to an offline full model (or different
  metric definitions) makes deltas meaningless. Detect by asserting one metric definition and one regime
  across the whole matrix.
- **Direction without effect size** -> "removing A hurts" with no magnitude. Detect by always reporting the
  effect size and its CI, not just the sign.
- **Skipping the paper's own ablations** -> designing new ablations before reproducing the paper's table,
  so a reproduction gap is missed. Detect by reproducing the published table first, then extending.
- **Unpaired seeds** -> different seed sets per variant inflate variance. Detect by using the same seed set
  across variants.

## Detection recipe
For any ablation matrix, log: the per-row single-factor change, the held-fixed factors, the seed set, and
per-variant mean + CI with effect sizes. Confirm the paper's table is reproduced before any new ablation.
