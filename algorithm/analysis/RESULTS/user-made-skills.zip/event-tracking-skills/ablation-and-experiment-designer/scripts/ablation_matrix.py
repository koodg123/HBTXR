#!/usr/bin/env python3
"""Generate a one-factor-at-a-time ablation table and a seed plan.

From a component list this builds:

  * a controlled ablation MATRIX: a baseline (full-model) reference row plus one row
    per component, each removing or varying exactly that component while holding all
    others fixed. Every row records the change-vs-full and the held-fixed factors,
    so each delta is attributable to a single factor.

  * a SEED PLAN: the same set of seeds assigned to every variant (paired), so a
    confidence interval is computed over the intended replicates and variants are
    comparable.

This is design-time scaffolding (it does not run training); the deltas/CIs are filled
in after the runs. The --demo path prints a small ablation table and the seed
assignment for a few example components.

Examples
--------
    python ablation_matrix.py --demo
    python ablation_matrix.py --demo --components representation,recurrence,loss --seeds 3 --metric mEuclid
"""
from __future__ import annotations

import argparse


def build_matrix(components, mode="remove", metric="p10"):
    """Return a list of ablation rows (dicts).

    Row 0 is the full-model reference. Each subsequent row changes exactly one
    component: 'remove' deletes it, 'vary' swaps it for an alternative. The other
    components are listed as held-fixed.
    """
    components = [c.strip() for c in components if c.strip()]
    rows = []
    rows.append({
        "variant": "full",
        "change_vs_full": "(reference)",
        "factor": "none",
        "held_fixed": "all",
        "metric": metric,
        "delta": 0.0,
    })
    verb = "remove" if mode == "remove" else "vary"
    sign = "-" if mode == "remove" else "~"
    for c in components:
        others = [o for o in components if o != c] + ["data", "schedule", "budget", "seeds"]
        rows.append({
            "variant": "%s %s" % (sign, c),
            "change_vs_full": "%s %s" % (verb, c),
            "factor": c,
            "held_fixed": ", ".join(others),
            "metric": metric,
            "delta": None,  # filled after runs
        })
    return rows


def seed_plan(components, n_seeds=5, base_seed=0):
    """Same seed set assigned to EVERY variant (paired comparison)."""
    seeds = list(range(base_seed, base_seed + n_seeds))
    variants = ["full"] + ["- %s" % c.strip() for c in components if c.strip()]
    return {"seeds": seeds, "assignment": {v: seeds for v in variants}}


def single_factor_ok(rows):
    """True if every non-reference row changes exactly one named component factor."""
    for r in rows[1:]:
        if r["factor"] in (None, "", "none"):
            return False
    return True


def _print_table(rows):
    w_var = max(len(r["variant"]) for r in rows)
    w_chg = max(len(r["change_vs_full"]) for r in rows)
    header = "%-*s | %-*s | %-6s | %-7s | held fixed" % (
        w_var, "variant", w_chg, "change vs full", "metric", "delta")
    print(header)
    print("-" * len(header))
    for r in rows:
        delta = "0" if r["delta"] == 0.0 else ("?" if r["delta"] is None else str(r["delta"]))
        held = r["held_fixed"]
        if len(held) > 40:
            held = held[:37] + "..."
        print("%-*s | %-*s | %-6s | %-7s | %s" % (
            w_var, r["variant"], w_chg, r["change_vs_full"], r["metric"], delta, held))


def _demo(args):
    components = [c.strip() for c in args.components.split(",") if c.strip()]
    rows = build_matrix(components, mode="remove", metric=args.metric)
    print("Ablation matrix (one factor per row):")
    _print_table(rows)
    print()
    ok = single_factor_ok(rows)
    print("single-factor-per-row check:", "PASS" if ok else "FAIL")
    print("variants (incl. baseline):", len(rows))
    print()
    plan = seed_plan(components, n_seeds=args.seeds)
    print("Seed plan (same set per variant -> paired comparison):")
    print("  seeds:", plan["seeds"])
    for variant, seeds in plan["assignment"].items():
        print("  %-18s -> seeds %s" % (variant, seeds))
    total_runs = len(plan["assignment"]) * len(plan["seeds"])
    print("total training runs:", total_runs,
          "(%d variants x %d seeds)" % (len(plan["assignment"]), len(plan["seeds"])))
    print("note: deltas '?' are filled after runs; report mean + CI and flag deltas within the CI.")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="print a small ablation table and seed plan")
    p.add_argument("--components", default="representation,recurrence,event-cutout",
                   help="comma-separated components to ablate")
    p.add_argument("--seeds", type=int, default=5, help="number of paired seeds per variant")
    p.add_argument("--metric", default="p10", help="metric name for the table")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
