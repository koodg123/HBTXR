# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Components to credit / ablate (representation, architecture block, loss term, augmentation, training stage):

Held-fixed factors (data split, schedule, budget, metric definition, eval regime):

Seed plan (seeds per variant, mean + CI, effect-size reporting):

Constraints:

Assumptions:

Required artifact:

Verification evidence (per-variant mean + CI, effect sizes, single-factor-per-row check):

Risks and missing inputs:
