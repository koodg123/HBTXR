#!/usr/bin/env python3
"""Direct least-squares ellipse fit plus a polynomial gaze-mapping fit/apply.

Implements the two core primitives of a geometric (classical) eye tracker:

1. fit_ellipse: Fitzgibbon's direct least-squares conic fit, constrained to an
   ellipse (4AC - B^2 = 1), returning geometric parameters
   (cx, cy, axis_a, axis_b, theta) with axis_a >= axis_b and theta the major-axis
   orientation in radians. Solved as a generalized eigenproblem on the scatter
   matrices; the ellipse constraint guarantees a non-degenerate ellipse.

2. fit_poly_gaze / apply_poly_gaze: fit a 2nd-order (configurable) bivariate
   polynomial mapping a pupil coordinate (px, py) -> gaze (gx, gy) by least
   squares on calibration pairs, and apply it. This is the standard pupil-to-gaze
   calibration map.

Examples
--------
    python ellipse_fit.py --demo
    python ellipse_fit.py --demo --noise 0.5 --gaze-order 2
    python ellipse_fit.py --help
"""
from __future__ import annotations

import argparse

import numpy as np


def fit_ellipse(points):
    """Direct least-squares ellipse fit (Fitzgibbon 1996).

    points : array [N, 2] of (x, y).
    Returns (cx, cy, axis_a, axis_b, theta) where axis_a >= axis_b and theta is
    the orientation of the MAJOR axis in radians, normalized to (-pi/2, pi/2].
    """
    pts = np.asarray(points, dtype=np.float64)
    x = pts[:, 0]
    y = pts[:, 1]
    # Design matrix for the conic A x^2 + B xy + C y^2 + D x + E y + F = 0.
    D = np.column_stack([x * x, x * y, y * y, x, y, np.ones_like(x)])
    S = D.T @ D                                   # scatter matrix (6x6)
    # Constraint matrix enforcing 4AC - B^2 = 1 (ellipse-specific).
    C = np.zeros((6, 6), dtype=np.float64)
    C[0, 2] = 2.0
    C[2, 0] = 2.0
    C[1, 1] = -1.0
    # Solve the generalized eigenproblem S a = lambda C a.
    eigvals, eigvecs = np.linalg.eig(np.linalg.solve(S, C))
    # The ellipse solution is the eigenvector with the single positive eigenvalue.
    finite = np.isfinite(eigvals)
    cand = np.where(finite & (eigvals > 0))[0]
    if len(cand) == 0:
        cand = np.where(finite)[0]
    idx = cand[np.argmax(eigvals[cand].real)]
    a = eigvecs[:, idx].real
    return _conic_to_geometric(a)


def _conic_to_geometric(coef):
    """Convert conic coefficients (A,B,C,D,E,F) to (cx, cy, axis_a, axis_b, theta)."""
    A, B, C, Dc, E, F = coef
    b2 = B / 2.0
    d2 = Dc / 2.0
    e2 = E / 2.0
    den = b2 * b2 - A * C
    cx = (C * d2 - b2 * e2) / den
    cy = (A * e2 - b2 * d2) / den
    num = 2.0 * (A * e2 * e2 + C * d2 * d2 + F * b2 * b2 - 2.0 * b2 * d2 * e2 - A * C * F)
    s = np.sqrt((A - C) ** 2 + 4.0 * b2 * b2)
    # ax1 corresponds to the (A+C)+s branch; ax2 to the (A+C)-s branch.
    ax1 = np.sqrt(abs(num / (den * ((A + C) + s))))
    ax2 = np.sqrt(abs(num / (den * ((A + C) - s))))
    # theta0 is the orientation tied to the ax1 branch.
    if abs(b2) < 1e-12:
        theta0 = 0.0 if A <= C else np.pi / 2.0
    else:
        theta0 = 0.5 * np.arctan2(2.0 * b2, (A - C))
    # Pick the major axis and align theta to it.
    if ax1 >= ax2:
        axis_a, axis_b, theta = ax1, ax2, theta0
    else:
        axis_a, axis_b, theta = ax2, ax1, theta0 + np.pi / 2.0
    # Normalize theta to (-pi/2, pi/2].
    theta = (theta + np.pi / 2.0) % np.pi - np.pi / 2.0
    return float(cx), float(cy), float(axis_a), float(axis_b), float(theta)


def ellipse_residual(points, params):
    """RMS algebraic residual vs the fitted ellipse (a diagnostic)."""
    pts = np.asarray(points, dtype=np.float64)
    cx, cy, a, b, theta = params
    ct, st = np.cos(-theta), np.sin(-theta)
    xr = ct * (pts[:, 0] - cx) - st * (pts[:, 1] - cy)
    yr = st * (pts[:, 0] - cx) + ct * (pts[:, 1] - cy)
    val = (xr / a) ** 2 + (yr / b) ** 2 - 1.0
    return float(np.sqrt(np.mean(val ** 2)))


def _poly_features(px, py, order):
    """Bivariate polynomial feature vector up to the given total degree."""
    feats = []
    for i in range(order + 1):
        for j in range(order + 1 - i):
            feats.append((px ** i) * (py ** j))
    return np.array(feats, dtype=np.float64)


def fit_poly_gaze(pupil_xy, gaze_xy, order=2):
    """Least-squares fit of a bivariate polynomial map pupil (px,py) -> gaze (gx,gy).

    Returns coefficient matrix [n_features, 2].
    """
    pupil_xy = np.asarray(pupil_xy, dtype=np.float64)
    gaze_xy = np.asarray(gaze_xy, dtype=np.float64)
    Phi = np.array([_poly_features(p[0], p[1], order) for p in pupil_xy])
    coef, _, _, _ = np.linalg.lstsq(Phi, gaze_xy, rcond=None)
    return coef


def apply_poly_gaze(coef, pupil_xy, order=2):
    """Apply a fitted polynomial gaze map to one or many pupil coordinates."""
    pupil_xy = np.atleast_2d(np.asarray(pupil_xy, dtype=np.float64))
    Phi = np.array([_poly_features(p[0], p[1], order) for p in pupil_xy])
    out = Phi @ coef
    return out if out.shape[0] > 1 else out[0]


def _demo(args):
    rng = np.random.default_rng(0)
    # --- synthetic noisy ellipse boundary ---
    cx_t, cy_t, a_t, b_t, th_t = 40.0, 24.0, 12.0, 7.0, np.deg2rad(25.0)
    t = np.linspace(0, 2 * np.pi, args.n, endpoint=False)
    ex = a_t * np.cos(t)
    ey = b_t * np.sin(t)
    ct, st = np.cos(th_t), np.sin(th_t)
    bx = cx_t + ct * ex - st * ey + rng.normal(0, args.noise, args.n)
    by = cy_t + st * ex + ct * ey + rng.normal(0, args.noise, args.n)
    pts = np.column_stack([bx, by])
    params = fit_ellipse(pts)
    res = ellipse_residual(pts, params)
    cx, cy, a, b, th = params
    print("ellipse fit (direct least-squares conic)")
    print("  true   center/axes/theta:", (cx_t, cy_t), (round(a_t, 2), round(b_t, 2)),
          round(np.rad2deg(th_t), 1), "deg")
    print("  fitted center/axes/theta:", (round(cx, 2), round(cy, 2)),
          (round(a, 2), round(b, 2)), round(np.rad2deg(th), 1), "deg")
    print("  center error (px):", round(np.hypot(cx - cx_t, cy - cy_t), 3))
    print("  axis error (px):", round(abs(a - a_t), 3), "/", round(abs(b - b_t), 3))
    print("  RMS algebraic residual:", round(res, 4))

    # --- synthetic pupil -> gaze calibration (a smooth quadratic ground truth) ---
    gx_targets, gy_targets = np.meshgrid(np.linspace(-1, 1, 3), np.linspace(-1, 1, 3))
    gaze = np.column_stack([gx_targets.ravel(), gy_targets.ravel()])
    pupil = np.column_stack([
        30.0 + 8.0 * gaze[:, 0] + 0.5 * gaze[:, 0] * gaze[:, 1],
        20.0 + 6.0 * gaze[:, 1] - 0.3 * gaze[:, 1] ** 2,
    ])
    # Held-out test points (interpolated, not on the calibration grid).
    test_gaze = np.array([[-0.5, 0.5], [0.5, -0.5], [0.0, 0.0]])
    test_pupil = np.column_stack([
        30.0 + 8.0 * test_gaze[:, 0] + 0.5 * test_gaze[:, 0] * test_gaze[:, 1],
        20.0 + 6.0 * test_gaze[:, 1] - 0.3 * test_gaze[:, 1] ** 2,
    ])
    coef = fit_poly_gaze(pupil, gaze, order=args.gaze_order)
    pred = np.atleast_2d(apply_poly_gaze(coef, test_pupil, order=args.gaze_order))
    map_res = float(np.sqrt(np.mean(np.sum((pred - test_gaze) ** 2, axis=1))))
    print("polynomial gaze mapping (order", args.gaze_order, "| 3x3 calib grid)")
    print("  held-out mapping residual (RMS, normalized units):", round(map_res, 5))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="fit a synthetic noisy ellipse and a gaze map")
    p.add_argument("--n", type=int, default=80, help="number of boundary points")
    p.add_argument("--noise", type=float, default=0.4, help="boundary point noise std (px)")
    p.add_argument("--gaze-order", type=int, default=2, help="polynomial order of the gaze map")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
