from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a prompt pack for online-pupil-fitting-and-gaze-mapping.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--fit", default="direct-lsq-conic",
                        help="direct-lsq-conic|iterative|ransac")
    parser.add_argument("--gaze-order", type=int, default=2,
                        help="polynomial order of the gaze map")
    args = parser.parse_args()
    print("Skill: online-pupil-fitting-and-gaze-mapping")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Ellipse fit: {args.fit}")
    print(f"Gaze-map polynomial order: {args.gaze_order}")
    print("Pin: update rule, outlier rejection, frame-event sync, recon rate, occlusion, calibration grid.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
