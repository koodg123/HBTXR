---
name: online-pupil-fitting-and-gaze-mapping
description: Build the geometric and classical pipeline for high-frequency pupil estimation and gaze mapping, separate from end-to-end deep regression. Use this whenever a reproduction needs online or per-event 2D parametric pupil fitting, ellipse fitting to event or reconstructed-frame evidence, event-to-high-frame-rate video reconstruction to handle occlusion and blinks (anti-blink tracking), or a polynomial/regression mapping from a pupil model to a point of gaze. Trigger on "fit the pupil per event", "online 2D pupil model update", "reconstruct high-frame-rate eye video from events", "anti-blink occlusion handling", "polynomial gaze mapping from pupil", "hybrid frame-event pupil fitting", or any reproduction with a geometric/fitting pipeline, even without exact wording. Pairs with the representation builder and complements the deep model-family skills.
---

# Online Pupil Fitting and Gaze Mapping

## Overview

Several of the highest-frequency eye trackers are not end-to-end networks at all: they fit a parametric
pupil model and update it as events arrive, then map the pupil to gaze. This skill reproduces that
geometric pipeline -- per-event/online fitting, occlusion/anti-blink handling, and calibration-based
gaze mapping -- as explicit, parameterized choices that differ entirely from training a network. It is a
P0 IDEA-Gen leaf skill under `Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not
broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/hardware/dataset,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
per-event update rule, the reconstruction frame rate, or the gaze-mapping polynomial order and
calibration procedure are unknown -- list the missing inputs before making design choices. Use
`templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "online ellipse fit + 2nd-order polynomial gaze map, report residual").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (event stream / reconstructed frames), and downstream consumers (gaze evaluation, latency reporting).
3. Separate known facts from assumptions about the update rule, fusion, reconstruction rate, and calibration.
4. Choose the smallest artifact that unblocks the next Worker: a fitting/mapping module plus a one-line pipeline spec.
5. Define the evidence required for signoff before producing the main artifact (fit residual, ellipse params, mapping residual, update latency).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the fitting/reconstruction/mapping options and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/ellipse_fit.py` to fit an ellipse to 2D boundary points and to fit/apply a polynomial gaze map.
5. Produce the fitting/reconstruction/mapping module with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Reproduce three parts of the geometric pipeline; each has its own subtleties.

**Online pupil fitting.** *Per-event/online 2D fitting* maintains a parametric pupil model (ellipse or
similar) and updates it every one or few events, so estimates arrive far faster than any frame rate --
reproduce the update rule, what each event contributes, and how the model is initialized and re-acquired.
*Ellipse fitting* fits an ellipse to event or reconstructed-frame boundary/edge points, robust to
outliers (direct least-squares conic fit, optionally RANSAC) -- reproduce the fitting method and outlier
rejection. *Hybrid frame-event fitting* uses low-rate frames for robust initialization/relocalization and
high-rate events for fast updates between frames -- reproduce how the two modalities are combined and
synchronized.

**Occlusion and anti-blink.** *Event-to-video reconstruction* reconstructs high-frame-rate near-eye video
from the event stream so spatial structure is available between frames -- reproduce the reconstruction
method and frame rate. *Occlusion-robust fusion* fuses spatial and temporal cues so the pupil can still
be estimated when the eyelid partially occludes it during blinks -- reproduce the fusion and how
occlusion is detected/handled. This is what enables robust high-frequency analysis under blinks.

**Gaze mapping.** *Polynomial/regression mapping* maps the parametric pupil model to a point of gaze with
a fitted polynomial or regressor -- reproduce the polynomial order/feature set and the calibration
procedure (number and layout of calibration targets) that fits it.

Details that decide reproduction: the per-event update rule and model parameterization; frame-event
synchronization and the initialization/relocalization policy; reconstruction frame rate and the
occlusion-handling mechanism; the gaze-mapping form and the calibration data/procedure.

## Deliverables

- A fitting / reconstruction / mapping pipeline with explicit update rules and calibration.
- High-rate pupil and (optionally) gaze estimates.
- A one-line spec of the fitting method, fusion/reconstruction, and gaze-mapping form.
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Update rule, fusion, reconstruction rate, and calibration are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Fit residual, mapping residual, and update latency are visible.

## Escalate When

- The per-event update rule, reconstruction rate, or calibration procedure is missing.
- Multiple plausible fitting/fusion/mapping designs would materially change the result.
- Verification depends on unavailable paper detail or reference trajectories.
- The task should be split into a new leaf skill (e.g. a dedicated event-to-video reconstruction skill).
