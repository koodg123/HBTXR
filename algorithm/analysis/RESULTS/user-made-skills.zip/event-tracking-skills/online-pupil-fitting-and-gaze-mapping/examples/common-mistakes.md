# Common Mistakes

- Treating `online-pupil-fitting-and-gaze-mapping` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing the update rule, reconstruction rate, or calibration grid without marking assumptions.
- Producing prose without a concrete fitting/mapping module another Worker or evaluator can run.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Using an unconstrained conic fit that can return a non-ellipse, instead of the ellipse-constrained method.
- Letting outliers (eyelashes, reflections) bias the ellipse without RANSAC/trimming.
- Mis-synchronizing frame and event timestamps so frame re-init corrects to stale geometry.
- Reporting the gaze residual only on the calibration set instead of held-out targets (hiding extrapolation error).
- Confusing the reconstruction frame rate with the pupil-estimate rate.
