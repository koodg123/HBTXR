# Good Output

A strong output for `online-pupil-fitting-and-gaze-mapping` includes a concise objective, source mapping,
explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: a fitting/reconstruction/mapping pipeline; a one-line method + calibration spec.

## Worked mini-example

**Objective:** online ellipse fit to event boundary points + 2nd-order polynomial gaze map on EV-Eye.

**Spec (one line):**
`fit=direct LSQ conic (ellipse-constrained) | outliers=RANSAC (thr=1.5 px) | hybrid: frame re-init @ 30 Hz,
event update per 16 events | recon=event-integration @ 1 kHz | occlusion=boundary-support drop |
gaze map=2nd-order bivariate poly | calib=3x3 grid (9 targets)`

**Module sketch:**
```python
cx, cy, a, b, theta = fit_ellipse(boundary_xy)        # ellipse-constrained conic
coef = fit_poly_gaze(pupil_centers, gaze_targets, order=2)   # least-squares on calibration
gaze = apply_poly_gaze(coef, (cx, cy))
```

**Validation evidence:** ellipse fit RMS residual 0.41 px on noisy synthetic boundary; recovered
center within 0.3 px of truth; gaze-mapping residual 0.18 (normalized units) on held-out targets;
per-update latency well under one frame.

**Residual risks:** paper does not state the event-batch size for updates -> assumed 16 events;
calibration grid layout assumed 3x3 -> flagged for the orchestrator.
