# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Pupil model and parameterization (ellipse / other):

Online update rule (per-event / per-N-events; what each event contributes; init / re-acquire policy):

Ellipse fitting method and outlier rejection (direct least-squares conic / RANSAC):

Hybrid frame-event fusion and synchronization (frame init/relocalization + event updates):

Event-to-video reconstruction method and frame rate (anti-blink):

Occlusion detection and handling:

Gaze mapping (polynomial order / feature set) and calibration procedure (targets, layout):

Constraints:

Assumptions:

Required artifact:

Verification evidence (fit residual, ellipse params, mapping residual, update latency):

Risks and missing inputs:
