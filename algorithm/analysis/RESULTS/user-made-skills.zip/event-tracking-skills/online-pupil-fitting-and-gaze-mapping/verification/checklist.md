# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The fitting / reconstruction / mapping pipeline is present and traceable.
- [ ] A one-line method + fusion/reconstruction + gaze-mapping spec is present.
- [ ] The per-event update rule and init/re-acquisition policy are stated.
- [ ] The ellipse fit is ellipse-constrained (no degenerate conic) and outlier rejection is stated.
- [ ] Frame-event synchronization is pinned when hybrid fitting is used.
- [ ] Reconstruction frame rate and occlusion handling are stated when anti-blink is claimed.
- [ ] Gaze-mapping order/features and calibration grid are stated; residual is on held-out targets.
- [ ] Fit residual, mapping residual, and per-update latency are reported.
- [ ] Residual risks and missing inputs are listed.
