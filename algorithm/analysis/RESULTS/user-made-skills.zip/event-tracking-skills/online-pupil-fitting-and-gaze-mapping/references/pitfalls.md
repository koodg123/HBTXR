# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- The per-event (or per-N-event) update rule and the model parameterization.
- The ellipse-fitting method (direct least-squares conic vs iterative) and outlier rejection thresholds.
- Frame-event synchronization (timestamp alignment) and the init / relocalization cadence.
- Event-to-video reconstruction method and frame rate.
- Occlusion-detection signal/threshold and the fusion down-weighting rule.
- The gaze-mapping polynomial order/feature set and the calibration target grid.

## Failure modes
- **Degenerate / non-ellipse conic fit** -- an unconstrained conic fit can return a hyperbola or
  parabola, especially with few or collinear points. Use the ellipse-constrained direct method
  (`4AC - B^2 = 1`) and assert the discriminant; the functional script enforces this.
- **Outliers bias the ellipse** -- eyelashes, reflections, and stray edges pull the conic off the true
  boundary. Detect via a large fit residual; mitigate with RANSAC/iterative trimming before reporting.
- **Frame-event timestamp misalignment** -- if frame and event clocks are not aligned, the frame re-init
  corrects to a stale geometry and the high-rate track drifts. Pin the alignment and verify with a known
  synthetic offset.
- **Re-acquisition not handled** -- after a blink or loss of track, an online fitter that never re-inits
  locks onto noise. State the re-acquisition policy and trigger.
- **Reconstruction-rate confusion** -- reporting pupil-estimate rate as if it were the reconstruction
  frame rate (or vice versa). Separate and report both.
- **Occlusion silently corrupts the fit** -- during a blink, fitting to the partial boundary yields a
  wrong ellipse. Detect occlusion and down-weight; do not feed occluded evidence into the fit unflagged.
- **Calibration extrapolation** -- a polynomial fit on a small target grid extrapolates poorly outside
  it; gaze error grows toward the screen edges. Report residual on held-out targets, not only the fit set.
- **Under-determined calibration** -- a 2nd-order bivariate polynomial needs enough independent targets;
  too few targets overfit. Pin the target count vs the number of coefficients.

## Detection recipe
For any built fitting/mapping pipeline, log: the ellipse fit residual (RMS point-to-conic), the recovered
`(cx, cy, a, b, theta)`, the gaze-mapping residual on held-out targets, the per-update latency, and the
reconstruction vs estimate rates. These catch most geometric-pipeline reproduction bugs.
