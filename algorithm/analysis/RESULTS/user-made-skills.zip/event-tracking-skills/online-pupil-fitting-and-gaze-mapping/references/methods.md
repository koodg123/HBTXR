# Methods -- Online Pupil Fitting and Gaze Mapping

Reproducing a geometric eye tracker means reproducing three parts: online pupil fitting, occlusion /
anti-blink handling, and gaze mapping. Each section gives the construction, when it matters, and the
parameters that must be pinned.

## Online pupil fitting

### Per-event / online 2D fitting
Maintain a parametric pupil model (an ellipse `(cx, cy, a, b, theta)` or similar) and update it every one
or a few events, so estimates arrive far faster than any frame rate (kHz-scale). Each event is an
edge/boundary observation that nudges the current model (e.g. a recursive least-squares or Kalman-style
update, or a sliding buffer re-fit).
- Pin: the update rule, what each event contributes (which residual it minimizes), the buffer/forgetting
  policy, and the initialization / re-acquisition policy after loss of track.

### Ellipse fitting (direct least-squares conic)
Fit an ellipse to a set of boundary points by solving the conic
`A x^2 + B xy + C y^2 + D x + E y + F = 0` under the ellipse constraint `4AC - B^2 = 1` (Fitzgibbon's
direct least-squares method), which guarantees an ellipse and is solved as a generalized eigenproblem.
Decode the algebraic conic coefficients to geometric parameters `(cx, cy, a, b, theta)`.
- Robustness: reject outliers with RANSAC or iterative trimming before/within the fit, because stray
  edge points (eyelashes, reflections) bias the conic.
- Pin: the fitting method (direct LSQ vs iterative), the outlier-rejection scheme and its thresholds.

### Hybrid frame-event fitting
Use low-rate frames for robust initialization/relocalization (a clean full-image pupil detection) and
high-rate events for fast updates between frames. The frame anchors absolute geometry; events propagate
it forward.
- Pin: how the two modalities are combined (re-init cadence, how a frame correction is blended into the
  event-updated state) and how they are time-synchronized (timestamp alignment, latency compensation).

## Occlusion and anti-blink

### Event-to-video reconstruction
Reconstruct high-frame-rate near-eye video from the event stream (e.g. an event-integration or learned
reconstruction) so spatial structure is available between sparse frames, enabling fitting through fast
motion and partial occlusion.
- Pin: the reconstruction method and the reconstructed frame rate.

### Occlusion-robust fusion
Fuse spatial and temporal cues so the pupil can still be estimated when the eyelid partially occludes it
during a blink: detect occlusion (e.g. a drop in visible boundary support or an event-density signature),
then down-weight occluded evidence and rely on the temporal model until the pupil reappears.
- Pin: the occlusion-detection signal and threshold, and the fusion/down-weighting rule.

## Gaze mapping

### Polynomial / regression mapping
Map the parametric pupil model (typically the pupil center, sometimes plus shape features) to a 2D point
of gaze with a fitted polynomial or regressor. A common form is a 2nd-order bivariate polynomial in the
pupil coordinates whose coefficients are fit by least squares on calibration data.
- Calibration: the subject fixates a known set of targets (e.g. a 3x3 or 5x5 grid); pupil-gaze pairs at
  those targets fit the mapping coefficients.
- Pin: the polynomial order and feature set, the number/layout of calibration targets, and the fitting
  (ordinary vs regularized least squares).

## Details that decide reproduction
- The per-event update rule and the model parameterization.
- Frame-event synchronization and the initialization / relocalization policy.
- Reconstruction frame rate and the occlusion-handling mechanism.
- The gaze-mapping form (order/features) and the calibration data/procedure.

## Choosing quickly
- Pure event, sub-frame latency -> per-event online ellipse update.
- Robust absolute geometry -> hybrid frame-event with periodic frame re-init.
- Blink / occlusion robustness -> event-to-video reconstruction + occlusion-aware fusion.
- Calibrated gaze output -> 2nd-order polynomial map fit on a target grid.
