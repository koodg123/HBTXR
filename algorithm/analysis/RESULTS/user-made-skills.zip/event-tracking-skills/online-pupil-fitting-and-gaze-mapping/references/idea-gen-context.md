# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Some of the highest-frequency event eye trackers are classical geometric pipelines, not deep networks:
they fit a parametric pupil model per event and map it to gaze through a calibrated polynomial. The
orchestrator pulls in this skill when the contribution is sub-frame latency from fitting (and anti-blink
robustness from event-to-video reconstruction), because the per-event update, occlusion fusion, and
calibration are a regime apart from training a network and complement the deep model-family skills.

## Worker Capability

Build the geometric pupil-fitting and gaze-mapping pipeline: online/per-event parametric (ellipse)
fitting with outlier rejection, hybrid frame-event fusion and anti-blink reconstruction, and a
calibrated polynomial/regression gaze map -- producing high-rate pupil and gaze estimates.

## Expected Outputs

- A fitting / reconstruction / mapping pipeline with explicit update rules and calibration.
- A one-line spec of the fitting method, fusion/reconstruction, and gaze-mapping form, plus residuals.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (geometric / classical fitting cluster).
