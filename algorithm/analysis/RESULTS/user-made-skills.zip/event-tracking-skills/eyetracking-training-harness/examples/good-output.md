# Good Output

A strong output for `eyetracking-training-harness` includes a concise objective, source mapping, explicit
assumptions, the main artifact, and a validation section.

Expected artifact examples: a config-driven seeded training loop; an event-aware augmentation module; an
online/offline evaluation runner.

## Worked mini-example

**Objective:** training recipe for a causal pupil regressor on 3ET+, online evaluation.

**Recipe spec (one line):**
`AdamW(lr=2e-3, wd=1e-2) | cosine decay, 5-epoch warmup | 100 epochs | batch=32 | seeds={0,1,2} |
aug={event-cutout p=0.5, temporal-shift +/-2ms p=0.3, spatial-flip p=0.5 (label x mirrored),
event-deletion frac=0.1 p=0.3} | eval=online/causal`

**Augmentation call sketch:**
```python
ev = event_cutout(ev, box_frac=0.3, p=0.5, rng=rng)        # drop events in a random spatial box
ev = temporal_shift(ev, max_shift=2000.0, rng=rng)         # us; shifts t window
ev, label = spatial_flip(ev, label, W=64, p=0.5, rng=rng)  # mirror x + flip label x
ev = event_delete(ev, frac=0.1, rng=rng)                   # random event deletion
```

**Validation evidence:** seeds {0,1,2}; obtained p10 = 92.1 +/- 0.4 vs target 92.5 (within noise);
augmentation event-count deltas logged before/after each op; eval regime = online/causal (no future
context); train and eval share the same voxel normalization.

**Residual risks:** paper does not state the warmup length -> assumed 5 epochs; flagged for the orchestrator.
