# Common Mistakes

- Treating `eyetracking-training-harness` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing optimizer/schedule/epochs/augmentation settings without marking assumptions.
- Producing prose without a concrete config and runnable augmentation/eval modules another Worker can use.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Evaluating offline a model whose claim is online/causal (or vice versa), so the numbers are not comparable.
- Dropping or weakening an augmentation, or guessing its probability, and silently changing robustness.
- Applying spatial flip or affine on events but forgetting to transform the label accordingly.
- Reporting a single-seed run as the result when a seed sweep would show the gap is noise.
