# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The config-driven training loop is present and traceable (optimizer, schedule, epochs, batch, seeds, stages).
- [ ] The event-aware augmentation module is present with each augmentation's probability/strength.
- [ ] The online/offline evaluation runner is present and the chosen regime is stated.
- [ ] Geometric augmentations (flip/affine) apply the matching label transform.
- [ ] The evaluation regime matches the paper's claim (online/causal vs offline/windowed).
- [ ] Metrics are reported across seeds (mean plus a confidence interval), not a single run.
- [ ] Train and eval representations/normalization are identical.
- [ ] Residual risks and missing inputs are listed.
