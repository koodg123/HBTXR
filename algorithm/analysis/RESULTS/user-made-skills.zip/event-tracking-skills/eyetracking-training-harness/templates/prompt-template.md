# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Optimization (optimizer, lr + schedule, epochs, batch, weight decay, seeds, stages):

Augmentation set (Event-Cutout / affine-on-events / temporal-shift / spatial-flip / event-deletion) with probabilities/strengths:

Evaluation regime (online/causal vs offline/windowed):

Constraints:

Assumptions:

Required artifact:

Verification evidence (seed list, target vs obtained metric, augmentation probs, eval regime, event-count parity):

Risks and missing inputs:
