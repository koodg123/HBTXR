---
name: eyetracking-training-harness
description: Provide the training loop, augmentation, schedule, and online/causal evaluation needed to train event-based and near-eye eye-tracking models reproducibly. Use this whenever a reproduction needs the optimization setup (optimizer, learning-rate schedule, epochs, batch size, seeds), event-aware data augmentation (Event-Cutout, affine transforms applied directly on events, temporal shift, spatial flip, event deletion), or evaluation that respects online/causal streaming versus offline windowed inference. Trigger on "set up the training loop", "what augmentation do they use", "Event-Cutout augmentation", "affine augmentation on events", "train with the right schedule", "evaluate online vs offline", or any reproduction that hinges on the training recipe, even without exact wording. Pairs with the output-head, representation, and benchmark skills, and with ablation-and-experiment-designer.
---

# Eye-Tracking Training Harness

## Overview

The training recipe is where event eye-tracking reproductions quietly diverge: a missing augmentation,
a different schedule, or evaluating offline a model meant to run online. This skill standardizes the
optimization loop and, critically, the event-specific augmentation and the online/offline evaluation
distinction so a run is comparable and repeatable. It is a P0 IDEA-Gen leaf skill under
`Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/dataset, assumptions,
expected deliverables, verification evidence). If the task is underspecified -- e.g. the augmentation set,
schedule, or evaluation regime is unknown -- list the missing inputs before fixing the recipe. Use
`templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "match p10 within 1 point on 3ET+ under the paper's schedule").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (representation, output head), and downstream consumers (benchmark harness, ablation designer).
3. Separate known facts from assumptions about optimizer, schedule, epochs, batch, seeds, augmentation set, and evaluation regime.
4. Choose the smallest artifact that unblocks the next Worker: a config-driven loop plus an augmentation module and an online/offline eval runner.
5. Define the evidence required for signoff before producing the artifact (seed list, target vs obtained metric, augmentation probabilities, eval regime).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the optimization knobs and augmentation menu and `references/pitfalls.md` for the failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/event_augment.py` to apply and validate the event-aware augmentations (Event-Cutout, temporal shift, spatial flip, event deletion) on (x,y,t,p) arrays.
5. Produce the training loop, augmentation module, and eval runner with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Record and reproduce every optimization knob, drive everything from a config, and keep train and eval
representations/normalization identical.

Optimization setup (full detail in `references/methods.md`): optimizer (commonly AdamW), initial learning
rate and schedule (warmup/decay), number of epochs, batch size, weight decay, and random seeds. Many
papers train in stages (pretrain then finetune); preserve the stage structure and per-stage settings.

Event-aware augmentation (labeled event data is scarce, so this materially affects reported robustness):
**Event-Cutout** (drop events in random spatio-temporal regions); **affine on events** (apply affine
spatial transforms directly to event coordinates, not a rendered image); **temporal shift** (shift the
event window in time); **spatial flip** (mirror events with the corresponding label transform); **event
deletion** (randomly remove a fraction of events). Reproduce which augmentations are used and their
probabilities/strengths.

Online vs offline evaluation is decisive and a frequent source of mismatched numbers. **Online/causal**:
the model sees only past events, runs incrementally with buffering, timed for streaming latency (required
for low-latency claims). **Offline/windowed**: the whole window (or bidirectional context) is available;
usually higher accuracy but not representative of streaming. Evaluate in the regime the paper claims and
state it; pair latency claims with the latency-characterization skill. When chasing a gap, vary one thing
at a time (schedule, augmentation set, sequence length are the usual suspects).

## Deliverables

- A config-driven, seeded training loop with the exact optimizer/schedule/epochs/batch.
- An event-aware augmentation module with named augmentations and probabilities.
- An evaluation runner supporting both online/causal and offline/windowed regimes.
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Optimizer, schedule, augmentation set, and evaluation regime are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The optimizer/schedule/epochs/augmentation/evaluation regime is missing from the source.
- Multiple plausible recipes would materially change the result.
- Verification depends on unavailable training compute or paper detail.
- The task should be split into a new leaf skill (e.g. a dedicated distillation-recipe skill).
