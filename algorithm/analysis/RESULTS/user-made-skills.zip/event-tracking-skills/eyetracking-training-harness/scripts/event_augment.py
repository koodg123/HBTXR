#!/usr/bin/env python3
"""Event-aware augmentations for event-based eye-tracking training.

Operates directly on event arrays (x, y, t, p) rather than on a rendered image, so
event semantics are preserved. Implements the augmentations used in the literature:

  * Event-Cutout    -- drop all events inside a random spatial box.
  * Temporal shift  -- shift the event timestamps (the time window) by an offset.
  * Spatial flip    -- mirror x about the sensor width (with matching label transform).
  * Event deletion  -- randomly remove a fraction of events.

Each function returns new arrays (it never mutates its inputs). The --demo path
fabricates a tiny synthetic stream and prints event counts and spatial bounding
statistics before and after each augmentation.

Examples
--------
    python event_augment.py --demo
    python event_augment.py --demo --width 128 --height 96 --n 5000
"""
from __future__ import annotations

import argparse

import numpy as np


def _as_arrays(xs, ys, ts, ps):
    return (
        np.asarray(xs, dtype=np.float64),
        np.asarray(ys, dtype=np.float64),
        np.asarray(ts, dtype=np.float64),
        np.asarray(ps),
    )


def event_cutout(xs, ys, ts, ps, box_frac=0.3, W=64, H=64, rng=None):
    """Drop events inside a random spatial box of side ~box_frac of the sensor.

    Returns the kept (xs, ys, ts, ps). The box is placed uniformly at random and
    fully contained in the sensor.
    """
    rng = np.random.default_rng() if rng is None else rng
    xs, ys, ts, ps = _as_arrays(xs, ys, ts, ps)
    bw = max(1, int(round(box_frac * W)))
    bh = max(1, int(round(box_frac * H)))
    x0 = rng.integers(0, max(1, W - bw + 1))
    y0 = rng.integers(0, max(1, H - bh + 1))
    inside = (xs >= x0) & (xs < x0 + bw) & (ys >= y0) & (ys < y0 + bh)
    keep = ~inside
    return xs[keep], ys[keep], ts[keep], ps[keep]


def temporal_shift(xs, ys, ts, ps, shift=0.0):
    """Shift all timestamps by `shift` (same units as ts). Window length is preserved."""
    xs, ys, ts, ps = _as_arrays(xs, ys, ts, ps)
    return xs.copy(), ys.copy(), ts + float(shift), np.array(ps, copy=True)


def spatial_flip(xs, ys, ts, ps, W=64, label=None):
    """Mirror x about the sensor width: x -> (W - 1) - x.

    If `label` (x, y) is given, its x is mirrored too and returned alongside the
    flipped events. Returns (xs, ys, ts, ps) or (xs, ys, ts, ps, label).
    """
    xs, ys, ts, ps = _as_arrays(xs, ys, ts, ps)
    xf = (W - 1) - xs
    if label is None:
        return xf, ys.copy(), ts.copy(), np.array(ps, copy=True)
    lx, ly = float(label[0]), float(label[1])
    return xf, ys.copy(), ts.copy(), np.array(ps, copy=True), (float(W - 1) - lx, ly)


def event_delete(xs, ys, ts, ps, frac=0.1, rng=None):
    """Randomly delete a fraction `frac` of events; returns the kept arrays."""
    rng = np.random.default_rng() if rng is None else rng
    xs, ys, ts, ps = _as_arrays(xs, ys, ts, ps)
    n = xs.shape[0]
    keep_mask = rng.random(n) >= float(frac)
    return xs[keep_mask], ys[keep_mask], ts[keep_mask], ps[keep_mask]


def _stats(xs, ys, ts):
    n = int(np.asarray(xs).shape[0])
    if n == 0:
        return "events=0  bbox=empty  t=[--,--]"
    xs = np.asarray(xs, dtype=np.float64)
    ys = np.asarray(ys, dtype=np.float64)
    ts = np.asarray(ts, dtype=np.float64)
    return (
        "events=%d  bbox=x[%.1f,%.1f] y[%.1f,%.1f]  t=[%.1f,%.1f]"
        % (n, xs.min(), xs.max(), ys.min(), ys.max(), ts.min(), ts.max())
    )


def _demo(args):
    rng = np.random.default_rng(0)
    n = args.n
    xs = rng.integers(0, args.width, n).astype(np.float64)
    ys = rng.integers(0, args.height, n).astype(np.float64)
    ts = np.sort(rng.uniform(0, 20_000.0, n))  # microseconds, ~20 ms window
    ps = rng.integers(0, 2, n)
    label = (args.width / 2.0, args.height / 2.0)

    print("original                :", _stats(xs, ys, ts))

    cx, cy, ct, cp = event_cutout(xs, ys, ts, ps, box_frac=0.3,
                                  W=args.width, H=args.height, rng=rng)
    print("after Event-Cutout      :", _stats(cx, cy, ct),
          " (dropped %d)" % (n - cx.shape[0]))

    sx, sy, st, sp = temporal_shift(xs, ys, ts, ps, shift=3000.0)
    print("after temporal-shift+3ms:", _stats(sx, sy, st))

    fx, fy, ft, fp, flabel = spatial_flip(xs, ys, ts, ps, W=args.width, label=label)
    print("after spatial-flip      :", _stats(fx, fy, ft),
          " label %s -> %s" % (label, (round(flabel[0], 1), round(flabel[1], 1))))

    dx, dy, dt, dp = event_delete(xs, ys, ts, ps, frac=0.1, rng=rng)
    print("after event-deletion 10%:", _stats(dx, dy, dt),
          " (dropped %d)" % (n - dx.shape[0]))


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a synthetic event stream")
    p.add_argument("--n", type=int, default=2000, help="number of synthetic events")
    p.add_argument("--width", type=int, default=64)
    p.add_argument("--height", type=int, default=64)
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
