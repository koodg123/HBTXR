# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Event eye-tracking reproductions reproduce numbers only when the training recipe matches. The
orchestrator pulls in this skill once a representation and an output head exist, because the optimization
schedule, the event-specific augmentation set, and the online/offline evaluation regime each move the
reported error enough to break a reproduction on their own.

## Worker Capability

Provide a config-driven, seeded training loop with the exact optimizer and schedule, an event-aware
augmentation module, and an evaluation runner that respects online/causal streaming versus offline
windowed inference.

## Expected Outputs

- A config-driven, seeded training loop (optimizer, schedule, epochs, batch, stages).
- An event-aware augmentation module with named augmentations and probabilities.
- An evaluation runner supporting both online/causal and offline/windowed regimes.

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (training/recipe cluster).
