# Methods -- Training Harness, Augmentation, and Evaluation

The recipe is where reproductions diverge. Drive everything from a config file so runs are comparable and
repeatable, and keep train and eval representations/normalization identical.

## Optimization setup
Record and reproduce every knob:
- **Optimizer**: commonly AdamW; record betas, epsilon, and weight decay.
- **Learning rate and schedule**: initial lr plus warmup and decay (cosine, step, or linear). Record
  warmup length and the decay shape; these change convergence and final error.
- **Epochs / iterations**: total training length; some papers report iterations, some epochs -- convert
  carefully against the dataset size and batch.
- **Batch size**: affects effective lr; if you must change batch, scale lr and say so.
- **Random seeds**: fix and report; for trustworthy claims run a seed sweep (hand statistics to
  experimental-rigor-stats).
- **Staged training**: many papers pretrain then finetune (or distill). Preserve the stage structure and
  per-stage optimizer/schedule; collapsing stages changes the result.

## Event-aware augmentation
Labeled event data is scarce, so augmentation materially affects reported robustness and error. The
augmentations are event-specific (operate on (x,y,t,p), not a rendered image):
- **Event-Cutout**: drop all events inside a random spatio-temporal region (a spatial box, optionally over
  a time sub-window) to force robustness to missing evidence. Pin the box-size distribution and the
  drop probability.
- **Affine on events**: apply affine spatial transforms (rotation, scale, shear, translation) directly to
  event coordinates, preserving event semantics while enriching geometry. Pin the transform ranges and
  the matching label transform.
- **Temporal shift**: shift the event window in time (and/or jitter timestamps) to augment temporal
  alignment. Pin the shift range and units.
- **Spatial flip**: mirror events spatially (horizontal flip mirrors x); apply the corresponding label
  transform (flip the x coordinate / swap left-right). Pin the flip probability.
- **Event deletion**: randomly remove a fraction of events to simulate low-activity or noisy intervals.
  Pin the deletion fraction.
Reproduce which augmentations are used and their probabilities/strengths -- they are a common source of a
reproduction gap.

## Online vs offline evaluation
This distinction is decisive and often the source of mismatched numbers:
- **Online / causal**: the model sees only past events, runs incrementally with buffering, and is timed
  for streaming latency. Required for low-latency claims. State the buffer/state-carry policy.
- **Offline / windowed**: the whole window (or bidirectional context) is available; typically higher
  accuracy but not representative of streaming deployment.
Evaluate in the same regime the paper claims, and state it explicitly. Pair latency claims with the
latency-characterization skill.

## Reproduction discipline
- Keep train and eval representations and normalization identical (coordinate with the representation
  builder).
- Log target vs obtained metrics each run for the reproduction log.
- Vary one thing at a time when chasing a gap; schedule, augmentation set, and sequence length are the
  usual suspects (route systematic variation to ablation-and-experiment-designer).
