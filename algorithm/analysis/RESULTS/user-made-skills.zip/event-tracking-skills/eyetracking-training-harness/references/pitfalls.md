# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Optimizer family and its hyperparameters (betas, eps, weight decay).
- Initial learning rate, warmup length, and decay shape.
- Epochs vs iterations (and the conversion via dataset size and batch).
- Batch size and any lr scaling tied to it.
- Random seeds (and the seed list for a sweep).
- Stage structure (pretrain/finetune/distill) and per-stage settings.
- Augmentation set and each augmentation's probability/strength.
- Evaluation regime: online/causal vs offline/windowed, plus buffer/state-carry policy.

## Failure modes
- **Offline evaluation of an online model** -> reports an accuracy the streaming deployment cannot reach,
  and hides latency. Detect by checking whether the eval feeds future context; for online claims, the
  prediction at time t must use only events <= t.
- **Silent augmentation mismatch** -> dropping or weakening an augmentation (or guessing its probability)
  changes robustness numbers. Detect by listing the exact augmentation set and probabilities and diffing
  against the paper.
- **Label transform forgotten on geometric augmentation** -> flipping or affine-transforming events
  without transforming the label corrupts supervision. Detect by visualizing a flipped sample with its
  transformed label and confirming alignment.
- **Epochs/iterations confusion** -> training 10x too long or short because epochs were read as
  iterations (or vice versa). Detect by computing total samples seen and comparing to the paper.
- **Batch-size change without lr scaling** -> changes effective optimization and final error. Detect by
  recording batch and lr together and noting any scaling rule applied.
- **Seed-of-one reporting** -> a single run's number is reported as the result; a small gap may be noise.
  Detect by running a seed sweep and reporting mean plus a confidence interval.
- **Train/eval representation drift** -> different normalization or window between training and evaluation
  silently degrades accuracy. Detect by asserting identical representation parameters across phases.

## Detection recipe
For any training run, log: the full config (optimizer/schedule/epochs/batch/seeds/stages), the active
augmentation set with probabilities, the evaluation regime, total samples seen, and target vs obtained
metric across seeds. These catch most recipe-driven reproduction gaps.
