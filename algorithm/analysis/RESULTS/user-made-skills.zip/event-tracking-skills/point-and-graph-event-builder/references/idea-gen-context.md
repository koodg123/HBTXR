# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

The most efficient and label-frugal event trackers treat events as points or graph nodes rather than
dense tensors, which has no analogue in CNN pipelines. The orchestrator pulls in this skill when the
model consumes points or graphs, because the construction (sampling, neighborhood, clustering) is exactly
what those reproductions hinge on.

## Worker Capability

Build point-cloud and graph constructions and their set/graph operators or modularity-aware clustering,
with sampling, normalization, neighborhood, and clustering objective pinned to the paper.

## Expected Outputs

- A point/graph construction + set/graph operators (or clustering) returning features or cluster assignments.
- A one-line spec of the family and full configuration (sampling, normalization, neighborhood, clustering objective).

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (point/graph-model cluster).
