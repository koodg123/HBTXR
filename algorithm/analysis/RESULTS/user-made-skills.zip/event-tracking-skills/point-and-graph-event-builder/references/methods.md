# Methods -- Point-Cloud and Graph Event Models

Some of the most efficient and label-frugal event trackers abandon dense tensors entirely and treat each
event as a point or graph node. Reproducing them means reproducing point/graph construction and the
set/graph operators or clustering. Each entry gives the construction, when to use it, and the parameters
to pin.

## Point-cloud family

### Point representation
Events as a set of `(x, y, t, p)` points, normalized (e.g. t to [0,1] within the window) and subsampled
to a fixed `N`. Resolution-independent because it does not depend on a pixel grid. Reproduce the
normalization, the sampling count, and any temporal ordering.
- Pin: subsample size `N`, normalization of x/y/t, sampling method (random vs farthest-point), ordering.

### Point-based networks
Hierarchical set operators -- grouping, local aggregation, sampling -- that learn from unordered points.
Reproduce the grouping radius/neighborhood, the aggregation function, and the downsampling schedule.
- Pin: grouping radius or k, aggregation (max/mean/attention), downsampling schedule and ratios.

### Frequency / rate adaptation
Some point trackers adapt their sampling or processing to pupil speed or inter-sample interval, spending
more compute during fast motion. Reproduce the adaptation rule and the signal that drives it.
- Pin: the adaptation rule, the driving signal (speed, event rate), and the range it spans.

## Graph family

### Graph construction
Nodes from events or event clusters; edges from spatio-temporal proximity, typically kNN in
`(x, y, alpha*t)` space where `alpha` is the temporal scale that makes time comparable to space. Reproduce
the neighborhood definition (k vs radius) and edge weighting.
- Pin: node source (raw events vs clustered), `k` or radius, temporal scale `alpha`, edge features/weights.

### Graph neural networks
Message passing over the constructed graph for per-node or pooled features. The construction (above) is
what most determines reproduction; the message-passing operator follows standard GNN forms.
- Pin: layer type, number of hops/layers, pooling.

### Modularity-aware spatio-temporal clustering
An unsupervised approach that clusters the event graph (optimizing a modularity-style objective) to track
the pupil without dense labels. Reproduce the clustering objective, how clusters map to pupil estimates,
and how temporal continuity across windows is maintained. This is the route to high-fidelity tracking
under label sparsity.
- Pin: the clustering objective, number/scale of clusters, cluster-to-pupil mapping, temporal-continuity rule.

## Details that decide reproduction
- Sampling/subsampling count and method (random vs farthest-point) for points; neighborhood (k or radius)
  for graphs.
- Normalization of coordinates and time (and the temporal scale `alpha` that balances them).
- For clustering: the objective, the number/scale of clusters, and the cluster-to-pupil mapping.
- Whether processing is causal/online or windowed/offline.

## Choosing quickly
- Resolution-independent, set-based learning -> point cloud + point-based network.
- Explicit spatio-temporal connectivity -> kNN graph + GNN.
- Label-sparse / unsupervised tracking -> modularity-aware graph clustering.
- Fast pupil motion with a tight compute budget -> rate-adaptive point sampling.
