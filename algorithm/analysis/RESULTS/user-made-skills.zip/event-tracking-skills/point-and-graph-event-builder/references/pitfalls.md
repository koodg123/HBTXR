# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Subsample size `N` and sampling method (random vs farthest-point) for points.
- Normalization of x/y/t and the temporal scale `alpha` that balances time against space.
- Neighborhood definition for graphs: `k` (kNN) or radius, and edge weighting.
- For clustering: the objective, number/scale of clusters, and the cluster-to-pupil mapping.
- Whether processing is causal/online or windowed/offline.

## Failure modes
- **Unbalanced temporal scale alpha** -> if `alpha` is too small the graph collapses into a single time
  slice; too large and it fragments into per-instant components. Sweep alpha and report degree stats;
  pin the value the paper uses.
- **Wrong sampling method** -> random subsampling vs farthest-point sampling produce very different point
  coverage and downstream accuracy. Reproduce the exact method, not just the count `N`.
- **Normalization mismatch** -> normalizing x/y/t with evaluation-set extents, or differently at train and
  deployment, shifts every coordinate. Freeze normalization at train time and reuse it.
- **k vs radius confusion** -> a kNN graph guarantees degree >= k per node; a radius graph can leave
  isolated nodes in sparse regions. Check for isolated nodes and match the paper's neighborhood type.
- **Clustering objective drift** -> using plain modularity when the paper uses a spatio-temporal /
  resolution-limit-aware variant changes the clusters. Reproduce the exact objective and cluster scale.
- **Broken temporal continuity** -> clusters/tracks that are not linked across windows produce a jumpy
  pupil trajectory. Reproduce the cross-window association rule.
- **Guessed unstated choices** -> silently inventing `N`, `k`, `alpha`, or the cluster count the paper
  omits. Flag the missing choice to the orchestrator instead of guessing.

## Detection recipe
For any built point set / graph, log: node count; edge count; degree stats (mean/min/max) and the number
of isolated nodes; the normalization extents and `alpha`; and the sampling method/count. For clustering,
add the cluster count and a continuity check across windows. These catch most reproduction-breaking bugs
in point/graph models.
