# Common Mistakes

- Treating `point-and-graph-event-builder` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing sampling count, neighborhood k/radius, temporal scale alpha, or cluster count without marking assumptions.
- Producing prose without a concrete point/graph construction another Worker or evaluator can use.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Reproducing the sampling count but not the sampling method (random vs farthest-point), which changes coverage.
- Leaving the temporal scale alpha unbalanced so the graph collapses to one time slice or fragments per instant.
- Using a radius graph that strands isolated nodes when the paper uses kNN (or vice versa).
- Substituting plain modularity for the paper's spatio-temporal clustering objective, or breaking cross-window continuity.
