# Good Output

A strong output for `point-and-graph-event-builder` includes a concise objective, source mapping,
explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: a point/graph construction + set/graph operators (or clustering); a one-line
family + full-configuration spec.

## Worked mini-example

**Objective:** spatio-temporal kNN graph feeding a GNN pupil tracker on EyeGraph, windowed offline.

**Spec (one line):**
`event graph | nodes=raw events | normalize x,y,t -> [0,1] | temporal scale alpha=1.0 | kNN k=6 |
undirected edges | causality=windowed (offline)`

**Module sketch:**
```python
pts, edges, deg, dmean, dmin, dmax = build_event_graph(xs, ys, ts, k=6, alpha=1.0)
assert pts.shape[1] == 3                      # (x, y, alpha*t)
assert (deg >= 6).all()                       # kNN guarantees degree >= k
```

**Validation evidence:** node count 120; edge count 484 (undirected); degree mean=8.07 min=6 max=15;
0 isolated nodes; normalization extents recorded; alpha=1.0. Degree >= k confirms the kNN construction.

**Residual risks:** paper does not state the temporal scale alpha -> assumed 1.0; flagged for the
orchestrator (alpha materially changes connectivity).
