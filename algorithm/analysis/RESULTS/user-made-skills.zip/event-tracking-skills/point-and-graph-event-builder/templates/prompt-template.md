# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Model family (point-cloud / point-network / graph-construction / GNN / modularity clustering):

Point settings (sampling count N, sampling method random vs farthest-point, normalization of x/y/t, temporal ordering):

Graph settings (neighborhood k or radius, temporal scale alpha, edge weighting, node source events vs clusters):

Clustering settings (objective, number/scale of clusters, cluster-to-pupil mapping, temporal continuity):

Constraints:

Assumptions:

Required artifact:

Verification evidence (node count, edge count, degree stats, normalization, causality, parity with reference):

Risks and missing inputs:
