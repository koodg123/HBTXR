# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The point/graph construction (or clustering) module is present and traceable.
- [ ] A one-line family + full-configuration spec is present.
- [ ] Node count, edge count, and degree stats (mean/min/max) are reported.
- [ ] Sampling count and method (random vs farthest-point) are stated for point models.
- [ ] Neighborhood definition (k or radius) and temporal scale alpha are pinned for graphs.
- [ ] Normalization of x/y/t is fixed and identical for train and deployment.
- [ ] Clustering objective and cluster-to-pupil mapping are stated (if clustering is used).
- [ ] Causality (online vs windowed/offline) is declared and consistent with evaluation.
- [ ] Residual risks and missing inputs are listed.
