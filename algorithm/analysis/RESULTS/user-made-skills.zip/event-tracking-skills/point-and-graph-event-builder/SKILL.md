---
name: point-and-graph-event-builder
description: Build point-cloud and graph-based model families that treat events as sets or graphs rather than dense tensors, for event eye tracking. Use this whenever the architecture represents events as a point cloud and processes them with a point-based network, or builds a dynamic spatio-temporal graph from events and applies a graph neural network or modularity-aware graph clustering (including unsupervised clustering for label-sparse settings). Trigger on "point-cloud event tracker", "point-based network for events", "build an event graph", "graph clustering for pupil tracking", "modularity-aware spatio-temporal graph", "GNN for events", or any reproduction whose model consumes points or graphs, even without exact wording. Assumes the representation builder produces the point set or graph, and hands features or clusters to an output head or fitting step.
---

# Point and Graph Event Builder

## Overview

Some of the most efficient and label-frugal event trackers abandon dense tensors entirely: they treat
each event as a point or a graph node. This changes the whole network family, and reproducing these
methods means reproducing point/graph construction and the set/graph operators, which have no analogue in
standard CNN pipelines. It is a P0 IDEA-Gen leaf skill under `Event Eye-Tracking Reproduction` and
produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/hardware/dataset,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
sampling count, neighborhood definition, or clustering objective is unknown -- list the missing inputs
before making design choices. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "produce a spatio-temporal kNN graph feeding GNN X").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (the point set / event stream), and downstream consumers (the output head or fitting step).
3. Separate known facts from assumptions about sampling, normalization, neighborhood, and clustering objective.
4. Choose the smallest artifact that unblocks the next Worker: the point/graph construction + set/graph operators (or clustering), with a one-line config spec.
5. Define the evidence required for signoff before producing the artifact (node count, edge count, degree stats, normalization, causality).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the point and graph families and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/event_graph.py` to build/validate the spatio-temporal kNN graph and confirm node/edge/degree stats (or adapt it to the chosen construction).
5. Produce the point/graph construction and operators (or clustering) with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Reproduce point/graph construction first; the set/graph operators or clustering follow from it.

**Point-cloud family** (full detail in `references/methods.md`): **point representation** -- events as a
set of (x,y,t,p) points, normalized and subsampled; resolution-independent because it does not depend on
a pixel grid (reproduce normalization, sampling count, temporal ordering); **point-based networks** --
hierarchical set operators (grouping, local aggregation, sampling) over unordered points (reproduce
grouping radius/neighborhood, aggregation, downsampling schedule); **frequency/rate adaptation** -- some
point trackers adapt sampling/processing to pupil speed (reproduce the adaptation rule and its driver).

**Graph family**: **graph construction** -- nodes from events or clusters, edges from spatio-temporal
proximity, typically kNN in (x, y, alpha*t) space (reproduce the neighborhood definition and edge
weighting); **graph neural networks** -- message passing for per-node or pooled features;
**modularity-aware spatio-temporal clustering** -- an unsupervised approach that clusters the event graph
(optimizing a modularity-style objective) to track the pupil without dense labels (reproduce the
clustering objective, the cluster-to-pupil mapping, and how temporal continuity across windows is
maintained). This is the route to high-fidelity tracking under label sparsity.

Details that decide reproduction: sampling/subsampling count and method (random vs farthest-point) for
points, neighborhood (k, radius, temporal scale alpha) for graphs; normalization of coordinates and time;
for clustering, the objective, the number/scale of clusters, and the cluster-to-pupil mapping; whether
processing is causal/online or windowed/offline. Match sampling, neighborhood, and clustering objective
exactly, and flag unstated choices rather than guessing.

## Deliverables

- A point/graph construction plus set/graph operators (or clustering) as modules, returning features (for an output head) or cluster assignments (for a fitting step).
- A one-line spec of the family and ALL configuration (sampling count/method, normalization, neighborhood k/radius/alpha, clustering objective).
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Sampling, normalization, neighborhood, and clustering objective are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The target sampling count, neighborhood definition, or clustering objective is missing.
- Multiple plausible constructions (random vs farthest-point sampling; k vs radius graph) would materially change the result.
- Verification depends on unavailable paper detail or reference graphs/clusters.
- The task should be split into a new leaf skill (e.g. a dedicated graph-clustering study).
