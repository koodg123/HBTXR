from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for point-and-graph-event-builder.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--family", default="point-cloud",
                        help="point-cloud|point-network|graph-construct|gnn|modularity-clustering")
    args = parser.parse_args()
    print("Skill: point-and-graph-event-builder")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Model family: {args.family}")
    print("Pin: sampling count/method, normalization of (x,y,t), neighborhood (k, radius, alpha), clustering objective, causality.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
