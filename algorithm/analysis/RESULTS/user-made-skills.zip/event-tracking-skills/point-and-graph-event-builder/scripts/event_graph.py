#!/usr/bin/env python3
"""Build a spatio-temporal kNN graph from event points.

Treats events as a set of (x, y, t) points, normalizes them into a common
spatio-temporal space, scales time by `alpha` so temporal and spatial distances
are comparable, computes the k nearest neighbors of every node in
(x, y, alpha*t) space, and returns an undirected edge list plus degree
statistics. This is the graph-construction step that GNN and graph-clustering
event trackers assume has already happened.

Normalization
-------------
x, y, t are each min-max normalized to [0, 1] over the window. Time is then
scaled by `alpha` (the temporal scale); a larger alpha makes events farther
apart in time, so neighbors are drawn from a tighter temporal slice.

kNN graph
---------
For each node we take its k nearest neighbors by Euclidean distance in the
(x, y, alpha*t) space (excluding itself). Edges are made undirected by
deduplicating (i, j) and (j, i), so a node can end up with degree > k.

Examples
--------
    python event_graph.py --help
    python event_graph.py --demo
    python event_graph.py --demo --nodes 200 --k 8 --alpha 0.5
"""
from __future__ import annotations

import argparse

import numpy as np


def normalize_points(xs, ys, ts, alpha):
    """Min-max normalize x,y,t to [0,1] and scale time by alpha. Returns [N,3]."""
    def _norm(a):
        a = np.asarray(a, dtype=np.float64)
        lo, hi = a.min(), a.max()
        if hi > lo:
            return (a - lo) / (hi - lo)
        return np.zeros_like(a)
    xn = _norm(xs)
    yn = _norm(ys)
    tn = _norm(ts) * float(alpha)
    return np.stack([xn, yn, tn], axis=1)


def knn_edges(points, k):
    """Return a sorted undirected edge list [E,2] from kNN in `points` [N,3].

    Uses a full pairwise distance matrix (fine for the small graphs this skill
    produces). Self is excluded; edges are deduplicated and made undirected.
    """
    N = points.shape[0]
    if N < 2:
        return np.zeros((0, 2), dtype=np.int64)
    k = min(k, N - 1)
    diff = points[:, None, :] - points[None, :, :]
    d2 = np.einsum("ijc,ijc->ij", diff, diff)
    np.fill_diagonal(d2, np.inf)
    nbr = np.argsort(d2, axis=1)[:, :k]          # [N,k] nearest neighbor indices

    edge_set = set()
    for i in range(N):
        for j in nbr[i]:
            a, b = (i, int(j)) if i < j else (int(j), i)
            edge_set.add((a, b))
    if not edge_set:
        return np.zeros((0, 2), dtype=np.int64)
    edges = np.array(sorted(edge_set), dtype=np.int64)
    return edges


def degree_stats(edges, n_nodes):
    """Return (degrees [N], mean, min, max) from an undirected edge list."""
    deg = np.zeros(n_nodes, dtype=np.int64)
    for a, b in edges:
        deg[a] += 1
        deg[b] += 1
    if n_nodes == 0:
        return deg, 0.0, 0, 0
    return deg, float(deg.mean()), int(deg.min()), int(deg.max())


def build_event_graph(xs, ys, ts, k, alpha):
    """Convenience: normalize -> kNN edges -> degree stats."""
    pts = normalize_points(xs, ys, ts, alpha)
    edges = knn_edges(pts, k)
    deg, dmean, dmin, dmax = degree_stats(edges, pts.shape[0])
    return pts, edges, deg, dmean, dmin, dmax


def _demo(args):
    rng = np.random.default_rng(3)
    N = args.nodes
    # fabricate event points: a moving blob over time (structured, not uniform)
    t = np.sort(rng.uniform(0, 10_000, N))          # microseconds
    cx = 20 + 10 * (t / t.max())
    cy = 30 - 8 * (t / t.max())
    xs = cx + rng.normal(0, 3, N)
    ys = cy + rng.normal(0, 3, N)

    pts, edges, deg, dmean, dmin, dmax = build_event_graph(xs, ys, t, args.k, args.alpha)
    print("event points (nodes):", N, " k:", args.k, " temporal scale alpha:", args.alpha)
    print("normalized point matrix [N,3] (x,y,alpha*t) shape:", pts.shape)
    print("node count:", pts.shape[0])
    print("edge count (undirected):", edges.shape[0])
    print(f"degree: mean={dmean:.2f}  min={dmin}  max={dmax}")
    if edges.shape[0]:
        print("first 3 edges (node i -> node j):", [tuple(int(v) for v in e) for e in edges[:3]])
    iso = int((deg == 0).sum())
    print("isolated nodes (degree 0):", iso)


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a synthetic event point set")
    p.add_argument("--nodes", type=int, default=120, help="number of event points (nodes)")
    p.add_argument("--k", type=int, default=6, help="neighbors per node for kNN")
    p.add_argument("--alpha", type=float, default=1.0, help="temporal scale on normalized t")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
