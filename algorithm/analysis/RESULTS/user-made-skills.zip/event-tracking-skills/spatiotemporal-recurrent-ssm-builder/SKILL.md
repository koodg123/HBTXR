---
name: spatiotemporal-recurrent-ssm-builder
description: Build the recurrent, causal-convolutional, and state-space model families used for event-based temporal eye tracking. Use this whenever the architecture involves a (change-based) ConvLSTM, a causal spatiotemporal convolutional network with online buffering, a GRU or bidirectional GRU, a state-space model such as Mamba or a linear time-varying SSM, a 3D convolutional temporal encoder, or a cascade of these for long-term temporal modeling. Trigger on "build a ConvLSTM tracker", "causal temporal CNN for events", "add a bidirectional GRU", "use a Mamba/SSM block", "linear time-varying state space module", "3D conv temporal encoder", or any reproduction whose model is recurrent or state-space, even without exact wording. Assumes the input representation is already produced by the representation builder, and hands its features to an output head.
---

# Spatiotemporal Recurrent / SSM Builder

## Overview

Event eye tracking is fundamentally a sequence problem: the pupil moves continuously and abruptly, and
the most accurate trackers model temporal context explicitly. This skill builds the recurrent and
state-space model families correctly, where the subtle details -- causality, state handling, sequence
length -- decide whether a reproduction matches its reported numbers. It is a P0 IDEA-Gen leaf skill
under `Event Eye-Tracking Reproduction` and produces Worker-sized artifacts, not broad strategy.

## Prompt-First Rule

Start by creating a compact prompt pack (objective, source artifact, target model/hardware/dataset,
assumptions, expected deliverables, verification evidence). If the task is underspecified -- e.g. the
state dimension, hidden size, or sequence length is unknown -- list the missing inputs before making
design choices. Use `templates/prompt-template.md` or `scripts/build_prompt.py`.

## Start Every Task With

1. Restate the target as a measurable objective (e.g. "produce a causal ConvLSTM encoder feeding head X").
2. Identify the parent skill (`paper-reproduction-orchestrator`), upstream artifacts (the event representation), and downstream consumers (the output head).
3. Separate known facts from assumptions about channels, depths, state dims, hidden sizes, and sequence length.
4. Choose the smallest artifact that unblocks the next Worker: a temporal-encoder module plus a one-line config spec.
5. Define the evidence required for signoff before producing the artifact (per-step shapes, causality, state-carry behavior).

## Workflow

1. Read `references/idea-gen-context.md` for cluster rationale and parent-skill fit.
2. Read `references/methods.md` for the model families and `references/pitfalls.md` for failure modes.
3. Build the prompt pack with `templates/prompt-template.md` or `scripts/build_prompt.py`.
4. Use `scripts/convlstm_cell.py` to build/validate the recurrent forward pass and confirm state carry (or adapt it to the chosen family).
5. Produce the temporal-encoder module with explicit inputs, constraints, decisions, and rejected alternatives.
6. Map the artifact to `verification/checklist.md`, then return provenance (source, parent skill, assumptions, artifact, residual risks).

## Core Guidance

Pick the family that matches the paper, copy its block configuration exactly, and pin causality and state.

Families (full detail in `references/methods.md`): **ConvLSTM / change-based ConvLSTM** -- convolutional
recurrent encoder over event representations; the change-based variant delta-encodes the recurrent path
to raise activation sparsity and cut arithmetic (reproduce the delta gating). **Causal spatiotemporal
CNN** -- a stack of causal convolutions (no future leakage) that runs online by buffering layer outputs
(reproduce causal padding + buffering). **GRU / bidirectional GRU** -- lightweight per-step recurrence;
bidirectional implies an offline/windowed setting. **State-space models (Mamba / linear time-varying
SSM)** -- selective/structured state-space blocks for long-range temporal correlation (reproduce state
dimension, selection/time-varying mechanism, and whether the scan is causal). **3D conv temporal
encoder** -- convolution over the (t,h,w) volume for short-term dynamics; often the first cascade stage.
**Cascades** -- spatial encoder then recurrence (GRU) then SSM (Mamba); preserve order and inter-stage
interfaces.

Details that decide reproduction: **causality** (forward-only/online/low-latency vs bidirectional/
windowed/offline -- state which and keep evaluation consistent); **state handling** (how recurrent/SSM
state is initialized and whether carried across windows or reset per sample); **sequence length and
stride** (the temporal window and step in training and inference); **sparsity hooks** (for change-based
and causal variants, the mechanism behind the claimed activation sparsity -- delegate efficiency
accounting to `sparse-event-compute`). Copy channels, depths, state dims, and hidden sizes exactly, and
flag any dimension the paper leaves unstated rather than guessing silently.

## Deliverables

- A temporal-encoder module (ConvLSTM/TCN/GRU/SSM/3D-conv/cascade) with explicit causality, state, and sequence-length settings, returning per-step or pooled features.
- A one-line spec of the chosen family and ALL configuration (channels, depths, state dims, hidden sizes, window/stride).
- Prompt pack and assumption ledger.
- Validation evidence and unresolved-risk list.

## Quality Checks

- The output is narrow enough for a Worker task and concrete enough for an evaluator.
- Claims are tied to measurable metrics or explicitly marked as assumptions.
- Causality, state-carry policy, and sequence length are not silently invented.
- The artifact names parent skill `paper-reproduction-orchestrator` and IDEA-Gen domain `Event Eye-Tracking Reproduction`.
- Bottlenecks, tradeoffs, and missing evidence are visible.

## Escalate When

- The target state dimension, hidden size, sequence length, or causality is missing.
- Multiple plausible block configurations would materially change the result.
- Verification depends on unavailable paper detail or reference activations.
- The task should be split into a new leaf skill (e.g. a dedicated SSM-scan kernel).
