# Prompt Template

Objective:

Source artifacts:

IDEA-Gen phase: P0

Domain: Event Eye-Tracking Reproduction

Parent skill: paper-reproduction-orchestrator

Target model, algorithm, hardware, or dataset:

Model family (ConvLSTM / change-based ConvLSTM / causal TCN / GRU / bidirectional GRU / Mamba-SSM / LTV-SSM / 3D-conv / cascade):

Configuration (channels, depths, state dims, hidden sizes, kernel sizes):

Temporal settings (sequence length, stride, causality online vs bidirectional, state init/carry policy):

Constraints:

Assumptions:

Required artifact:

Verification evidence (per-step shapes, state-carry confirmation, causality check, parity with reference):

Risks and missing inputs:
