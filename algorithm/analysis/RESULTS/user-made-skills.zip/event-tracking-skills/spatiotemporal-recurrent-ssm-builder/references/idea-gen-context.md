# IDEA-Gen Context

Phase: P0
Domain: Event Eye-Tracking Reproduction
Parent skill: `paper-reproduction-orchestrator`

## Why This Skill Exists

Event-based eye tracking is a sequence problem; the accurate trackers model temporal context explicitly.
The orchestrator pulls in this skill after the representation builder, because the recurrent/state-space
encoder consumes a representation of known shape and produces the temporal features an output head needs.

## Worker Capability

Build the recurrent, causal-convolutional, and state-space model families (ConvLSTM, change-based
ConvLSTM, causal TCN, GRU/biGRU, Mamba/LTV-SSM, 3D-conv, cascades) with causality, state handling, and
sequence length pinned to the paper.

## Expected Outputs

- A temporal-encoder module with explicit causality, state, and sequence-length settings.
- A one-line spec of the family and full configuration (channels, depths, state dims, hidden sizes).

## Source Mapping

Use this skill when work is derived from `C:\workspace\AgentOS\IDEA-Gen\idea-analysis`, especially the
cluster and roadmap notes for `Event Eye-Tracking Reproduction` (temporal-model / architecture cluster).
