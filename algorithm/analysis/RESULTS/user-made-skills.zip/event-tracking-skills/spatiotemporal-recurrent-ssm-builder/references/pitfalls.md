# Pitfalls & Parameter-Pinning Checklist

## Parameters to pin every time
- Causality: forward-only/online vs bidirectional/windowed/offline.
- State init and carry policy: zero-init vs learned; reset per sample vs carried across windows.
- Sequence length and stride for training and inference.
- Block configuration: channels, depths, state dims, hidden sizes, kernel sizes (copied from the paper).
- For change-based/causal variants: the delta threshold or buffering scheme behind the sparsity claim.

## Failure modes
- **Silent non-causality** -> a centered 3D kernel, bilinear-in-time input, or full-window SSM scan leaks
  future events while the paper claims online inference. Detect by appending future timesteps and checking
  the output at time `t` is unchanged (append-future invariance).
- **State reset mismatch** -> resetting recurrent/SSM state every sample when the paper carries it across
  windows (or vice versa) changes both accuracy and latency. Pin and state the carry policy explicitly.
- **Bidirectional claimed as online** -> a bidirectional GRU/attention cannot run causally; reporting it as
  low-latency online is wrong. If bidirectional, the setting is offline/windowed.
- **Sequence-length / stride drift** -> training with one window and evaluating with another shifts the
  effective temporal context. Pin both and keep them consistent with the reported metric.
- **Dropped change-based gating** -> reproducing a "ConvLSTM" without the delta gate loses the activation
  sparsity the efficiency numbers depend on. Reproduce the gate and log the sparsity.
- **Guessed unstated dims** -> silently inventing a hidden size or state dimension the paper omits.
  Flag the missing dimension to the orchestrator instead of guessing.
- **Wrong inter-stage interface in cascades** -> feeding the wrong feature shape (pooled vs per-step)
  between spatial encoder, GRU, and SSM. Pin each stage's output shape.

## Detection recipe
For any built encoder, log: per-step output shapes; the cell/state mass over time (confirms state carry);
an append-future invariance result (confirms causality if online is claimed); the recurrent-input
sparsity per step (for change-based variants); and the sequence length/stride actually used. These catch
most reproduction-breaking bugs in temporal models.
