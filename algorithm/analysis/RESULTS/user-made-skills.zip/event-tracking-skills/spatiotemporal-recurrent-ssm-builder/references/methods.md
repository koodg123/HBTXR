# Methods -- Recurrent / State-Space Temporal Encoders

Event eye tracking is a sequence problem: the pupil moves continuously and abruptly, and the accurate
trackers model temporal context explicitly. Pick the family the paper uses, copy its block configuration
exactly, and pin causality and state. Each entry gives the construction, when to use it, and the
parameters that must be pinned.

## ConvLSTM / change-based ConvLSTM
A convolutional recurrent encoder over event representations. Four gates -- input `i`, forget `f`,
output `o`, candidate `g` -- are computed by convolving the stacked `[x_t, h_{t-1}]` feature maps:

    z = conv([x_t, h_{t-1}], W) + b
    i = sigmoid(z_i);  f = sigmoid(z_f);  o = sigmoid(z_o);  g = tanh(z_g)
    c_t = f * c_{t-1} + i * g
    h_t = o * tanh(c_t)

The **change-based** variant delta-encodes the recurrent path: instead of feeding the full hidden map
back each step, it feeds only the change `h_t - h_ref` whose magnitude exceeds a threshold `delta`,
holding sub-threshold components at zero. This raises activation sparsity and cuts arithmetic on
event-sparse inputs. Reproduce the delta gating and the sparsity it depends on.
- Pin: kernel size `K` (1 for 1x1 mixing), hidden/cell channels, delta threshold, state init/carry.

## Causal spatiotemporal CNN
A stack of causal convolutions (left-padded in time so no future leakage) that can run online by
buffering layer outputs. The causal padding plus the buffering scheme is what makes it low-latency.
- Pin: causal-padding scheme, dilation/receptive field, buffer length per layer, online vs windowed.

## GRU / bidirectional GRU
Lightweight recurrence over per-step features. Bidirectional variants use both forward and backward
context; bidirectional use implies an offline or windowed setting (it cannot be online).
- Pin: hidden size, number of layers, direction (uni vs bi), state init/carry policy.

## State-space models (Mamba / linear time-varying SSM)
Selective/structured state-space blocks that capture long-range temporal correlation efficiently with a
linear recurrence. Reproduce the state dimension, the selection / time-varying mechanism (input-dependent
parameters), and whether the scan is causal (online) or full-window (offline).
- Pin: state dimension, selection mechanism, expansion factor, scan causality.

## 3D convolutional temporal encoder
Convolution over the `(t, h, w)` volume for explicit short-term dynamics; often the first stage of a
cascade. Note that a centered temporal kernel is non-causal.
- Pin: temporal kernel size, temporal padding (causal vs centered), channels, stride.

## Cascades
Many trackers chain a spatial encoder, then a recurrence (GRU), then an SSM (Mamba) to extract long-term
dynamics. Preserve the order and the interface (feature shape / pooling) between stages.
- Pin: stage order, per-stage output shapes, where pooling/flattening happens.

## Details that decide reproduction
- **Causality**: forward-only (online, low-latency) vs bidirectional/windowed (offline, higher accuracy).
  State which, and keep evaluation consistent with it.
- **State handling**: how recurrent/SSM state is initialized and whether it is carried across windows or
  reset per sample. Carrying state across windows changes both latency and accuracy.
- **Sequence length and stride**: the temporal window and step used in training and inference.
- **Sparsity hooks**: for change-based and causal variants, the mechanism that produces the claimed
  activation sparsity. Delegate the efficiency accounting to `sparse-event-compute`.

## Choosing quickly
- Convolutional spatial structure + recurrence -> ConvLSTM (change-based for sparsity claims).
- Low-latency streaming -> causal spatiotemporal CNN or causal SSM scan.
- Lightweight per-step features -> GRU (biGRU only if offline).
- Long-range temporal correlation -> Mamba / LTV-SSM.
- Short-term dynamics first stage -> 3D conv, then a cascade into recurrence/SSM.
