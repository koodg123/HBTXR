# Common Mistakes

- Treating `spatiotemporal-recurrent-ssm-builder` as broad brainstorming instead of a Worker-sized leaf skill.
- Inventing channels, hidden sizes, state dims, or sequence length without marking assumptions.
- Producing prose without a concrete temporal-encoder module another Worker or evaluator can use.
- Ignoring the parent skill `paper-reproduction-orchestrator` and duplicating higher-level planning.
- Claiming online/low-latency while building a bidirectional GRU or a centered/full-window scan (non-causal).
- Resetting recurrent/SSM state per sample when the paper carries it across windows (or vice versa).
- Reproducing a "ConvLSTM" without the change-based delta gate, losing the activation sparsity the efficiency numbers depend on.
- Mismatching the inter-stage interface in a cascade (pooled vs per-step features between encoder, GRU, and SSM).
