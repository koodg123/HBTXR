# Good Output

A strong output for `spatiotemporal-recurrent-ssm-builder` includes a concise objective, source mapping,
explicit assumptions, the main artifact, and a validation section.

Expected artifact examples: a temporal-encoder module with explicit causality/state/sequence settings;
a one-line family + full-configuration spec.

## Worked mini-example

**Objective:** temporal encoder for a streaming pupil regressor on 3ET+, online inference.

**Spec (one line):**
`change-based ConvLSTM | K=3 | hidden=32 cell channels | delta-gate=0.02 | causality=causal (forward-only)
| state=carried across windows | seq_len=20 stride=10 | per-step features [32,Hf,Wf]`

**Module sketch:**
```python
states, sparsity = run_sequence(seq, hidden=32, K=3, change_based=True, delta=0.02)
h_T, c_T = states[-1]                       # state carried to the next window
assert h_T.shape == (32, Hf, Wf)
```

**Validation evidence:** per-step h/c shapes `[32,Hf,Wf]`; cell mass grows across time (state carry
confirmed); append-future invariance holds (causal); recurrent-input sparsity per step
`[0.91, 0.88, 0.86, ...]` (delta gate active); seq_len=20 / stride=10 used in both train and eval.

**Residual risks:** paper does not state the hidden channel count -> assumed 32 from the FLOP budget;
flagged for the orchestrator.
