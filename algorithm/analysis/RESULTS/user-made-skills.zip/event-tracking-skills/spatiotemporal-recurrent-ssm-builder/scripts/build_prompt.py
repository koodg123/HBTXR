from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a prompt pack for spatiotemporal-recurrent-ssm-builder.")
    parser.add_argument("--objective", required=True)
    parser.add_argument("--source", default="C:\\workspace\\AgentOS\\IDEA-Gen\\idea-analysis")
    parser.add_argument("--target", default="unspecified")
    parser.add_argument("--family", default="convlstm",
                        help="convlstm|change-convlstm|causal-tcn|gru|bigru|mamba-ssm|ltv-ssm|conv3d|cascade")
    args = parser.parse_args()
    print("Skill: spatiotemporal-recurrent-ssm-builder")
    print("Phase: P0")
    print("Domain: Event Eye-Tracking Reproduction")
    print("Parent skill: paper-reproduction-orchestrator")
    print(f"Objective: {args.objective}")
    print(f"Source: {args.source}")
    print(f"Target: {args.target}")
    print(f"Model family: {args.family}")
    print("Pin: causality (online vs bidirectional), state init/carry, sequence length/stride, channels/depth/state-dim, sparsity hooks.")
    print("Include assumptions, decisions, deliverables, verification evidence, and risks.")


if __name__ == "__main__":
    main()
