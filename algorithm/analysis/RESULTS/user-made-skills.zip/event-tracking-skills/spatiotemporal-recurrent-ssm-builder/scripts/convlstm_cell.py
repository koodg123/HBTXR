#!/usr/bin/env python3
"""Numpy forward pass of a (change-based) ConvLSTM cell over a short sequence.

Implements one ConvLSTM cell with the four standard gates -- input (i),
forget (f), output (o), and candidate cell (g) -- computed by a convolution of
the stacked [input, hidden] feature maps. The convolution is a simple spatial
correlation with a learned kernel (kernel size K, "same" zero padding); set
K=1 for the cheap 1x1 mixing variant. State (cell c and hidden h) is carried
from one timestep to the next, which is the whole point of a recurrent encoder.

Change-based variant
--------------------
The change-based ConvLSTM delta-encodes the recurrent input: instead of feeding
the full hidden map back each step, it feeds only the change h_t - h_{t-1} that
exceeds a threshold (delta gating). Sub-threshold activations are held at zero,
which raises activation sparsity and cuts arithmetic on event-sparse inputs.
The efficiency accounting itself belongs to sparse-event-compute; here we expose
the delta gate and report the resulting sparsity so the mechanism is reproduced.

Gate equations (per timestep t)
-------------------------------
    z = conv([x_t, h_in], W) + b           # h_in is h_{t-1} or its delta-gated form
    i = sigmoid(z_i);  f = sigmoid(z_f)
    o = sigmoid(z_o);  g = tanh(z_g)
    c_t = f * c_{t-1} + i * g
    h_t = o * tanh(c_t)

Examples
--------
    python convlstm_cell.py --help
    python convlstm_cell.py --demo
    python convlstm_cell.py --demo --kernel 1 --hidden 6 --change-based --delta 0.05
"""
from __future__ import annotations

import argparse

import numpy as np


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def conv2d_same(x, w):
    """Spatial correlation of x [Cin,H,W] with w [Cout,Cin,K,K], 'same' zero pad.

    Plain stdlib+numpy reference implementation (no SciPy). Returns [Cout,H,W].
    """
    cin, H, W = x.shape
    cout, cin_w, K, _ = w.shape
    assert cin == cin_w, "input channels must match kernel"
    pad = K // 2
    xp = np.pad(x, ((0, 0), (pad, pad), (pad, pad)), mode="constant")
    out = np.zeros((cout, H, W), dtype=np.float64)
    for oh in range(H):
        for ow in range(W):
            patch = xp[:, oh:oh + K, ow:ow + K]          # [Cin,K,K]
            # correlate with every output filter at once
            out[:, oh, ow] = np.tensordot(w, patch, axes=([1, 2, 3], [0, 1, 2]))
    return out


def make_params(cin, hidden, K, seed=0):
    """Return (W, b): W is [4*hidden, cin+hidden, K, K], b is [4*hidden,1,1]."""
    rng = np.random.default_rng(seed)
    gates = 4 * hidden
    scale = 1.0 / np.sqrt((cin + hidden) * K * K)
    W = rng.normal(0.0, scale, size=(gates, cin + hidden, K, K))
    b = np.zeros((gates, 1, 1), dtype=np.float64)
    return W, b


def convlstm_step(x_t, h_prev, c_prev, W, b, hidden,
                  change_based=False, delta=0.0, h_ref=None):
    """One ConvLSTM timestep. Returns (h_t, c_t, h_used).

    change_based: if True, the recurrent input is the delta-gated change of the
    hidden map relative to h_ref (the last transmitted hidden state). Components
    whose absolute change is below `delta` are zeroed (held), which is what makes
    the recurrent path sparse.
    """
    if change_based:
        if h_ref is None:
            h_ref = np.zeros_like(h_prev)
        change = h_prev - h_ref
        gated = np.where(np.abs(change) >= delta, change, 0.0)
        h_in = gated
    else:
        h_in = h_prev

    stacked = np.concatenate([x_t, h_in], axis=0)        # [cin+hidden, H, W]
    z = conv2d_same(stacked, W) + b                       # [4*hidden, H, W]
    zi, zf, zo, zg = z[0:hidden], z[hidden:2 * hidden], z[2 * hidden:3 * hidden], z[3 * hidden:4 * hidden]
    i = sigmoid(zi)
    f = sigmoid(zf)
    o = sigmoid(zo)
    g = np.tanh(zg)
    c_t = f * c_prev + i * g
    h_t = o * np.tanh(c_t)
    return h_t, c_t, h_in


def run_sequence(seq, hidden, K, change_based=False, delta=0.0, seed=0):
    """Run the cell over seq [T,Cin,H,W]; return list of (h,c) and sparsity log."""
    T, cin, H, W = seq.shape
    W_p, b_p = make_params(cin, hidden, K, seed=seed)
    h = np.zeros((hidden, H, W), dtype=np.float64)
    c = np.zeros((hidden, H, W), dtype=np.float64)
    h_ref = np.zeros_like(h)
    states = []
    sparsity = []
    for t in range(T):
        h, c, h_used = convlstm_step(seq[t], h, c, W_p, b_p, hidden,
                                     change_based=change_based, delta=delta, h_ref=h_ref)
        if change_based:
            # transmit only when change is significant; update reference there
            mask = np.abs(h - h_ref) >= delta
            h_ref = np.where(mask, h, h_ref)
            sparsity.append(float((h_used == 0).mean()))
        states.append((h.copy(), c.copy()))
    return states, sparsity


def _demo(args):
    rng = np.random.default_rng(1)
    T, cin, H, W = 4, 2, 8, 8
    # fabricate a tiny event-like sequence: sparse, mostly zero feature maps
    seq = (rng.random((T, cin, H, W)) > 0.85).astype(np.float64) * rng.normal(1.0, 0.2, (T, cin, H, W))
    states, sparsity = run_sequence(seq, args.hidden, args.kernel,
                                    change_based=args.change_based, delta=args.delta)
    print("input sequence shape [T,Cin,H,W]:", seq.shape)
    print("kernel size K:", args.kernel, " hidden channels:", args.hidden,
          " change_based:", args.change_based, " delta:", args.delta)
    print("--- per-timestep output ---")
    for t, (h, c) in enumerate(states):
        print(f"  t={t}  h shape {h.shape}  c shape {c.shape}  "
              f"mean|h|={abs(h).mean():.4f}  mean|c|={abs(c).mean():.4f}")
    # confirm state carry: h at t differs from a fresh zero state, and c accumulates
    c0_mass = float(np.abs(states[0][1]).sum())
    cT_mass = float(np.abs(states[-1][1]).sum())
    print("state carry confirmed (cell mass grows across time):",
          cT_mass > c0_mass, f"  c[0]_mass={c0_mass:.3f} -> c[T-1]_mass={cT_mass:.3f}")
    if args.change_based:
        print("recurrent-input sparsity per step (fraction zeroed):",
              [round(s, 3) for s in sparsity])


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="run on a synthetic event sequence")
    p.add_argument("--hidden", type=int, default=4, help="hidden/cell channels")
    p.add_argument("--kernel", type=int, default=3, help="conv kernel size (1 = 1x1 mixing)")
    p.add_argument("--change-based", action="store_true", help="enable delta-gated recurrent path")
    p.add_argument("--delta", type=float, default=0.02, help="delta-gate threshold (change-based)")
    args = p.parse_args()
    if args.demo:
        _demo(args)
    else:
        p.print_help()


if __name__ == "__main__":
    main()
