# Verification Checklist

- [ ] Skill phase `P0` and domain `Event Eye-Tracking Reproduction` are stated.
- [ ] Parent skill `paper-reproduction-orchestrator` is referenced.
- [ ] Source IDEA-Gen note or cluster is cited.
- [ ] Assumptions are separated from facts.
- [ ] The temporal-encoder module is present and traceable.
- [ ] A one-line family + full-configuration spec is present.
- [ ] Per-step output shapes are stated and asserted.
- [ ] Causality is declared (online vs bidirectional) and verified (append-future invariance) if online is claimed.
- [ ] State init and carry policy (per-sample reset vs cross-window carry) is stated.
- [ ] Sequence length and stride are pinned and identical for train and eval.
- [ ] Change-based / causal sparsity mechanism is reproduced and logged (if applicable).
- [ ] Residual risks and missing inputs are listed.
